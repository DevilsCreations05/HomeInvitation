﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using SFA.BusinessLayer.BusinessObjects;
using SFA.BusinessLayer.Facade;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.POIFS.FileSystem;
using NPOI.HSSF.Util;
using System.Data;
using SFA.BusinessObjects.Reports;
using SFA.Facade.Reports;
using SFA.BusinessObjects;
using SFA.Facade;
using SFA.DataLayer.DataObjects;

public partial class pages_ExportData : BasePage
{
    protected void Page_PreInit(object sender, System.EventArgs e)
    {
        CurrentModule = Modules.Common;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["report"] != null)
            {
                string ReportFormat = Convert.ToString(Request.QueryString["report"]);

                if (ReportFormat != "")
                {
                    BindExcelReport(ReportFormat);
                }
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
    }

    private void BindExcelReport(string ReportFormat)
    {
        string ReportFormat_New = "", _stFileName_New = "", _stVirtualFileName_New = "";
        string ticks = SessionManager.UserCode + "_" + Guid.NewGuid().ToString().Replace("-", "");
        ReportFormat_New = ReportFormat + "_" + ticks;
        string _stFileName = Server.MapPath("..//Data//");
        string _stVirtualFileName = "..//Data//";
        try
        {
            if (!Directory.Exists(_stFileName))
            {
                Directory.CreateDirectory(_stFileName);
            }
            _stFileName = _stFileName + "ExportToExcel\\";
            _stVirtualFileName = _stVirtualFileName + "ExportToExcel\\";

            if (!Directory.Exists(_stFileName))
            {
                Directory.CreateDirectory(_stFileName);
            }

            else
            {
                _stFileName_New = _stFileName + ReportFormat_New + ".xls";
                _stVirtualFileName_New = _stVirtualFileName + "/" + ReportFormat_New + ".xls";

                _stFileName = _stFileName + ReportFormat + ".xls";
                _stVirtualFileName = _stVirtualFileName + "/" + ReportFormat + ".xls";


            }

            if (File.Exists(_stFileName))
            {
                File.Delete(_stFileName);
            }

            //ViewState["_stFileName_New"] = _stFileName_New;
            //ViewState["_stVirtualFileName_New"] = _stVirtualFileName_New;
            _stFileName = _stFileName_New;
            switch (ReportFormat.Trim())
            {
                case "MerchandisersActivityReport":
                    SalesmansActivityReportExcel(_stFileName);
                    break;
                case "LoadMovementDetails":
                    ExportLoadMovementDetails(_stFileName);
                    break;
                case "LoadMovementDetailsConsolidated":
                    ExportLoadMovementDetailsConsolidated(_stFileName);
                    break;
                case "Area":
                    ExportArea(_stFileName);
                    break;
                case "Movement":
                    ExportMovement(_stFileName);
                    break;
                case "MainUnloadRequest":
                    ExportMainUnloadRequest(_stFileName);
                    break;
                case "ExportMovement_Load":
                    ExportMovement_Load(_stFileName);
                    break;
                case "ExportMovement_LoadConsolidated":
                    ExportMovement_LoadConsolidated(_stFileName);
                    break;
                case "Brand":
                    ExportBrand(_stFileName);
                    break;
                case "Category":
                    ExportCategory(_stFileName);
                    break;
                case "Customers":
                    ExportCustomers(_stFileName);
                    break;
                case "UnAssignedCustomers":
                    ExportUnAssignedCustomers(_stFileName);
                    break;
                case "JourneyPlanCustomers":
                    ExportJourneyPlanCustomers(_stFileName);
                    break;
                case "Order":
                    //ExportOrder(_stFileName);
                    ExporttoExcel("Order");
                    break;
                case "Invoice":
                    ExportInvoice(_stFileName);
                    break;
                case "Payment":
                    ExportPayment(_stFileName);
                    break;
                case "Customer":
                    ExportCustomer(_stFileName);
                    break;
                case "OrdersReportByPreseller":
                    ExportOrdersReportByPreseller(_stFileName);
                    break;
                case "SalesReport":
                    ExportSalesReport(_stFileName);
                    break;
                case "CustomerVisit":
                    ExportCustomerVisit(_stFileName);
                    break;
                case "OrderReport":
                    ExportOrdersReport(_stFileName);
                    break;
                case "ActualVsTarget":
                    ExportActualVsTarget(_stFileName);
                    break;

                case "RouteTripinfo":
                    ExportRouteTripinfo(_stFileName);
                    break;
                case "ManageCollectionReport":
                    ExportManageCollectionReport(_stFileName);
                    break;
                case "skipCustomer":
                    ExportSkipCustomer(_stFileName);
                    break;
                case "SkipCustomerReport":
                    ExportSkipCustomerReport(_stFileName);
                    break;
                case "unplannedorders":
                    ExportUnplannedOrdersReport(_stFileName);
                    break;
                case "petrolusage":
                    ExportPetrolUsageReport(_stFileName);
                    break;
                case "CustomerGeoDeByDeliveryAgent":
                    ExportCustomergeoCodeByDeliveryAgent(_stFileName);
                    break;
                case "salesinvoice":
                    Exportsalesinvoice(_stFileName);
                    break;
                case "OrderDelivery":
                    ExportOrderDelivery(_stFileName);
                    break;
                case "MTDWastageReport":
                    ExportMTDWastageReport(_stFileName);
                    break;
                case "DeliveryReport":
                    ExportDeliveryReport(_stFileName);
                    break;
                case "DeliveryAgentRoutePlan":
                    ExportDeliveryAgentRoutePlan(_stFileName);
                    break;
                case "EOTDetails":
                    ExportEOTDetails(_stFileName);
                    break;
                case "OrderVsRecommended":
                    ExportOrdervsRecommended(_stFileName);
                    break;
                case "VMOrderVsRecommended":
                    ExportVMOrdervsRecommended(_stFileName);
                    break;
                case "DailyDeliveryAgentCommision":
                    ExportIndividualDeliveryAgentCommision(_stFileName);
                    break;
                case "DAMonthlyIncentiveReport":
                    ExportMonthlyDeliveryAgentCommision(_stFileName);
                    break;
                case "HelperMonthlyIncentiveReport":
                    ExportMonthlyHelperCommision(_stFileName);
                    break;
                case "DailyCollection":
                    ExportDailyCollectionSummary(_stFileName);
                    break;
                case "PassCode":
                    ExportCustomerPassCode(_stFileName);
                    break;
                case "Vehicle":
                    ExportVehicle(_stFileName);
                    break;
                case "SalesmanCoinBox":
                    ExportSalesmanCoinBox(_stFileName);
                    break;
                case "VMInvoiceDetail":
                    ExportVMInvoiceDetail(_stFileName);
                    break;
                case "DAOrderModification":
                    ExportDAOrderModification(_stFileName);
                    break;
                case "VMStatus":
                    ExportVMStatus(_stFileName);
                    break;
                case "VMInventory":
                    ExportVMInventory(_stFileName);
                    break;
                case "HHReceipt":
                    ExportHHReceipt(_stFileName);
                    break;
                case "OrderReportwithMUSTHAVE_Preseller":
                    ExportOrderReportwithMUSTHAVE_Preseller(_stFileName);
                    break;
                case "OrderReportwithMUSTHAVE_DeliveryAgent":
                    ExportOrderReportwithMUSTHAVE_DeliveryAgent(_stFileName);
                    break;
                case "VMLoad":
                    ExportLoadSheet(_stFileName);
                    break;
                case "VMDeliveryReport":
                    ExportVMDeliveryReport(_stFileName);
                    break;
                case "VMReceiptSummary":
                    ExportVMReceiptSummary(_stFileName);
                    break;
                case "MaintainBank":
                    ExportMaintainBank(_stFileName);
                    break;
                case "MaintainReason":
                    ExportMaintainReason(_stFileName);
                    break;
                case "MaintainSalesman":
                    ExportMaintainSalesman(_stFileName);
                    break;
                case "MaintainPrice":
                    ExportMaintainPrice(_stFileName);
                    break;
                case "MaintainLocation":
                    ExportMaintainLocation(_stFileName);
                    break;
                case "MaintainItem":
                    ExportMaintainItem(_stFileName);
                    break;
                case "MaintainCustomerGroup":
                    ExportMaintainCustomerGroup(_stFileName);
                    break;
                case "VanStockReport":
                    ExportVanStockReport(_stFileName);
                    break;
                case "vanstockreport":
                    ExportVanStockReport(_stFileName);
                    break;
                case "PendingInvoiceReport":
                    ExportPendingInvoiceReport_New(_stFileName);
                    break;
                case "ReachBySubChannel":
                    ExportReachBySubChannelReport(_stFileName);
                    break;
                case "SurveyReport":
                    ExportSurveyReport(_stFileName);
                    break;
                case "Selling_SKUs":
                    ExportCoreSKus(_stFileName);
                    break;
                case "MustSellingSKUs":
                    ExportStoreGroupSKus(_stFileName);
                    break;
                case "SellingSKUs":
                    ExportSellingSKus(_stFileName);
                    break;
                case "SellingSKUs_Export":
                    ExportSellingSKusData(_stFileName);
                    break;
                case "CustomerItem_Export":
                    ExportCustomerItemData(_stFileName);
                    break;

                case "CustomerStatement":
                    ExportCustomerStatement(_stFileName);
                    break;
                case "CompetitorReport":
                    ExportCompetitorReport(_stFileName);
                    break;
                //case "DailStockStatusByRoutereport":
                //    ExportDailyStockStatusByRoutReport(_stFileName);
                //    break;

                case "PDCDetails":
                    ExportPDCDetailsReport(_stFileName);
                    break;
                case "MaintainMovement":
                    ExportMaintainMovementReport(_stFileName);
                    break;

                case "DailyOrdersReport":
                    ExportDailyOrdersReport(_stFileName);
                    break;
                case "DSRSupervisorReport":
                    ExportDSRSupervisorReport(_stFileName);
                    break;
                case "WeeklyCustomerOrderHistory":
                    ExportWeeklyCustomerOrderHistory(_stFileName);
                    break;
                case "CustomerOrderSummary":
                    ExportSalesReportsByPreseller(_stFileName);
                    break;
                case "BlockedCustomerReport":
                    ExportBlockedCustomerReport(_stFileName);
                    break;
                case "PaymentSummaryDetailsReport":
                    ExportPaymentSummaryDetailsReport(_stFileName);
                    break;

                case "VanSalesCoverageReport":
                    ExportVanSalesCoverageReport(_stFileName);
                    break;
                case "OrderAndDelivery":
                    ExportOrderAndDelivary(_stFileName);
                    break;
                case "MaintainJourney":
                    ExportMaintainJourneyReport(_stFileName);
                    break;
                case "CoverageReport":
                    ExportCoverageReport(_stFileName);
                    break;
                case "FocOrder":
                    ExportFOCReport(_stFileName);
                    break;
                case "StoreCheckReport":
                    ExportStoreCheckReport(_stFileName);
                    break;
                case "newoutlet":
                    ExportNewoutletReport(_stFileName);
                    break;
                case "MarketReportByVan":
                    ExportMarketReportByVan(_stFileName);
                    break;
                case "LogReport":
                    ExportLogReport_New(_stFileName);
                    break;
                case "MarketReportBysku":
                    ExportMarketReportBySKU(_stFileName);
                    break;
                case "AllItems":
                    ExportAllItems(_stFileName);
                    break;
                case "MtdSalesCUSTOMER":
                    ExportAll_Mtdsales(_stFileName);
                    break;

                case "UserPermissionReport":
                    ExportAllUserPermissions(_stFileName);
                    break;
                case "UserDetailsExport":
                    ExportAllUserDetails(_stFileName);
                    break;
                case "RolePermissionReport":
                    ExportAllRolePermission(_stFileName);
                    break;
                case "ARSDataReport":
                    ExportARSDataReport(_stFileName);
                    break;
                case "PssapOutstandingCompReport":
                    ExportPssapOutstandingCompReport(_stFileName);
                    break;
                case "PresalesOrder":
                    ExportPreSalesOrderReport(_stFileName);
                    break;
                case "CashReceiptCreditInvoice":
                    ExportCashReceiptCreditInvoiceReport(_stFileName);
                    break;
                case "VSSAPHHOutstandingCompReport":
                    ExportVSSAPHHOutstandingCompReportReport(_stFileName);
                    break;
                case "WhpestockComarisonReport":
                    ExportWhpestockComarisonReport(_stFileName);
                    break;
                case "VanSalesCashInvoice":
                    ExportVanSalesCashInvoiceReport(_stFileName);
                    break;
                case "VanSalesCreditInvoice":
                    ExportVanSalesCreditInvoiceReport(_stFileName);
                    break;
                case "HHSAPInvoicePreSalesStatusReport":
                    ExportHHSAPInvoicePreSalesStatusReport(_stFileName);
                    break;
                case "HHSAPInvoiceVanSalesStatusReport":
                    ExportHHSAPInvoiceVanSalesStatusReport(_stFileName);
                    break;
                case "SalesOrderItempricingVarianceReport":
                    ExportSalesOrderItempricingVarianceReport(_stFileName);
                    break;
                case "OutstandingInvoiceLineItemComparisionReport":
                    ExportOutstandingInvoiceLineItemComparisionReport(_stFileName);
                    break;
                case "InvoiceLineItemValComparisionReport":
                    ExportInvoiceLineItemValComparisionReport(_stFileName);
                    break;
                case "InvoiceItemPricingConditionComparisionReport":
                    ExportInvoiceItemPricingConditionComparisionReport(_stFileName);
                    break;
                case "HHSAPCashreceiptstatusReport":
                    ExportHHSAPCashreceiptstatusReport(_stFileName);
                    break;
                case "VanSellerSAPHHCreditVarianceReport":
                    ExportVanSellerSAPHHCreditVarianceReport(_stFileName);
                    break;
                case "PreSellerSAPHHCreditValCompReport":
                    ExportPreSellerSAPHHCreditVarianceReport(_stFileName);
                    break;
                case "CashReceiptCashInvoice":
                    ExportCashReceiptCashInvoiceReport(_stFileName);
                    break;
                case "InvoiceHeaderVarianceReport":
                    ExportInvoiceHeaderVarianceReport(_stFileName);
                    break;
                case "SAPPEVanStockComarisionReport":
                    ExportSAPPEVanStockComarisionReport(_stFileName);
                    break;
                case "LoadNoteQuantityComparision":
                    ExportLoadNoteQuantityComparision(_stFileName);
                    break;
                case "UnLoadNoteQuantityComparision":
                    ExportUnLoadNoteQuantityComparision(_stFileName);
                    break;
                case "SAPPEAppStockComparisionReport":
                    ExportSAPAppStockComarisionReport(_stFileName);
                    break;
                case "SalesOrderHeaderValComparisionReport":
                    ExportSalesOrderHeaderValComparisionReport(_stFileName);
                    break;
                case "PromotionArticleReport":
                    ExportPromotionArticleReport(_stFileName);
                    break;
                case "SalesOrderLineItemValComparision":
                    ExportSalesOrderLineItemValComparisionReport(_stFileName);
                    break;
                case "OutstandingInvoiceComparisionReport":
                    ExportOutstandingInvoiceComparisionReport(_stFileName);
                    break;
                case "finalsettlement":
                    ExportFinalSettlementReport(_stFileName);
                    break;
                case "WeeklySalesReturnHistory":
                    ExportWeeklySalesHistoryReport(_stFileName);
                    break;
                case "SKUDispersion":
                    ExportSKUDispersion(_stFileName);
                    break;
                case "WeeklyOrdersHistory":
                    ExportWeeklyOrdersHistory(_stFileName);
                    break;
                case "RolePermissionLog":
                    ExportRolePermissionLog(_stFileName);
                    break;
                case "StockMovement":
                    ExportStockMovementReport(_stFileName);
                    break;
                case "TotalSalesGraphDetailsReport":
                    ExportTotalSalesGraphDetailsReport(_stFileName);
                    break;
                case "NearExpiryItem":
                    ExportNearExpiryItem(_stFileName);
                    break;
                case "ManageAuditReport":
                    ExportManageAuditReport(_stFileName);
                    break;

                case "AdherenceReportJourneyPlan":
                    ExportAdherenceReportJourneyPlan(_stFileName);
                    break;
                case "vanstockfullfillment":
                    ExportHieOrderFulfillmentReport(_stFileName);
                    break;
                case "TargetVsAchievement":
                    ExportActualAndTarget(_stFileName);
                    break;
                case "ActualAndBudget":
                    ExportActualAndBudget(_stFileName);
                    break;
                case "UserLogReport":
                    ExportUserLogReport(_stFileName);
                    break;
                case "ViewUserDeviceLogIn":
                    ExportViewUserDeviceLogIn(_stFileName);
                    break;
                case "CustomerGeoCodeReport":
                    ExportCustomerGeoCodeReport(_stFileName);
                    break;
                case "CustomersWithoutJP":
                    ExportCustomersWithoutJP(_stFileName);
                    break;
                case "JourneyReport":
                    ExportJourneyReport(_stFileName);
                    break;
                case "OutletsCoveredVsOutletsBilled":
                    ExportOutletsCoveredVsOutletsBilledReport(_stFileName);
                    break;
                case "UniqueOutletCoverage":
                    ExportUniqueOutletCoverageReport(_stFileName);
                    break;

                case "SalesmanJourney":
                    ExportSalesmanJourneyReport(_stFileName);
                    break;
                //case "AssetTracking":
                //    ExportAssetTracking(_stFileName);
                //    break;
                case "zerosalesoutletreport":
                    ExportZeroSalesOutletReport(_stFileName);
                    break;
                case "AdherenceReport":
                    ExportAdherenceReport(_stFileName);
                    break;
                case "RevenueDispersion":
                    ExportRevenueDispersion(_stFileName);
                    break;
                case "SurveyAnswerDetail":
                    ExportSurveyDetails(_stFileName);
                    break;
                case "AssetTracking1":
                    ExportAssetTracking(_stFileName, "A.Status=1");
                    break;
                case "AssetTracking2":
                    ExportAssetTracking(_stFileName, "A.Status=2");
                    break;
                case "AssetTracking3":
                    ExportAssetTracking(_stFileName, "A.Status=3");
                    break;
                case "AssetTracking4":
                    ExportAssetTracking(_stFileName, "A.Status=4");
                    break;
                case "AssetTracking0":
                    ExportAssetTracking(_stFileName, "A.Status=0");
                    break;
                case "InitaitiveReport":
                    ExportInitaitiveReport(_stFileName);
                    break;
                case "DeliveryChequeReport":
                    DeliveryCheckReport_Export_Code(_stFileName);
                    break;
                case "DistributionKeyDetail":
                    ExportDistributionKeyDetail(_stFileName);
                    break;
                case "MaintainItemDetails":
                    ExportItemDetails(_stFileName);
                    break;
                case "HybridBackendLoadRequestDetails":
                    ExportHybridBackendLoadRequestDetails(_stFileName);
                    break;
                case "CustomerDetails":
                    ExportCustomerDetails(_stFileName);
                    break;
                case "pricing":
                    ExportPricing(_stFileName);
                    break;
                case "sku_Items":
                    ExportSellingSKusDataGrid(_stFileName);
                    break;
                case "Journeyplan":
                    ExportJourneyPlan(_stFileName);
                    break;
                case "FrozenReport":
                    ExportFrozenReport(_stFileName);
                    break;
                case "CustomerReport":
                    ExportCustomerReport(_stFileName);
                    break;
                case "JourneyplanReport":
                    ExportJourneyPlanReport(_stFileName);
                    break;
                case "JourneyplanCustomers":
                    ExportJourneyPlanRouteCustomers(_stFileName);
                    break;
                case "StoreCheckReportV1":
                    ExportAmbientReport(_stFileName);
                    break;
                case "ShareofShelfReportExport":
                    ShareofShelfReportExportExcel(_stFileName);
                    break;
                case "ExpiryCheckReportExport":
                    ExpiryCheckReportExportExcel(_stFileName);
                    break;
                case "PriceCheckReportExport":
                    PriceCheckReportExportExcel(_stFileName);
                    break;
                case "CompetitorReportV1":
                    ExportCompetitorReportV1(_stFileName);
                    break;
                case "FileGeneration":
                    ExportFileGeneration(_stFileName);
                    break;
                case "ScratchCardUsage":
                    ExportFileScratchCardUsage(_stFileName);
                    break;
                case "ExportItemSubGroupReport":
                    ExportItemSubGroupReport(_stFileName);
                    break;
                case "ItemFrequency_Export":
                    ExportItemFrequencyData(_stFileName);
                    break;

                case "CurrentVanStock":
                    ExportCurrentVanStock(_stFileName);
                    break;
                case "InnerCustomerItem_Export":
                    ExportInnerCustomerItem_Export(_stFileName);
                    break;
                case "AttendanceReport":
                    ExportAttendanceReportExport(_stFileName);
                    break;
                case "TargetReport":
                    ExportTargetReportReportExport(_stFileName);
                    break;
                case "CurrentVanStockReport":
                    ExportCurrentVanStockReport(_stFileName);
                    break;
                case "ItemwiseSalesAndWastageData":
                    ExportFileItemwiseSalesAndWastageData(_stFileName);
                    break;
                case "CustomerItemwiseSalesAndWastageData":
                    ExportFileCustomerItemwiseSalesAndWastageData(_stFileName);
                    break;
                case "ManageSalesOrders":
                    ExportManageSalesOrders(_stFileName);
                    break;
                case "ManagePresellerOrders":
                    ExportManagePresellerOrders(_stFileName);
                    break;
                case "ManageDamageOrders":
                    ExportManageDamageOrders(_stFileName);
                    break;
                case "DailySalesReportMTD":
                    ExportDailySalesReportMTD(_stFileName);
                    break;
                case "CollecionSettlement":
                    ExportCollecionSettlement(_stFileName);
                    break;
                case "NonstampedinvoiceExport":
                    NonstampedinvoiceExport(_stFileName);
                    break;
                case "GatePassGenerationExport":
                    GatePassGenerationExport(_stFileName);
                    break;
                case "DropSizeByCustomerExport":
                    DropSizeByCustomerExport(_stFileName);
                    break;
                case "ActivityLogExport":
                    ActivityLogExport(_stFileName);
                    break;
                case "DropSizeByRouteExport":
                    DropSizeByRouteExport(_stFileName);
                    break;
                case "EnforceLoadRequestExport":
                    EnforceLoadRequestExport(_stFileName);
                    break;
                case "ItemCarryOverStockDuringEOTExport":
                    ItemCarryOverStockDuringEOTExport(_stFileName);
                    break;
                case "RouteActivityReport":
                    ExportRouteActivityReport(_stFileName);
                    break;
                case "WastageExceptionExport":
                    WastageExceptionExportReport(_stFileName);
                    break;
                case "StockMovementExport":
                    StockMovementExportReport(_stFileName);
                    break;
                case "StockMovementMultiRouteExport":
                    StockMovementMultiRouteExport(_stFileName);
                    break;
                case "StockMovementExportMTD":
                    StockMovementExportMTDReport(_stFileName);
                    break;
                case "StockMovementExportMul":
                    StockMovementExportMulReport(_stFileName);
                    break;
                case "StockMovementValueExport":
                    StockMovementValueExportReport(_stFileName);
                    break;
                case "VehicleHistoryExport":
                    VehicleHistoryExportReport(_stFileName);
                    break;
                case "InventoryLocationReport":
                    InventoryLocationReportExport(_stFileName);
                    break;
                case "SalesBackInvoicecharge":
                    SalesBackInvoicechargeExport(_stFileName);
                    break;
                case "NonStampedInvoice":
                    NonStampedInvoiceExport(_stFileName);
                    break;
                case "StampedInvoice":
                    StampedInvoiceExport(_stFileName);
                    break;
                case "RouteWiseLoadRequest":
                    RouteWiseLoadRequestReport(_stFileName);
                    break;
                case "DepotWiseLoadRequest":
                    DepotWiseLoadRequestReport(_stFileName);
                    break;
                case "SFAJDELoadComparison":
                    SFAJDELoadComparisonReportExport(_stFileName);
                    break;
                case "LoadRequestComparison":
                    LoadRequestComparisonReport(_stFileName);
                    break;
                case "DailySalesDetailReport":
                    DailySalesDetailInvoiceReport(_stFileName);
                    break;
                case "MTDSO":
                    MTDSO_Export(_stFileName);
                    break;
                case "WareHouseItemStock":
                    WareHouseItemStockExport(_stFileName);
                    break;
                case "Session_Endorsement":
                    Session_EndorsementExport(_stFileName);
                    break;
                case "NonStampDateForMail":
                    NonStampDateForMailExport(_stFileName);
                    break;
                case "CustomerCategoryClassification":
                    CustomerCategoryClassificationExport(_stFileName);
                    break;
                case "ManageReturnAuditReport":
                    ExportManageReturnAuditReport(_stFileName);
                    break;
                case "MaintainPromotion":
                    ExportMaintainPromotion(_stFileName);
                    break;
                case "MaintainRoute":
                    ExportMaintainRoute(_stFileName);
                    break;
                case "MarketSalesPerformance":
                    ExportMarketSalesPerformance(_stFileName);
                    break;
                case "MonthlySalesStockReport":
                    //ExportMonthlySalesStockReport(_stFileName);
                    break;
                case "TopSKUs":
                    ExportTopSKUs(_stFileName);
                    break;
                case "TopCustomers":
                    ExportTopCustomers(_stFileName);
                    break;
                case "MaintainUserCustomer":
                    ExportMaintainUserCustomer(_stFileName);
                    break;
                case "JourneyPlanExtract":
                    ExportJourneyPlanReportWeek(_stFileName);
                    break;
                case "HolidayRouteCustomerMapping":
                    ExportHolidayRouteCustomerMapping(_stFileName);
                    break;
                case "JourneyplanBulkImport":
                    ExportJourneyplanBulkImport(_stFileName);
                    break;
                case "OrderAdjustment":
                    ExportOrderAdjustment(_stFileName);
                    break;

                case "LoadRequestChangelogReposrt":
                    ExportLoadRequestchnageLogreport(_stFileName);
                    break;
                case "ViewLoaditem":
                    ExportViewLoaditem(_stFileName);
                    break;
                case "LoadTemplateByRouteAndDay":
                    ExportLoadTemplateByRouteAndDay(_stFileName);
                    break;
                case "UnplannedCustomers":
                    ExportUnplannedCustomers(_stFileName);
                    break;
                case "PendingforstampedInvoices":
                    ExportPendingforstampedInvoices(_stFileName);
                    break;


            }

        }
        finally
        {

        }
        ExportFile(_stVirtualFileName_New, ReportFormat_New);
    }

    private void ExportMaintainUserCustomer(string strFileName)
    {

        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        String SearchString = Convert.ToString(Session["SearchString"]);
        SearchString = SearchString != "" ? SearchString : "1=1";

        IList<User> lstDist = new BlaseUserFacade().GetUserCustomerSearchExport("Code DESC", 500000, 0, SearchString, SessionManager.UserCode);
        if (lstDist != null && lstDist.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL_no" + "\t" + "Region code" + "\t" + "Region Name" + "\t" + "Routecode" + "\t" + "RouteName" + "\t" + "Customer code" + "\t" + "Customer Name" + "\n");
            int i = 1;
            foreach (User obj in lstDist)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obj.RegionCode + "\t");
                strFileContents.Append(obj.Region + "\t");
                strFileContents.Append(obj.Code + "\t");
                strFileContents.Append(obj.Description + "\t");
                strFileContents.Append(obj.CustomerCode + "\t");
                strFileContents.Append(obj.CustomerName + "\t");

                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }

    }

    //Vamshi 
    private void ExportLoadMovementDetails(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;
        FilterValue = (Session["MovementCodeDetails"] != null) ? Session["MovementCodeDetails"].ToString() : "1=1";
        IList<MovementDetail> objMovementDetail = new MovementDetailFacade().GetMovementDetailSearch("CAST([LineNo] AS INT) ASC", 10000000, 0, FilterValue, "");
        if (objMovementDetail != null && objMovementDetail.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SNo" + "\t" + "ItemCode" + "\t" + "ItemDescription" + "\t" + "UOM" + "\t" + "Supervisor App Qty" + "\t" + "Receiving Quantity" + "\t" + "Item Cost" + "\t" + "Extended Cost");
            strFileContents.Append("\n");
            int i = 1;
            foreach (MovementDetail obMovementDetail in objMovementDetail)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obMovementDetail.ItemCode + "\t");
                strFileContents.Append(obMovementDetail.ItemDescription + "\t");
                strFileContents.Append(obMovementDetail.UOM + "\t");
                strFileContents.Append(obMovementDetail.QuantityBU + "\t");
                strFileContents.Append(obMovementDetail.LogisticsQunatityLevel1 + "\t");
                strFileContents.Append(obMovementDetail.PriceLevel1 + "\t");
                strFileContents.Append(obMovementDetail.PriceLevel2 + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    //lokesh
    private void ExportLoadMovementDetailsConsolidated(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;
        FilterValue = (Session["MovementCodeDetails"] != null) ? Session["MovementCodeDetails"].ToString() : "1=1";
        string OrderNumber = (Session["hdnOrderCode"] != null) ? Session["hdnOrderCode"].ToString() : "1=1";
        IList<MovementDetail> objMovementDetail = new MovementDetailFacade().GetMovementDetailConsolidatedSearch("CAST([LineNo] AS INT) ASC", 10000000, 0, FilterValue, OrderNumber);
        if (objMovementDetail != null && objMovementDetail.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("S.No" + "\t" + "ItemCode" + "\t" + "ItemDescription" + "\t" + "UOM" + "\t" + "Approved Qty");
            strFileContents.Append("\n");
            int i = 1;
            foreach (MovementDetail obMovementDetail in objMovementDetail)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obMovementDetail.ItemCode + "\t");
                strFileContents.Append(obMovementDetail.ItemDescription + "\t");
                strFileContents.Append(obMovementDetail.UOM + "\t");
                strFileContents.Append(obMovementDetail.QuantityBU + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    private void ExportArea(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;
        FilterValue = (Session["AreaFilter"] != null) ? Session["AreaFilter"].ToString() : "1=1";
        IList<Area> objArea = new AreaFacade().GetAreaSearchforExport(FilterValue);
        if (objArea != null && objArea.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL_no" + "\t" + "AREAID" + "\t" + "LOCATIONID" + "\t" + "AREANAME");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Area obArea in objArea)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obArea.AREAID + "\t");
                strFileContents.Append(obArea.LOCATIONID + "\t");
                strFileContents.Append(obArea.AREANAME + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }



    private void ExportDistributionKeyDetail(string strFileName)
    {

        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        String SearchString = Convert.ToString(Session["DistributionKeyDetailSearchString"]);
        SearchString = SearchString != "" ? SearchString : "1=1";
        string DistributionKey = Session["DistributionKey"].ToString();

        IList<DistriButionKeyDetail> lstDist = new ClientFacade().GetDistriButionKey("DistributionKey DESC", 500000, 0, SearchString, DistributionKey);
        if (lstDist != null && lstDist.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL_no" + "\t" + "Item" + "\t" + "Value");
            strFileContents.Append("\n");
            int i = 1;
            foreach (DistriButionKeyDetail objDist in lstDist)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(objDist.ItemCode + "\t");
                strFileContents.Append(objDist.Value + "\t");

                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }

    }



    private void ExportMovement(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string MovementCode = string.Empty;
        if (Request.QueryString["MC"] != null)
        {
            MovementCode = CommonFunctions.getStringValue(Request.QueryString["MC"]);
        }
        MovementHeader objMovementHeader = new MovementHeaderFacade().GetMovementHeaderByCode(MovementCode);
        if (objMovementHeader != null)
        {
            string _MovementStatus = "";
            if (objMovementHeader.MovementStatus == 100)
            {
                _MovementStatus = "Shipped";
                if (objMovementHeader.MovementType == 3)
                {
                    if (objMovementHeader.SAPContractNumber == "")
                    {
                        _MovementStatus = objMovementHeader.SAPContractNumber == "" ? "Not Confirmed" : "Confirmed";
                    }
                    else
                    {
                        _MovementStatus = objMovementHeader.SAPContractNumber == "" ? "Not Confirmed" : "Confirmed";
                    }
                }
            }
            else if (objMovementHeader.MovementStatus == 150)
            {
                _MovementStatus = "Processed";
            }
            else if (objMovementHeader.MovementStatus == 99)
            {
                _MovementStatus = "Processed";
                if (objMovementHeader.MovementType == 3)
                {
                    _MovementStatus = "Approved";
                }
            }
            else if (objMovementHeader.MovementStatus == 2)
            {
                _MovementStatus = "Pending";
            }
            else if (objMovementHeader.MovementStatus == -13)
            {
                _MovementStatus = "Rejected";
            }
            strFileContents = new StringBuilder();
            strFileContents.Append("Movement Code" + "\t" + objMovementHeader.MovementCode + "\t" + "Movement Type" + "\t" + (objMovementHeader.MovementType == 1 ? "Load" : objMovementHeader.MovementType == 3 ? "Return Unload" : "Unload"));
            strFileContents.Append("\n");
            strFileContents.Append("Salesman" + "\t" + ("[" + objMovementHeader.UserCode + "] " + objMovementHeader.User.USERNAME) + "\t" + "Movement Status" + "\t" + _MovementStatus);
            strFileContents.Append("\n");
            strFileContents.Append("Requested Date" + "\t" + objMovementHeader.MovementDate.ToString("MMM dd, yyyy hh:mm tt") + "\t");
            strFileContents.Append("\n");
            if (objMovementHeader.MovementStatus != 2 && objMovementHeader.MovementStatus != -13)
            {
                strFileContents.Append("Processed Date" + "\t" + objMovementHeader.ApprovedDate.ToString("MMM dd, yyyy hh:mm tt") + "\t" + "Processed By" + "\t" + objMovementHeader.ApproveByCode);
                strFileContents.Append("\n");
            }
            IList<MovementDetail> MovementDetails = new MovementDetailFacade().GetMovementDetailSearch("CAST([LineNo] AS INT) ASC", 500000, 0, " MH.MovementCode='" + MovementCode + "' ", "");
            strFileContents.Append("Item Code" + "\t" + "Description" + "\t" + "UOM" + "\t" + "WH Qty" + "\t" + "Requested Qty" + "\t" + "Processed Qty" + "\t" + "Shipped Qty");
            strFileContents.Append("\n");
            double InprocessQTY = 0;
            foreach (MovementDetail objMovementDetail in MovementDetails)
            {
                if (objMovementDetail.MovementStatus == 2 || objMovementDetail.MovementStatus == 0)
                {
                    if (objMovementHeader.MovementType != 1)
                    {
                        InprocessQTY = CommonFunctions.getDoubleValue(objMovementDetail.MovementStatus);
                    }
                    else
                    {
                        InprocessQTY = Math.Min(CommonFunctions.getDoubleValue(objMovementDetail.QuantityLevel1), CommonFunctions.getDoubleValue(objMovementDetail.WHQuantity));
                    }
                }
                else
                {
                    InprocessQTY = CommonFunctions.getDoubleValue(objMovementDetail.InProcessQuantity);
                }

                strFileContents.Append(objMovementDetail.ItemCode + "\t");
                strFileContents.Append(objMovementDetail.ItemDescription + "\t");
                strFileContents.Append(objMovementDetail.UOM + "\t");
                strFileContents.Append(objMovementDetail.WHQuantity + "\t");
                strFileContents.Append(objMovementDetail.QuantityLevel1 + "\t");
                strFileContents.Append(InprocessQTY.ToString() + "\t");
                strFileContents.Append((_MovementStatus == "Shipped" ? objMovementDetail.ShippedQuantity.ToString() : "0") + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }


    private void ExportMovement_Load(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string MovementCode = string.Empty;
        if (Request.QueryString["MC"] != null)
        {
            MovementCode = CommonFunctions.getStringValue(Request.QueryString["MC"]);
        }
        MovementHeader objMovementHeader = new MovementHeaderFacade().GetMovementHeaderByCode(MovementCode);
        if (objMovementHeader != null)
        {
            string _MovementStatus = "";
            if (objMovementHeader.MovementStatus == 100)
            {
                _MovementStatus = "Shipped";
                if (objMovementHeader.MovementType == 3)
                {
                    if (objMovementHeader.SAPContractNumber == "")
                    {
                        _MovementStatus = objMovementHeader.SAPContractNumber == "" ? "Not Confirmed" : "Confirmed";
                    }
                    else
                    {
                        _MovementStatus = objMovementHeader.SAPContractNumber == "" ? "Not Confirmed" : "Confirmed";
                    }
                }
            }
            else if (objMovementHeader.MovementStatus == 150)
            {
                _MovementStatus = "Processed";
            }
            else if (objMovementHeader.MovementStatus == 99)
            {
                _MovementStatus = "Processed";
                if (objMovementHeader.MovementType == 3)
                {
                    _MovementStatus = "Approved";
                }
            }
            else if (objMovementHeader.MovementStatus == 2)
            {
                _MovementStatus = "Pending";
            }
            else if (objMovementHeader.MovementStatus == -13)
            {
                _MovementStatus = "Rejected";
            }
            strFileContents = new StringBuilder();
            strFileContents.Append("Movement Code" + "\t" + objMovementHeader.MovementCode + "\t" + "Movement Type" + "\t" + (objMovementHeader.MovementType == 1 ? "Load" : objMovementHeader.MovementType == 3 ? "Return Unload" : "Unload"));
            strFileContents.Append("\n");
            strFileContents.Append("Salesman" + "\t" + ("[" + objMovementHeader.UserCode + "] " + objMovementHeader.User.USERNAME) + "\t" + "Movement Status" + "\t" + _MovementStatus);
            strFileContents.Append("\n");
            strFileContents.Append("Requested Date" + "\t" + objMovementHeader.MovementDate.ToString("MMM dd, yyyy hh:mm tt") + "\t");
            strFileContents.Append("\n");
            if (objMovementHeader.MovementStatus != 2 && objMovementHeader.MovementStatus != -13)
            {
                strFileContents.Append("Processed Date" + "\t" + objMovementHeader.ApprovedDate.ToString("MMM dd, yyyy hh:mm tt") + "\t" + "Processed By" + "\t" + objMovementHeader.ApproveByCode);
                strFileContents.Append("\n");
            }
            IList<MovementDetail> MovementDetails = new MovementDetailFacade().GetMovementDetailSearch("CAST([LineNo] AS INT) ASC", 500000, 0, " MH.MovementCode='" + MovementCode + "' ", "");
            strFileContents.Append("Item Code" + "\t" + "Description" + "\t" + "UOM" + "\t" + "WH Qty" + "\t" + "Requested Qty" + "\t" + "Processed Qty");
            strFileContents.Append("\n");
            double InprocessQTY = 0;
            foreach (MovementDetail objMovementDetail in MovementDetails)
            {
                if (objMovementDetail.MovementStatus == 2 || objMovementDetail.MovementStatus == 0)
                {
                    if (objMovementHeader.MovementType != 1)
                    {
                        InprocessQTY = CommonFunctions.getDoubleValue(objMovementDetail.MovementStatus);
                    }
                    else
                    {
                        InprocessQTY = Math.Min(CommonFunctions.getDoubleValue(objMovementDetail.QuantityLevel1), CommonFunctions.getDoubleValue(objMovementDetail.WHQuantity));
                    }
                }
                else
                {
                    InprocessQTY = CommonFunctions.getDoubleValue(objMovementDetail.InProcessQuantity);
                }

                strFileContents.Append(objMovementDetail.ItemCode + "\t");
                strFileContents.Append(objMovementDetail.ItemDescription + "\t");
                strFileContents.Append(objMovementDetail.UOM + "\t");
                strFileContents.Append(objMovementDetail.WHQuantity + "\t");
                strFileContents.Append(objMovementDetail.QuantityLevel1 + "\t");
                strFileContents.Append(InprocessQTY.ToString() + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    private void ExportMovement_LoadConsolidated(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string MovementCode = string.Empty;
        if (Request.QueryString["MC"] != null)
        {
            MovementCode = CommonFunctions.getStringValue(Request.QueryString["MC"]);
        }
        MovementHeader objMovementHeader = new MovementHeaderFacade().GetMovementHeaderConsoignmentByCode(MovementCode);
        if (objMovementHeader != null)
        {
            string _MovementStatus = "";
            if (objMovementHeader.MovementStatus == 100)
            {
                _MovementStatus = "Shipped";
                if (objMovementHeader.MovementType == 3)
                {
                    if (objMovementHeader.SAPContractNumber == "")
                    {
                        _MovementStatus = objMovementHeader.SAPContractNumber == "" ? "Not Confirmed" : "Confirmed";
                    }
                    else
                    {
                        _MovementStatus = objMovementHeader.SAPContractNumber == "" ? "Not Confirmed" : "Confirmed";
                    }
                }
            }
            else if (objMovementHeader.MovementStatus == 150)
            {
                _MovementStatus = "Processed";
            }
            else if (objMovementHeader.MovementStatus == 99)
            {
                _MovementStatus = "Processed";
                if (objMovementHeader.MovementType == 3)
                {
                    _MovementStatus = "Approved";
                }
            }
            else if (objMovementHeader.MovementStatus == 2)
            {
                _MovementStatus = "Pending";
            }
            else if (objMovementHeader.MovementStatus == -13)
            {
                _MovementStatus = "Rejected";
            }
            strFileContents = new StringBuilder();
            strFileContents.Append("Movement Code" + "\t" + objMovementHeader.MovementCode + "\t" + "Movement Type" + "\t" + (objMovementHeader.MovementType == 1 ? "Load" : objMovementHeader.MovementType == 3 ? "Return Unload" : "Unload"));
            strFileContents.Append("\n");
            strFileContents.Append("Salesman" + "\t" + ("[" + objMovementHeader.UserCode + "] " + objMovementHeader.User.USERNAME) + "\t" + "Movement Status" + "\t" + _MovementStatus);
            strFileContents.Append("\n");
            strFileContents.Append("Requested Date" + "\t" + objMovementHeader.MovementDate.ToString("MMM dd, yyyy hh:mm tt") + "\t");
            strFileContents.Append("\n");
            if (objMovementHeader.MovementStatus != 2 && objMovementHeader.MovementStatus != -13)
            {
                strFileContents.Append("Processed Date" + "\t" + objMovementHeader.ApprovedDate.ToString("MMM dd, yyyy hh:mm tt") + "\t" + "Processed By" + "\t" + objMovementHeader.ApproveByCode);
                strFileContents.Append("\n");
            }
            IList<MovementDetail> MovementDetails = new MovementDetailFacade().GetMovementDetailSearch("CAST([LineNo] AS INT) ASC", 500000, 0, " MH.MovementCode='" + MovementCode + "' ", "");
            strFileContents.Append("Item Code" + "\t" + "Description" + "\t" + "UOM" + "\t" + "WH Qty" + "\t" + "Requested Qty" + "\t" + "Processed Qty");
            strFileContents.Append("\n");
            double InprocessQTY = 0;
            foreach (MovementDetail objMovementDetail in MovementDetails)
            {
                if (objMovementDetail.MovementStatus == 2 || objMovementDetail.MovementStatus == 0)
                {
                    if (objMovementHeader.MovementType != 1)
                    {
                        InprocessQTY = CommonFunctions.getDoubleValue(objMovementDetail.MovementStatus);
                    }
                    else
                    {
                        InprocessQTY = Math.Min(CommonFunctions.getDoubleValue(objMovementDetail.QuantityLevel1), CommonFunctions.getDoubleValue(objMovementDetail.WHQuantity));
                    }
                }
                else
                {
                    InprocessQTY = CommonFunctions.getDoubleValue(objMovementDetail.InProcessQuantity);
                }

                strFileContents.Append(objMovementDetail.ItemCode + "\t");
                strFileContents.Append(objMovementDetail.ItemDescription + "\t");
                strFileContents.Append(objMovementDetail.UOM + "\t");
                strFileContents.Append(objMovementDetail.WHQuantity + "\t");
                strFileContents.Append(objMovementDetail.QuantityLevel1 + "\t");
                strFileContents.Append(InprocessQTY.ToString() + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportPendingInvoiceReportold(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;

            string SearchString = string.Empty;
            SearchString = (Session["PendingInvoiceReport"] != null) ? Session["PendingInvoiceReport"].ToString() : "1=1";

            IList<PendingInvoices> objPendingInvoiceList = new PendingInvoicesFacade().GetPendingInvoiceListExport("C.Description ASC", SearchString);
            if (objPendingInvoiceList != null && objPendingInvoiceList.Count > 0)
            {
                strFileContents = new StringBuilder();

                strFileContents.Append("PendingInvoiceId" + "\t" + "Client" + "\t" + "ClientCode" + "\t" + "TrxCode" + "\t" + "TrxType" + "\t" + "TrxDate" + "\t" + "OriginalAmount" + "\t" + "BalanceAmount"
                    + "\t" + "JDEReference");
                strFileContents.Append("\n");
                foreach (PendingInvoices objPendingInvoice in objPendingInvoiceList)
                {
                    strFileContents.Append(objPendingInvoice.PendingInvoiceId + "\t");
                    strFileContents.Append(objPendingInvoice.Client + "\t");
                    strFileContents.Append(objPendingInvoice.ClientCode + "\t");
                    strFileContents.Append(objPendingInvoice.TrxCode + "\t");
                    strFileContents.Append(objPendingInvoice.TrxType + "\t");
                    strFileContents.Append(objPendingInvoice.TrxDate + "\t");
                    strFileContents.Append(objPendingInvoice.OriginalAmount + "\t");
                    strFileContents.Append(objPendingInvoice.BalanceAmount + "\t");
                    strFileContents.Append(objPendingInvoice.JDEReference + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportBrand(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;
        FilterValue = (Session["BrandFilter"] != null) ? Session["BrandFilter"].ToString() : "1=1";
        IList<Brand> objBrand = new BrandFacade().GetBrandSearchforExport(FilterValue);
        if (objBrand != null && objBrand.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL_no" + "\t" + "CODE" + "\t" + "NAME");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Brand obBrand in objBrand)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obBrand.Code + "\t");
                strFileContents.Append(obBrand.Name + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportRolePermissionLog(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;
        FilterValue = (Session["RolePermissionLogSearchString"] != null) ? Session["RolePermissionLogSearchString"].ToString() : "1=1";
        if (FilterValue == "")
        {
            FilterValue = "1=1";
        }
        IList<RolePermissionLog> RolePermissionLog = new RolePermissionLogFacade().GetRolePermissionLogSearch("UL.ModifiedDate DESC", FilterValue, SessionManager.UserCode, 500000, 0);
        if (RolePermissionLog != null && RolePermissionLog.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Role Name" + "\t" + "Permission" + "\t" + "SubModule Name" + "\t" + "Module Name" + "\t" + "Modified Date" + "\t" + "Modified By" + "\t" + "Action");
            strFileContents.Append("\n");
            foreach (RolePermissionLog objRolePermissionLog in RolePermissionLog)
            {
                strFileContents.Append("[" + objRolePermissionLog.RoleCode + "] " + objRolePermissionLog.RoleName + "\t");
                strFileContents.Append(objRolePermissionLog.Permission.ToString().Replace("\r\n", "") + "\t");
                strFileContents.Append(objRolePermissionLog.SubModuleName + "\t");
                strFileContents.Append(objRolePermissionLog.ModuleName + "\t");
                strFileContents.Append(objRolePermissionLog.ModifiedDate + "\t");
                strFileContents.Append(objRolePermissionLog.ModifiedBy + "\t");
                strFileContents.Append(objRolePermissionLog.Action + "\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportCategory(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;
        FilterValue = (Session["CategoryFilter"] != null) ? Session["CategoryFilter"].ToString() : "1=1";
        IList<Category> objCategory = new CategoryFacade().GetCategorySearchforExport(FilterValue);
        if (objCategory != null && objCategory.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL_no" + "\t" + "CODE" + "\t" + "NAME" + "\t" + "Icon");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Category obCategory in objCategory)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obCategory.Code + "\t");
                strFileContents.Append(obCategory.Name + "\t");
                strFileContents.Append(obCategory.Icon + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportCustomers(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string searchString = string.Empty;
        searchString = (Session["CustomersFilter"] != null) ? Session["CustomersFilter"].ToString() : "1=1";
        IList<Customer> objCustomer = new CustomerFacade().GetCustomerExport(searchString);
        if (objCustomer != null && objCustomer.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Site Id" + "\t" + "Site Name" + "\t" + "Customer Id" + "\t" + "Customer Status" + "\t" + "Customer Account Creation Date" + "\t" + "Trade Channel" + "\t" + "Salesman");
            strFileContents.Append("\t" + "Party Name" + "\t" + "Channel" + "\t" + "SubChannel" + "\t" + "Region Code" + "\t" + "Region Description" + "\t" + "Country Code" + "\t" + "Country Description");
            strFileContents.Append("\t" + "Route Code" + "\t" + "Route Description" + "\t" + "Customer Category" + "\t" + "Customer Site Status" + "\t" + "Customer Site Creation Date" + "\t" + "Site Status" + "\t" + "Address1");
            strFileContents.Append("\t" + "Address2" + "\t" + "Address3" + "\t" + "Address4" + "\t" + "PO Box Number" + "\t" + "City" + "\t" + "Payment Type" + "\t" + "Payment Code");
            strFileContents.Append("\t" + "Payment Description" + "\t" + "Credit Limit" + "\t" + "Latitude" + "\t" + "Longitude" + "\t" + "Shop Open Time" + "\t" + "Shop Close Time" + "\t" + "Delivery Start1");
            strFileContents.Append("\t" + "Delivery Stop1" + "\t" + "Delivery Start2" + "\t" + "Delivery Stop2" + "\t" + "Delivery Priority" + "\t" + "Service Pattern" + "\t" + "Customer Visits" + "\t" + "Email");
            strFileContents.Append("\t" + "Contact Person Name" + "\t" + "Contact Person Mobile No");
            strFileContents.Append("\n");
            foreach (Customer obCustomer in objCustomer)
            {
                strFileContents.Append(obCustomer.SITE + "\t");
                strFileContents.Append(obCustomer.SITE_NAME + "\t");
                strFileContents.Append(obCustomer.CUSTOMERID + "\t");
                strFileContents.Append(obCustomer.CUSTOMER_STATUS + "\t");
                strFileContents.Append(obCustomer.CUST_ACCT_CREATION_DATE.ToString("MMM d, yyyy") + "\t");
                strFileContents.Append(obCustomer.TRADE_CHANNEL + "\t");
                strFileContents.Append(obCustomer.SALESMAN + "\t");
                strFileContents.Append(obCustomer.PARTY_NAME + "\t");
                strFileContents.Append(obCustomer.CHANNEL + "\t");
                strFileContents.Append(obCustomer.SUBCHANNEL + "\t");
                strFileContents.Append(obCustomer.REGION_CODE + "\t");
                strFileContents.Append(obCustomer.REGION_DESCRIPTION + "\t");
                strFileContents.Append(obCustomer.COUNTRY_CODE + "\t");
                strFileContents.Append(obCustomer.COUNTRY_DESCRIPTION + "\t");
                strFileContents.Append(obCustomer.ROUTE_CODE + "\t");
                strFileContents.Append(obCustomer.ROUTE_DESCRIPTION + "\t");
                strFileContents.Append(obCustomer.CUSTCATEGORY + "\t");
                strFileContents.Append(obCustomer.CUST_SITE_STATUS + "\t");
                strFileContents.Append(obCustomer.CUST_SITE_CREATION_DATE.ToString("MMM d, yyyy") + "\t");
                strFileContents.Append(obCustomer.SITE_USE_STATUS + "\t");
                strFileContents.Append(obCustomer.ADDRESS1 + "\t");
                strFileContents.Append(obCustomer.ADDRESS2 + "\t");
                strFileContents.Append(obCustomer.ADDRESS3 + "\t");
                strFileContents.Append(obCustomer.ADDRESS4 + "\t");
                strFileContents.Append(obCustomer.PO_BOX_NUMBER + "\t");
                strFileContents.Append(obCustomer.CITY + "\t");
                strFileContents.Append(obCustomer.PAYMENT_TYPE + "\t");
                strFileContents.Append(obCustomer.PAYMENT_TERM_CODE + "\t");
                strFileContents.Append(obCustomer.PAYMENT_TERM_DESCRIPTION + "\t");
                strFileContents.Append(obCustomer.CREDIT_LIMIT + "\t");
                strFileContents.Append(obCustomer.GEO_CODE_X + "\t");
                strFileContents.Append(obCustomer.GEO_CODE_Y + "\t");
                strFileContents.Append(obCustomer.SHOP_OPEN_TIME + "\t");
                strFileContents.Append(obCustomer.SHOP_CLOSE_TIME + "\t");
                strFileContents.Append(obCustomer.DELIVERY_TW_START1 + "\t");
                strFileContents.Append(obCustomer.DELIVERY_TW_STOP1 + "\t");
                strFileContents.Append(obCustomer.DELIVERY_TW_START2 + "\t");
                strFileContents.Append(obCustomer.DELIVERY_TW_STOP2 + "\t");
                strFileContents.Append(obCustomer.DELIVERY_TW_PRIORITY_LEVEL + "\t");
                strFileContents.Append(obCustomer.SERVICE_PATTERN_SET + "\t");
                strFileContents.Append(obCustomer.CUSTOMER_VISITS + "\t");
                strFileContents.Append(obCustomer.EMAIL + "\t");
                strFileContents.Append(obCustomer.CONTACTPERSONNAME + "\t");
                strFileContents.Append(obCustomer.CONTACTPERSONMOBILENO + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportUnAssignedCustomers(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string searchString = string.Empty;
        searchString = (Session["UnAssignedCustomersFilter"] != null) ? Session["UnAssignedCustomersFilter"].ToString() : "1=1";
        IList<Customer> objCustomer = new CustomerFacade().GetUnAssignedCustomerExport(searchString);
        if (objCustomer != null && objCustomer.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Customer Name" + "\t" + "Customer Code" + "\t" + "Sales Organization" + "\t" + "Region" + "\t" + "Country" + "\t" + "Channel");
            strFileContents.Append("\n");

            foreach (Customer obCustomer in objCustomer)
            {
                strFileContents.Append(obCustomer.SiteName + "\t");
                strFileContents.Append(obCustomer.Site + "\t");
                strFileContents.Append(obCustomer.SalesOrganization + "\t");
                strFileContents.Append(obCustomer.RegionName + "\t");
                strFileContents.Append(obCustomer.CountryName + "\t");
                strFileContents.Append(obCustomer.ChannelName + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportJourneyPlanCustomers(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string searchString = string.Empty;
        string UserCode = string.Empty;
        string SalesOrgCode = string.Empty;
        searchString = (Session["UnAssignedCustomersInJPFilters"] != null) ? Session["UnAssignedCustomersInJPFilters"].ToString() : "1=1";
        UserCode = (Session["UnAssignedCustomersInJPUserCode"] != null) ? Session["UnAssignedCustomersInJPUserCode"].ToString() : SessionManager.UserCode;
        SalesOrgCode = (Session["UnAssignedCustomersInJPSalesOrgCode"] != null) ? Session["UnAssignedCustomersInJPSalesOrgCode"].ToString() : "";


        IList<Customer> objCustomer = new CustomerFacade().GetCustomerUnAssignedInJPSearch("Code  DESC", 500000, 0, searchString, UserCode, SalesOrgCode);
        if (objCustomer != null && objCustomer.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Customer" + "\t" + "Region" + "\t" + "Country" + "\t" + "JourneyCount");
            strFileContents.Append("\n");

            foreach (Customer obCustomer in objCustomer)
            {
                strFileContents.Append("[" + obCustomer.Site + "] " + obCustomer.SiteName + "\t");
                strFileContents.Append(obCustomer.RegionName + "\t");
                strFileContents.Append(obCustomer.CountryName + "\t");
                strFileContents.Append(obCustomer.SubChannelName + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportSKUDispersion(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        string SearchString = "1=1";
        string cSalesOrg = Session["UCCommonFilter_SalesOrganization"] != null ? Session["UCCommonFilter_SalesOrganization"].ToString() : "";
        string cRegions = Session["UCCommonFilter_BillingStart"] != null ? Session["UCCommonFilter_BillingStart"].ToString() : ""; ;
        string cASMs = Session["UCCommonFilter_BillingStart"] != null ? Session["UCCommonFilter_BillingStart"].ToString() : ""; ;
        string cSupervisors = Session["UCCommonFilter_BillingStart"] != null ? Session["UCCommonFilter_BillingStart"].ToString() : ""; ;
        string cRoutes = Session["UCCommonFilter_BillingStart"] != null ? Session["UCCommonFilter_BillingStart"].ToString() : ""; ;
        string cStartMonth = Session["UCCommonFilter_StartMonth"] != null ? Session["UCCommonFilter_StartMonth"].ToString() : "";
        string cEndMonth = Session["UCCommonFilter_EndMonth"] != null ? Session["UCCommonFilter_EndMonth"].ToString() : "";
        string cStartVal = Session["UCCommonFilter_DistinctLineItemFrom"] != null ? Session["UCCommonFilter_DistinctLineItemFrom"].ToString() : "";
        string cEndVal = Session["UCCommonFilter_DistinctLineItemTo"] != null ? Session["UCCommonFilter_DistinctLineItemTo"].ToString() : "";
        string cRangeVal = Session["UCCommonFilter_DistinctLineItemRange"] != null ? Session["UCCommonFilter_DistinctLineItemRange"].ToString() : "";
        string cCategory = Session["UCCommonFilter_Category"] != null ? Session["UCCommonFilter_Category"].ToString() : "";
        string UserCode = SessionManager.UserCode != null ? SessionManager.UserCode : "";


        IList<SKUDispersion> objSKUDispersionList = new SKUDespersionFacade().GetSKUDispersionDetails(SearchString, cSalesOrg, cRegions, cASMs, cSupervisors, cRoutes, cStartVal, cEndVal, cRangeVal, cStartMonth, cEndMonth, cCategory, UserCode);

        if (objSKUDispersionList != null && objSKUDispersionList.Count > 0)
        {
            strFileContents = new StringBuilder();

            foreach (SKUDispersion objSKUDispersion in objSKUDispersionList)
            {
                strFileContents.Append("\t\t" + objSKUDispersion.Month + "\t\t");
            }
            strFileContents.Append("\n");
            foreach (SKUDispersion objSKUDispersion in objSKUDispersionList)
            {
                strFileContents.Append("Distinct Line Item\t");
                strFileContents.Append("No. Of Invoices\t");
                strFileContents.Append("No. Of Customers\t");
                strFileContents.Append("%\t");
                strFileContents.Append("\t");
            }
            strFileContents.Append("\n");

            int i = 0;
            foreach (SKUDispersion objSKUDispersion in objSKUDispersionList)
            {
                foreach (MonthlySKUDispersion objMonthlySKUDispersion in objSKUDispersion.objMonthlySKUDispersions)
                {
                    int TotalInvoiceNumber = objSKUDispersion.TotalInvoicesNumber;
                    int TotalCustomerNumber = objSKUDispersion.TotalCustomersNumber;
                    MonthlySKUDispersion objMonthlySKUDispersion1 = objSKUDispersion.objMonthlySKUDispersions[i];
                    strFileContents.Append("[" + objMonthlySKUDispersion1.LineItem + "] \t");
                    strFileContents.Append(" " + objMonthlySKUDispersion.InvoicesNumber + "\t");
                    strFileContents.Append(objMonthlySKUDispersion.CustomersNumber + "\t");
                    string percentage = "0";
                    if ((TotalInvoiceNumber + TotalCustomerNumber) > 0)
                        percentage = CommonFunctions.GetCurrencyFormatWithThousands_New(Convert.ToDouble((objMonthlySKUDispersion.CustomersNumber + objMonthlySKUDispersion.InvoicesNumber)) / (TotalCustomerNumber + TotalInvoiceNumber) * 100);
                    ;
                    strFileContents.Append(percentage + "\t");
                    strFileContents.Append("\t");
                }
                strFileContents.Append("\n");
                i++;
            }

            foreach (SKUDispersion objSKUDispersion in objSKUDispersionList)
            {
                strFileContents.Append("Total\t");
                strFileContents.Append(objSKUDispersion.TotalInvoicesNumber + "\t");
                strFileContents.Append(objSKUDispersion.TotalCustomersNumber + "\t");
                strFileContents.Append("100\t");
                strFileContents.Append("\t");
            }

            strFileContents.Append("\n");
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    //private void ExportSKUDispersion(string strFileName)
    //{
    //    System.IO.StreamWriter sw;
    //    StringBuilder strFileContents = null;
    //    string searchString = string.Empty;
    //    string UserCode = string.Empty;
    //    string SalesOrgCode = string.Empty;
    //    string Salesman = string.Empty;

    //    searchString = (Session["SKUDispersionSearchString"] != null) ? Session["SKUDispersionSearchString"].ToString() : "1=1";
    //    UserCode = (Session["SKUDispersionUserCode"] != null) ? Session["SKUDispersionUserCode"].ToString() : SessionManager.UserCode;
    //    SalesOrgCode = (Session["SKUDispersioncSalesOrg"] != null) ? Session["SKUDispersioncSalesOrg"].ToString() : "";
    //    Salesman = (Session["SKUDispersioncSalesman"] != null) ? Session["SKUDispersioncSalesman"].ToString() : "";


    //    IList<Customer> objCustomer = new CustomerFacade().GetCustomerUnAssignedInJPSearch("Code  DESC", 500000, 0, searchString, UserCode, SalesOrgCode);
    //    if (objCustomer != null && objCustomer.Count > 0)
    //    {
    //        strFileContents = new StringBuilder();
    //        strFileContents.Append("Customer" + "\t" + "Region" + "\t" + "Country" + "\t" + "JourneyCount");
    //        strFileContents.Append("\n");

    //        foreach (Customer obCustomer in objCustomer)
    //        {
    //            strFileContents.Append("[" + obCustomer.Site + "] " + obCustomer.SiteName + "\t");
    //            strFileContents.Append(obCustomer.RegionName + "\t");
    //            strFileContents.Append(obCustomer.CountryName + "\t");
    //            strFileContents.Append(obCustomer.SubChannelName + "\t");
    //            strFileContents.Append("\n");
    //        }
    //        sw = System.IO.File.CreateText(strFileName);
    //        sw.Write(strFileContents.ToString());
    //        sw.Close();
    //    }
    //}

    private void ExportFile(string filePath, string Filename)
    {
        try
        {
            Response.Clear();
            Response.ContentType = "application/vnd.ms-excel";


            filePath = Server.MapPath(filePath);
            if (!System.IO.File.Exists(filePath))
            {
                filePath = Server.MapPath("..//Data//ExportToExcel//NoRecord.xls");
                Response.AddHeader("content-disposition", "attachment;filename=" + "NoRecord" + ".xls");
            }
            else if (Filename == "MaintainPromotion")
            {
                Response.AddHeader("content-disposition", "attachment;filename=" + Filename + ".csv");

            }
            else
            {
                Response.AddHeader("content-disposition", "attachment;filename=" + Filename + ".xls");
            }
            FileStream sourcefile = new FileStream(filePath, FileMode.Open);
            long filesize;
            filesize = sourcefile.Length;
            byte[] getcontent = new byte[(int)filesize];
            sourcefile.Read(getcontent, 0, (int)sourcefile.Length);
            sourcefile.Close();
            Response.BinaryWrite(getcontent);
            //Response.End();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            Response.End();
        }

    }

    private void ExportOrderReportwithMUSTHAVE_Preseller(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["OrderReportwithMUSTHAVE"] != null) ? Session["OrderReportwithMUSTHAVE"].ToString() : " 1 = 1";

        IList<OrderReportwithMustHave> objOrderReportwithMustHave = (new OrderReportwithMustHaveFacade()).GetReportforPreseller(SearchString);

        if (objOrderReportwithMustHave != null && objOrderReportwithMustHave.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Salesman Name \t Customer ID \t Site No \t Site Name  \t Customer Name \t Channel \t BLASE_ORDER_NO \t Order Date \t BLASE_ORDER_STATUS \t Item Code \t Recommended QTY \t Order QTY \t OrderVariance \t Unit Selling Price \t InitialDiscount \t OrderAmount");
            strFileContents.Append("\n");

            foreach (OrderReportwithMustHave orderReportwithMustHave in objOrderReportwithMustHave)
            {
                strFileContents.Append(orderReportwithMustHave.SalesmanName + "\t");
                strFileContents.Append(orderReportwithMustHave.CUSTOMERID + "\t");
                strFileContents.Append(orderReportwithMustHave.SITE_NUMBER + "\t");
                strFileContents.Append(orderReportwithMustHave.SITE_NAME + "\t");
                strFileContents.Append(orderReportwithMustHave.PARTY_NAME + "\t");
                strFileContents.Append(orderReportwithMustHave.CHANNEL + "\t");
                strFileContents.Append(orderReportwithMustHave.BLASE_ORDER_NO + "\t");
                strFileContents.Append(orderReportwithMustHave.OrderDate + "\t");
                strFileContents.Append(orderReportwithMustHave.BLASE_ORDER_STATUS + "\t");
                strFileContents.Append(orderReportwithMustHave.ITEM_CODE + "\t");
                strFileContents.Append(orderReportwithMustHave.RECOMMENDED_QTY + "\t");
                strFileContents.Append(orderReportwithMustHave.ORDER_QUANTITY + "\t");
                strFileContents.Append(orderReportwithMustHave.OrderVariance + "\t");
                strFileContents.Append(orderReportwithMustHave.UNIT_SELLING_PRICE + "\t");
                strFileContents.Append(orderReportwithMustHave.InitialDiscount + "\t");
                strFileContents.Append(orderReportwithMustHave.OrderAmount + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportOrderReportwithMUSTHAVE_DeliveryAgent(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["OrderReportwithMUSTHAVE"] != null) ? Session["OrderReportwithMUSTHAVE"].ToString() : " 1 = 1";

        IList<OrderReportwithMustHave> objOrderReportwithMustHave = (new OrderReportwithMustHaveFacade()).GetReportforDeliveryAgent(SearchString);

        if (objOrderReportwithMustHave != null && objOrderReportwithMustHave.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Salesman Name \t Customer Id \t Site No  \t Site Name  \t Customer Name \t Channel \t BLASE_ORDER_NO \t Order Date \t BLASE_ORDER_STATUS \t Item Code \t Recommended QTY \t Order QTY \t OrderVariance \t Unit Selling Price \t InitialDiscount \t OrderAmount");
            strFileContents.Append("\t DELIVERED_QUANTITY \t DeliveryDifference \t Discountwhiledelivery \t DeliveryAmount \t SupervisorName");
            strFileContents.Append("\n");

            foreach (OrderReportwithMustHave orderReportwithMustHave in objOrderReportwithMustHave)
            {
                strFileContents.Append(orderReportwithMustHave.SalesmanName + "\t");
                strFileContents.Append(orderReportwithMustHave.CUSTOMERID + "\t");
                strFileContents.Append(orderReportwithMustHave.SITE_NUMBER + "\t");
                strFileContents.Append(orderReportwithMustHave.SITE_NAME + "\t");
                strFileContents.Append(orderReportwithMustHave.PARTY_NAME + "\t");
                strFileContents.Append(orderReportwithMustHave.CHANNEL + "\t");
                strFileContents.Append(orderReportwithMustHave.BLASE_ORDER_NO + "\t");
                strFileContents.Append(orderReportwithMustHave.OrderDate + "\t");
                strFileContents.Append(orderReportwithMustHave.BLASE_ORDER_STATUS + "\t");
                strFileContents.Append(orderReportwithMustHave.ITEM_CODE + "\t");
                strFileContents.Append(orderReportwithMustHave.RECOMMENDED_QTY + "\t");
                strFileContents.Append(orderReportwithMustHave.ORDER_QUANTITY + "\t");
                strFileContents.Append(orderReportwithMustHave.OrderVariance + "\t");
                strFileContents.Append(orderReportwithMustHave.UNIT_SELLING_PRICE + "\t");
                strFileContents.Append(orderReportwithMustHave.InitialDiscount + "\t");
                strFileContents.Append(orderReportwithMustHave.OrderAmount + "\t");
                strFileContents.Append(orderReportwithMustHave.DELIVERED_QUANTITY + "\t");
                strFileContents.Append(orderReportwithMustHave.DeliveryDifference + "\t");
                strFileContents.Append(orderReportwithMustHave.Discountwhiledelivery + "\t");
                strFileContents.Append(orderReportwithMustHave.DeliveryAmount + "\t");
                strFileContents.Append(orderReportwithMustHave.SupervisorName + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportInvoice(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["SearchString"] != null) ? Session["SearchString"].ToString() : "1=1";
        IList<OrderItem> objOrderItem = new OrderItemFacade().GetOrderItemFOREXPORT(SearchString);
        if (objOrderItem != null && objOrderItem.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Invoice Number" + "\t" + "Invoice Date" + "\t" + "Customer Site" + "\t" + "Customer Name" + "\t" + "Salesman Code" + "\t" + "Payment Type" + "\t" + "Quantity" + "\t" + "Item Code");
            strFileContents.Append("\n");
            foreach (OrderItem obOrderItem in objOrderItem)
            {
                strFileContents.Append(obOrderItem.INVOICE_NUMBER + "\t");
                strFileContents.Append(obOrderItem.INVOICE_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(obOrderItem.SITE_NUMBER + "\t");
                strFileContents.Append(obOrderItem.CUSTOMER_NAME + "\t");
                strFileContents.Append(obOrderItem.SALESMANNAME + "\t");
                strFileContents.Append(obOrderItem.PAYMENT_TYPE + "\t");
                strFileContents.Append(obOrderItem.SUGGESTED_SYS_QTY + "\t");
                strFileContents.Append(obOrderItem.ITEM_CODE + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportInitaitiveReport(string strFileName)
    {
        //InitiativeTradePlans.ForEach(a => a.Reason = HttpUtility.UrlDecode(a.Reason));
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["InitiativeSearchstring"] != null) ? Session["InitiativeSearchstring"].ToString() : "1=1";
        List<Initiative> objInitiativeList = new InitiativeFacade().GetInitiativeDetails_Export(SearchString);
        if (objInitiativeList != null && objInitiativeList.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Title" + "\t" + "Start Date" + "\t" + "End Date" + "\t" + "Sales Organization");
            strFileContents.Append("\n");
            foreach (Initiative objInitiative in objInitiativeList)
            {
                strFileContents.Append(HttpUtility.UrlDecode(objInitiative.Title) + "\t");
                strFileContents.Append(objInitiative.StartDate.ToString("MMM d, yyyy") + "\t");
                strFileContents.Append(objInitiative.EndDate.ToString("MMM d, yyyy") + "\t");
                strFileContents.Append("[" + objInitiative.SalesOrgCode + "] " + objInitiative.SalesOrgName + "\t");
                strFileContents.Append("\n");
                strFileContents.Append("\t" + "\t" + "Customer" + "\t" + "Executed On" + "\t" + "Comment");
                strFileContents.Append("\n");
                foreach (InitiativeTradePlan objInitiativeTradePlan in objInitiative.InitiativeTradePlans)
                {
                    strFileContents.Append("\t" + "\t");
                    strFileContents.Append("[" + objInitiativeTradePlan.OutletId + "] " + objInitiativeTradePlan.OutletName + "\t");
                    strFileContents.Append(objInitiativeTradePlan.strImplementedOn + "\t");
                    strFileContents.Append(HttpUtility.UrlDecode(objInitiativeTradePlan.Reason) + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void DeliveryCheckReport_Export_Code(string strFileName)
    {
        string seachstring = null;
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            if (Session["SEARCHSTRING"] != null)
            {
                seachstring = Session["SEARCHSTRING"].ToString();
            }
            else
            {
                seachstring = "1=1";
            }

            string RegionName = string.Empty;
            string AreaName = string.Empty;
            string CustomerName = string.Empty;
            string Classification = string.Empty;
            strFileContents = new StringBuilder();
            strFileContents.Append("\n");

            strFileContents.Append("\n");
            seachstring = Session["SEARCHSTRING"] == null ? "1=1" : CommonFunctions.GetStringValue(Session["SEARCHSTRING"]);
            DateTime StartDate = Session["StartOrderDate"] == null ? DateTime.Now : Convert.ToDateTime(Session["StartOrderDate"]);
            DateTime EndDate = Session["EndOrderDate"] == null ? DateTime.Now : Convert.ToDateTime(Session["EndOrderDate"]);
            RegionName = Session["RegionName"] == null ? "All" : CommonFunctions.GetStringValue(Session["RegionName"]);
            AreaName = Session["AreaName"] == null ? "All" : CommonFunctions.GetStringValue(Session["AreaName"]);
            CustomerName = Session["CustomerName"] == null ? "All" : CommonFunctions.GetStringValue(Session["CustomerName"]);
            Classification = Session["Classification"] == null ? "All" : CommonFunctions.GetStringValue(Session["Classification"]);
            List<DeliveryCheckHeader> objDeliveryCheckHeaderList = new DeliveryChequeReportFecade().GetDeliveryChequeReportByPaging("DeliveryCheckId ASC", 500000, 0, seachstring, SessionManager.SalesOrgCode, SessionManager.UserCode);
            strFileContents.Append("SearchCriteria: \tRegionName:" + RegionName + " \tCity:" + AreaName + " \tClassification:" + Classification + " \tCustomer:" + CustomerName + " \tStartOrderDate:" + StartDate.ToString("yyyy-MM-dd") + " \tEndOrderDate:" + EndDate.ToString("yyyy-MM-dd") + "\n\n\n");
            if (objDeliveryCheckHeaderList != null && objDeliveryCheckHeaderList.Count > 0)
            {


                strFileContents.Append("User" + "\t" + "Customer" + "\t" + "LPONo" + "\t" + "Comments");
                strFileContents.Append("\n");
                foreach (DeliveryCheckHeader objDeliveryCheckHeader in objDeliveryCheckHeaderList)
                {
                    strFileContents.Append("[" + objDeliveryCheckHeader.UserCode + "]" + objDeliveryCheckHeader.UserName + "\t");
                    strFileContents.Append(("[" + objDeliveryCheckHeader.ClientCode + "] " + objDeliveryCheckHeader.ClientName + "\t"));
                    strFileContents.Append(objDeliveryCheckHeader.LPONo == "" ? "N/A" + "\t " : objDeliveryCheckHeader.LPONo + "\t");
                    strFileContents.Append(objDeliveryCheckHeader.Comments == "" ? "N/A" + "\t " : objDeliveryCheckHeader.Comments + "\t");
                    List<DeliveryCheckDetail> DeliveryCheckDetailList = new DeliveryChequeReportFecade().GetDeliveryCheckDetail_Mapping(objDeliveryCheckHeader.DeliveryCheckId);
                    if (DeliveryCheckDetailList.Count > 0)
                    {
                        strFileContents.Append("\n\n");
                        strFileContents.Append("\tItemcode" + "\t" + "ItemDescription" + "\t" + "Quantity" + "\t");
                        strFileContents.Append("\n\n");
                        foreach (DeliveryCheckDetail OBJDeliveryCheckDetail in DeliveryCheckDetailList)
                        {
                            strFileContents.Append("\t" + OBJDeliveryCheckDetail.ItemCode + "\t");
                            strFileContents.Append((OBJDeliveryCheckDetail.ItemDescription + "\t"));
                            strFileContents.Append(OBJDeliveryCheckDetail.Quantity + "\t");
                            strFileContents.Append("\n");
                        }

                    }
                    else
                        strFileContents.Append("\n\n\tNo Items\t\n");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportPayment(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["SearchString"] != null) ? Session["SearchString"].ToString() : "1=1";
        IList<Receipt> objReceipt = new ReceiptFacade().GetReceiptSearchforExport(SearchString);
        if (objReceipt != null && objReceipt.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Receipt Type" + "\t" + "Receipt Method" + "\t" + "Receipt Number" + "\t" + "Receipt Id" + "\t" + "Customer Number" + "\t" + "Site Number" + "\t" + "Receipt Date" + "\t" + "Check Date" + "\t");
            strFileContents.Append("Amount" + "\t" + "Bank" + "\t" + "Check No" + "\t" + "CC No" + "\t" + "CC Expiry" + "\t" + "Coupon No" + "\t" + "Customer Name" + "\t" + "Preseller" + "\t" + "SUBCHANNEL");
            strFileContents.Append("\n");
            foreach (Receipt obReceipt in objReceipt)
            {
                strFileContents.Append(obReceipt.RECEIPT_TYPE + "\t");
                strFileContents.Append(obReceipt.RECEIPT_METHOD + "\t");
                strFileContents.Append(obReceipt.RECEIPT_NUMBER + "\t");
                strFileContents.Append(obReceipt.RECEIPT_ID + "\t");
                strFileContents.Append(obReceipt.CUSTOMER_NO + "\t");
                strFileContents.Append(obReceipt.SITE_NUMBER + "\t");
                strFileContents.Append(obReceipt.RECEIPT_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(((obReceipt.RECEIPT_TYPE.ToLower() != "cash") ? obReceipt.CHECK_DATE.ToString("MMM dd, yyyy") : "") + "\t");
                strFileContents.Append(obReceipt.AMOUNT + "\t");
                strFileContents.Append(obReceipt.BANK + "\t");
                strFileContents.Append(obReceipt.CHECK_NO + "\t");
                strFileContents.Append(obReceipt.CC_NO + "\t");
                strFileContents.Append(obReceipt.CC_EXPIRY + "\t");
                strFileContents.Append(obReceipt.COUPON_NO + "\t");
                strFileContents.Append(obReceipt.CustomerName + "\t");
                strFileContents.Append(obReceipt.Preseller + "\t");
                strFileContents.Append(obReceipt.SUBCHANNEL + "\t");

                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportHHReceipt(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["HHReceipt"] != null) ? Session["HHReceipt"].ToString() : "BU.ROLE = 'HOUSEHOLD'";
        IList<Receipt> objReceipt = new ReceiptFacade().GetHHReceiptSearchforExport(SearchString);
        if (objReceipt != null && objReceipt.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Receipt Type" + "\t" + "Receipt Method" + "\t" + "Receipt Number" + "\t" + "Receipt Id" + "\t" + "Customer Number" + "\t" + "Site Number" + "\t" + "Receipt Date" + "\t" + "Check Date" + "\t");
            strFileContents.Append("Amount" + "\t" + "Bank" + "\t" + "Check No" + "\t" + "CC No" + "\t" + "CC Expiry" + "\t" + "Coupon No" + "\t" + "Scheme No" + "\t" + "Book No" + "\t" + "Customer Name" + "\t" + "Preseller" + "\t" + "SUBCHANNEL");
            strFileContents.Append("\n");
            foreach (Receipt obReceipt in objReceipt)
            {
                strFileContents.Append(obReceipt.RECEIPT_TYPE + "\t");
                strFileContents.Append(obReceipt.RECEIPT_METHOD + "\t");
                strFileContents.Append(obReceipt.RECEIPT_NUMBER + "\t");
                strFileContents.Append(obReceipt.RECEIPT_ID + "\t");
                strFileContents.Append(obReceipt.CUSTOMER_NO + "\t");
                strFileContents.Append(obReceipt.SITE_NUMBER + "\t");
                strFileContents.Append(obReceipt.RECEIPT_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(((obReceipt.RECEIPT_TYPE.ToLower() != "cash") ? obReceipt.CHECK_DATE.ToString("MMM dd, yyyy") : "") + "\t");
                strFileContents.Append(obReceipt.AMOUNT + "\t");
                strFileContents.Append(obReceipt.BANK + "\t");
                strFileContents.Append(obReceipt.CHECK_NO + "\t");
                strFileContents.Append(obReceipt.CC_NO + "\t");
                strFileContents.Append(obReceipt.CC_EXPIRY + "\t");
                strFileContents.Append(obReceipt.COUPON_NO + "\t");
                strFileContents.Append(obReceipt.SCHEMENO + "\t");
                strFileContents.Append(obReceipt.BOOKNO + "\t");
                strFileContents.Append(obReceipt.CustomerName + "\t");
                strFileContents.Append(obReceipt.Preseller + "\t");
                strFileContents.Append(obReceipt.SUBCHANNEL + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportOrdersReportByPreseller(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["SalesPresellerReport"] != null) ? Session["SalesPresellerReport"].ToString() : "";
        IList<SalesReport> objSalesReports = new SalesInvoiceFacade().GetSalesReportByPreseller_Export("", 0, 0, SearchString, SessionManager.UserCode, Session["SalesPresellerReportSalesTeam"].ToString());
        if (objSalesReports != null && objSalesReports.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SITE" + "\t" + "SITE_NAME" + "\t" + "CUSTOMERID" + "\t" + "PARTY_NAME" + "\t" + "SUBCHANNEL" + "\t" + "ORDERS" + "\t" + "QUANTITY" + "\t" + "AMOUNT" + "\t");
            strFileContents.Append("\n");
            foreach (SalesReport objSalesReport in objSalesReports)
            {
                strFileContents.Append(objSalesReport.SITE + "\t");
                strFileContents.Append(objSalesReport.SITE_NAME + "\t");
                strFileContents.Append(objSalesReport.CUSTOMERID + "\t");
                strFileContents.Append(objSalesReport.PARTY_NAME + "\t");
                strFileContents.Append(objSalesReport.SUBCHANNEL + "\t");
                strFileContents.Append(objSalesReport.ORDER_COUNT + "\t");
                strFileContents.Append(objSalesReport.ACTUAL_QTY_SHIPPED + "\t");
                strFileContents.Append(objSalesReport.INVOICE_AMOUNT + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportSalesReport(string strFileName)
    {
        try
        {
            string SearchString = (Session["SalesReport"] != null) ? CommonFunctions.getStringValue(Session["SalesReport"]) : "1=1";
            List<Channel> ChannelList = new List<Channel>();
            IList<User> objUsers = (new SalesmanFacade()).GetSalesAmountByUser("Salesman ASC", 500, 0, SearchString, out ChannelList, SessionManager.UserCode);
            //DataSet ds = (new TrxHeaderFacade()).GetSalesAmountByUser("Salesman", 500, 0, SearchString, out ChannelList);
            if (objUsers != null && objUsers.Count > 0)
            {
                string FileName_2 = "SalesReportData_";
                HSSFWorkbook hssfworkbook = new HSSFWorkbook();
                string filename__2 = "";
                filename__2 = FileName_2 + DateTime.Now.ToString("MMddyyss") + ".xls";

                System.Web.HttpResponse Response = System.Web.HttpContext.Current.Response;
                Response.ContentType = "application/vnd.ms-excel";
                Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", filename__2));
                Response.Clear();

                HSSFSheet sheet1 = (HSSFSheet)hssfworkbook.CreateSheet("Sheet 1");
                HSSFRow row1 = (HSSFRow)sheet1.CreateRow(0);

                for (int j = 0; j <= (ChannelList.Count + 3) - 1; j++)
                {
                    HSSFCell cell = (HSSFCell)row1.CreateCell(j);
                    HSSFHyperlink cell1 = (HSSFHyperlink)row1.CreateCell(j);

                    switch (j)
                    {
                        case 0:
                            cell.SetCellValue("UserCode");
                            //cell.SetCellType(NPOI.SS.UserModel.CellType.STRING);
                            break;
                        case 1:
                            cell.SetCellValue("Salesman");
                            //cell.SetCellType(NPOI.SS.UserModel.CellType.STRING);
                            break;
                        case 2:
                            cell.SetCellValue("Total");
                            //cell.SetCellType(NPOI.SS.UserModel.CellType.NUMERIC);
                            break;
                        default:
                            String columnName = ChannelList[(j - 3)].Code;
                            cell.SetCellValue(columnName);

                            break;
                    }
                }

                //loops through data
                for (int i = 0, k = 0; i <= objUsers.Count - 1; i++)
                {
                    HSSFRow row = (HSSFRow)sheet1.CreateRow(i + 1);
                    HSSFCell cell = (HSSFCell)row.CreateCell(k);
                    cell.SetCellValue(objUsers[i].UserCode);

                    cell = (HSSFCell)row.CreateCell(k + 1);
                    cell.SetCellValue(objUsers[i].Description);

                    cell = (HSSFCell)row.CreateCell(k + 2);
                    cell.SetCellValue(objUsers[i].SalesValue);

                    for (int j = 0; j <= ChannelList.Count - 1; j++)
                    {
                        cell = (HSSFCell)row.CreateCell((k + 3) + j);
                        cell.SetCellValue(objUsers[i].Channels[j].SalesValue.ToString());
                    }
                }
                //writing the data to binary from memory
                Response.BinaryWrite(WriteToStream(hssfworkbook).GetBuffer());
                Response.End();
                // DataTableToExcel(ds.Tables[0], strFileName, FileName_2);
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private static MemoryStream WriteToStream(HSSFWorkbook hssfworkbook)
    {
        //Write the stream data of workbook to the root directory
        MemoryStream file = new MemoryStream();
        hssfworkbook.Write(file);
        return file;
    }

    private void ExportOrder(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["OrderSearchString"] != null) ? Session["OrderSearchString"].ToString() : "1=1";
        IList<Order> objOrderList = null;// new OrderFacade().GetOrderSearch("CREATED_ON DESC", 0, 0, SearchString);
        if (objOrderList != null && objOrderList.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Blase Order no" + "\t" + "Order Date" + "\t" + "Site Number" + "\t" + "Site Name" + "\t" + "Cutomer Id" + "\t" + "Customer Name" + "\t" + "Order Type" + "\t" + "Order Source" + "\t" + "Sales Man" + "\t" + "Created By" + "\t" + "Created By Name");
            strFileContents.Append("\n");
            foreach (Order objOrder in objOrderList)
            {
                strFileContents.Append(objOrder.BLASE_ORDER_NO + "\t");
                strFileContents.Append(objOrder.ORDER_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(objOrder.SITE_NUMBER + "\t");
                strFileContents.Append(objOrder.SITE_NAME + "\t");
                strFileContents.Append(objOrder.CUSTOMER_NUMBER + "\t");
                strFileContents.Append(objOrder.CUSTOMER_NAME + "\t");
                strFileContents.Append(objOrder.ORDER_TYPE + "\t");
                strFileContents.Append((objOrder.OrderType.Length == 0 ? "App Order" : objOrder.OrderType) + "\t");
                strFileContents.Append(objOrder.SALESMANNAME + "\t");
                strFileContents.Append(objOrder.CREATED_BY + "\t");
                strFileContents.Append(objOrder.CREATED_BY_NAME + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportCustomer(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["CustomerReports"] != null) ? Session["CustomerReports"].ToString() : "1=1";
        IList<Customer> objCustomer = new CustomerFacade().GetCustomerReportExport(SearchString);
        if (objCustomer != null && objCustomer.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SITE" + "\t" + "SITE_NAME" + "\t" + "CUSTOMERID" + "\t" + "PARTY_NAME" + "\t" + "SUBCHANNEL" + "\t" + "GEO_CODE_X " + "\t" + "GEO_CODE_Y ");
            strFileContents.Append("\n");
            foreach (Customer obCustomer in objCustomer)
            {
                strFileContents.Append(obCustomer.SITE + "\t");
                strFileContents.Append(obCustomer.SITE_NAME + "\t");
                strFileContents.Append(obCustomer.CUSTOMERID + "\t");
                strFileContents.Append(obCustomer.PARTY_NAME + "\t");
                strFileContents.Append(obCustomer.SUBCHANNEL + "\t");
                strFileContents.Append(obCustomer.GEO_CODE_X + "\t");
                strFileContents.Append(obCustomer.GEO_CODE_Y + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportCustomerVisit(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = "1=1", SortExpression = "Date DESC";
        string cSalesOrg = Session["UCCommonFilter_SalesOrganization"] != null ? Session["UCCommonFilter_SalesOrganization"].ToString() : "";
        string cRegions = Session["UCCommonFilter_Region"] != null ? Session["UCCommonFilter_Region"].ToString() : ""; ;
        string cASMs = Session["UCCommonFilter_ASM"] != null ? Session["UCCommonFilter_ASM"].ToString() : ""; ;
        string cSupervisors = Session["UCCommonFilter_Supervisor"] != null ? Session["UCCommonFilter_Supervisor"].ToString() : ""; ;
        string cRoutes = Session["UCCommonFilter_Route"] != null ? Session["UCCommonFilter_Route"].ToString() : ""; ;
        string StartDate = Session["UCCommonFilter_StartDate"] != null ? Session["UCCommonFilter_StartDate"].ToString() : "";
        string EndDate = Session["UCCommonFilter_EndDate"] != null ? Session["UCCommonFilter_EndDate"].ToString() : "";
        string UserCode = SessionManager.UserCode != null ? SessionManager.UserCode : "";

        IList<CustomerVisit> objCustomerVisits = new CustomerVisitFacade().GetCustomerVisitSearch_Export(SortExpression, SearchString, cSalesOrg, cRegions, cASMs, cSupervisors, cRoutes, StartDate, EndDate, UserCode);
        if (objCustomerVisits != null && objCustomerVisits.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "User Code" + "\t" + "User Name" + "\t" + "Emp Role" + "\t" + "Total Time " + "\t" + "Date" + "\t" + "Checkin Time" + "\t" + "Checkout Time");
            strFileContents.Append("\n");
            foreach (CustomerVisit objCustomerVisit in objCustomerVisits)
            {
                strFileContents.Append(objCustomerVisit.CUSTOMERSITEID + "\t");
                strFileContents.Append(objCustomerVisit.SITE_NAME + "\t");
                strFileContents.Append(objCustomerVisit.EMPNO + "\t");
                strFileContents.Append(objCustomerVisit.VisitCode + "\t");
                strFileContents.Append(objCustomerVisit.EMPROLE + "\t");
                strFileContents.Append(objCustomerVisit.TOTALTIMEINMINS + "\t");
                strFileContents.Append(Convert.ToDateTime(objCustomerVisit.DATE).ToString("yyyy-MM-dd") + "\t");
                strFileContents.Append(Convert.ToDateTime(objCustomerVisit.ARRIVALTIME).ToString("hh:mm tt") + "\t");
                strFileContents.Append(Convert.ToDateTime(objCustomerVisit.OUTTIME).ToString("hh:mm tt") + "\t");

                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    private void ExportManageCollectionReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string empNo;
        string dt;
        DateTime date;
        empNo = Request.QueryString["empNo"] != null ? Request.QueryString["empNo"] : "0";
        string searchString = "1=1";

        string RouteCode = Session["Collection_RouteCode"].ToString();
        string Locations = Session["Collection_LocationCode"].ToString();
        string Divisions = Session["Collection_Division"].ToString();
        string StartDate = Session["Collection_StartDate"].ToString();
        string EndDate = Session["Collection_EndDate"].ToString();

        IList<Collection> objOrders = new CollectionFacade().GetUserCollectionDetails(SessionManager.UserCode, RouteCode, Locations, Divisions, StartDate, EndDate);
        if (objOrders != null && objOrders.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("RouteCode" + "\t" + "Customer Code" + "\t" + "Customer Name" + "\t" + "Depot" + "\t" + "Total Sales" + "\t" + "Cash" + "\t" + "Cheque" + "\t" + "OutStanding");
            strFileContents.Append("\n");
            foreach (Collection objOrder in objOrders)
            {
                strFileContents.Append(objOrder.RouteCode + "\t");
                strFileContents.Append(objOrder.CustomerCode + "\t");
                strFileContents.Append(objOrder.CustomerName + "\t");
                strFileContents.Append(objOrder.LocationName + "\t");
                strFileContents.Append(objOrder.TotalSales + "\t");
                strFileContents.Append(objOrder.TotalCash + "\t");
                strFileContents.Append(objOrder.TotalCheque + "\t");
                strFileContents.Append(objOrder.Outstanding + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }


    private void ExportRouteTripinfo(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string empNo;
        string dt;
        DateTime date;
        empNo = Request.QueryString["empNo"] != null ? Request.QueryString["empNo"] : "0";
        string searchString = "1=1";

        searchString = Session["RouteTripInfo_searchString"].ToString();


        IList<RouteTripDetail> objOrders = new RouteTripDetailFacade().GetRouteTripDetailSearch("cast(J.StartTime as date) DESC", 99999999, 0, searchString, SessionManager.UserCode);
        if (objOrders != null && objOrders.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("UserCode" + "\t" + "User Name" + "\t" + "Route Code" + "\t" + "Route Name" + "\t" + "Route StartDate" + "\t" + "EOT DateTime" + "\t" + "Trip Date" + "\t" + "EOT Status");
            strFileContents.Append("\n");
            foreach (RouteTripDetail objOrder in objOrders)
            {
                strFileContents.Append(objOrder.UserCode + "\t");
                strFileContents.Append(objOrder.UserName + "\t");
                strFileContents.Append(objOrder.RouteCode + "\t");
                strFileContents.Append(objOrder.RouteName + "\t");
                strFileContents.Append(objOrder.RouteStartDate.ToString("MMM dd,yyyy") + "\t");
                strFileContents.Append(objOrder.EOTDateTime.ToString("MMM dd,yyyy") + "\t");
                strFileContents.Append(objOrder.TripDate.ToString("MMM dd,yyyy") + "\t");
                strFileContents.Append(objOrder.EOTStatus + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }


    private void ExportActualVsTarget(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        string UserCode = "", SearchString = "1=1", SortExpression = "AchievedAmount DESC", SalesOrganizations = "", Regions = "", ASMs = "", Supervisors = "", Routes = "", StartMonth = "";
        int MaximumRows = 99999, StartRowIndex = 0;
        if (SessionManager.UserCode != null)
        {
            UserCode = SessionManager.UserCode.ToString();
        }
        if (Session["UCCommonFilter_SalesOrganization"] != null)
        {
            SalesOrganizations = Session["UCCommonFilter_SalesOrganization"].ToString();
        }
        if (Session["UCCommonFilter_Region"] != null)
        {
            Regions = Session["UCCommonFilter_Region"].ToString();
        }
        if (Session["UCCommonFilter_ASM"] != null)
        {
            ASMs = Session["UCCommonFilter_ASM"].ToString();
        }
        if (Session["UCCommonFilter_Supervisor"] != null)
        {
            Supervisors = Session["UCCommonFilter_Supervisor"].ToString();
        }
        if (Session["UCCommonFilter_Route"] != null)
        {
            Routes = Session["UCCommonFilter_Route"].ToString();
        }
        if (Session["UCCommonFilter_StartMonth"] != null)
        {
            StartMonth = Session["UCCommonFilter_StartMonth"].ToString();
        }
        ActualTargetReport objActualTargetReport = new ActualTargetsFacade().GetActualTarget(SortExpression, MaximumRows, StartRowIndex, SearchString, UserCode, SalesOrganizations, Regions, ASMs, Supervisors, Routes, StartMonth);
        if (objActualTargetReport.objActualTargetList != null && objActualTargetReport.objActualTargetList.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Route" + "\t" + "Target Amount" + "\t" + "Achieved Amount" + "\t" + "Percentage (%)");
            strFileContents.Append("\n");
            foreach (ActualTarget objOrder in objActualTargetReport.objActualTargetList)
            {
                strFileContents.Append(objOrder.SALESMANCODE + "\t");
                strFileContents.Append(objOrder.TargetAmount + "\t");
                strFileContents.Append(objOrder.AchievedAmount + "\t");
                strFileContents.Append(objOrder.Percentage + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportOrdersReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string empNo;
        string dt;
        DateTime date;
        empNo = Request.QueryString["empNo"] != null ? Request.QueryString["empNo"] : "0";
        dt = Request.QueryString["date"] != null ? Request.QueryString["date"] : "";
        if (empNo.Length == 0)
        {
            empNo = "0";
        }
        if (dt.Length == 0)
        {
            dt = DateTime.Now.Date.ToString("MM/dd/yyyy");
        }
        date = Convert.ToDateTime(dt);
        IList<Order> objOrders = null;//new OrderFacade().GetOrdersByPreseller_Export(empNo, date);
        if (objOrders != null && objOrders.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("LOCATION" + "\t" + "ORDER DATE" + "\t" + "SITE NUMBER" + "\t" + "CUSTOMER NUMBER" + "\t" + "CUSTOMER NAME" + "\t" + "SUBCHANNEL");
            strFileContents.Append("\n");
            foreach (Order objOrder in objOrders)
            {
                strFileContents.Append(objOrder.LOCATION + "\t");
                strFileContents.Append(objOrder.ORDER_DATE.ToString("MM/dd/yyyy") + "\t");
                strFileContents.Append(objOrder.SITE_NUMBER + "\t");
                strFileContents.Append(objOrder.CUSTOMER_NUMBER + "\t");
                strFileContents.Append(objOrder.CUSTOMER_NAME + "\t");
                strFileContents.Append(objOrder.customer.SUBCHANNEL + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportSkipCustomer(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["SkipCustomers"] != null) ? Session["SkipCustomers"].ToString() : "1=1";
        SearchString = (SearchString.Length == 0) ? " 1 = 1" : SearchString;
        IList<EmployeeReasonLog> objEmployeeReasonLogs = new EmployeeReasonLogFacade().GetSkipCustomerReportExport(SearchString);
        if (objEmployeeReasonLogs != null && objEmployeeReasonLogs.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SITE NAME" + "\t" + "CUSTOMERID" + "\t" + "PARTY NAME" + "\t" + "SUBCHANNEL" + "\t" + "DATE" + "\t" + "REASON");
            strFileContents.Append("\n");
            foreach (EmployeeReasonLog objEmployeeReasonLog in objEmployeeReasonLogs)
            {
                strFileContents.Append(objEmployeeReasonLog.SITE_NAME + "\t");
                strFileContents.Append(objEmployeeReasonLog.CUSTOMERID + "\t");
                strFileContents.Append(objEmployeeReasonLog.PARTY_NAME + "\t");
                strFileContents.Append(objEmployeeReasonLog.SUBCHANNEL + "\t");
                strFileContents.Append(objEmployeeReasonLog.Date.ToString("MM/dd/yyyy") + "\t");
                strFileContents.Append(objEmployeeReasonLog.Reason + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportSkipCustomerReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        string SelectChannel = string.Empty;
        string SelectSalesTeam = string.Empty;
        string SelectSalesman = string.Empty;
        string SelectCustomer = string.Empty;
        string SalesOrg = string.Empty;
        SelectCustomer = (Session["SkipCustomersSel"] != null) ? Session["SkipCustomersSel"].ToString() : "";
        SelectSalesman = (Session["SkipSalesmanSel"] != null) ? Session["SkipSalesmanSel"].ToString() : "";
        SelectSalesTeam = (Session["SkipSalesteamSel"] != null) ? Session["SkipSalesteamSel"].ToString() : "";
        SelectChannel = (Session["SkipChannelSel"] != null) ? Session["SkipChannelSel"].ToString() : "";
        SalesOrg = (Session["SalesOrg"] != null) ? Session["SalesOrg"].ToString() : "";


        SearchString = (Session["SkipCustomers"] != null) ? Session["SkipCustomers"].ToString() : "1=1";
        if (SearchString.Split('|').Length > 1)
            SalesOrg = SearchString.Split('|')[1];
        SearchString = SearchString.Split('|')[0];
        SearchString = (SearchString.Length == 0) ? " 1 = 1" : SearchString;
        // IList<EmployeeReasonLog> objEmployeeReasonLogs = new EmployeeReasonLogFacade().GetSkipCustomerReportExport_New(SearchString, SessionManager.UserCode);
        IList<EmployeeReasonLogReport> obEmployeeReasonLogReport = new EmployeeReasonLogFacade().GetSkipCustomerSearchNew("UserName ASC", 500000, 0, SearchString, SessionManager.UserCode, SelectSalesTeam, SalesOrg);
        EmployeeReasonLog objEmployeeReasonLog = new EmployeeReasonLog();
        strFileContents = new StringBuilder();
        if (SessionManager.UserTypeCode == "Manager")
        {
            //  strFileContents.Append("Search Criteria: " + "\t" + "Salesman: " + Session["SkipSalesmanSel"].ToString() + "\t" + "Customer: " + Session["SkipCustomersSel"].ToString() + "\t" + "Date : " + Session["SkipCustomersSdate"].ToString() + " To " + Session["SkipCustomersEdate"].ToString() + "\n\n\n");
        }
        else
        {
            // strFileContents.Append("Search Criteria: " + "\t" + "Salesman: " + Session["SkipSalesmanSel"].ToString() + "\t" + "Sales Team: " + Session["SkipSalesteamSel"].ToString() + "\t" + "Customer: " + Session["SkipCustomersSel"].ToString() + "\t" + "Date : " + Session["SkipCustomersSdate"].ToString() + " To " + Session["SkipCustomersEdate"].ToString() + "\n\n\n");
        }
        if (obEmployeeReasonLogReport != null && obEmployeeReasonLogReport.Count > 0)
        {

            strFileContents.Append("User" + "\t" + "Customer Count" + "\n");
            foreach (EmployeeReasonLogReport objReasonLog in obEmployeeReasonLogReport)
            {
                strFileContents.Append("[" + objReasonLog.UserCode + "] " + objReasonLog.UserName + "\t");
                strFileContents.Append(objReasonLog.UserCount);
                strFileContents.Append("\n");
                strFileContents.Append("\t" + "Customer" + "\t" + "Date" + "\t" + "Reason" + "\n");
                IList<EmployeeReasonLog> objEmployeeReasonLogList = new EmployeeReasonLogFacade().GetSkipCustomerLogSearchNew(SearchString, objReasonLog.UserCode, "", SelectSalesTeam, SelectSalesman, SelectChannel);
                if (objEmployeeReasonLogList != null && objEmployeeReasonLogList.Count > 0)
                {
                    foreach (EmployeeReasonLog objReason in objEmployeeReasonLogList)
                    {
                        strFileContents.Append("\t");
                        strFileContents.Append("[" + objReason.SITE_NAME + "]" + objReason.CUSTOMERID + "\t");
                        strFileContents.Append(objReason.Date.ToString("MM/dd/yyyy") + "\t");
                        strFileContents.Append(objReason.Reason + "\t");
                        strFileContents.Append("\n");
                    }
                    sw = System.IO.File.CreateText(strFileName);
                    sw.Write(strFileContents.ToString());
                    sw.Close();
                }


            }

        }

    }

    private void ExportUnplannedOrdersReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string dt;
        DateTime date;
        string location = "";
        int total = 0;

        dt = Request.QueryString["date"] != null ? Request.QueryString["date"] : "";

        if (dt.Length == 0)
        {
            dt = DateTime.Now.Date.ToString("MM/dd/yyyy");
        }
        date = Convert.ToDateTime(dt);
        IList<Location> objLocations = null;// new OrderFacade().GetUnplannedOrders_Export(date);

        if (objLocations != null && objLocations.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("REGION\tSALESMAN CODE\tORDER COUNT\tSUBCHANNEL");
            strFileContents.Append("\n");

            foreach (Location objLocation in objLocations)
            {
                if (location.Length > 0 && location != objLocation.LOCATIONNAME)
                {
                    total = objLocations.Where(l => l.LOCATIONNAME == location).Sum(l => l.ORDER_COUNT);

                    strFileContents.AppendFormat("{0} Total\t", location);
                    strFileContents.AppendFormat("{0}\t", "");
                    strFileContents.AppendFormat("{0}", total);
                    strFileContents.Append("\n");
                }

                strFileContents.AppendFormat("{0}\t", (location == objLocation.LOCATIONNAME) ? "" : objLocation.LOCATIONNAME);
                strFileContents.AppendFormat("{0}\t", objLocation.SALESMAN);
                strFileContents.AppendFormat("{0}\t", objLocation.ORDER_COUNT);
                strFileContents.AppendFormat("{0}", objLocation.SUBCHANNEL);
                strFileContents.Append("\n");

                location = objLocation.LOCATIONNAME;
            }

            total = objLocations.Where(l => l.LOCATIONNAME == location).Sum(l => l.ORDER_COUNT);

            strFileContents.AppendFormat("{0} Total\t", location);
            strFileContents.AppendFormat("{0}\t", "");
            strFileContents.AppendFormat("{0}", total);
            strFileContents.Append("\n");

            total = objLocations.Sum(l => l.ORDER_COUNT);

            strFileContents.AppendFormat("{0}\t", "Grand Total ");
            strFileContents.AppendFormat("{0}\t", "");
            strFileContents.AppendFormat("{0}", total);
            strFileContents.Append("\n");

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportPetrolUsageReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string strSearchString = (Session["PetrolUsage"] != null) ? Session["PetrolUsage"].ToString() : " 1 = 1";

        IList<PetrolUsage> objPetrolUsage = new PetrolUsageFacade().ExportPetrolUsage(strSearchString);

        if (objPetrolUsage != null && objPetrolUsage.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Usage Time\tDistance\tAmount\tEmpId\tStationName\tUserId\tLiter");
            strFileContents.Append("\n");

            foreach (PetrolUsage obPetrolUsage in objPetrolUsage)
            {

                strFileContents.AppendFormat("{0}\t", obPetrolUsage.UsageTime);
                strFileContents.AppendFormat("{0}\t", obPetrolUsage.Distance);
                strFileContents.AppendFormat("{0}\t", obPetrolUsage.Amount);
                strFileContents.AppendFormat("{0}\t", obPetrolUsage.EmpId);
                strFileContents.AppendFormat("{0}\t", obPetrolUsage.PetrolStation.StationName);
                strFileContents.AppendFormat("{0}\t", obPetrolUsage.BlaseUser.USERID);
                strFileContents.AppendFormat("{0}\t", obPetrolUsage.Liter);
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportCustomergeoCodeByDeliveryAgent(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["CustomerGeoCodeReports"] != null) ? Session["CustomerGeoCodeReports"].ToString() : "1=1";
        // IList<Customer> objCustomer = new CustomerFacade().GetCustomerGeoCodeReportExport(SearchString);
        IList<Customer> objCustomer = new CustomerFacade().GetCustomerGeoCodeSearch("LastModifiedDate DESC", 1000000, 0, SearchString, Session["CustomerGeoCodeUserCode"].ToString(), "");
        if (objCustomer != null && objCustomer.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Site No" + "\t" + "Customer Name" + "\t" + "Latitude " + "\t" + "Longitude " + "\t" + "Last Modified");
            strFileContents.Append("\n");
            foreach (Customer obCustomer in objCustomer)
            {
                strFileContents.Append(obCustomer.Site + "\t");
                strFileContents.Append(obCustomer.CustomerName + "\t");
                strFileContents.Append(obCustomer.GEO_CODE_X + "\t");
                strFileContents.Append(obCustomer.GEO_CODE_Y + "\t");
                strFileContents.Append(obCustomer.LastModifiedDate.ToString("MMM d, yyyy") + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void Exportsalesinvoice(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["Orderinvoice"] != null) ? Session["Orderinvoice"].ToString() : " DATEDIFF(D, I.INVOICE_DATE, GETDATE()) = 0";
        IList<OrderInvoice> objOrderInvoice = new OrderInvoiceFacade().GetOrderInvoiceExport(SearchString);
        if (objOrderInvoice != null && objOrderInvoice.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Preseller" + "\t" + "Customer Type" + "\t" + "Order No" + "\t" + "Order Date " + "\t" + "SUBCHANNEL" + "\t" + "Customer No\tCustomer Name\tSite No\tInvoiceNo\tInvoice Date\tInvoice Amount ");
            strFileContents.Append("\n");
            int i = 1;
            foreach (OrderInvoice obOrderInvoice in objOrderInvoice)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obOrderInvoice.SALESMANNAME + "\t");
                strFileContents.Append(obOrderInvoice.PAYMENT_TYPE + "\t");
                strFileContents.Append(obOrderInvoice.Order_Number + "\t");
                strFileContents.Append(obOrderInvoice.ORDER_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(obOrderInvoice.SUBCHANNEL + "\t");
                strFileContents.Append(obOrderInvoice.CUSTOMERID + "\t");
                strFileContents.Append(obOrderInvoice.SITE_NAME + "\t");
                strFileContents.Append(obOrderInvoice.SITE + "\t");
                strFileContents.Append(obOrderInvoice.INVOICE_NUMBER + "\t");
                strFileContents.Append(obOrderInvoice.INVOICE_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(obOrderInvoice.INVOICE_AMOUNT + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportOrderDelivery(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["OrderDelivery"] != null) ? Session["OrderDelivery"].ToString() : " DATEDIFF(D, DRP.[Date], GETDATE()) = 0";
        IList<OrderDelivery> objOrderDelivery = new OrderDeliveryFacade().GetOrderDeliveryExport(SearchString);
        if (objOrderDelivery != null && objOrderDelivery.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Preseller" + "\t" + "Customer Type" + "\t" + "Order No" + "\t" + "Order Date " + "\t" + "SUBCHANNEL" + "\t" + "Customer No\tCustomer Name\tSite No\tItem\tITEM DESC\tORD QTY\tDEL_QTY\tINVOICED QTY\tRATE\tDISC%\tINV_AMT ");
            strFileContents.Append("\n");
            int i = 1;
            foreach (OrderDelivery obOrderDelivery in objOrderDelivery)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obOrderDelivery.SALESMANNAME + "\t");
                strFileContents.Append(obOrderDelivery.PAYMENT_TYPE + "\t");
                strFileContents.Append(obOrderDelivery.Order_Number + "\t");
                strFileContents.Append(obOrderDelivery.ORDER_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(obOrderDelivery.SUBCHANNEL + "\t");
                strFileContents.Append(obOrderDelivery.CUSTOMERID + "\t");
                strFileContents.Append(obOrderDelivery.SITE_NAME + "\t");
                strFileContents.Append(obOrderDelivery.SITE + "\t");
                strFileContents.Append(obOrderDelivery.ItemCode + "\t");
                strFileContents.Append(obOrderDelivery.ITEM_DESCRIPTION + "\t");
                strFileContents.Append(obOrderDelivery.ORDER_QUANTITY + "\t");
                strFileContents.Append(obOrderDelivery.ACTUAL_QTY_SHIPPED + "\t");
                strFileContents.Append(obOrderDelivery.ACTUAL_QTY_SHIPPED + "\t");
                strFileContents.Append("" + "\t");
                strFileContents.Append(obOrderDelivery.DISCOUNT + "\t");
                strFileContents.Append(obOrderDelivery.INVOICE_AMOUNT + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportMTDWastageReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["MTDWastSearch"] != null) ? Session["MTDWastSearch"].ToString() : "1=1";
        IList<MTD> objMTDList = new MTDSalesPerformenceFacade().GetMTDSalesOverviewForReportExport(SearchString, SessionManager.UserCode);
        if (objMTDList != null && objMTDList.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Category" + "\t" + "CustomerCode" + "\t" + "CustomerName" + "\t" + "Qty(CS)" + "\t" + "Qty(PCS)" + "\t" + "Percentages" + "\t" + "ExpiredValue" + "\t" + " DamagedValue");
            strFileContents.Append("\n");
            int i = 1;
            foreach (MTD obMTD in objMTDList)
            {
                strFileContents.Append(obMTD.Category + "\t");
                strFileContents.Append(obMTD.CustomerCode + "\t");
                strFileContents.Append(obMTD.CustomerName + "\t");
                strFileContents.Append(obMTD.QuantityCS + "\t");
                strFileContents.Append(obMTD.QuantityPCS + "\t");
                strFileContents.Append(obMTD.Percentages + "\t");
                strFileContents.Append(obMTD.ExpiredValue + "\t");
                strFileContents.Append(obMTD.DamagedValue + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportDeliveryReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["OrderDeliveryReport"] != null) ? Session["OrderDeliveryReport"].ToString() : " DATEDIFF(D,  DRP.[Date], GETDATE()) = 0";
        IList<OrderDeliveryReport> objOrderDeliveryReport = new OrderDeliveryReportFacade().GetOrderDeliveryReportExport(SearchString);
        if (objOrderDeliveryReport != null && objOrderDeliveryReport.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Preseller" + "\t" + "Customer Type" + "\t" + "Order No" + "\t" + "Order Date " + "\t" + "SUBCHANNEL" + "\t" + "Customer No\tCustomer Name\tSite No\tORD QTY\tDEL_QTY\tINV QTY\tINV_AMT \tStatus");
            strFileContents.Append("\n");
            int i = 1;
            foreach (OrderDeliveryReport obOrderDeliveryReport in objOrderDeliveryReport)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obOrderDeliveryReport.SALESMAN + "\t");
                strFileContents.Append(obOrderDeliveryReport.PAYMENT_TYPE + "\t");
                strFileContents.Append(obOrderDeliveryReport.BLASE_ORDER_NO + "\t");
                strFileContents.Append(obOrderDeliveryReport.ORDER_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(obOrderDeliveryReport.SUBCHANNEL + "\t");
                strFileContents.Append(obOrderDeliveryReport.CUSTOMERID + "\t");
                strFileContents.Append(obOrderDeliveryReport.SITE_NAME + "\t");
                strFileContents.Append(obOrderDeliveryReport.SITE + "\t");
                strFileContents.Append(obOrderDeliveryReport.TotalOrderQuantity + "\t");
                strFileContents.Append(obOrderDeliveryReport.TotalDeliveredQuantity + "\t");
                strFileContents.Append(obOrderDeliveryReport.TotalDeliveredQuantity + "\t");
                strFileContents.Append(obOrderDeliveryReport.TotalInvoiceAmount + "\t");
                strFileContents.Append((obOrderDeliveryReport.DeliveryStatus == true) ? "Delivered" : "Pending" + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportDeliveryAgentRoutePlan(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["DeliveryRoutePlanSearch"] != null) ? Session["DeliveryRoutePlanSearch"].ToString() : "1=1";
        IList<DeliveryRoutePlanExport> objDeliveryRoutePlanExport = new DeliveryRoutePlanExportFacade().GetDeliveryRoutePlanforExport(SearchString);
        if (objDeliveryRoutePlanExport != null && objDeliveryRoutePlanExport.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No\tEmpId\tPLATENO\tBLASE_ORDER_NO\tINVOICE_NUMBER\tSITE\tCUSTOMERID\tPARTY_NAME\tSITE_NAME\tUSERID\tDeliveryStatus\tORDER DATE\tRegion Code\tIsCancelled\tItemCode\tItemDesc\tQuantity\tUOM\tARRIVAL_TIME\tDEP_TIME\tStatus");
            strFileContents.Append("\n");
            int i = 1;
            foreach (DeliveryRoutePlanExport obDeliveryRoutePlanExport in objDeliveryRoutePlanExport)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.EmpId + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.PLATENO + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.BLASE_ORDER_NO + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.INVOICE_NUMBER + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.SITE + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.CUSTOMERID + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.PARTY_NAME + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.SITE_NAME + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.USERID + "\t");
                strFileContents.Append(((obDeliveryRoutePlanExport.DeliveryStartus) ? "Delivered" : "Pending") + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.ORDER_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(obDeliveryRoutePlanExport.REGION_CODE + "\t");
                strFileContents.Append(((obDeliveryRoutePlanExport.IsCancelled) ? "true" : "false") + "\t");
                if (obDeliveryRoutePlanExport.objDeliverableOrderItems != null && obDeliveryRoutePlanExport.objDeliverableOrderItems.Count > 0)
                {
                    for (int j = 0; j < obDeliveryRoutePlanExport.objDeliverableOrderItems.Count; j++)
                    {
                        if (j != 0)
                        {
                            strFileContents.Append(i + "\t");
                            for (int k = 0; k < 13; k++)
                            {
                                strFileContents.Append("\t");
                            }
                        }
                        strFileContents.Append(obDeliveryRoutePlanExport.objDeliverableOrderItems[j].ItemCode + "\t");
                        strFileContents.Append(obDeliveryRoutePlanExport.objDeliverableOrderItems[j].ItemDesc + "\t");
                        strFileContents.Append(obDeliveryRoutePlanExport.objDeliverableOrderItems[j].Quantity + "\t");
                        strFileContents.Append(obDeliveryRoutePlanExport.objDeliverableOrderItems[j].UOM + "\t");
                        strFileContents.Append(obDeliveryRoutePlanExport.objDeliverableOrderItems[j].ARRIVAL_TIME + "\t");
                        strFileContents.Append(obDeliveryRoutePlanExport.objDeliverableOrderItems[j].DEP_TIME + "\t");
                        strFileContents.Append(((obDeliveryRoutePlanExport.objDeliverableOrderItems[j].DeliveryStartus) ? "D" : "E") + "\t");
                        strFileContents.Append("\n");
                        i = i + 1;
                    }
                }
                else
                {
                    i = i + 1;
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExporttoExcel(string strFileName)
    {
        StringBuilder sb = new StringBuilder();
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.ClearContent();
        HttpContext.Current.Response.ClearHeaders();
        HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        sb.Append(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + strFileName + ".xls");

        //StringWriter sw = new StringWriter();
        //HtmlTextWriter htw = new HtmlTextWriter(sw);
        //System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();
        //img.ImageUrl = Server.MapPath("../images/logo.jpg");
        //img.RenderControl(htw);
        //HttpContext.Current.Response.Write(sw.ToString());




        HttpContext.Current.Response.Charset = "utf-8";
        HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
        //sets font
        // string headerTable = @"<Table style='height:500px;'><tr><td><img src='" + Server.MapPath("../images/logo.jpg") + "' /></td></tr><tr><td></td></tr></Table>";
        // HttpContext.Current.Response.Write(headerTable);


        sb.Append("<font style='font-size:10.0pt; font-family:Calibri;'>");
        sb.Append("<BR><BR><BR>");
        //sets the table border, cell spacing, border color, font of the text, background, foreground, font height


        sb.Append("<Table border='1' bgColor='#ffffff' " +
          "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
          "style='text-align:left; font-size:10.0pt; font-family:Calibri; background:white;'>");
        //sb.Append("<tr><td><img alt='' src='data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCACsAjwDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD+/iiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiivxV/a7/4K8zeEPjzd/sN/wDBOv4CX37fv7cNgwHj/wAC+FPFlj4V+Bn7NOnGeW2m1/8AaZ+NM8N9oXg2+spI5Gi+HdtIPFmo3VvLoN5daHrl5oNtegH7VUV/Phbf8E5v+Cw/7VyT+JP26f8Agr94x/ZwsNdmleX9nX/gmB4M0v4TaB4K02X7SY7LRv2mvHem6r8W9d1Ly7lYbm51bRJYrGe1il03UL0Olwmmn/BuD+wxq5L/ABP+PX/BQ742TXKvHrlx8VP26vjNqc/iaAo6RW+vt4dufC4uIbYGPyEtFtDiKFZmlXzQwB+/lFfgD/xDd/sHaJkfC342/wDBQT4JLD8ukp8Kf25vjRpS6DHKQ2oxaOPEN54nMMesytdT6mLo3LSTXt61u8CtEERf+CLP7VnwqLy/smf8F2/+Clvw5eFg2j6V+0l4g+G/7ZPhDREhUR2Om2Xhr4leGvC6voWnQhbW10ie/cfZY4I57uaZJbmQA/f+iv59Zrr/AIOV/wBlNN7af+wd/wAFUfAukwh3FjLr/wCxf+1F4oa1EhmTy7h9X/Z90abUYYl8hoRMkWozOHgjsYohJ2/wj/4L/fsiT+P9E+Bf7cvw8+OX/BMb4/6vMLGy8C/to+BL3wT8N/E1+kiRXN58Pv2gbM3Xwz8ReFY5JIorbxZ4j1HwhZahMzJY20iGCWQA/dOiqenahp+r6fY6tpN9Z6npep2drqGm6np11BeafqGn3kCXNlfWN5bSS293Z3lu8dxa3UEkkE8DpLDI8bB2uUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFUdT1Kx0XTNR1nU7hbTTdJsbvUtRu3WR0trGxt5rm7uGSJHkdYYIJJGWNHkYKQiM5AIB+Iv/BUL9r/9oTxT8Y/hb/wSd/4J1+I4tC/bJ/aO8Pz+NPjB8corKTU9K/Yh/ZIt76TSvFvxz1jy5EiT4keK5mk8MfBvQ2mgvZNcdNSa/wBE1e9+HuqXf6AfsK/sI/s8f8E7/gHonwE/Z78NzWthHNJrvj/4g+IpotV+J/xj+ImoEzeI/id8VvFrW8N54p8X+IbxpJ5Z59mnaRZNb+H/AA3Yab4dstO0uL8xP+Dfrwtd/Gb4LftGf8FWPiLaXs3xj/4KafH/AOInxPt7rWbiG71Lwd+zZ8M/G/iz4Zfs6fCPTgolOm6F4O8OaJqV1Z24vbqe9tdS0ubU7maeztlT+gOgAooooAKKKKACvLPjP8Dfgt+0d8Otd+Enx++FfgP4w/DfxHGE1rwP8RvCujeLPDd5JGkyW16NN1mzvIbbVLAzSTaVrFosOraVdlL3S723vI4px6nRQB/Ozff8Eff2sP2DJNS8Yf8ABEj9tHXvhF4WXUrnXbr/AIJ9/teX2vfG79i7Xg8z3dxoHw78Q6gL/wCK/wAAm1KdRPfat4d1rWdZ1u9eC01LxNpujRMq+p/s7/8ABbPwxpvxY0L9kj/gqV8D9e/4Jp/tcazNHY+DbD4o67Y65+y/8emDpaLq/wABf2k7Ly/BOptf3wWD/hFfEt9Y3llqt/pHg/SvEXibxdJe6fF+6deEftIfsv8A7O/7YPwo134H/tO/CDwX8Z/hj4h2yX/hPxrpKX1vb30Uc8Vrreg6jC0GseFfEmnJcTnSfFPhnUNM8SaS8skularbTM0hAPdUdJEWSN1dHVXR0YMjowBV1ZWIZWGCrAkEEEMRyXV/Nbd/sof8FR/+CPMcviX/AIJ2eN/EX/BRL9hnQWa81f8A4J5ftB+K2m/aR+EPhWDzpr2z/ZC+Pt1bSXXiTSNGsoYYfD/wk8aWeoNa6bZro/hPQfFPjnXLnXh+qX7B/wDwUz/ZL/4KJ+GdeuPgV4x1LRfih4BZ7L4z/s2/FHR5vAf7RnwR163vpNL1DRfiZ8MNWnOq6atlqkT6Z/wkGltqfhS51FJtNtddk1S3vrGIA/QCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK+Uf289SvtF/YR/bW1jS7hrTUdK/ZR/aP1LT7tFjd7a+sfgz45urS4VJUkjZoZ4klVZEeNiAHRlJU/V1Y3iPw9o3i7w54g8J+IrGHU9B8TaLqvh7XNNuFDQaho2sWF1p2p2M6nIaG7s7ueCVTkGNyD/FkA/Nb/AIIlafpem/8ABHz/AIJtW2kSWctrJ+yH8D7+VrGGWCAapqngrS9U1uN0liiY3kOsXd9FqMwUx3OoLd3EMs0Dxzv+oVfz8f8ABvT4i8Q/CP4BftK/8EvPihq1zf8Axa/4Jf8A7Sfj74IJNqUrvqnij9nz4ha1q3xU/Z2+JgWSx0+SHR/GPh7XddsfD1s1svkaDoGmuiw2s9rZx/0D0AFFFFABRRRQAUUUUAFFFFABX5Rft7f8EjPgL+2l4r0H9oXwJ4o8WfslftxfDqKOf4Sftq/ASRNA+KOi3lmhWw0T4labazWOm/Gf4fTIiadq/g7xjKbifw7Pqvh3RfEGj6ZqesQ3H6u0UAfzz/BL/gq98fP2M/ix4R/Y1/4LkeD/AAn8GPG/izUIfDnwD/4KE/D6G4tf2KP2nLiGKKOOx8U63dwWEH7P/wAWJow17rnh/wAUW2j+DnkXUNRjg8I+HpPCC6t/QpDLFcRRT28sc8E0aSwzQuskUsUih45YpEZkkjkTDo6syspDKxHzHyr45/Af4MftN/Cjxj8Dv2gPhr4V+K/wr8eaa+leK/A/jHTItS0bU7beJbe4jDbbnTNW0y6SLUdD1/Sbi013QtWgs9Y0PUrLVrW0vU/nV0vX/wBpP/g3f8V6H4a+Jnivx3+1F/wRY8SeINM8M+Gvidr41Xxh+0F/wTWvtd1OXT/Dnh3x1cWkE+p/Ej9luK4l07RNK14RS6v4NjkstG06xsNRtNC8M+MgD+oOiuZ8GeNPBvxI8IeGviB8PPFfh3xx4I8Y6LpviTwj4y8I61pviHwt4n8O6taxXmla74f17Sbq803WNJ1K0mhurHUbC6ntLm3kjmgmkjcNXTUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUVDcXFvZ2893dzw2trawy3F1dXEscNvb28MbyTTzzSuscMMMcbySyyOI441d3cKrMQDzLTfjl8FtZ+MfiX9nrSPiv4A1P43+DvB+kfEDxZ8ILDxdoV18SPDngbXL4ado/izXPB8F8+taZoeoXjwQW+o3dnFbs13pjFxHqGmvN6nX8F3/AAbzeNPHH7SX/Be79qX9u/xTrF7rsH7Z/wCwZ+0Z8c9OW7guLY+C/B8//BSHwp8EfhD4Chhv9moPp+kfDj9nXTU0KSZZni0OGytru5M6R7/70aACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP50/265x/wTi/4K+/sg/8FJ4Lh9G/Z2/ba03Rv+CeP7cE6xSf2H4b8e3Fxfa5+yX8dNfkDiCyaDW7N/ht4p8WarNbaP4X8AafHbxl9Q1iTzf6LK+Sf27/ANj/AOHn7fX7Hvx8/ZD+JzfZfDfxn8D3vh631xLO2vbvwl4ssrmDXfAvjjTra7ilil1HwX4v0vQvEtnEwXz5tPFs0qJIz18X/wDBFz9sj4m/tJfs3+MfgL+1Gq6V+2/+wh46n/Ze/a40Ge5nmvdb8S+Fop7XwD8bbN7q1sp9R8MfHLwrp3/CT6P4kW0g03xDrll4tvdERtGispGAP2GooooAKKKKACiiigAooooAKKKKACsHxT4W8MeOfDHiLwV418PaL4s8I+LNF1Tw34p8LeJNLstZ8O+I/Dus2Vxp2saHruj6jBc2Oq6Tqthc3FlqOnXsE1peWk0ttcwyQsytvUUAfy8fbPiD/wAG5nxg0bSrq88V/Er/AIImfHb4iQaXp1zfvrnifxh/wS8+KHjjXmWKG91WYXl9rX7Jfi/Xb8mJ7+4k1Xwhq1zKITd+N2kHxA/pz0TW9E8T6Jo/iXw1rGl+IPD3iDS9P1vQNf0TULTVdE1vRNVtIb7StY0fVbCe4stT0vU7KeC90/ULKea0vLSaG5tp5YJElbG8feAfBPxV8C+L/hn8SfC2i+NfAXjzw7rHhLxn4Q8R2EGp6B4l8M67YXGm6zomr6fco8N3Y6jZXM9vcQupzHISpDhWr+cX9lXxf42/4Ib/ALWvgj/gmr8e/E+seKv+CdX7U3jfVrT/AIJnftAeKLu+v7z4A/EzXNRk1C4/YU+LPiG+u7qSTS727vPN+BnifVJRdapcXM9ibi8tbvXdN8JgH9M9FFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV5/wDFn/kk/wAT/wDsn/jT/wBRvWK9ArB8VaEnijwt4l8MSXLWaeItB1jQnvEiEz2qarp15YNcrCzxiZoBc+asRkQOVCF1BLUAfw0f8GgDw/FD4vftCfEGxm/tHS/2dP2If2QP2arbVnhVov7U+IvxF+Onxz8SaLpV2Lq5RI9D1aGSw12ygaNl1WO3n1C0troor/3a1/Hv/wAGXfwIvvhz/wAE5v2h/i7r+kzaTr/xh/aq8Q6FDFd2LWt+/hT4SeBfBfh+xS98+GG7jmsfGmvfEPTpNPnBWxmt5mUpc3N5Ev8AYRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV/O1/wAFQfA3jX/gnV+1l4J/4Llfs/eE9Z8UeC9J8M6J8C/+Cpvwh8I6bFe6v8Rv2Vhf2UHhj9o/QtMjWJ9Q+I37NV1a6bNqd3I5utS+GtppmkX2t+GvAGh+N9Tl/olqjqemaZremajoutadY6tpGr2N3pmraTqdpb32manpl9by2t9p2o2F1HNbXtje2001td2lzHJb3FvLLBPG8TupAOU+GPxN+Hvxq+HHgj4ufCfxfovjz4cfEbwzo3jHwN4z8O3i3uh+JPDGu2MOoaTq+nXK4LQXdrNG5ilWO5t5C9teQRXUcsQ7mv5ePD2p+Jv+Ddb9oz/hBvFN1qmvf8EV/wBqX4mSyfDrxfdDUL+b/gmZ8dvGmoTXV74M8YX8Wnyhf2Y/ip4mvz/wjWtX93HbeB9RcLqDw6xa+Jte8Y/096dqGn6vp9jq2k31nqel6nZ2uoabqenXUF5p+oafeQJc2V9Y3ltJLb3dneW7x3FrdQSSQTwOksMjxsHYAuUUUUAFFFFABRRRQAUUUUAFFFFABXxn/wAFAP2Hvg7/AMFFv2Tfin+yn8aLR49F8caal74T8YWESnxL8MfiZopnvfAfxQ8IXO6OW017whrBhujFHPFBreiy614S1kz+HdZ1mym+zKKAPxV/4I0/tg/Gn4l+DPjN+wb+2ze2q/t6f8E9vE2kfCP41agbq4P/AAvD4YX+nR3vwS/af8OrqMNrf6npPxS8JLaya5qTwfaZ9fhTxPq1ro//AAlujaDF+1Vfzuf8Fk/Dmq/sRftBfsk/8FvvhbaXFtF+zr4k0L9nD9vnStIS5D/Ef9hH4z+L9P0C417WbGwhmuvEOqfAL4havpHjXwnp0ESyTX+pQ6jrF2dG8N28C/0I6NrGkeItH0nxDoGp2Os6Hrmm2GsaLrGmXUN7pmq6RqVrFeabqenXtvJJBeWN/aSxXVpdQSPDPbyRzRSPGwYgGlRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV86/tf/G23/Zo/ZI/ae/aKubq3tF+B/wF+L/xWhluRC8b33gT4f8AiXxNp1qkE4aO7uL6+0q2s7OwKSPfXk9vYwwzTTLE/wBFV+E3/ByR4z1/Qf8AgkH8fvh14Qkgi8ZftIeNfgF+zP4UlumC2wvPiz8cPBeka5HMWlgjC3PhG28R2sck9zb28E08d1NK8cUltIAfCX/BoV8RvGEP7Bfxt/Zb+LNrqek/Fn4FfGfwz8VbzRdbvYbzWD8Iv2vPg54B+O/wi8UaifPlvIbnxoL/AMY63JDqGb1C4S+kXVU1LT7f+sav5xPFHhPRf+CaX/Bc39knxlo0baP+zl/wUk/ZW0P9hjXpN8kGmeH/ANqP9ljTbXVP2dtY8QPEqW8tz4/+F6H4Q+CNPS3ln/tmPVrprm208SR1/R3QAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAcR8S/hp8PfjN8PfGXwn+K/g3w/8QPh18QPD+p+FfG3grxVpltq3h3xL4d1a2ktdR0rVdOuo5Ibi3uIZGwSBLDL5dxbyR3MUUo/mx0Dxp8ff+DdnxdZfDn4sDx9+0T/AMEWPE3iaDTPhZ8areDXPHPxr/4Jt3XiPVbe20z4dfGVIxNqXjP9lyz1G5Nl4P8AGsaXWv8AhSC4t/Djfatb/wCEV8H67/ULWTr2gaD4q0PWPDHijRNJ8R+HfEGm3uja94f17TbLV9D1vR9RtpbTUdJ1jSdQhubHU9N1C1lltr2wvYJrW6tpJYLiKSJ3VgDG+H/xB8B/FjwR4X+JXww8Y+G/H/gHxpo9n4g8I+NPCGtafr/hjxJod/H5lnqui6zplzdWOoWc6Z2zW87qHDRuRKrAdfX85fjD/glz+2T/AME4vGXiz45/8EOvid4fg+G/iLWLzxf8TP8Aglf+0Dq08v7NXjPVrl7u41m9/Zs8dXNzBqH7O3jDWD5IsdGk1Gy8C3urNaHxD4msvBWkaR4OT6R/Za/4Ln/se/GfxzYfs8/tL2vi7/gnz+2HG0Fhrn7L37X1hN8OtTutYlu5tPgHwx+KOt2uk/D74raLrd9byReD73R9TsPEXiiEw3Fj4Qi86OIgH7R0UUUAFFFFABRRRQAV+UXjf/goZ8QNU/4K0fB//gnB+zp8MPC/xV8PeFvhH4r+M37enxNu9cv7Kb9nPw3remG2+A/h/TZ7OWTS5/HnjbXlttR1DwXqtrdazfeCtZ0TXdLj0/Sota8Q2/tP/BSb9vLwF/wTl/ZL8d/tDeKdNbxh4yabT/AfwH+EGnTn/hKPjf8AHvxjNLpXw2+F3hewgMmpX8+sasV1DxBJo9pf6npHgzTvE3iK20y+k04WUniH/BH79hnxz+x1+zl4l8e/tH6lD4v/AG3/ANsDxtfftIftqfENmguLq9+Kni17q+0n4Y6ZdwyXEFv4M+CeiagPBXhrRNJuX8KWOpjxXq3hK2stH1qOyQA/WOiiigDyT4+/BfwX+0h8CfjJ+z58RbUXngf41fDTxz8LfFkIiilmGg+N/DOq+G9RubRZlZI7+zt9Ta80244ktdQhtrqGRJ4kkr8nv+Dfn4z+N/Gv/BPbT/2bPjLeW83x7/4J4/Ff4mfsC/GWCKeYl9Q/Z+1pNC+H+q2sF4kd9JpF98MbvwfZWGsTo0Gt3umavfW0u/7RZQft5X8/37Krwfs+f8HEX/BT74DhhY6R+2f+yd+yj+3P4Q0gIbfToNV+Feoa3+zV8TL7S41UQS6j4o124sdc8QSbje3d1AblkaKGeZQD+gGiiigAooooAKKKKACiiigAooooAKKKKACiiigAr8Av+C6CyeOviP8A8EUPgBEyvb/Ef/gr3+zP488RWWwh9V8GfA7QfiD438R6Y88sltBb2s/2mwluWivYdZZooRpEF44u7Rv39r8A/wDgpkx8Q/8ABaH/AIN0vhtP8ljqnxN/4KO/EySeU/abRdQ+EX7Jfh/W9LgfSXKQz3l1LrMqafrDTrPoUgluba2unneNQD6j/wCC0P7HPjb9tH9gP4jeGfgu89l+0v8AA/xB4P8A2pP2TNd09R/bmj/tEfArVZfGHg638POyskOt+MNOi13wDpc85W0tb7xNbahdSJFbGSvov/gnj+2R4O/4KB/sU/s9ftc+DY7Oxi+LXgPTdS8V+G7O5a4XwT8S9Kkn8P8AxN8CSPLLJck+EPG2la3oltNeCO6vtOtrPVGhSO7jNfZ1fzlfsiXMH/BMX/gsZ+0t+wHrMUPhv9mH/gpJNrv7b/7ENzK5tfDvh/8AaJsrOw0/9rX9n7SGmlS3j1LWmsLP4r+FvDml21ro/h7whb6ZpNp9p1bVhGQD+jWiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK+cP2m/2Pv2WP20Ph/N8MP2q/gL8N/jj4OfzXs9O8eeGrPUr/QrqYKsupeEfEcaQ+I/BesOiCP+2/CeraVrAgLwLfCF5Eb6PooA/nfT/gj1+2v+xbGb3/gkL/wU2+Jfwx8GabhtK/Yz/bes5/2mP2W47KNrJLbwl4I8XX0B+KnwP8L28dmssj+F/wDhJfENzM9xAusWtvc3JNkf8FYf+Cjn7I8s2k/8FNP+CR3xeuvDWlQu1/8AtQf8E5dTT9p34N30CzTxSeIdW+FV9d6T8TvhZ4Ztlt5Jbq48WatqWsRQPazPo6rPCD/QvRQB+NPws/4OEf8AgjD8W7NZtL/b0+E/gbUY5Li11Pw78aYPF/wT8Q6LqNpNHb32l6rYfFbw74SSK8srhzBK1tcXNnLJFdNZ3dzDb3Ey/S//AA9k/wCCUf8A0k5/YA/8TS/Zq/8AnoV9H/E79mP9mb43XX2340fs7fA/4t3n7n/S/id8I/h747uv9HtprO3/ANI8VeHNXl/cWs81rD8/7q2lmt4yInkVvnD/AIdNf8Eo/wDpGN+wB/4hb+zV/wDOwoAo6l/wV1/4JN6VY3GoXX/BTb9g6WC2VWkj039r79n3WL5g0ixj7PpmkfES+1G7YMwLJa2szpHulcCJXkHxj8R/+DjH/gmZpuqS+Af2ZvFnxZ/b4+N9yoTw98Df2LPgl8Sfi14r125mE8drJH4nOhaL8P7fTVuIlGo3Ufiy71Gys2e+i0a7SMRv91ab/wAErv8Aglrot9b6no//AATX/YO0rUbRme11DTf2OP2crG+tneN4ne3u7X4aRTws8bvGzRyKWjZ0LFWbP2H4K+H/AIA+GujDw58OPA/hHwDoCzPcLoXgrwzonhfRhcSBRJONL0OxsLMTSBFDy+T5jBVDOdoyAfhz+yV+xL+1h+15+1f4R/4Kd/8ABWHwt4X8B+LfhbZ30H7CX7A3hzxDaeOPBf7JVhrf2OTVPix8VPFUFlBpfxD/AGlNdWzgWHVNPV9E8GW8dpqNklp4jg8MeHPCn76UUUAFFFFABX4AftmKvw+/4OIf+CJ3jGw/c3n7QP7P/wDwUi+A+vSWiRC4vND+FXws8J/G3SrTV5HSN20u31e/lurBIpp5E1RnJtoYXnuX/f8Ar8Af+CiP/Kez/g28/wC8wn/rFvgOgD9/qKKKACiiigAooooAKKKKACiivyn/AGv/APgtH/wT6/Y08WD4SeJfipqXxu/aOvro6V4c/ZR/Zc8M6j8d/wBojxB4kZ2SDwu3gvwS91ZeENduiFe00/4g634Ylu4nRrEXDvAkgB+rFfh78fv+CztrqXxr8Ufsjf8ABMH9mvxV/wAFKf2nPByvbfEyT4deMdA8C/svfAK+ke6tIYPjV+0lr0V54PtNetbiCWU+BfDjX2q6jPYaz4WfWtJ8XWk+mR/kP+1V+39/wWo/4KP/ALQHgT/glT8D/wBlmz/4JfR/tV/CDxh8WvEvxV+K3xDHjf8Aah8B/sm6Fr194Y1b4l+IPDPgO80dPgLL8Qtesrr4Y2HhK6tdY+JEmu3wttN8TeGNOuIPHS/VP7L/APwatfsv/Cz4OeHPgz+0v+17+2B+078P9JEsuo/AvRfijrX7PH7KeqahelZNY1Z/gr8LdT/tuTXNck3JrfiTU/iXqOv6vapYw6jfyPaQS0AeGfGL4yftX+J7zUJf+Clv/ByB+xh/wTwsruQS6n+yP/wT6ufhXc/E3QNMmjYQRyfHD4geJtX+N+la5bRQzQ6jJo3hXVvDtxq8ks+lXsdvDYWbfC+qeJv+DW3WL+4034l/8FFf+Cm/7d+tab5X9veIPFfxP/4KB/Ep7DUpYUl0/WdS13wJ8Kvh9oFzqGoifWmtJ9Ge7sluLrxNb3NtbzLbwx/1s/BH/gkX/wAEtf2crGzs/hB+wL+zB4fuLGNIrfxFrHwg8JeOPHAjjKlVm+IHxA03xR40ussqu5utelaSRUkkZ5FDD7e1fWPht8HPA2oa7r+reCfhZ8OfB9jNfaprGr32geCvA3hfTDcF7i81DUL2bS9D0OxNzOXmuLma3tzcTFpJDLIWYA/ip+Btj/wQ2+KHxCsvBn/BPv8A4OAf+Cgf7HfxxudR0zSdA8G+N/2hvjp4Q8Cap4v1W6ey07wt4l+Hn7W3wu8L+Hvidqj3DWmhWnhGx8ZvJc6pb6HDbLdanJbvP+wn7O3/AATM/wCCid/+35+yr+1f+3/+3X8If2s/BH7DXgX9obSf2YNe8C/A5PhF8VvGXiX9ozwfoXw+8V+JvjDo+hXN14DtobTwPpfk2D+FdR1GW91EWdxckOb/AFCbwn9uL/go9+yX/wAFI7Hxl+xN+wb+w34Z/wCCxPxVvLW/8Nal441nwRYD9iH4CahdxTp/wlvj79qHxAulW1ldaPFLF4g8Pn4M68ms+IJIlsPBXxC0/wAXvpsT/sb/AMEwv2TfiD+wn/wT+/Zf/ZI+KfxXn+M/jz4LeAZfDniT4gPPqtzYXV5f+Jte8SQeGPDM+tRw6rL4J+HVlrNr8PPAD6jaWF4fA3hzw95+jaXIDpEIB94V+S//AAWY/Yt8dftffshjxP8As/XUmiftgfsj+OPD/wC1j+xz4osbbztVT41/CZrrXLfwFGFlt3utO+LGjxX/AIJm0u6uo9El1++8LaxrsN1Z6Otuf1oooA+Kf+Cdv7a/gH/god+xt8FP2r/AcEekH4g+G4ofHnglrh57/wCGvxY0F20b4mfDbVfPjhvBc+EfFVpqFhZXN9a2lzq+h/2R4iWyhtNStlP2tX82lu0P/BHH/gr9PbXEg8P/APBPr/gsR40aawlcR2Hgj9nj/gpdbWsstxYu5kSw0PQ/2sNDtXmtiMXes/ESFLeO3sPCng28vH/pLoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvwE/aUC/E3/AIORv+CYvgiA/a5/2Zf2F/21f2jr+3kH21NJsPjHq/hn9n2z1W2tnLLodxqF5p8mmTazAsc+o24/sWWV4FMdfv3X8/37JUq/Hv8A4OHv+CqHxytALvQv2Rf2Uv2Sf2GtC1ty9xDd6v8AEHUdd/aQ+IOjaLcyxObNPDHiC3tdP8SaZazQQDWJLS8ntri4kW6AB/QDRRRQAUUUUAFFeVfGj46fBT9nD4e638V/j98V/APwe+HXh6Ezax41+I/ivRfCfh21O1/JtV1HWr2ziutRvXTyNN0mzM+qanePDY6bZ3F7LDC/4i3n/Bc7xZ+1JrN94J/4I8/sF/Hb9vq4trq6068/aP8AGNvP+zL+xToVzbssV3LH8Y/irplnqvjbUtGcST3vhHSPDWlajrFssDeFdW1EXKSqAf0H1+Kn7b3/AAXa/Y0/ZF8e6j+z18No/E37Y37XEDXdoP2bP2dG03XL3wlqNr5y3Uvxu+KF1cjwB8E9F0VoWn8X3PiXUrrxL4V0ndr2r+DxoqPe1+BHwV8Y/wDBd/8A4LSfthfF34CX37fngf4Efsa/AvVLfwd+1R8Vv+Cf/hm+8M/DCXxletjxN+z7+zh8dvFul6l8Sviv8RdP0SY2Hi3xv/wkg+GXgrUJLnXrOz8TaBefD0+J/wBevgp/war/APBE74Oizuta/Zy8XfHXXrNoJB4j+OPxl+JGuT3c8UiSyXGo+GfBmseAvAeotdyIHuorzwjLauGliS3SCSaJwD87vGfx78Uft0Xr3v8AwVk/4Ldfsff8E8/gPqjSwr/wTx/YH/bJ+Dknxi1LSb2C5Q6N+0t+0tpvi7XdavlmgS40zxR4Y8E6be/DfxFaTAWs2gawPKr95/8Aglt8If8Agj18Ovhprv8Aw6fsv2WNa8N6JLY+G/H3jj4FeLPDPxM+IL3jQtPp2lfFP4lSa14n+Id7cXcdpJqOlaf40114pYhNqGj2gtpJJm+Dv2yLb/ghR/wS803Rvhh4G/4Jz/sjfG39sP4jLbeGPgN+xt8Hv2bfg34//aa+LHiLWEtTollrUtx4K8TeJ/A/gG4NlBrGseN/G0i6S2nadrGoeHLDxJ4pt10Kf3r/AII1/wDBOP4n/sn6t+1L+1/+0t4T+D/ws/aX/be1z4f6t4q/Z6/Zx8OeHfCfwC/Zw+GHw10nVdL+Gfwk8L6b4U03TdH8S+MNOstbu5PiL46Av49b1qK1On6pqFwPEHivWAD0L/goD/wT1/aN+KX7SXwd/wCChX/BPj48+BfgL+258GfhjrnwKvrf4y+FNV8W/AD9ob9n3W/GEXjhvgz8YrbQI5/FfhnSdF8XG88T6J4p8FW8+vW9/fXirBHqEWga9pvg0H7cH/Bwn4Fs4NA8Zf8ABCX4RfHbxFaNJDqHxC+CH/BT34EfC/4faw0CwxG80bwX8Y/CGq+M9Jtb6VJ7u0g1TVbq7hs5re1vQl3BNJJ/QBRQB/PrpPjn/g5W/ak0HU9Jh+BP7Cn/AAS80++1CO0m8YfEP4j6n+2B8ddD0nzLOb+0fAfhb4cyyfBTU9QBhube6l8e6oLaWyuWtrTw9b36w6/Fp+F/+CAfwi+KvijSviX/AMFQP2sP2mf+CoPxB0q+tNV0/wAO/Gzxhc/DX9l/w9q1pLHcR33gz9mD4WahpvhXRYbmcSHUtC1jXfEPhfUrZorS/wBCmRbh5v33ooA4f4cfDL4a/BvwVofw3+EPw+8F/DDwD4bt2tPDvgb4e+FtC8H+ENDtWkeZ4NI8OeHrDTtK06OSZ3mlW1tIxLM8k0m6V3c9xRRQAUUUUAfIP7eX7GPws/4KB/snfF39lP4tJLaaL8RdDH/CO+L9Pt4ZPEfw3+IejT/2r4C+JvhKeQCSz8QeC/EVtYarbGGWEajYrqPh6/lbR9T1O3k+I/8Agjt+2j8WfjH4C+KP7FH7aN5a6f8A8FBf2CtesvhH+0RaT3pe5+MHg1baN/hN+1L4XE8NrLrHhn4xeF20/UNW1W3hUjxSbjVdQ07Q7TxF4a0Ufs1X4V/8FcP2PfjTpPi74X/8FY/2ANAF1+3P+xtpd8nij4eWDT29n+2T+yU0l5qfxP8A2ZvF9rZWtzPreuRWYvPEvwluEt73VbDxQt1ZeHtMuPGlz4C1fSQD91KK+V/2Kf2x/gf+33+zL8Mv2p/2fdfbWPAfxG0nz3069EUHibwV4qsJDZeK/h7420yOaY6P4u8G6vHPpOsWfmS2lwUg1nRby/8ADt/o+r3P1RQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBxXxK+IXhT4R/Db4g/Fjx3qK6R4K+GXgrxZ8QvGWrOE2aZ4U8HaBqXiPxDqLiSWJNtjpWlXd0weWNMJhpUG56/Fj/AIN4vAHi2f8AYN8Sftl/FPTbjT/jF/wUl/aH+Nv7cXxAtrzDS6ZpHxO8Y3emfC3QtMlEUI/4RiH4ceGvDviHw1bRRpbWtp4juEtYo4WEYT/g4S+JXiq5/Yl8KfsN/CS9mi+O3/BTH44/DH9jH4cxWaLNcaZ4S8aeI7TVfjb4z1O2a5th/wAIloPw20rV9E8U3zSiHT4vFGm3N3tsxcTr+0nwv+HPhT4OfDH4c/CHwHYtpngr4XeBvCHw58G6azo7af4U8FeHtP8ADPh2xZ0ihR2tNK0y0gLpFGjFMrEinZQB3NFFfhP+05/wWK1zxN8aPFP7D/8AwSW+C8H7d/7Ymg7dN+Ifi+21Z9O/Y3/ZVublr23OsftEfGexu4tO1LVNGmtZ2m+F/gvVF8R6rqGn6x4Nj8Qad4/spPCsoB+ufx7/AGifgN+yx8Mte+Mn7Rvxb8C/Bv4a+HIXl1Xxj4/8RafoOlCZYZ5odM00Xc6XWua7qAt5ItI8OaJBfeINZu9lho2mXl9JFA34YD/gqP8At/8A/BSO7Phf/gjX+ybceDvgfqVwLK8/4KY/tx+Hdf8AAHwXbR5JWiuPEX7OfwGmS2+IPxvuHtDLceG9f1a2s/DVj4ksxoXj/wAJWdhO2oj0/wCAH/BEfQ/GHxK8O/tXf8FafjTqn/BSH9qvTNuo+HNE8eaeun/sffAW9uJlvptB+BX7PC29t4XurPS7g/ZovFHjjSbq61t7XT/FEnhPRPFKyXY/eGGGK3iigt4o4YIY0hhhhRY4ooo1CRxRRoAkccaAKiKAqLhVGByAfhV8Fv8Aggt+z/d+PdH/AGgf+CkHxg+KH/BVD9pawknvLfxj+1LNC/wG8F3d1PBcXVh8H/2VNNu734XeA/C8ktulwvhjVYvFOmwX0lzfaelk0kcEcH/BwV8Z/jF+zh/wTg0/wt+z0vjD4Y+GPjH8Z/hP+zf8aPjb8JPAXiHxRq/7LH7MHjiHxPH8Uvi3oHhLwHpt5rdtJp+iaHbeBNEm0SxtrjTr/wAV2S+H9W0vxc3ha4P7wUUAfy6/sr/8FT/gR8D/ANn74afso/8ABHb/AIJM/wDBQj9qD4Z/C3w7FoXhDxNafBJ/gN8D9UvZGuL/AFTW/GPx0+LzaO03jbxjrlzd+I/Fesal4NSfVdW1DVNYRWUfZK9tuPg5/wAHB/7eS3Ufxs+P3wP/AOCRHwT1aOW3ufhh+zBa2f7R/wC2Bf6TcJafa9H8RfH7Wriw+H3gHU1DXA0jx38Gzb6xp08QWXR7qJ1u3/odooA/Ov8AYY/4JV/sSf8ABPG01fU/gF8MJtU+LHixri5+I/7Sfxa1m4+Jf7SHxM1O9bzNU1Lxf8VPEEB1KBdYn/0vVNA8J2/h3wfc6gZNS/4RtdRlubl/0UoooAKKKKACiiigAooooAKKKKACiiigD+Zf9qLwr4n/AOCG37ZHiT/go58FfDeran/wTb/av8ZaRb/8FJ/gn4S0+91CL9nn4ua/fx6Rov7cfw68LaejeRoms6lc2dh8cdK0e2e7v5Lhr2Ox1O/1Hwv/AGH/AEkeE/Ffhfx74V8N+OPBHiHR/FfhDxdoek+JvCvijw9qNpqugeIvDmt2MGpaNrmi6rZSz2mpaXqthcQXthfWsslvc2s0U8MjxurFvi7wj4W+IHhPxN4E8ceH9J8V+D/GOg6v4X8WeF9esbfUtD8Q+G9d0+50vWtE1jTrqOW3v9N1XT7q4s760nR4Z7aaWKRWRiK/m3/Zi8a+KP8Aghd+1v4b/wCCdPx68Taxq/8AwTZ/ai8Z6m//AATe/aC8X393d237OXxQ167u9Y1b9h34reKtQkMdvoep3z3N/wDA3XtWuvtNyss1pcXWoR3viceGQD+mqiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKK8a/aN8f678J/2dPj78VPC8enzeI/ht8Gfin4/8PRatbzXWlS674Q8CeI/EOkx6na29zZz3OnyX2mWy3tvDd2801sZYormGRvOAB+IPwhkj/wCCg3/Bf/42/G9nttZ+Av8AwR7+E9z+zL8KLhRbXmm6n+2p+0FbLqH7QPibSLxorhYtQ+G3gDS4/hL4x0oNbXmn6/HoV3FcFXv7dv30+IHxB8B/CfwR4p+JXxP8Y+G/APgHwVo954g8X+NPF+tafoHhjw3odhG0l5qutazqdzbWOn2cCL881xOilykalpXQH8Y/+DcDwPovh3/gj5+zP8RYpNQ1Tx5+0fffFH9o743eM9avDfeIfiF8ZfiN8TPEy+KfGev3vlxC5v7qx0XRNHik8vzBpek6alzLc3i3N7L8PftM6YP+Cmf/AAcAap/wTV/ar1LWtf8A2LP2Tv2ffh9+0zo/7PXhjWdR8N+BPjb8WdWHhjVLK/8A2kbSK4vJ/idoHhe71ov4b8KQTaFoFvFZwW+p2Wo2+oeLE1IA7PUfjF+2B/wX+13VPBP7JXiz4m/sW/8ABI6y1LVPDvxE/a6tdNvvBv7TP7dVrYXtxpmveDv2ZtO1myXUfhb8Fb2a3vtH174kazaprWtQtNompaRLNF49+E0X72fsqfsj/s3fsP8AwW8N/s/fss/Cfwz8JPhl4bUSQaJ4etpGvta1d7e2tr3xT4x8Q30lzrvjTxdqsVnarq3ivxPqGpa9fR29pb3F+1rbWsKe86HoeieGNE0fw14a0fS/D/h7w/pen6HoGgaHp9npWiaJomlWcNhpWj6PpVhDb2WmaXpllBDZafp9lBFZ2dnFDa20McEaLWpQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV8yftifsh/Az9u39m/4l/su/tD+GP8AhI/h18SNHaynmtHhtfEnhPxBatJdeGfH3gjV5ra8/sLxp4M1YW2t+HNV+z3Fsl7biy1aw1HQrrVdIn+m6KAPy8/4JWaD/wAFAPhV8HviF+zN+31bQ+Otb/Zs8dL8NvgT+1fBruh3dz+1f8BE0qG+8C+PvFfh201jUtd8N/ELwrp8kPhDxzJ4kigvdb1K1g1GXUPEGtp4j8Y6h+odFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAH/9k=' /></td></tr>");
        sb.Append("<TR style='text-align:left; font-size:12pt;background:#9A9999'>");
        //am getting my grid's column headers
        string[] Headers = new string[] { "Sr No", "Blase Order no", "Order Date", "Site Number", "Site Name", "Customer Id", "Customer Name", "Order Type", "Order Source", "Sales Man", "Created By", "Created By Name" };
        int columnscount = Headers.Length;

        for (int j = 0; j < columnscount; j++)
        {      //write in new column
            sb.Append("<Td>");
            //Get column headers  and make it as bold in excel columns
            sb.Append("<B>");
            // sb.Append(GridView_Result.Columns[j].HeaderText.ToString());
            sb.Append(Headers[j]);
            sb.Append("</B>");
            sb.Append("</Td>");
        }
        sb.Append("</TR>");

        string SearchString = string.Empty;
        SearchString = (Session["OrderSearchString"] != null) ? Session["OrderSearchString"].ToString() : "1=1";
        IList<Order> objOrderList = null;// new OrderFacade().GetOrderSearch("CREATED_ON DESC", 0, 0, SearchString);
        int serialNo = 1;
        foreach (Order row in objOrderList)
        {//write in new row
            sb.Append("<TRtext-align:left; >");
            sb.Append("<Td>");
            sb.Append(serialNo.ToString());
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.BLASE_ORDER_NO);
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.ORDER_DATE.ToString("MMM dd, yyyy"));
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.SITE_NUMBER);
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.SITE_NAME);
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.CUSTOMER_NUMBER);
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.CUSTOMER_NAME);
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.ORDER_TYPE);
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append((row.OrderType.Length == 0 ? "App Order" : row.OrderType) + "\t");
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.SALESMANNAME);
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.CREATED_BY);
            sb.Append("</Td>");

            sb.Append("<Td>");
            sb.Append(row.CREATED_BY_NAME);
            sb.Append("</Td>");

            sb.Append("</TR>");
            serialNo = serialNo + 1;
        }
        sb.Append("</Table>");
        sb.Append("</font>");
        HttpContext.Current.Response.Write(sb.ToString());
        HttpContext.Current.Response.Flush();
        HttpContext.Current.Response.End();
    }

    private void SalesmansActivityReportExcel(string strFileName)
    {
      //  strFileName = strFileName.Replace("Salesman", "Merchandiser");
        System.IO.StreamWriter sw;
        try
        {
            string UserCode = SessionManager.UserCode;
            string SortExpression = "AttendanceDate ASC,CustomerCode";
            StringBuilder strFileContents = null;
            int MaximumRows = 1000000;
            int StartRowIndex = 0;
            string RegionCode = Session["SalesmansAcitvityReportRegion"] != null ? Session["SalesmansAcitvityReportRegion"].ToString() : "";
            string RouteCode = Session["SalesmansAcitvityReportRoute"] != null ? Session["SalesmansAcitvityReportRoute"].ToString() : "";
            string SalesmanCode = Session["SalesmansAcitvityReportSalesman"] != null ? Session["SalesmansAcitvityReportSalesman"].ToString() : "";
            string CustomerCode = Session["SalesmansAcitvityReportCustomer"] != null ? Session["SalesmansAcitvityReportCustomer"].ToString() : "";
            string StartDate = Session["SalesmansAcitvityReportStartDate"] != null ? Session["SalesmansAcitvityReportStartDate"].ToString() : "";
            string EndDate = Session["SalesmansAcitvityReportEndDate"] != null ? Session["SalesmansAcitvityReportEndDate"].ToString() : "";
            string SearchString1 = Session["SalesmansAcitvityReportChannel"] != null ? Session["SalesmansAcitvityReportChannel"].ToString() : ""; ;
            string SearchString2 = Session["SalesmansAcitvityReportSubChannel"] != null ? Session["SalesmansAcitvityReportSubChannel"].ToString() : ""; ;
            string SearchString3 = Session["SalesmansAcitvityReportRSM"] != null ? Session["SalesmansAcitvityReportRSM"].ToString() : ""; ;
            string SearchString4 = Session["SalesmansAcitvityReportSupervisor"] != null ? Session["SalesmansAcitvityReportSupervisor"].ToString() : ""; ;
            string SearchString5 = Session["SalesmansAcitvityReportChain"] != null ? Session["SalesmansAcitvityReportChain"].ToString() : ""; ;
            string SearchString6 = "";
            strFileContents = new StringBuilder();
            IList<SalesmansAcitvityReport> lst = GetSalesmansAcitvityReportSearchAll(SortExpression, MaximumRows, StartRowIndex, RegionCode, RouteCode,
                SalesmanCode, CustomerCode, StartDate, EndDate, SearchString1, SearchString2, SearchString3, SearchString4, SearchString5, SearchString6);
            //strFileContents.Append("Depo Code \tDepo Name\tRoute Code \tRoute Name \tSalesman Code \tSalesman Name \tAttendance Date\tEot \tStart Time\tEnd Time\tEot Status \tCustomer Code \tCustomer Name \tVisit Date \t Check In Time\t Check out Time\t Duration\tVisited\tJourneyPlan\tOrder Volume\tOrder Value\tMSL Sold\tNPD Sold\tPerfect Store\tPerfect Point");
            strFileContents.Append("Depo Code \tDepo Name\tRoute Code \tRoute Name \tMerchandiser Code \tMerchandiser Name \tAttendance Date\tEot \tStart Time\tEnd Time\tEot Status \tCustomer Code \tCustomer Name \tVisit Date \t Check In Time\t Check out Time\t Duration\tVisited\tJourneyPlan");
            strFileContents.Append("\n");
            int i = 0;
            int Precision = 0;
            foreach (SalesmansAcitvityReport obj in lst)
            {
                Precision = obj.Precision;
                strFileContents.Append((obj.RegionCode != null ? (obj.RegionCode != "" ? CommonFunctions.GetStringValue(obj.RegionCode) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.RegionName != null ? (obj.RegionName != "" ? CommonFunctions.GetStringValue(obj.RegionName) : "N/A") : "N/A") + "\t ");

                strFileContents.Append((obj.RouteCode != null ? (obj.RouteCode != "" ? CommonFunctions.GetStringValue(obj.RouteCode) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.RouteName != null ? (obj.RouteName != "" ? CommonFunctions.GetStringValue(obj.RouteName) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.SalesmanCode != null ? (obj.SalesmanCode != "" ? CommonFunctions.GetStringValue(obj.SalesmanCode) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.SalesmanName != null ? (obj.SalesmanName != "" ? CommonFunctions.GetStringValue(obj.SalesmanName) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.AttendanceDate != null ? (obj.AttendanceDate != "" ? CommonFunctions.GetStringValue(obj.AttendanceDate) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.EotDate != null ? (obj.EotDate != "" ? CommonFunctions.GetStringValue(obj.EotDate) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.StartTime != null ? (obj.StartTime != "" ? CommonFunctions.GetStringValue(obj.StartTime) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.EndTime != null ? (obj.EndTime != "" ? CommonFunctions.GetStringValue(obj.EndTime) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.EotStatus != null ? (obj.EotStatus != "" ? CommonFunctions.GetStringValue(obj.EotStatus) : "N/A") : "N/A") + "\t ");

                strFileContents.Append((obj.CustomerCode != null ? (obj.CustomerCode != "" ? CommonFunctions.GetStringValue(obj.CustomerCode) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.CustomerName != null ? (obj.CustomerName != "" ? CommonFunctions.GetStringValue(obj.CustomerName) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.VisitDate != null ? (obj.VisitDate != "" ? CommonFunctions.GetStringValue(obj.VisitDate) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.CheckInTime != null ? (obj.CheckInTime != "" ? CommonFunctions.GetStringValue(obj.CheckInTime) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.CheckOutTime != null ? (obj.CheckOutTime != "" ? CommonFunctions.GetStringValue(obj.CheckOutTime) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.Duration != null ? (obj.Duration != "" ? CommonFunctions.GetStringValue(obj.Duration) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.Visited != null ? (obj.Visited != "" ? CommonFunctions.GetStringValue(obj.Visited) : "N/A") : "N/A") + "\t ");
                strFileContents.Append((obj.JourneyPlan != null ? (obj.JourneyPlan != "" ? CommonFunctions.GetStringValue(obj.JourneyPlan) : "N/A") : "N/A") + "\t ");
              /*
                strFileContents.Append(obj.OrderVolume + "\t ");
                strFileContents.Append(obj.OrderValue + "\t ");
                strFileContents.Append(obj.MSLSold + "\t ");
                strFileContents.Append(obj.NPDSold + "\t ");
                strFileContents.Append(obj.PerfectStore  + "\t ");
                strFileContents.Append(obj.PerfectPoint + "\t ");
            */
                strFileContents.Append("\n");

            }
            strFileContents.Append("\n");

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    public IList<SalesmansAcitvityReport> GetSalesmansAcitvityReportSearchAll(string SortExpression, int MaximumRows, int StartRowIndex, string RegionCode,
           string RouteCode, string SalesmanCode, string CustomerCode, string StartDate, string EndDate, string SearchString1, string SearchString2, string SearchString3,
           string SearchString4, string SearchString5, string SearchString6)
    {
        IList<SalesmansAcitvityReport> lstSalesmansAcitvityReport = new List<SalesmansAcitvityReport>();
        SalesmansAcitvityReport objSalesmansAcitvityReport = null;
        FinalResult objFinalResult = new FinalResult();
        try
        {
            DbParam[] param = new DbParam[16];
            DataTable dt;
            DataSet ds;

            param[0] = new DbParam("@sortExpression", SortExpression, SqlDbType.VarChar);
            param[1] = new DbParam("@maximumRows", MaximumRows.ToString(), SqlDbType.Int);
            param[2] = new DbParam("@startRowIndex", StartRowIndex.ToString(), SqlDbType.Int);
            param[3] = new DbParam("@RegionCode", RegionCode, SqlDbType.VarChar);
            param[4] = new DbParam("@RouteCode", RouteCode, SqlDbType.VarChar);
            param[5] = new DbParam("@StartDate", StartDate, SqlDbType.VarChar);
            param[6] = new DbParam("@EndDate", EndDate, SqlDbType.VarChar);
            param[7] = new DbParam("@SalesmanCode", SalesmanCode, SqlDbType.VarChar);
            param[8] = new DbParam("@CustomerCode", CustomerCode, SqlDbType.VarChar);
            param[9] = new DbParam("@SearchString1", SearchString1, SqlDbType.VarChar);
            param[10] = new DbParam("@SearchString2", SearchString2, SqlDbType.VarChar);
            param[11] = new DbParam("@SearchString3", SearchString3, SqlDbType.VarChar);
            param[12] = new DbParam("@SearchString4", SearchString4, SqlDbType.VarChar);
            param[13] = new DbParam("@SearchString5", SearchString5, SqlDbType.VarChar);
            param[14] = new DbParam("@SearchString6", SearchString6, SqlDbType.VarChar);
            param[15] = new DbParam("@UserCode", SessionManager.UserCode, SqlDbType.VarChar);

            ds = Db.GetDataSet("sp_SalesmansAcitvityReport_SELALL_Export", param);

            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    objSalesmansAcitvityReport = new SalesmansAcitvityReport();
                    if (row.Table.Columns.Contains("Precision"))
                    {
                        objSalesmansAcitvityReport.Precision = Db.ToInteger(row["Precision"]);
                    }
                    if (row.Table.Columns.Contains("SalesmanCode"))
                    {
                        objSalesmansAcitvityReport.SalesmanCode = Db.ToString(row["SalesmanCode"]);
                    }
                    if (row.Table.Columns.Contains("SalesmanName"))
                    {
                        objSalesmansAcitvityReport.SalesmanName = Db.ToString(row["SalesmanName"]);
                    }
                    if (row.Table.Columns.Contains("SalesOrgCode"))
                    {
                        objSalesmansAcitvityReport.SalesOrgCode = Db.ToString(row["SalesOrgCode"]);
                    }
                    if (row.Table.Columns.Contains("SalesOrgName"))
                    {
                        objSalesmansAcitvityReport.SalesOrgName = Db.ToString(row["SalesOrgName"]);
                    }
                    if (row.Table.Columns.Contains("CustomerCode"))
                    {
                        objSalesmansAcitvityReport.CustomerCode = Db.ToString(row["CustomerCode"]);
                    }
                    if (row.Table.Columns.Contains("CustomerName"))
                    {
                        objSalesmansAcitvityReport.CustomerName = Db.ToString(row["CustomerName"]);
                    }
                    if (row.Table.Columns.Contains("ChannelCode"))
                    {
                        objSalesmansAcitvityReport.ChannelCode = Db.ToString(row["ChannelCode"]);
                    }
                    if (row.Table.Columns.Contains("ChannelName"))
                    {
                        objSalesmansAcitvityReport.ChannelName = Db.ToString(row["ChannelName"]);
                    }
                    if (row.Table.Columns.Contains("RouteCode"))
                    {
                        objSalesmansAcitvityReport.RouteCode = Db.ToString(row["RouteCode"]);
                    }
                    if (row.Table.Columns.Contains("RouteName"))
                    {
                        objSalesmansAcitvityReport.RouteName = Db.ToString(row["RouteName"]);
                    }
                    if (row.Table.Columns.Contains("RegionCode"))
                    {
                        objSalesmansAcitvityReport.RegionCode = Db.ToString(row["RegionCode"]);
                    }
                    if (row.Table.Columns.Contains("RegionName"))
                    {
                        objSalesmansAcitvityReport.RegionName = Db.ToString(row["RegionName"]);
                    }
                    if (row.Table.Columns.Contains("EotDate"))
                    {
                        objSalesmansAcitvityReport.EotDate = string.IsNullOrEmpty(Db.ToString(row["EotDate"])) ? "N/A" : Convert.ToDateTime(Db.ToString(row["EotDate"])).ToString("dd/MM/yyyy").Replace("-", "/");
                    }
                    if (row.Table.Columns.Contains("VisitDate"))
                    {
                        objSalesmansAcitvityReport.VisitDate = string.IsNullOrEmpty(Db.ToString(row["Customer_VisitDate"])) ? "N/A" : Convert.ToDateTime(Db.ToString(row["Customer_VisitDate"])).ToString("dd/MM/yyyy").Replace("-", "/");
                    }
                    if (row.Table.Columns.Contains("AttendanceDate"))
                    {
                        objSalesmansAcitvityReport.AttendanceDate = string.IsNullOrEmpty(Db.ToString(row["AttendanceDate"])) ? "N/A" : Convert.ToDateTime(Db.ToString(row["AttendanceDate"])).ToString("dd/MM/yyyy").Replace("-", "/");
                    }
                    if (row.Table.Columns.Contains("AttendanceDate"))
                    {
                        objSalesmansAcitvityReport.AttendanceDateNew = Convert.ToDateTime(Db.ToString(row["AttendanceDate"])).ToString("yyyy-MM-dd");
                    }
                    if (row.Table.Columns.Contains("StartTime"))
                    {
                        objSalesmansAcitvityReport.StartTime = Db.ToString(row["StartTime"]);
                    }
                    if (row.Table.Columns.Contains("EndTime"))
                    {
                        objSalesmansAcitvityReport.EndTime = Db.ToString(row["EndTime"]);
                    }
                    if (row.Table.Columns.Contains("CheckInTime"))
                    {
                        objSalesmansAcitvityReport.CheckInTime = Db.ToString(row["CheckInTime"]);
                    }
                    if (row.Table.Columns.Contains("CheckOutTime"))
                    {
                        objSalesmansAcitvityReport.CheckOutTime = Db.ToString(row["CheckOutTime"]);
                    }
                    if (row.Table.Columns.Contains("EotStatus"))
                    {
                        objSalesmansAcitvityReport.EotStatus = Db.ToString(row["EotStatus"]);
                    }
                    if (row.Table.Columns.Contains("ImagePath"))
                    {
                        objSalesmansAcitvityReport.ImagePath = Db.ToString(row["ImagePath"]);
                    }
                    if (row.Table.Columns.Contains("Duration"))
                    {
                        objSalesmansAcitvityReport.Duration = Db.ToString(row["Duration"]);
                    }
                    if (row.Table.Columns.Contains("Visited"))
                    {
                        objSalesmansAcitvityReport.Visited = Db.ToString(row["Visited"]);
                    }
                    if (row.Table.Columns.Contains("JourneyPlan"))
                    {
                        objSalesmansAcitvityReport.JourneyPlan = Db.ToString(row["JourneyPlan"]);
                    }
                    /*
                    if (row.Table.Columns.Contains("OrderValue"))
                    {
                        objSalesmansAcitvityReport.OrderValue = Db.ToDouble(row["OrderValue"]);
                    }
                    if (row.Table.Columns.Contains("OrderVolume"))
                    {
                        objSalesmansAcitvityReport.OrderVolume = Db.ToDouble(row["OrderVolume"]);
                    }
                    if (row.Table.Columns.Contains("PerfectPoint"))
                    {
                        objSalesmansAcitvityReport.PerfectPoint = Db.ToDouble(row["PerfectPoint"]);
                    }
                    if (row.Table.Columns.Contains("PerfectStore"))
                    {
                        objSalesmansAcitvityReport.PerfectStore = Db.ToDouble(row["PerfectStore"]);
                    }
                    if (row.Table.Columns.Contains("MSLSold"))
                    {
                        objSalesmansAcitvityReport.MSLSold = Db.ToInteger(row["MSLSold"]);
                    }
                    if (row.Table.Columns.Contains("NPDSold"))
                    {
                        objSalesmansAcitvityReport.NPDSold = Db.ToInteger(row["NPDSold"]);
                    }
                    if (row.Table.Columns.Contains("Attribute1"))
                    {
                        objSalesmansAcitvityReport.Attribute1 = Db.ToString(row["Attribute1"]);
                    }
                    if (row.Table.Columns.Contains("Attribute2"))
                    {
                        objSalesmansAcitvityReport.Attribute2 = Db.ToString(row["Attribute2"]);
                    }
                    if (row.Table.Columns.Contains("Attribute3"))
                    {
                        objSalesmansAcitvityReport.Attribute3 = Db.ToString(row["Attribute3"]);
                    }
                    if (row.Table.Columns.Contains("Attribute4"))
                    {
                        objSalesmansAcitvityReport.Attribute4 = Db.ToString(row["Attribute4"]);
                    }
                    if (row.Table.Columns.Contains("Attribute5"))
                    {
                        objSalesmansAcitvityReport.Attribute5 = Db.ToString(row["Attribute5"]);
                    }
                    if (row.Table.Columns.Contains("Attribute6"))
                    {
                        objSalesmansAcitvityReport.Attribute6 = Db.ToString(row["Attribute6"]);
                    }
                    if (row.Table.Columns.Contains("Attribute7"))
                    {
                        objSalesmansAcitvityReport.Attribute7 = Db.ToString(row["Attribute7"]);
                    }
                    */
                    lstSalesmansAcitvityReport.Add(objSalesmansAcitvityReport);
                }
            }
        }
        catch (Exception ex)
        { }
        return lstSalesmansAcitvityReport;
    }

    public class FinalResult
    {

        //public FinalResult()
        //{
        //    this.lstRouteProductDistributionReport = new List<RouteProductDistributionReport>();
        //    this.lstSubCategory = new List<RouteProductDistributionReportSubCategory>();
        //}

        public int TotalRecords { get; set; }
        //public List<RouteProductDistributionReport> lstRouteProductDistributionReport { get; set; }
        //public List<RouteProductDistributionReportSubCategory> lstSubCategory { get; set; }
    }


    private void ExportEOTDetails(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = new StringBuilder();
        int EOTId = 0;
        if (Request.QueryString["Id"] != null)
        {
            EOTId = Convert.ToInt32(Request.QueryString["Id"]);
        }
        EOT objEot = new EOTFacade().GetEOTById(EOTId);
        if (objEot != null)
        {
            strFileContents.Append("EmpNo \t Username \t Role \t Type \t Time \t Reason");
            strFileContents.Append("\n");
            strFileContents.Append(objEot.EmpNo + "\t");
            strFileContents.Append(objEot.UserName + "\t");
            strFileContents.Append(objEot.ROLE + "\t");
            strFileContents.Append(objEot.EOTType + "\t");
            strFileContents.Append((objEot.EOTTime.ToString("MMM d, yyyy") + " " + objEot.EOTTime.ToShortTimeString()) + "\t");
            strFileContents.Append(objEot.Reason + "\t");
            strFileContents.Append("\n");
            strFileContents.Append("\n");

            if (SessionManager.UserRole.ToLower() != "accountant")
            {
                /*GRV Details*/
                #region GRV Details
                IList<OrderItem> objOrderItems = BindGRV(EOTId, objEot.ROLE);
                if (objOrderItems != null && objOrderItems.Count > 0)
                {
                    strFileContents.Append("GRV Details \n \n");
                    strFileContents.Append("SLNO \t DATE \t ITEMCODE \t DESCRIPTION \t QTYQUALIFIED \t QTYPICKED");
                    strFileContents.Append("\n");
                    int i = 1;
                    foreach (OrderItem objorderitem in objOrderItems)
                    {
                        strFileContents.Append(i + "\t");
                        strFileContents.Append(objorderitem.INVOICE_DATE + "\t");
                        strFileContents.Append(objorderitem.ITEM_CODE + "\t");
                        strFileContents.Append(objorderitem.ITEM_DESCRIPTION + "\t");
                        strFileContents.Append(objorderitem.ORDER_QUANTITY + "\t");
                        strFileContents.Append(objorderitem.ACTUAL_QTY_SHIPPED + "\t");
                        strFileContents.Append("\n");
                        i++;
                    }

                    if (objOrderItems != null)
                    {
                        var totqty = (from obj in objOrderItems
                                      select obj.ORDER_QUANTITY).Sum();

                        var totdelqty = (from obj in objOrderItems
                                         select obj.ACTUAL_QTY_SHIPPED).Sum();

                        strFileContents.Append(" \t   \t   \t TOTAL \t " + CommonFunctions.getStringValue(CommonFunctions.getDoubleValue(totqty)) + " \t " + CommonFunctions.getStringValue(CommonFunctions.getDoubleValue(totdelqty)));
                        strFileContents.Append("\n");
                        //if (gvGRVDetils.Rows.Count > 0)
                        //{
                        //    ((Label)(gvGRVDetils.FooterRow.FindControl("lblTOTQTYQUALIFIED"))).Text = CommonFunctions.getStringValue(CommonFunctions.getDoubleValue(totqty));
                        //    ((Label)(gvGRVDetils.FooterRow.FindControl("lblTOTDeliveredQuantity"))).Text = CommonFunctions.getStringValue(CommonFunctions.getDoubleValue(totdelqty));
                        //}
                    }
                }
                strFileContents.Append("\n");
                #endregion
                /*GRV Details*/
            }

            if (SessionManager.UserRole.ToLower() != "accountant")
            {
                /*UNDELIVERED/RETURNED QTY*/
                #region UNDELIVERED/RETURNED QTY
                IList<OrderItem> objorderitems = BindundeliveredQty(EOTId, objEot.ROLE);
                if (objorderitems != null && objorderitems.Count() > 0)
                {
                    var items = from obj in objorderitems
                                where obj.SUGGESTED_SYS_QTY - obj.ACTUAL_QTY_SHIPPED > 0
                                select obj;
                    objorderitems = null;
                    objorderitems = items.ToList<OrderItem>();
                    if (objorderitems != null && objorderitems.Count() > 0)
                    {
                        strFileContents.Append("UNDELIVERED/RETURNED QTY \n \n");
                        strFileContents.Append("SLNO" + "\t" + "DATE" + "\t" + "ITEMCODE" + "\t" + "DESCRIPTION" + "\t" + "ORDER QTY" + "\t" + "ALLOC QTY" + "\t" + "UNDELIVERED QTY");
                        strFileContents.Append("\n");
                        int i = 1;
                        foreach (OrderItem item in objorderitems)
                        {
                            strFileContents.Append(i + "\t");
                            strFileContents.Append(item.ORDER_DATE + "\t");
                            strFileContents.Append(item.ITEM_CODE + "\t");
                            strFileContents.Append(item.ITEM_DESCRIPTION + "\t");
                            strFileContents.Append(item.ORDER_QUANTITY + "\t");
                            strFileContents.Append(item.ACTUAL_QTY_SHIPPED + "\t");
                            strFileContents.Append((item.ORDER_QUANTITY - item.ACTUAL_QTY_SHIPPED) + "\t");
                            strFileContents.Append("\n");
                            i++;
                        }
                    }
                }
                if (objorderitems != null && objorderitems.Count() > 0)
                {
                    var totqty = (from obj in objorderitems
                                  select obj.SUGGESTED_SYS_QTY).Sum();

                    var totdelqty = (from obj in objorderitems
                                     select obj.ACTUAL_QTY_SHIPPED).Sum();

                    strFileContents.Append(" \t   \t   \t  \t  \t TOTAL \t" + CommonFunctions.getStringValue(CommonFunctions.getDoubleValue(totqty) - CommonFunctions.getDoubleValue(totdelqty)));
                    strFileContents.Append("\n");
                    //if (gvUndelivered.Rows.Count > 0)
                    //    ((Label)(gvUndelivered.FooterRow.FindControl("lblTOTDeliveredQuantity"))).Text = CommonFunctions.getStringValue(CommonFunctions.getDoubleValue(totqty) - CommonFunctions.getDoubleValue(totdelqty));
                }

                strFileContents.Append("\n");
                #endregion
                /*UNDELIVERED/RETURNED QTY*/
            }

            if (SessionManager.UserRole.ToLower() != "accountant")
            {
                /*ORDER SUMMARY*/
                #region ORDER SUMMARY
                IList<Order> objGRVOrders = bindOrdersummary(EOTId, objEot.ROLE);
                if (objGRVOrders != null && objGRVOrders.Count > 0)
                {
                    strFileContents.Append("ORDER SUMMARY \n \n");
                    strFileContents.Append("SLNO \t ORDERNO \t ORDER DATE \t CUST NO \t SITE NO \t SITE NAME \t ORDER QTY \t ALLOC QTY \t INVOICED QTY \t INVOICE NO");
                    strFileContents.Append("\n");
                    int i = 1;
                    foreach (Order objorder in objGRVOrders)
                    {
                        strFileContents.Append(i + "\t");
                        strFileContents.Append(objorder.BLASE_ORDER_NO + "\t");
                        strFileContents.Append(objorder.ORDER_DATE.ToString("MMM d, yyyy") + " " + objorder.ORDER_DATE.ToShortTimeString() + "\t");
                        strFileContents.Append(objorder.CUSTOMER_NUMBER + "\t");
                        strFileContents.Append(objorder.customer.SITE + "\t");
                        strFileContents.Append(objorder.customer.SITE_NAME + "\t");
                        strFileContents.Append(objorder.ORDERQTY + "\t");
                        strFileContents.Append(objorder.ALLOCQTY + "\t");
                        strFileContents.Append(objorder.INVOICEDQTY + "\t");
                        strFileContents.Append(objorder.INVOICENO + "\t");
                        strFileContents.Append("\n");
                        i++;
                    }
                }

                var TOTINVOICEDQTY = (from obj in objGRVOrders
                                      select obj.INVOICEDQTY).Sum();

                var TOTALLOCQTY = (from obj in objGRVOrders
                                   select obj.ALLOCQTY).Sum();
                if (objGRVOrders.Count > 0)
                {
                    strFileContents.Append(" \t   \t   \t  \t  \t  \t TOTAL \t" + CommonFunctions.getStringValue(TOTALLOCQTY) + " \t " + CommonFunctions.getStringValue(TOTINVOICEDQTY));
                    strFileContents.Append("\n");
                    //((Label)gvOrderItemSummary.FooterRow.FindControl("lblTOTALLOCQTY")).Text = CommonFunctions.getStringValue(TOTALLOCQTY);
                    //((Label)gvOrderItemSummary.FooterRow.FindControl("lblTOTINVOICEDQTY")).Text = CommonFunctions.getStringValue(TOTINVOICEDQTY);
                }
                strFileContents.Append("\n");
                #endregion
                /*ORDER SUMMARY*/
            }

            if (SessionManager.UserRole.ToLower() != "logisticsweb")
            {
                #region RECEIPT DETAILS

                IList<Receipt> objReceipts = new ReceiptFacade().GetReceiptByEOTId(EOTId);
                var items = (from obj in objReceipts
                             where obj.RECEIPT_METHOD.ToLower() == "cheque"
                             select obj);
                IList<Receipt> objReceipt1 = items.ToList<Receipt>();
                strFileContents.Append("RECEIPT DETAILS \n \n");
                int i = 1;
                if (objReceipt1.Count > 0)
                {

                    strFileContents.Append("SLNO \t DATE \t RECEIPT NO \t CUST NO \t CUST NAME \t SITE NO \t PAYMODE \t AMOUNT");
                    strFileContents.Append("\n");
                    foreach (Receipt objReceipt in objReceipt1)
                    {
                        strFileContents.Append(i + "\t");
                        strFileContents.Append(objReceipt.RECEIPT_DATE + "\t");
                        strFileContents.Append(objReceipt.RECEIPT_NUMBER + "\t");
                        strFileContents.Append(objReceipt.CUSTOMER_NO + "\t");
                        strFileContents.Append(objReceipt.CustomerName + "\t");
                        strFileContents.Append(objReceipt.SITE_NUMBER + "\t");
                        strFileContents.Append("CREDIT \t");
                        strFileContents.Append(objReceipt.AMOUNT + "\t");
                        strFileContents.Append("\n");
                        i++;
                    }

                    var sum = (from obj in objReceipt1
                               select obj.AMOUNT).Sum();

                    if (objReceipts.Count > 0)
                        strFileContents.Append(" \t \t \t \t \t \t TOTAL \t " + CommonFunctions.getStringValue(sum));
                    strFileContents.Append("\n");
                }
                //CASH
                objReceipts.Clear();
                objReceipts = null;
                objReceipts = new ReceiptFacade().GetReceiptByEOTId(EOTId);
                var items2 = (from obj in objReceipts
                              where obj.RECEIPT_METHOD.ToLower() == "cash"
                              select obj);
                IList<Receipt> objReceipt2 = items2.ToList<Receipt>();
                i = 1;
                if (objReceipt2.Count > 0)
                {
                    strFileContents.Append("SLNO \t DATE \t RECEIPT NO \t CUST NO \t CUST NAME \t SITE NO \t PAYMODE \t AMOUNT");
                    strFileContents.Append("\n");
                    foreach (Receipt objReceipt in objReceipt2)
                    {
                        strFileContents.Append(i + "\t");
                        strFileContents.Append(objReceipt.RECEIPT_DATE + "\t");
                        strFileContents.Append(objReceipt.RECEIPT_NUMBER + "\t");
                        strFileContents.Append(objReceipt.CUSTOMER_NO + "\t");
                        strFileContents.Append(objReceipt.CustomerName + "\t");
                        strFileContents.Append(objReceipt.SITE_NUMBER + "\t");
                        strFileContents.Append("CASH \t");
                        strFileContents.Append(objReceipt.AMOUNT + "\t");
                        strFileContents.Append("\n");
                        i++;
                    }

                    var sum2 = (from obj in objReceipt2
                                select obj.AMOUNT).Sum();

                    if (objReceipts.Count > 0)
                        strFileContents.Append(" \t \t \t \t \t TOTAL \t " + CommonFunctions.getStringValue(sum2));
                    strFileContents.Append("\n");
                }
                #endregion

                #region INVOICE SUMMARY
                IList<Order> objGRVOrders = bindOrdersummary(EOTId, objEot.ROLE);

                var orderITEMS = from obj in objGRVOrders
                                 where obj.customer.PAYMENT_TYPE.ToLower() == "cash"
                                 select obj;

                IList<Order> objGRVOrders1 = orderITEMS.ToList<Order>();
                strFileContents.Append("INVOICE SUMMARY \n \n");
                if (objGRVOrders1 != null && objGRVOrders1.Count > 0)
                {
                    strFileContents.Append("SLNO \t ORDERNO \t ORDER DATE \t CUST NO \t SITE NO \t SITE NAME \t ORDER QTY \t ALLOC QTY \t INVOICED QTY \t INVOICE NO \t INVOICE AMT \t PAYMODE");
                    strFileContents.Append("\n");
                    i = 1;
                    foreach (Order objorder in objGRVOrders1)
                    {
                        strFileContents.Append(i + "\t");
                        strFileContents.Append(objorder.BLASE_ORDER_NO + "\t");
                        strFileContents.Append(objorder.ORDER_DATE.ToString("MMM d, yyyy") + " " + objorder.ORDER_DATE.ToShortTimeString() + "\t");
                        strFileContents.Append(objorder.CUSTOMER_NUMBER + "\t");
                        strFileContents.Append(objorder.customer.SITE + "\t");
                        strFileContents.Append(objorder.customer.SITE_NAME + "\t");
                        strFileContents.Append(objorder.ORDERQTY + "\t");
                        strFileContents.Append(objorder.ALLOCQTY + "\t");
                        strFileContents.Append(objorder.INVOICEDQTY + "\t");
                        strFileContents.Append(objorder.INVOICENO + "\t");
                        strFileContents.Append(objorder.INVOICEAMT + "\t");
                        strFileContents.Append("CASH \t");
                        strFileContents.Append("\n");
                        i++;
                    }

                    var totinvAmt = (from obj in objGRVOrders1
                                     select obj.INVOICEAMT).Sum();

                    strFileContents.Append(" \t   \t   \t  \t  \t  \t  \t  \t  \t CASH \t " + CommonFunctions.getStringValue(totinvAmt));
                    strFileContents.Append("\n");

                    strFileContents.Append("\n");

                }

                //CREDIT
                objGRVOrders.Clear();
                objGRVOrders = null;
                objGRVOrders = bindOrdersummary(EOTId, objEot.ROLE);

                var orderITEMS2 = from obj in objGRVOrders
                                  where obj.customer.PAYMENT_TYPE.ToLower() == "credit"
                                  select obj;


                IList<Order> objGRVOrders2 = orderITEMS2.ToList<Order>();

                if (objGRVOrders2 != null && objGRVOrders2.Count > 0)
                {
                    strFileContents.Append("SLNO \t ORDERNO \t ORDER DATE \t CUST NO \t SITE NO \t SITE NAME \t ORDER QTY \t ALLOC QTY \t INVOICED QTY \t INVOICE NO \t INVOICE AMT \t PAYMODE");
                    strFileContents.Append("\n");
                    i = 1;
                    foreach (Order objorder in objGRVOrders2)
                    {
                        strFileContents.Append(i + "\t");
                        strFileContents.Append(objorder.BLASE_ORDER_NO + "\t");
                        strFileContents.Append(objorder.ORDER_DATE.ToString("MMM d, yyyy") + " " + objorder.ORDER_DATE.ToShortTimeString() + "\t");
                        strFileContents.Append(objorder.CUSTOMER_NUMBER + "\t");
                        strFileContents.Append(objorder.customer.SITE + "\t");
                        strFileContents.Append(objorder.customer.SITE_NAME + "\t");
                        strFileContents.Append(objorder.ORDERQTY + "\t");
                        strFileContents.Append(objorder.ALLOCQTY + "\t");
                        strFileContents.Append(objorder.INVOICEDQTY + "\t");
                        strFileContents.Append(objorder.INVOICENO + "\t");
                        strFileContents.Append(objorder.INVOICEAMT + "\t");
                        strFileContents.Append("CREDIT \t");
                        strFileContents.Append("\n");
                        i++;
                    }

                    var totinvAmt2 = (from obj in objGRVOrders2
                                      select obj.INVOICEAMT).Sum();

                    strFileContents.Append(" \t   \t   \t  \t  \t  \t  \t  \t  \t  CREDIT \t " + CommonFunctions.getStringValue(totinvAmt2));
                    strFileContents.Append("\n");

                    strFileContents.Append("\n");
                }
                #endregion
            }
        }
        else
        {
            strFileContents.Append("");
        }
        sw = System.IO.File.CreateText(strFileName);
        sw.Write(strFileContents.ToString());
        sw.Close();
    }

    #region EOT Methods
    protected IList<OrderItem> BindGRV(int Id, string Role)
    {
        if (Role.ToLower() == "preseller")
            return new OrderItemFacade().GetGRVOrderitemsbyEOTId(Id);
        else
            return new OrderItemFacade().GetGRVOrderitemsbyEOTId_DA(Id);
    }

    private IList<OrderItem> BindundeliveredQty(int Id, string Role)
    {
        if (Role.ToLower() == "preseller")
        {
            //return new OrderItemFacade().GetUndeliveredOrderitemsbyEOTId(Id);
            return null;
        }
        else
            return new OrderItemFacade().GetUndeliveredOrderitemsbyEOTId_DA(Id);
    }

    private IList<Order> bindOrdersummary(int Id, string Role)
    {
        return null;
        //if (Role.ToLower() == "preseller")
        //    return new OrderFacade().GetOrderSummaryByEOTId(Id);
        //else
        //    return new OrderFacade().GetOrderSummaryByEOTId_DA(Id);
    }

    protected EOTDetails BindDetails(int EOTId, string Role)
    {
        if (Role.ToLower() == "preseller")
            return (new EOTDetailsFacade()).GetEOTEOTDetails(EOTId);
        else
            return (new EOTDetailsFacade()).GetDAEOTEOTDetails(EOTId);
    }

    protected IList<Order> BindOrders(int Id, string Role)
    {
        return null;
        //if (Role.ToLower() == "preseller")
        //    return new OrderFacade().GetOrderBYEOTId(Id);
        //else
        //    return new OrderFacade().GetOrderDABYEOTId(Id);
    }

    protected IList<Receipt> BindReceiptDetails(int Id)
    {
        return new ReceiptFacade().GetReceiptByEOTId(Id);
    }
    #endregion

    private void ExportTrxHeadervsRecommended(string strFileName)
    {
        //System.IO.StreamWriter sw;
        //StringBuilder strFileContents = new StringBuilder();

        //IList<TrxHeader> TrxHeader = new List<TrxHeader>();
        //if (Session["TrxHeaderVsRecommended"] != null && Session["TrxHeaderVsRecommended"].ToString() != "")
        //{
        //    string searchstring = Session["TrxHeaderVsRecommended"].ToString();
        //    //TrxHeaderitems = new TrxHeaderItemFacade().GetTrxHeaderItem_ForTrxHeadervsRecommended_EXPORT(searchstring);
        //    TrxHeader = (new OrderFacade()).GetRecomendedTrxHeaderExport(searchstring);
        //    strFileContents.Append("TrxHeaderNumber \t Region  \t Customer Id \t SiteNo \t SiteName \t TrxHeader Date \t Sub Channel \t Item Code \t Inventory Quantity \t Recomended Quantity \t TrxHeader Quantity \t Allocated Quantity \t Delivered Quantity");
        //    strFileContents.Append("\n");
        //    foreach (TrxHeader drTrxHeader in TrxHeader)
        //    {
        //        //strFileContents.Append(drTrxHeader.OrderNumber + "\t");
        //        //strFileContents.Append(drTrxHeader.objCustomer.RegionCode + "\t");
        //        //strFileContents.Append(drTrxHeader.objCustomer.CustomerId + "\t");
        //        //strFileContents.Append(drTrxHeader.Site_Number + "\t");
        //        //strFileContents.Append(drTrxHeader.Site_Name + "\t");
        //        //strFileContents.Append(drTrxHeader.Order_Date + "\t");
        //        //strFileContents.Append(drTrxHeader.objCustomer.SUBCHANNEL + "\t");
        //        //strFileContents.Append(drTrxHeader.ItemCode + "\t");
        //        //strFileContents.Append(drTrxHeader.INVENTORY_QUANTITY + "\t");
        //        //strFileContents.Append(drTrxHeader.RECOMMENDED_QTY + "\t");
        //        //strFileContents.Append(drTrxHeader.TrxHeader_QUANTITY + "\t");
        //        //strFileContents.Append(drTrxHeader.SUGGESTED_SYS_QTY + "\t");
        //        //strFileContents.Append(drTrxHeader.ACTUAL_QTY_SHIPPED + "\t");
        //        //strFileContents.Append("\n");
        //    }
        //}
        //else
        //{
        //    strFileContents.Append("---");
        //}
        //sw = System.IO.File.CreateText(strFileName);
        //sw.Write(strFileContents.ToString());
        //sw.Close();
    }

    private void ExportVMOrdervsRecommended(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = new StringBuilder();

        IList<Order> order = new List<Order>();
        if (Session["VMOrderVsRecommended"] != null && Session["VMOrderVsRecommended"].ToString() != "")
        {
            string searchstring = Session["VMOrderVsRecommended"].ToString();
            //orderitems = new OrderItemFacade().GetOrderItem_ForOrdervsRecommended_EXPORT(searchstring);
            //order = (new OrderFacade()).GetRecomendedOrderExport(searchstring);
            strFileContents.Append("OrderNumber \t Region  \t Customer Id \t SiteNo \t SiteName \t Order Date \t Sub Channel \t Item Code \t Inventory Quantity \t Recomended Quantity \t Order Quantity \t Allocated Quantity \t Delivered Quantity");
            strFileContents.Append("\n");
            foreach (Order drOrder in order)
            {
                strFileContents.Append(drOrder.BLASE_ORDER_NO + "\t");
                strFileContents.Append(drOrder.REGION_CODE + "\t");
                strFileContents.Append(drOrder.CUSTOMER_NUMBER + "\t");
                strFileContents.Append(drOrder.SITE_NUMBER + "\t");
                strFileContents.Append(drOrder.SITE_NAME + "\t");
                strFileContents.Append(drOrder.OrderDate + "\t");
                strFileContents.Append(drOrder.SUBCHANNEL + "\t");
                strFileContents.Append(drOrder.ItemCode + "\t");
                strFileContents.Append(drOrder.INVENTORY_QUANTITY + "\t");
                strFileContents.Append(drOrder.RECOMMENDED_QTY + "\t");
                strFileContents.Append(drOrder.ORDER_QUANTITY + "\t");
                strFileContents.Append(drOrder.SUGGESTED_SYS_QTY + "\t");
                strFileContents.Append(drOrder.ACTUAL_QTY_SHIPPED + "\t");
                strFileContents.Append("\n");
            }
        }
        else
        {
            strFileContents.Append("---");
        }
        sw = System.IO.File.CreateText(strFileName);
        sw.Write(strFileContents.ToString());
        sw.Close();
    }

    private void ExportIndividualDeliveryAgentCommision(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = new StringBuilder();

        IList<DeliveryAgentCommision> DeliveryAgentCommision = new List<DeliveryAgentCommision>();

        if (Session["AgenCommisionIndidual"] != null && Session["AgenCommisionIndidual"].ToString() != "")
        {
            string searchstring = Session["AgenCommisionIndidual"].ToString();
            DeliveryAgentCommision = new DeliveryAgentCommisionFacade().GetDeliveryAgentCommisionExport(searchstring);

            strFileContents.Append("Sr. No. \t Delivery Agent \t Tot. CTN Delivered \t Helper \t % Alloc \t CTN Allocated \t Rate \t Inc. Earned");
            strFileContents.Append("\n");
            foreach (DeliveryAgentCommision objDeliveryAgentCommision in DeliveryAgentCommision)
            {
                strFileContents.Append(objDeliveryAgentCommision.RowNum + "\t");
                strFileContents.Append(objDeliveryAgentCommision.DeliveryAgent + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Quantity + "\t");
                strFileContents.Append("" + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Perc_Alloc + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Qty_Alloc + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Rate + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Inc_Earned + "\t");
                strFileContents.Append("\n");
                if (objDeliveryAgentCommision.HelperCommision != null && objDeliveryAgentCommision.HelperCommision.Count > 0)
                {
                    for (int j = 0; j < objDeliveryAgentCommision.HelperCommision.Count; j++)
                    {
                        for (int i = 0; i < 3; i++)
                        {
                            strFileContents.Append("" + "\t");
                        }
                        strFileContents.Append(objDeliveryAgentCommision.HelperCommision[j].HelperName + "\t");
                        strFileContents.Append(objDeliveryAgentCommision.HelperCommision[j].Helper_Perc_Alloc + "\t");
                        strFileContents.Append(objDeliveryAgentCommision.HelperCommision[j].Helper_Qty_Alloc + "\t");
                        strFileContents.Append(objDeliveryAgentCommision.HelperCommision[j].Helper_Rate + "\t");
                        strFileContents.Append(objDeliveryAgentCommision.HelperCommision[j].Helper_Inc_Earned + "\t");
                        strFileContents.Append("\n");
                    }
                }
            }
        }
        else
        {
            strFileContents.Append("---");
        }
        sw = System.IO.File.CreateText(strFileName);
        sw.Write(strFileContents.ToString());
        sw.Close();
    }

    private void ExportMonthlyDeliveryAgentCommision(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = new StringBuilder();

        IList<DeliveryAgentCommision> DeliveryAgentCommision = new List<DeliveryAgentCommision>();

        if (Session["AgenCommisionMonthly"] != null && Session["AgenCommisionMonthly"].ToString() != "")
        {
            string searchstring = Session["AgenCommisionMonthly"].ToString();
            DeliveryAgentCommision = new DeliveryAgentCommisionFacade().GetDeliveryAgentCommisionMonthlyExport(searchstring);

            strFileContents.Append("Sr. No. \t Delivery Agent \t Tot. CTN Delivered \t CTN Allocated \t Inc. Earned");
            strFileContents.Append("\n");
            int RowCount = 1;

            double TotalInc_Earned = 0.0;

            foreach (DeliveryAgentCommision objDeliveryAgentCommision in DeliveryAgentCommision)
            {
                strFileContents.Append(RowCount + "\t");
                strFileContents.Append(objDeliveryAgentCommision.DeliveryAgent + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Quantity + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Qty_Alloc + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Inc_Earned + "\t");
                //TotalQuantity += objDeliveryAgentCommision.Quantity;
                //TotalQty_Alloc += objDeliveryAgentCommision.Qty_Alloc;
                TotalInc_Earned += objDeliveryAgentCommision.Inc_Earned;
                strFileContents.Append("\n");
                RowCount += 1;
            }
            strFileContents.Append("" + "\t");
            strFileContents.Append("Total" + "\t");
            for (int i = 0; i < 2; i++)
            {
                strFileContents.Append("" + "\t");
            }
            strFileContents.Append(TotalInc_Earned + "\t");
        }
        else
        {
            strFileContents.Append("---");
        }
        sw = System.IO.File.CreateText(strFileName);
        sw.Write(strFileContents.ToString());
        sw.Close();
    }

    private void ExportMonthlyHelperCommision(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = new StringBuilder();

        IList<HelperCommision> DeliveryAgentCommision = new List<HelperCommision>();

        if (Session["HelperCommisionMonthly"] != null && Session["HelperCommisionMonthly"].ToString() != "")
        {
            string searchstring = Session["HelperCommisionMonthly"].ToString();
            DeliveryAgentCommision = new HelperCommisionFacade().GetHelperCommisionExport(searchstring);

            strFileContents.Append("Sr. No. \t Helper \t Tot. CTN Delivered \t CTN Allocated \t Inc. Earned");
            strFileContents.Append("\n");
            int RowCount = 1;

            double TotalInc_Earned = 0.0;

            foreach (HelperCommision objDeliveryAgentCommision in DeliveryAgentCommision)
            {
                strFileContents.Append(RowCount + "\t");
                strFileContents.Append(objDeliveryAgentCommision.HelperName + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Quantity + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Helper_Qty_Alloc + "\t");
                strFileContents.Append(objDeliveryAgentCommision.Helper_Inc_Earned + "\t");
                //TotalQuantity += objDeliveryAgentCommision.Quantity;
                //TotalQty_Alloc += objDeliveryAgentCommision.Qty_Alloc;
                TotalInc_Earned += objDeliveryAgentCommision.Helper_Inc_Earned;
                strFileContents.Append("\n");
                RowCount += 1;
            }
            strFileContents.Append("" + "\t");
            strFileContents.Append("Total" + "\t");
            for (int i = 0; i < 2; i++)
            {
                strFileContents.Append("" + "\t");
            }
            strFileContents.Append(TotalInc_Earned + "\t");
        }
        else
        {
            strFileContents.Append("---");
        }
        sw = System.IO.File.CreateText(strFileName);
        sw.Write(strFileContents.ToString());
        sw.Close();
    }

    private void ExportDailyCollectionSummary(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = new StringBuilder();
        if (Request.QueryString["Date"] != null && Request.QueryString["Date"] != null)
        {
            string Date = Request.QueryString["Date"].ToString();
            string Region = Request.QueryString["Region"].ToString();

            IList<Receipt> reciepts_Cash = new List<Receipt>();
            reciepts_Cash = new ReceiptFacade().GetDailyCollectionSummary(Date, Region, "cash");

            if (reciepts_Cash.Count > 0)
            {
                strFileContents.Append("Sr. No. \t Preseller/Delivery Agent \t Rec No \t Customer No \t Site Number \t SITE Name \t Pay Mode \t Amount");
                strFileContents.Append("\n");
                int RowCount = 1;

                double TotalInc_Earned = 0.0;
                foreach (Receipt objReceipt in reciepts_Cash)
                {
                    strFileContents.Append(RowCount + "\t");
                    strFileContents.Append(objReceipt.EmpName + "\t");
                    strFileContents.Append(objReceipt.RECEIPT_NUMBER + "\t");
                    strFileContents.Append(objReceipt.CUSTOMER_NO + "\t");
                    strFileContents.Append(objReceipt.SITE_NUMBER + "\t");
                    strFileContents.Append(objReceipt.SITE_NAME + "\t");
                    strFileContents.Append("Cash \t");
                    strFileContents.Append(objReceipt.AMOUNT + "\t");
                    TotalInc_Earned += objReceipt.AMOUNT;
                    strFileContents.Append("\n");
                    RowCount += 1;
                }
                strFileContents.Append("\t \t \t \t \t \t Total \t" + TotalInc_Earned);
                strFileContents.Append("\n");
                strFileContents.Append("\n");
            }


            IList<Receipt> reciepts_Cheque = new List<Receipt>();
            reciepts_Cheque = new ReceiptFacade().GetDailyCollectionSummary(Date, Region, "cheque");

            if (reciepts_Cheque.Count > 0)
            {
                strFileContents.Append("Sr. No. \t Preseller/ Delivery Agent \t Rec No \t Customer No \t Site Number \t SITE Name \t Pay Mode \t Amount");
                strFileContents.Append("\n");
                int RowCount = 1;

                double TotalInc_Earned = 0.0;
                foreach (Receipt objReceipt in reciepts_Cheque)
                {
                    strFileContents.Append(RowCount + "\t");
                    strFileContents.Append(objReceipt.EmpName + "\t");
                    strFileContents.Append(objReceipt.RECEIPT_NUMBER + "\t");
                    strFileContents.Append(objReceipt.CUSTOMER_NO + "\t");
                    strFileContents.Append(objReceipt.SITE_NUMBER + "\t");
                    strFileContents.Append(objReceipt.SITE_NAME + "\t");
                    strFileContents.Append("Cheque \t");
                    strFileContents.Append(objReceipt.AMOUNT + "\t");
                    TotalInc_Earned += objReceipt.AMOUNT;
                    strFileContents.Append("\n");
                    RowCount += 1;
                }
                strFileContents.Append("\t \t \t \t \t \t Total \t" + TotalInc_Earned);
                strFileContents.Append("\n");
                strFileContents.Append("\n");
            }
            if (reciepts_Cash.Count == 0 && reciepts_Cash.Count == 0)
            {
                strFileContents.Append("---");
            }
        }
        else
        {
            strFileContents.Append("---");
        }
        sw = System.IO.File.CreateText(strFileName);
        sw.Write(strFileContents.ToString());
        sw.Close();
    }

    private void ExportCustomerPassCode(string strFileName)
    {
        System.IO.StreamWriter sw;
        string strFileContents = string.Empty;

        if (Request.QueryString["empNo"] != null && Request.QueryString["Role"] != null)
        {
            string empNo = Request.QueryString["empNo"].ToString();
            string Role = Request.QueryString["Role"].ToString();

            switch (Role)
            {
                case "VAN SALES":
                    {
                        strFileContents = GetAllPassCodeDetails(empNo);
                        break;
                    }
            }
        }
        else
        {
            strFileName = "----";
        }
        sw = System.IO.File.CreateText(strFileName);
        sw.Write(strFileContents);
        sw.Close();
    }

    protected string GetAllPassCodeDetails(string EmpNo)
    {
        StringBuilder strFileContents = new StringBuilder();
        IList<PassCode> PassCode = new PassCodeFacade().GetAllPassCodeDetails(EmpNo);

        if (PassCode != null && PassCode.Count > 0)
        {
            strFileContents.Append("Sr. No. \t EmpId \t UserId \t PassCode");

            strFileContents.Append("\n");

            int RowCount = 1;

            foreach (PassCode objPassCode in PassCode)
            {
                strFileContents.Append(RowCount + "\t");
                strFileContents.Append(objPassCode.EmpId + "\t");
                strFileContents.Append(objPassCode.UserId + "\t");
                strFileContents.Append(objPassCode.DAPassCode + "\t");
                strFileContents.Append("\n");
                RowCount += 1;
            }
        }
        else
        {
            strFileContents.Append("----");
        }
        return strFileContents.ToString();
    }

    private void ExportVehicle(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["VehicleReports"] != null) ? Session["VehicleReports"].ToString() : "1=1";
        IList<Vehicle> objVehicle = new VehicleFacade().GetVehicleReportExport(SearchString);
        if (objVehicle != null && objVehicle.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Vehicle Number" + "\t" + "Vehicle Model" + "\t" + "Vehicle Type" + "\t" + "Department" + "\t" + "UserID " + "\t" + "Agent Name " + "\t" + "Location " + "\t" + "Route ");
            strFileContents.Append("\n");
            foreach (Vehicle obVehicle in objVehicle)
            {
                strFileContents.Append(obVehicle.VEHICLE_NO + "\t");
                strFileContents.Append(obVehicle.VEHICLE_MODEL + "\t");
                strFileContents.Append(obVehicle.VEHICLE_TYPE + "\t");
                strFileContents.Append(obVehicle.DEPT + "\t");
                strFileContents.Append(obVehicle.EMPNO + "\t");
                strFileContents.Append(obVehicle.AGENT_NAME + "\t");
                strFileContents.Append(obVehicle.LOCATION + "\t");
                strFileContents.Append(obVehicle.ROUTE + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportSalesmanCoinBox(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["SalesmanCoinBoxReports"] != null) ? Session["SalesmanCoinBoxReports"].ToString() : "1=1";
        IList<SalesmanCoinBox> SalesmanCoinBoxs = new SalesmanCoinBoxFacade().GetSalesmanCoinBoxReportExport(SearchString);
        if (SalesmanCoinBoxs != null && SalesmanCoinBoxs.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Salesman Code" + "\t" + "BarCode" + "\t" + "BoxType" + "\t" + "Color" + "\t" + "Date" + "\t" + "UserID" + "\t" + "EmpNo ");
            strFileContents.Append("\n");
            foreach (SalesmanCoinBox objSalesmanCoinBox in SalesmanCoinBoxs)
            {
                strFileContents.Append(objSalesmanCoinBox.SalesmanCode + "\t");
                strFileContents.Append(objSalesmanCoinBox.BarCode + "\t");
                strFileContents.Append(objSalesmanCoinBox.CoinBox.BOXTYPE + "\t");
                strFileContents.Append(objSalesmanCoinBox.CoinBox.COLOR + "\t");
                strFileContents.Append(objSalesmanCoinBox.Date + "\t");
                strFileContents.Append(objSalesmanCoinBox.BlaseUser.USERID + "\t");
                strFileContents.Append(objSalesmanCoinBox.BlaseUser.EmpNo + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportVMInvoiceDetail(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["VMInvoiceDetail"] != null) ? Session["VMInvoiceDetail"].ToString() : "1=1";
        IList<VMInvoiceDetail> VMInvoiceDetails = new VMInvoiceFacade().GetVMInvoiceDetailReportExport(SearchString);
        if (VMInvoiceDetails != null && VMInvoiceDetails.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Site " + "\t" + "Site Name " + "\t" + "Invoice Date " + "\t" + "Invoice Number " + "\t" + "Item Code " + "\t" + "Invoiced QTY " + "\t" + "Unit Selling Price " + "\t" + "Invoice Amount ");
            strFileContents.Append("\n");
            foreach (VMInvoiceDetail objVMInvoiceDetail in VMInvoiceDetails)
            {
                strFileContents.Append(objVMInvoiceDetail.SITE_NUMBER + "\t");
                strFileContents.Append(objVMInvoiceDetail.Customer.SITE_NAME + "\t");
                strFileContents.Append(objVMInvoiceDetail.INVOICE_DATE + "\t");
                strFileContents.Append(objVMInvoiceDetail.INVOICE_NUMBER + "\t");
                strFileContents.Append(objVMInvoiceDetail.ITEM_CODE + "\t");
                strFileContents.Append(objVMInvoiceDetail.INVOICED_QTY + "\t");
                strFileContents.Append(objVMInvoiceDetail.UNIT_SELLING_PRICE + "\t");
                strFileContents.Append(objVMInvoiceDetail.INVOICE_AMOUNT + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportLoadSheet(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        SearchString = (Session["LoadSheet"] != null) ? Session["LoadSheet"].ToString() : "1=1";
        IList<VMLoad> VMLoadDetails = new VMLoadFacade().GetVMLoad("EmpNo ASC", 0, 0, SearchString);
        if (VMLoadDetails != null && VMLoadDetails.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("EmpNo " + "\t" + "Username " + "\t" + "Region " + "\t" + "Date " + "\t" + "PrimaryAllocQty " + "\t" + "SecAllocQty ");
            strFileContents.Append("\n");

            foreach (VMLoad objVMLoadDetail in VMLoadDetails)
            {
                strFileContents.Append(objVMLoadDetail.EmpNo + "\t");
                strFileContents.Append(objVMLoadDetail.objBlaseUser.USERNAME + "\t");
                strFileContents.Append(objVMLoadDetail.objBlaseUser.REGION + "\t");
                strFileContents.Append(objVMLoadDetail.DelDate.ToString("MMM d, yyyy") + "\t");
                strFileContents.Append(objVMLoadDetail.PrimaryAllocQty + "\t");
                strFileContents.Append(objVMLoadDetail.SecAllocQty);
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportDAOrderModification(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = new StringBuilder();

        IList<OrderItem> orderitems = new List<OrderItem>();
        if (Session["DAOrderModification"] != null && Session["DAOrderModification"] != "")
        {
            string searchstring = Session["DAOrderModification"].ToString();
            orderitems = new OrderItemFacade().GetDAOrderModification_EXPORT(searchstring);

            strFileContents.Append("OrderNumber \t SiteNo \t SiteName \t ItemCode \t Suggested Quantity \t Delivered Quantity \t Delivery Date \t Delivered By \t SUBCHANNEL");
            strFileContents.Append("\n");
            foreach (OrderItem orderitem in orderitems)
            {
                strFileContents.Append(orderitem.BLASE_ORDER_NO + "\t");
                strFileContents.Append(orderitem.SITE_NUMBER + "\t");
                strFileContents.Append(orderitem.SiteName + "\t");
                strFileContents.Append(orderitem.ITEM_CODE + "\t");
                strFileContents.Append(orderitem.SUGGESTED_SYS_QTY + "\t");
                strFileContents.Append(orderitem.ACTUAL_QTY_SHIPPED + "\t");
                strFileContents.Append(orderitem.ACTUAL_SHIP_DATE + "\t");
                strFileContents.Append(orderitem.DeliveredBy + "\t");
                strFileContents.Append(orderitem.SUBCHANNEL + "\t");
                strFileContents.Append("\n");
            }
        }
        else
        {
            strFileContents.Append("---");
        }
        sw = System.IO.File.CreateText(strFileName);
        sw.Write(strFileContents.ToString());
        sw.Close();
    }

    private void ExportVMStatus(string strFileName)
    {
        StreamWriter sw;
        StringBuilder strFileContents = new StringBuilder();

        string SearchString = string.Empty;
        SearchString = (Session["VMStatus"] != null) ? Session["VMStatus"].ToString() : "1=1";
        IList<VMStatus> VMStatus = new VMStatusFacade().GetVMStatusReportExport(SearchString);
        if (VMStatus != null && VMStatus.Count > 0)
        {

            strFileContents.Append(" Emp No" + "\t" + "Site " + "\t" + " Site Name" + "\t" + "User Id " + "\t" + "Old Barcode " + "\t" + "New Barcode " + "\t" + "Date");
            strFileContents.Append("\n");
            foreach (VMStatus objVMStatus in VMStatus)
            {
                strFileContents.Append(objVMStatus.EmpNo + "\t");
                strFileContents.Append(objVMStatus.Site + "\t");
                strFileContents.Append(objVMStatus.SiteName + "\t");
                strFileContents.Append(objVMStatus.UserId + "\t");
                strFileContents.Append(objVMStatus.OldCoinBoxbarCode + "\t");
                strFileContents.Append(objVMStatus.NewCoinBoxbarCode + "\t");
                strFileContents.Append(objVMStatus.Date.ToString("MMM d, yyyy") + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportVMInventory(string strFileName)
    {
        StreamWriter sw;
        StringBuilder strFileContents = new StringBuilder();

        string SearchString = string.Empty;
        SearchString = (Session["VMLoadInventory"] != null) ? Session["VMLoadInventory"].ToString() : "1=1";
        if (Session["VMLoadInventoryDate"] != null)
        {
            DateTime Date = Convert.ToDateTime(Session["VMLoadInventoryDate"].ToString());
            IList<VMLoadInventory> VMLoadInventory = new VMLoadInventoryFacade().GetVMLoadInventoryExport(SearchString, Date);
            if (VMLoadInventory != null && VMLoadInventory.Count > 0)
            {

                strFileContents.Append(" Emp No" + "\t" + "Primary Allocation Quantity " + "\t" + " Secondary Allocation Quantity " + "\t" + "User Id " + "\t" + "Delivered Quantity " + "\t" + "Available Quantity " + "\t" + "Available Quantity(Unit) " + "\t" + "Date");
                strFileContents.Append("\n");
                foreach (VMLoadInventory objVMLoadInventory in VMLoadInventory)
                {
                    strFileContents.Append(objVMLoadInventory.EmpNo + "\t");
                    strFileContents.Append(objVMLoadInventory.PrimaryAllocQty + "\t");
                    strFileContents.Append(objVMLoadInventory.SecAllocQty + "\t");
                    strFileContents.Append(objVMLoadInventory.USERID + "\t");
                    strFileContents.Append(objVMLoadInventory.DeliveredQuantity + "\t");
                    strFileContents.Append(objVMLoadInventory.AvailableQuantity + "\t");
                    strFileContents.Append(objVMLoadInventory.AvailableQuantityInUnit + "\t");
                    strFileContents.Append(objVMLoadInventory.Date.ToString("MMM d, yyyy") + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
    }

    private void ExportVMDeliveryReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["VMOrderDeliveryReport"] != null) ? Session["VMOrderDeliveryReport"].ToString() : " DATEDIFF(D,  DRP.[ORDER_DATE], GETDATE()) = 0";
        IList<OrderDeliveryReport> objOrderDeliveryReport = new OrderDeliveryReportFacade().GetVMOrderDeliveryReportExport(SearchString);
        if (objOrderDeliveryReport != null && objOrderDeliveryReport.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Preseller" + "\t" + "Customer Type" + "\t" + "Order No" + "\t" + "Order Date " + "\t" + "SUBCHANNEL" + "\t" + "Customer No\tCustomer Name\tSite No\tORD QTY\tDEL_QTY\tINV QTY\tINV_AMT \tStatus");
            strFileContents.Append("\n");
            int i = 1;
            foreach (OrderDeliveryReport obOrderDeliveryReport in objOrderDeliveryReport)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obOrderDeliveryReport.SALESMAN + "\t");
                strFileContents.Append(obOrderDeliveryReport.PAYMENT_TYPE + "\t");
                strFileContents.Append(obOrderDeliveryReport.BLASE_ORDER_NO + "\t");
                strFileContents.Append(obOrderDeliveryReport.ORDER_DATE.ToString("MMM dd, yyyy") + "\t");
                strFileContents.Append(obOrderDeliveryReport.SUBCHANNEL + "\t");
                strFileContents.Append(obOrderDeliveryReport.CUSTOMERID + "\t");
                strFileContents.Append(obOrderDeliveryReport.SITE_NAME + "\t");
                strFileContents.Append(obOrderDeliveryReport.SITE + "\t");
                strFileContents.Append(obOrderDeliveryReport.TotalOrderQuantity + "\t");
                strFileContents.Append(obOrderDeliveryReport.TotalDeliveredQuantity + "\t");
                strFileContents.Append(obOrderDeliveryReport.TotalDeliveredQuantity + "\t");
                strFileContents.Append(obOrderDeliveryReport.TotalInvoiceAmount + "\t");
                strFileContents.Append((obOrderDeliveryReport.DeliveryStatus == true) ? "Delivered" : "Pending" + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportVMReceiptSummary(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["VMReceiptSummaryReport"] != null) ? Session["VMReceiptSummaryReport"].ToString() : " DATEDIFF(D, R.RECEIPT_DATE, GETDATE()) = 0";

        IList<Receipt> receipt = (new ReceiptFacade()).ExportVMReceiptSummary(SearchString);

        if (receipt != null && receipt.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Receipt Number" + "\t" + "Receipt Date" + "\t" + "Region" + "\t" + "Salesman" + "\t" + "Invoice Number" + "\t" + "Invoice Amount" + "\t" + "Receipt Amount");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Receipt obReceipt in receipt)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(obReceipt.RECEIPT_NUMBER + "\t");
                strFileContents.Append((!string.IsNullOrEmpty(obReceipt.ReceiptDate) ? (Convert.ToDateTime(obReceipt.ReceiptDate)).ToString("MMM dd, yyyy") : "") + "\t");
                strFileContents.Append(obReceipt.Region + "\t");
                strFileContents.Append(obReceipt.USERID + "\t");
                strFileContents.Append(obReceipt.INVOICE_NUMBER + "\t");
                strFileContents.Append(obReceipt.INVOICE_AMOUNT + "\t");
                strFileContents.Append(obReceipt.ReceiptAmount + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportMaintainBank(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["MaintainBankReport"] != null) ? Session["MaintainBankReport"].ToString() : " DATEDIFF(D, R.RECEIPT_DATE, GETDATE()) = 0";

        IList<Bank> bank = (new BankFacade()).GetBankSearch(SearchString);

        if (bank != null && bank.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Bank Name" + "\t" + "Bank Code");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Bank objBank in bank)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(objBank.BankName + "\t");
                strFileContents.Append(objBank.BankCode + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportMaintainReason(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["MaintainReasonReport"] != null) ? Session["MaintainReasonReport"].ToString() : " DATEDIFF(D, R.RECEIPT_DATE, GETDATE()) = 0";

        IList<Reason> reason = (new ReasonFacade()).GetReasonSearch("ReasonId Desc", 0, 0, SearchString, SessionManager.UserCode, "");

        if (reason != null && reason.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Type" + "\t" + "Reason");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Reason objReason in reason)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(objReason.Type + "\t");
                strFileContents.Append(objReason.Name + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportMaintainSalesman(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["MaintainSalesmanReport"] != null) ? Session["MaintainSalesmanReport"].ToString() : " DATEDIFF(D, R.RECEIPT_DATE, GETDATE()) = 0";

        IList<Salesman> salesmans = (new SalesmanFacade()).GetSalesmanSearch("NAME Desc", 0, 0, SearchString);

        if (salesmans != null && salesmans.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Salesman Code" + "\t" + "Salesman Name" + "\t" + "Manager Code" + "\t" + "Employee No" + "\t" + "Start Date Active");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Salesman objsalesman in salesmans)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(objsalesman.SALES_EXECUTIVE_CODE + "\t");
                strFileContents.Append(objsalesman.NAME + "\t");
                strFileContents.Append(objsalesman.SALES_MANAGER_CODE + "\t");
                strFileContents.Append(objsalesman.EMPLOYEE_NUMBER + "\t");
                strFileContents.Append(objsalesman.START_DATE_ACTIVE + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportMaintainPrice(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["MaintainPriceReport"] != null) ? Session["MaintainSalesmanReport"].ToString() : " DATEDIFF(D, R.RECEIPT_DATE, GETDATE()) = 0";

        IList<Price> prices = (new PriceFacade()).GetPriceSearch("ITEMCODE DESC", 0, 0, SearchString, SessionManager.UserCode);

        if (prices != null && prices.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Item Code" + "\t" + "Customer Pricing Key" + "\t" + "Price Cases" + "\t" + "Start Date" + "\t" + "End Date" + "\t" + " 	Discount ");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Price objprice in prices)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(objprice.ITEMCODE + "\t");
                strFileContents.Append(objprice.CUSTOMERPRICINGKEY + "\t");
                strFileContents.Append(objprice.PRICECASES + "\t");
                strFileContents.Append(objprice.STARTDATE + "\t");
                strFileContents.Append(objprice.ENDDATE + "\t");
                strFileContents.Append(objprice.DISCOUNT + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportMaintainLocation(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["MaintainLocationReport"] != null) ? Session["MaintainLocationReport"].ToString() : " DATEDIFF(D, R.RECEIPT_DATE, GETDATE()) = 0";

        IList<Location> locations = (new LocationFacade()).GetLocationSearch("LOCATIONID ASC", 0, 0, SearchString);

        if (locations != null && locations.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Location Name" + "\t" + "Location Code" + "\t");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Location objLocation in locations)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(objLocation.LOCATIONNAME + "\t");
                strFileContents.Append(objLocation.LOCATIONID + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportMaintainItem(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["MaintainItemReport"] != null) ? Session["MaintainItemReport"].ToString() : " DATEDIFF(D, R.RECEIPT_DATE, GETDATE()) = 0";

        IList<Item> items = (new ItemFacade()).GetItemSearch("ITEMCODE ASC", 0, 0, SearchString, SessionManager.UserCode);

        if (items != null && items.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Item Code" + "\t" + "Item Description" + "\t" + "Category" + "\t" + "Brand" + "\t" + "Pricing Key");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Item objItem in items)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(objItem.ITEMCODE + "\t");
                strFileContents.Append(objItem.Description + "\t");
                strFileContents.Append(objItem.CATEGORY + "\t");
                strFileContents.Append(objItem.BRAND + "\t");
                strFileContents.Append(objItem.PRICINGKEY + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportMaintainCustomerGroup(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["MaintainCustomerGroupReport"] != null) ? Session["MaintainCustomerGroupReport"].ToString() : " DATEDIFF(D, R.RECEIPT_DATE, GETDATE()) = 0";

        IList<CustomerGroup> customergroups = (new CustomerGroupFacade()).GetCustomerGroupSearch("COMPANYID Desc", 0, 0, SearchString);

        if (customergroups != null && customergroups.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Company Id" + "\t" + "Cust Price Class" + "\t" + "Party Site Number");
            strFileContents.Append("\n");
            int i = 1;
            foreach (CustomerGroup objCustomergroups in customergroups)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(objCustomergroups.COMPANYID + "\t");
                strFileContents.Append(objCustomergroups.CUSTPRICECLASS + "\t");
                strFileContents.Append(objCustomergroups.PARTY_SITE_NUMBER + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportVanStockReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            SearchString = (Session["VanStockReport"] != null) ? Session["VanStockReport"].ToString() : "1=1";
            IList<VanStock> objVanStocks = new VanStockFacade().GetVanStockExport("V.UserCode DESC", SearchString, SessionManager.UserId);
            if (objVanStocks != null && objVanStocks.Count > 0)
            {
                strFileContents = new StringBuilder();

                strFileContents.Append("UserCode" + "\t" + "Salesman" + "\t" + "PartNo" + "\t" + "SellableQuantity" +
                    "\t" + "ReturnedQuantity" + "\t" + "TotalQuantity");
                strFileContents.Append("\n");

                foreach (VanStock objVanStock in objVanStocks)
                {
                    strFileContents.Append(objVanStock.UserCode + "\t");
                    strFileContents.Append(objVanStock.User.Description + "\t");
                    strFileContents.Append(objVanStock.ItemCode + "\t");
                    strFileContents.Append(objVanStock.SellableQuantity + "\t");
                    strFileContents.Append(objVanStock.ReturnedQuantity + "\t");
                    strFileContents.Append(objVanStock.TotalQuantity + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportReachBySubChannelReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            SearchString = (Session["OrderVsRecommended"] != null) ? Session["OrderVsRecommended"].ToString() : "1=1";
            ReachBySubChannel objReach = (new ReportsFacade()).GetReachBySubChannel("Item ASC", SearchString, 500, 0, SessionManager.UserCode);
            if (objReach != null && objReach.rows.Count > 0)
            {
                strFileContents = new StringBuilder();

                strFileContents.Append("" + "\t" + "");

                foreach (SubChannel objSubChannel in objReach.SubChannels)
                {
                    strFileContents.Append("\t" + objSubChannel.Code);
                }
                strFileContents.Append("\n");

                strFileContents.Append("Item Code" + "\t" + "Item");

                foreach (SubChannel objSubChannel in objReach.SubChannels)
                {
                    strFileContents.Append("\t" + objSubChannel.Description);
                }
                strFileContents.Append("\n");

                //foreach (TrxHeader objTrxHeader in objTrxHeaders)
                //{
                //    foreach (TrxDetail objTrxDetail in objTrxHeader.TrxDetails)
                //    {
                //        strFileContents.Append(objTrxHeader.OrderNumber + "\t");
                //        strFileContents.Append(objTrxHeader.Site_Number + "\t");
                //        strFileContents.Append(objTrxHeader.Site_Name + "\t");
                //        strFileContents.Append(objTrxDetail.ItemCode + "\t");
                //        strFileContents.Append(objTrxHeader.Order_Date + "\t");
                //        strFileContents.Append(objTrxDetail.RECOMMENDED_QTY + "\t");
                //        strFileContents.Append(objTrxDetail.ORDER_QUANTITY + "\t");
                //        strFileContents.Append("\n");
                //    }

                //}
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportOrdervsRecommended(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            SearchString = (Session["ReachReport"] != null) ? Session["ReachReport"].ToString() : "1=1";
            //IList<TrxHeader> objTrxHeaders = new TrxHeaderFacade().GetRecomendedOrderSearchExport(SearchString);
            //if (objTrxHeaders != null && objTrxHeaders.Count > 0)
            {
                strFileContents = new StringBuilder();

                strFileContents.Append("OrderNumber" + "\t" + "Site No" + "\t" + "Site Name" + "\t" + "Order Date" +
                    "\t" + "RecommendedQuantity" + "\t" + "OrderQuantity");
                strFileContents.Append("\n");

                //foreach (TrxHeader objTrxHeader in objTrxHeaders)
                {
                    //strFileContents.Append(objTrxHeader.TrxCode + "\t");
                    //strFileContents.Append(objTrxHeader.ClientCode + "\t");
                    //strFileContents.Append(objTrxHeader.Client.Description + "\t");
                    //strFileContents.Append(objTrxHeader.TrxDate + "\t");
                    //strFileContents.Append(objTrxHeader.RECOMMENDED_QTY + "\t");
                    //strFileContents.Append(objTrxHeader.ORDER_QUANTITY + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportSurveyReport(string strFileName)
    {
        //System.IO.StreamWriter sw;
        //try
        //{
        //    StringBuilder strFileContents = null;
        //    string SearchString = string.Empty;
        //    SearchString = (Session["OrderSearchString"] != null) ? Session["OrderSearchString"].ToString() : "1=1";
        //    IList<Survey> objSurveys = new SurveyFacade().GetSurveyForExport(SearchString);
        //    if (objSurveys != null && objSurveys.Count > 0)
        //    {
        //        strFileContents = new StringBuilder();

        //        strFileContents.Append("SalesMan" + "\t" + "Outlet" + "\t" + "Latitude" + "\t" + "Longitude" +
        //            "\t" + "SurverOn" + "\t" + "ClientCode" + "\t" + "JourneyCode" + "\t" + "UserRole" + "\t" + "VisitCode" + "\t" + "UserCode");
        //        strFileContents.Append("\n");

        //        foreach (Survey objSurvey in objSurveys)
        //        {
        //            strFileContents.Append(objSurvey.UserName + "\t");
        //            strFileContents.Append(objSurvey.SiteName + "\t");
        //            strFileContents.Append(objSurvey.Latitude + "\t");
        //            strFileContents.Append(objSurvey.Longitude + "\t");
        //            strFileContents.Append(objSurvey.Date + "\t");
        //            strFileContents.Append(objSurvey.ClientCode + "\t");
        //            strFileContents.Append(objSurvey.JourneyCode + "\t");
        //            strFileContents.Append(objSurvey.UserRole + "\t");
        //            strFileContents.Append(objSurvey.VisitCode + "\t");
        //            strFileContents.Append(objSurvey.UserCode + "\t");

        //            strFileContents.Append("\n");
        //        }
        //        sw = System.IO.File.CreateText(strFileName);
        //        sw.Write(strFileContents.ToString());
        //        sw.Close();
        //    }
        //}
        //catch (Exception ex)
        //{
        //    CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        //}
    }

    private void ExportCoreSKus(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            SearchString = (Session["CoreSkuSearch"] != null) ? Session["CoreSkuSearch"].ToString() : "1=1";
            IList<CoreSku> objItems = new CoreSkuFacade().GetCoreSkuExport("CS.ItemCode ASC", SearchString);
            if (objItems != null && objItems.Count > 0)
            {
                strFileContents = new StringBuilder();

                strFileContents.Append("ItemCode" + "\t" + "ItemDescription" + "\t" + "BrandCode" + "\t" + "Brand" + "\t" +
                    "ChannelCode" + "\t" + "ChannelDescription" + "\t" + "IsCoreSku" + "\t" + "DisplayOrder");

                strFileContents.Append("\n");
                foreach (CoreSku objItem in objItems)
                {
                    strFileContents.Append(objItem.ItemCode + "\t");
                    strFileContents.Append(objItem.Item.Description + "\t");
                    strFileContents.Append(objItem.Item.GroupCodeLevel5 + "\t");
                    strFileContents.Append(objItem.Item.BrandName + "\t");
                    strFileContents.Append(objItem.SubChannel.Code + "\t");
                    strFileContents.Append(objItem.SubChannel.Description + "\t");
                    strFileContents.Append(objItem.IsCoreSku + "\t");
                    strFileContents.Append(objItem.DisplayOrder + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportLogReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = "1=1";
            string Logreport_Filter = string.Empty;
            string fromDate = DateTime.Now.ToString();
            string toDate = DateTime.Now.ToString();
            if (Request.QueryString["Logreport_Filter"] != null && !string.IsNullOrEmpty(Request.QueryString["Logreport_Filter"].ToString()))
            {
                Logreport_Filter = Request.QueryString["Logreport_Filter"].ToString();
                if (Logreport_Filter.Length > 0)
                {
                    string[] searchStr = Logreport_Filter.Split('^');
                    SearchString = searchStr[0];
                    fromDate = searchStr[1];
                    toDate = searchStr[2];
                }
            }
            SearchString = (Session["CoreSkuSearch"] != null) ? Session["CoreSkuSearch"].ToString() : "1=1";
            IList<LogReportDetail> LogReportDetails = new LogReportFacade().GetLogReportSearch_Export(SearchString, fromDate, toDate, "1", "4", SessionManager.UserCode);
            if (LogReportDetails != null && LogReportDetails.Count > 0)
            {
                strFileContents = new StringBuilder();
                foreach (LogReportDetail objLogReportDetail in LogReportDetails)
                {
                    strFileContents.Append("\t \t \t Log Report for " + objLogReportDetail.EmpNo);
                    strFileContents.Append("\n");
                    strFileContents.Append("\t \t \t From \t" + fromDate + "\t To \t" + toDate);
                    strFileContents.Append("\n");
                    strFileContents.Append("\t Total Scheduled Calls \t " + objLogReportDetail.LogReport.ScheduledCalls + " \t Total Sales \t SAR" + objLogReportDetail.LogReport.TotalSales + "\t Monthly Sales \t SAR" + objLogReportDetail.LogReport.TotalSales);
                    strFileContents.Append("\n");
                    strFileContents.Append("\t Actual Calls \t " + objLogReportDetail.LogReport.TotalCalls + " \t Total Credit Note Calls \t SAR" + objLogReportDetail.LogReport.TotalCredits);
                    strFileContents.Append("\n");
                    strFileContents.Append("\t Total Productive Calls \t " + objLogReportDetail.LogReport.ProductiveCalls + " \t Total Payment Received \t SAR" + objLogReportDetail.LogReport.TotalPayments);
                    strFileContents.Append("\n");
                }



                strFileContents.Append("ItemCode" + "\t" + "ItemDescription" + "\t" + "BrandCode" + "\t" + "Brand" + "\t" +
                    "ChannelCode" + "\t" + "ChannelDescription" + "\t" + "IsCoreSku" + "\t" + "DisplayOrder");

                strFileContents.Append("\n");
                //foreach (CoreSku objItem in objItems)
                //{
                //    strFileContents.Append(objItem.ItemCode + "\t");
                //    strFileContents.Append(objItem.Item.Description + "\t");
                //    strFileContents.Append(objItem.Item.GroupCodeLevel5 + "\t");
                //    strFileContents.Append(objItem.Item.BrandName + "\t");
                //    strFileContents.Append(objItem.SubChannel.Code + "\t");
                //    strFileContents.Append(objItem.SubChannel.Description + "\t");
                //    strFileContents.Append(objItem.IsCoreSku + "\t");
                //    strFileContents.Append(objItem.DisplayOrder + "\t");

                //    strFileContents.Append("\n");
                //}
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportStoreGroupSKus(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            SearchString = (Session["StoreGroupSkuSearch"] != null) ? Session["StoreGroupSkuSearch"].ToString() : "1=1";
            IList<StoreGroupSku> objItems = new StoreGroupSkuFacade().GetStoreGroupSkuExport("CS.ItemCode ASC", SearchString);
            if (objItems != null && objItems.Count > 0)
            {
                strFileContents = new StringBuilder();

                strFileContents.Append("ItemCode" + "\t" + "ItemDescription" + "\t" + "BrandCode" + "\t" + "Brand" + "\t" +
                    "Client Group Code" + "\t" + "Client Group");// + "\t" + "IsCoreSku" + "\t" + "DisplayOrder");

                strFileContents.Append("\n");
                foreach (StoreGroupSku objItem in objItems)
                {
                    strFileContents.Append(objItem.ItemCode + "\t");
                    strFileContents.Append(objItem.Item.Description + "\t");
                    strFileContents.Append(objItem.Item.GroupCodeLevel5 + "\t");
                    strFileContents.Append(objItem.Item.objbrand.Description + "\t");
                    strFileContents.Append(objItem.StoreGroup.Code + "\t");
                    strFileContents.Append(objItem.StoreGroup.Description + "\t");
                    //strFileContents.Append(objItem.IsCoreSku + "\t");
                    //strFileContents.Append(objItem.DisplayOrder + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportSellingSKus(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;

            IList<SellingSKUClassification> objItems = new CustomerGroupSkuFacade().GetSellingSKUClassification();
            if (objItems != null && objItems.Count > 0)
            {
                strFileContents = new StringBuilder();

                strFileContents.Append("ItemCode" + "\t" + "GroupType" + "\t" + "GroupCode" + "\t" + "IsCoreSKU" + "\t");
                foreach (SellingSKUClassification objItem in objItems)
                {
                    strFileContents.Append(objItem.Description.Replace(" ", "") + "\t");
                }
                strFileContents.Append("\n");
                strFileContents.Append("SB0kmyx" + "\t" + "Customer" + "\t" + "100" + "\t" + "True" + "\t");
                for (int i = 0; i < objItems.Count; i++)
                {
                    if (i == 1)
                    {
                        strFileContents.Append("Fase" + "\t");
                    }
                    else if (i == 2)
                    {
                        strFileContents.Append("1" + "\t");
                    }
                    else
                    {
                        strFileContents.Append("No" + "\t");
                    }

                }
                strFileContents.Append("\n");
                strFileContents.Append("SB1xyz" + "\t" + "CustomerSalesGroup" + "\t" + "100" + "\t" + "No" + "\t");
                for (int i = 0; i < objItems.Count; i++)
                {
                    if (i == 1)
                    {
                        strFileContents.Append("Yes" + "\t");
                    }
                    else if (i == 2)
                    {
                        strFileContents.Append("False" + "\t");
                    }
                    else
                    {
                        strFileContents.Append("0" + "\t");
                    }

                }
                strFileContents.Append("\n");
                strFileContents.Append("SB1zyx" + "\t" + "Channel" + "\t" + "500" + "\t" + "True" + "\t");
                for (int i = 0; i < objItems.Count; i++)
                {
                    if (i == 1)
                    {
                        strFileContents.Append("Fase" + "\t");
                    }
                    else if (i == 2)
                    {
                        strFileContents.Append("1" + "\t");
                    }
                    else
                    {
                        strFileContents.Append("No" + "\t");
                    }

                }
                strFileContents.Append("\n");
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportSellingSKusData(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string GroupType = string.Empty;
            SearchString = (Session["StoreGroupSkuSearch"] != null) ? Session["StoreGroupSkuSearch"].ToString() : "1=1";
            GroupType = (Session["GroupType"] != null) ? Session["GroupType"].ToString() : "Customer";
            IList<SellingSKUClassification> objSC = new CustomerGroupSkuFacade().GetSellingSKUClassification();
            IList<CustomerGroupSku> objItems = new CustomerGroupSkuFacade().GetSellingSkuExport("Code ASC", SearchString, GroupType);

            if (objItems != null && objItems.Count > 0)
            {
                strFileContents = new StringBuilder();

                //strFileContents.Append("Item Code" + "\t" + "Item Description" + "\t" + "Brand Name" + "\t" +
                //    "Group Code" + "\t" + "Group Name" + "\t" + "Group Type" + "\t" + "IsCoreSku" + "\t" + "DisplayOrder" + "\t" + "IsNPD");
                strFileContents.Append("Item Code" + "\t" + "Item Description" + "\t" + "Brand Name" + "\t" +
                   "Group Code" + "\t" + "Group Name" + "\t" + "Group Type");
                foreach (SellingSKUClassification col in objSC)
                {
                    strFileContents.Append("\t");
                    strFileContents.Append(col.Description);
                }

                strFileContents.Append("\n");
                foreach (CustomerGroupSku objItem in objItems)
                {
                    strFileContents.Append(objItem.ItemCode + "\t");
                    strFileContents.Append(objItem.Item.Description + "\t");
                    strFileContents.Append(objItem.Item.GroupCodeLevel5 + "\t");
                    strFileContents.Append(objItem.CustomerGroups.Code + "\t");
                    strFileContents.Append(objItem.CustomerGroups.Description.Replace(",", "") + "\t");
                    //strFileContents.Append(objItem.GroupType + "\t");
                    //strFileContents.Append(objItem.IsCoreSku == false ? "No" + "\t" : "Yes" + "\t");
                    //strFileContents.Append((objItem.DisplayOrder == 99999 ? "N/A" : objItem.DisplayOrder.ToString()) + "\t");
                    //strFileContents.Append(objItem.IsNPD == false ? "No" : "Yes");
                    foreach (SellingSKUClassification colData in objItem.lstSellingSkuCls)
                    {
                        strFileContents.Append("\t");
                        strFileContents.Append(colData.Description == "" ? "No" : "Yes");
                    }

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }



    private void ExportCustomerStatement(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;


            string SearchString = string.Empty;
            string SortExpression = "Code DESC";

            SearchString = (Session["CustomerStatementSearchString"] != null) ? Session["CustomerStatementSearchString"].ToString() : "1=1";
            IList<Customer> objCustomers = new CustomerFacade().GetCustomerStatementCustomerSearch_Export(SortExpression, SearchString, SessionManager.UserCode, Session["DateSearchString"].ToString());

            if (objCustomers != null && objCustomers.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Sales Org" + "\t" + "Total Sales" + "\t" + "Credit Limit" + "\t" + "Pending Amount" + "\t");

                strFileContents.Append("\n");
                foreach (Customer objCustomer in objCustomers)
                {
                    strFileContents.Append(objCustomer.Site + "\t");
                    strFileContents.Append(objCustomer.SiteName + "\t");
                    strFileContents.Append(objCustomer.SalesOrganization + "\t");
                    strFileContents.Append("SAR" + " " + objCustomer.TotalSales + "\t");
                    strFileContents.Append("SAR" + " " + objCustomer.CreditLimit + "\t");
                    strFileContents.Append("SAR" + " " + objCustomer.PendingAmount + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportCompetitorReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string SortExpression = "CreatedOn DESC";

            SearchString = (Session["CompetitorReportSearchString"] != null) ? Session["CompetitorReportSearchString"].ToString() : "1=1";

            IList<Competitor> objCompetitorList = new CompetitorFacade().GetViewCompetitorSearch_Export(SortExpression, SearchString);

            if (objCompetitorList != null && objCompetitorList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Date" + "\t" + "Store Name" + "\t" + "Our Brand" + "\t" + "Competitor Brand" + "\t" + "Competitor Company" + "\t");

                strFileContents.Append("\n");
                foreach (Competitor objCompetitor in objCompetitorList)
                {
                    strFileContents.Append(objCompetitor.CreatedOn + "\t");
                    strFileContents.Append(objCompetitor.Store + "\t");
                    strFileContents.Append(objCompetitor.OurBrand + "\t");
                    strFileContents.Append(objCompetitor.BrandName + "\t");
                    strFileContents.Append(objCompetitor.Company + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportMaintainMovementReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;

            string SearchString = string.Empty;
            string SortExpression = "MovementDate Desc";
            string UserCode = "";
            SearchString = (Session["MaintainMovementSearchstring"] != null) ? Session["MaintainMovementSearchstring"].ToString() : "1=1";
            IList<MovementHeaderReport> objMovementHeaderList = new MovementHeaderFacade().GetMovementHeaderSearchNew_Export(SortExpression, SearchString, UserCode);

            if (objMovementHeaderList != null && objMovementHeaderList.Count > 0)
            {
                strFileContents = new StringBuilder();
                foreach (MovementHeaderReport objMovementHeaderReport in objMovementHeaderList)
                {

                    strFileContents.Append("User Code" + "\t" + "User Name" + "\t");

                    strFileContents.Append("Movement Code" + "\t" + "Type" + "\t" + "Date" + "\t" + "Status" + "\t");
                    strFileContents.Append("\n");
                    int count = 0;
                    foreach (MovementHeader objMovementHeader in objMovementHeaderReport.MovementHeaderList)
                    {
                        if (count == 0)
                        {
                            strFileContents.Append(objMovementHeaderReport.UserCode + "\t");
                            strFileContents.Append(objMovementHeaderReport.UserName + "\t");
                            count++;
                        }
                        else
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                        }
                        strFileContents.Append(objMovementHeader.MovementCode + "\t");
                        if (objMovementHeader.MovementType == 1)
                        {
                            strFileContents.Append("Load" + "\t");
                        }
                        else
                        {
                            strFileContents.Append("Unload" + "\t");
                        }
                        strFileContents.Append(objMovementHeader.MovementDate + "\t");
                        if (objMovementHeader.Status == 2)
                        {
                            strFileContents.Append("Pending" + "\t");
                        }
                        else if (objMovementHeader.Status == 3)
                        {
                            strFileContents.Append("Rejected" + "\t");
                        }
                        else
                        {
                            strFileContents.Append("Approved" + "\t");
                        }
                        strFileContents.Append("\n");
                    }
                    strFileContents.Append("\n");
                    strFileContents.Append(Environment.NewLine);
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportPDCDetailsReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {

            StringBuilder strFileContents = null;
            string QueryStr = "";
            if (Request.QueryString != null)
                QueryStr = Request.QueryString.ToString();
            // QueryStr = QueryStr.Split("^");
            string SearchString = string.Empty;
            SearchString = (Session["PDCDetailsReport"] != null) ? Session["PDCDetailsReport"].ToString() : "";
            string SortExpression = "CHEQUEDATE Desc";

            IList<PDCDetailsReport> objPDCDetailsReportList = new PDCDetailsReportFacade().GetPDCDetailsSearch_Export(SortExpression, SearchString, SessionManager.UserCode);

            if (objPDCDetailsReportList != null && objPDCDetailsReportList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Receipt Number" + "\t" + "Maturity Date" + "\t" + "Bank Name" + "\t" + "Cheque No." + "\t" + "Total Amount");
                strFileContents.Append("\n");
                foreach (PDCDetailsReport objPDCDetailsReport in objPDCDetailsReportList)
                {

                    strFileContents.Append(objPDCDetailsReport.SITE_NUMBER + "\t");
                    strFileContents.Append(objPDCDetailsReport.Site_Name + "\t");
                    strFileContents.Append(objPDCDetailsReport.Receipt_Number + "\t");
                    strFileContents.Append(objPDCDetailsReport.CHEQUEDATE + "\t");
                    strFileContents.Append(objPDCDetailsReport.BankName + "\t");
                    strFileContents.Append(objPDCDetailsReport.ChequeNo + "\t");
                    strFileContents.Append(objPDCDetailsReport.TotalAmount + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportOrderFulfillmentReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;

            string SearchString = string.Empty;
            string SortExpression = "MovementDate Desc";
            string UserCode = "";
            int maximumrows = 100;
            int startrowindex = 0;
            SearchString = "1=1";//(Session["OrderFulfillmentReport"] != null) ? Session["OrderFulfillmentReport"].ToString() : "1=1";
            IList<MovementHeaderReport> objMovementHeaderList = new MovementHeaderFacade().GetMovementHeaderSearchFulFill_Export(SortExpression, maximumrows, startrowindex, SearchString, UserCode);

            if (objMovementHeaderList != null && objMovementHeaderList.Count > 0)
            {
                strFileContents = new StringBuilder();
                foreach (MovementHeaderReport objMovementHeaderReport in objMovementHeaderList)
                {

                    strFileContents.Append("Movement Date" + "\t" + " Avg Fulfill Percent" + "\t");

                    strFileContents.Append("Salesman" + "\t" + "Requested Quantity" + "\t" + "Shipped Quantity" + "\t" + "Fulfill Percent" + "\t");
                    strFileContents.Append("\n");
                    int count = 0;
                    foreach (MovementHeader objMovementHeader in objMovementHeaderReport.MovementHeaderList)
                    {
                        if (count == 0)
                        {
                            strFileContents.Append(objMovementHeaderReport.MovementDate + "\t");
                            strFileContents.Append(objMovementHeaderReport.FulfillPercent + "\t");
                            count++;
                        }
                        else
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                        }
                        strFileContents.Append(objMovementHeader.UserCode + "\t");
                        strFileContents.Append(objMovementHeader.RequestedQuantity + "\t");
                        strFileContents.Append(objMovementHeader.ShippedQuantity + "\t");
                        strFileContents.Append(objMovementHeader.FulfillPercent + "\t");
                        strFileContents.Append("\n");
                    }
                    strFileContents.Append("\n");
                    strFileContents.Append(Environment.NewLine);
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    //private void ExportDailySalesReport(string strFileName)
    //{
    //    System.IO.StreamWriter sw;
    //    try
    //    {
    //        StringBuilder strFileContents = null;
    //        string SearchString = string.Empty;
    //        string GroupType = string.Empty;
    //        string Salesteam = string.Empty;
    //        SearchString = (Session["DailySalesReport_Filter_Excel"] != null) ? (Session["DailySalesReport_Filter_Excel"].ToString()) : "1=1";
    //        Salesteam = "";// (Session["DailySalesReport_Filter_Excel"] != null) ? (Session["DailySalesReport_Filter_Excel"].ToString()).Split('^')[1] : "";
    //        List<TrxHeader> lstTrxHeader = (new TrxHeaderFacade()).GetDSRSalesmanReport(SearchString, Session["DailySalesReport_FilterUserCode"].ToString(), Salesteam);
    //        strFileContents = new StringBuilder();
    //        strFileContents.Append("Total Cash Sales" + "\t" + "Total Credit Sales" + "\t" + "Total Credit Notes" + "\t" +
    //               "Total Sales\n");
    //        if (lstTrxHeader != null && lstTrxHeader.Count > 0)
    //        {
    //            List<TrxHeader> lstCashSales = (from t in lstTrxHeader
    //                                            where (t.TrxType == 1 || t.TrxType == 3 || t.TrxType == 5) && t.PaymentType == 1 // && t.PaymentType == 0
    //                                            select t).ToList();
    //            List<TrxHeader> lstCreditSales = (from t in lstTrxHeader
    //                                              where (t.TrxType == 1 || t.TrxType == 3 || t.TrxType == 5) && t.PaymentType == 0// && t.PaymentType == 1
    //                                              select t).ToList();
    //            List<TrxHeader> lstCreditNote = (from t in lstTrxHeader
    //                                             where t.TrxType == 4 && (t.TRXStatus == 100)// (t.TRXStatus == 2 || t.TRXStatus == 5 || t.TRXStatus == 6 || t.TRXStatus == -15)
    //                                             select t).ToList();
    //            string totalCashSales = String.Format("{0:f2}", lstCashSales.Sum(c => (decimal)c.TotalAmount));
    //            string totalCreditSales = String.Format("{0:f2}", lstCreditSales.Sum(c => (decimal)c.TotalAmount));
    //            string totalCreditNotes = String.Format("{0:f2}", lstCreditNote.Sum(c => (decimal)c.TotalAmount));
    //            decimal totalSales = lstCashSales.Sum(c => (decimal)c.TotalAmount) + lstCreditSales.Sum(c => (decimal)c.TotalAmount) - lstCreditNote.Sum(c => (decimal)c.TotalAmount);
    //            strFileContents.Append("SAR " + totalCashSales + "\t" + "SAR " + totalCreditSales + "\t" + "SAR " + totalCreditNotes + "\t" + "SAR " + totalSales);
    //            strFileContents.Append("\n\n\n");
    //            strFileContents.Append("Cash Sales\n");
    //            strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Invoice" + "\t" +
    //                "Total Amount (SAR)\n");
    //            if (lstCashSales != null && lstCashSales.Count > 0)
    //            {
    //                foreach (TrxHeader objItem in lstCashSales)
    //                {
    //                    strFileContents.Append(objItem.ClientCode + "\t");
    //                    strFileContents.Append(objItem.Site_Name + "\t");
    //                    strFileContents.Append(objItem.TrxCode + "\t");
    //                    strFileContents.Append(objItem.TotalAmount + "\t");
    //                    strFileContents.Append("\n");
    //                }
    //            }
    //            strFileContents.Append("\n\n\n");
    //            strFileContents.Append("Credit Sales\n");
    //            strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Invoice" + "\t" +
    //                "Total Amount (SAR)\n");
    //            if (lstCreditSales != null && lstCreditSales.Count > 0)
    //            {
    //                foreach (TrxHeader objItem in lstCreditSales)
    //                {
    //                    strFileContents.Append(objItem.ClientCode + "\t");
    //                    strFileContents.Append(objItem.Site_Name + "\t");
    //                    strFileContents.Append(objItem.TrxCode + "\t");
    //                    strFileContents.Append(objItem.TotalAmount + "\t");
    //                    strFileContents.Append("\n");
    //                }
    //            }
    //            strFileContents.Append("\n\n\n");
    //            strFileContents.Append("Credit Notes\n");
    //            strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Invoice" + "\t" +
    //                "Total Amount (SAR)\n");
    //            if (lstCreditNote != null && lstCreditNote.Count > 0)
    //            {
    //                foreach (TrxHeader objItem in lstCreditNote)
    //                {
    //                    strFileContents.Append(objItem.ClientCode + "\t");
    //                    strFileContents.Append(objItem.Site_Name + "\t");
    //                    strFileContents.Append(objItem.TrxCode + "\t");
    //                    strFileContents.Append(objItem.TotalAmount + "\t");
    //                    strFileContents.Append("\n");
    //                }
    //            }
    //            sw = System.IO.File.CreateText(strFileName);
    //            sw.Write(strFileContents.ToString());
    //            sw.Close();
    //        }
    //        else
    //        {
    //            strFileContents.Append("SAR 0.00" + "\t" + "SAR 0.00" + "\t" + "SAR 0.00" + "\t" + "SAR 0.00");
    //            strFileContents.Append("\n\n\n");
    //            strFileContents.Append("Cash Sales\n");
    //            strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Invoice" + "\t" +
    //                "Total Amount (SAR)\n");
    //            strFileContents.Append("\n\n\n");
    //            strFileContents.Append("Credit Sales\n");
    //            strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Invoice" + "\t" +
    //                "Total Amount (SAR)\n");
    //            strFileContents.Append("\n\n\n");
    //            strFileContents.Append("Credit Notes\n");
    //            strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Invoice" + "\t" +
    //                "Total Amount (SAR)\n");
    //            sw = System.IO.File.CreateText(strFileName);
    //            sw.Write(strFileContents.ToString());
    //            sw.Close();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
    //    }
    //}

    private void ExportDailyOrdersReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string GroupType = string.Empty;
            string Salesteam = string.Empty;
            SearchString = (Session["DailySalesReport_Filter_Excel"] != null) ? (Session["DailySalesReport_Filter_Excel"].ToString()) : "1=1";
            Salesteam = "";
            List<TrxHeader> lstTrxHeader = (new TrxHeaderFacade()).GetDSRSalesmanReport(SearchString, Session["DailySalesReport_FilterUserCode"].ToString(), Salesteam);
            strFileContents = new StringBuilder();
            strFileContents.Append("Total Cash Orders" + "\t" + "Total Credit Orders" + "\t" + "Total Orders\n");
            if (lstTrxHeader != null && lstTrxHeader.Count > 0)
            {
                List<TrxHeader> lstCashSales = (from t in lstTrxHeader
                                                where (t.TrxType == 1 || t.TrxType == 3 || t.TrxType == 5) && t.PaymentType == 1 // && t.PaymentType == 0
                                                select t).ToList();
                List<TrxHeader> lstCreditSales = (from t in lstTrxHeader
                                                  where (t.TrxType == 1 || t.TrxType == 3 || t.TrxType == 5) && t.PaymentType == 0// && t.PaymentType == 1
                                                  select t).ToList();
                List<TrxHeader> lstCreditNote = (from t in lstTrxHeader
                                                 where t.TrxType == 4 && (t.TRXStatus == 100)// (t.TRXStatus == 2 || t.TRXStatus == 5 || t.TRXStatus == 6 || t.TRXStatus == -15)
                                                 select t).ToList();

                //string totalCashSales = String.Format("{0:f2}", lstCashSales.Sum(c => Math.Round(c.TotalAmount, 3)));
                //string totalCreditSales = String.Format("{0:f2}", lstCreditSales.Sum(c => Math.Round(c.TotalAmount, 3)));
                //string totalCreditNotes = String.Format("{0:f2}", lstCreditNote.Sum(c => Math.Round(c.TotalAmount, 3)));

                string totalCashSales = CommonFunctions.GetCurrencyFormatWithThousands_New(lstCashSales.Sum(c => Math.Round(c.TotalAmount, 3)));
                string totalCreditSales = CommonFunctions.GetCurrencyFormatWithThousands_New(lstCreditSales.Sum(c => Math.Round(c.TotalAmount, 3)));
                string totalCreditNotes = CommonFunctions.GetCurrencyFormatWithThousands_New(lstCreditNote.Sum(c => Math.Round(c.TotalAmount, 3)));


                decimal totalSales = lstCashSales.Sum(c => (decimal)c.TotalAmount) + lstCreditSales.Sum(c => (decimal)c.TotalAmount) - lstCreditNote.Sum(c => (decimal)c.TotalAmount);

                strFileContents.Append("SAR " + totalCashSales + "\t" + "SAR " + totalCreditSales + "\t" + "SAR " + totalSales);
                strFileContents.Append("\n\n\n");
                strFileContents.Append("Cash Sales\n");
                strFileContents.Append("Customer  " + "\t" + "User  " + "\t" + "Invoice" + "\t" + "Total Amount \n");
                if (lstCashSales != null && lstCashSales.Count > 0)
                {


                    foreach (TrxHeader objItem in lstCashSales)
                    {
                        strFileContents.Append(objItem.ClientCode + "[" + objItem.Site_Name + "]" + "\t");
                        strFileContents.Append(objItem.UserCode + "[" + objItem.User.UserName + "]" + "\t");
                        strFileContents.Append(objItem.TrxCode + "\t");
                        strFileContents.Append("SAR " + CommonFunctions.GetCurrencyFormatWithThousands_New(objItem.TotalAmount) + "\t");
                        strFileContents.Append("\n");
                    }
                }
                strFileContents.Append("\n\n\n");
                strFileContents.Append("Credit Sales\n");

                strFileContents.Append("Customer  " + "\t" + "User  " + "\t" + "Invoice #" + "\t" + "Total Amount   \n");

                if (lstCreditSales != null && lstCreditSales.Count > 0)
                {
                    foreach (TrxHeader objItem in lstCreditSales)
                    {
                        strFileContents.Append(objItem.ClientCode + "[" + objItem.Site_Name + "]" + "\t");
                        strFileContents.Append(objItem.UserCode + "[" + objItem.User.UserName + "]" + "\t");
                        strFileContents.Append(objItem.TrxCode + "\t");
                        strFileContents.Append("SAR " + CommonFunctions.GetCurrencyFormatWithThousands_New(objItem.TotalAmount) + "\t");
                        strFileContents.Append("\n");

                    }
                }
                strFileContents.Append("\n\n\n");
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
            else
            {
                strFileContents.Append("SAR 0.00" + "\t" + "SAR 0.000" + "\t" + "SAR 0.000" + "\t" + "SAR 0.000");
                strFileContents.Append("\n\n\n");
                strFileContents.Append("Cash Sales\n");
                strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Invoice" + "\t" +
                    "Total Amount (SAR)\n");
                strFileContents.Append("\n\n\n");
                strFileContents.Append("Credit Sales\n");
                strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Invoice" + "\t" +
                    "Total Amount (SAR)\n");
                strFileContents.Append("\n\n\n");
                strFileContents.Append("Credit Notes\n");
                strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Invoice" + "\t" +
                    "Total Amount (SAR)\n");
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    private void ExportDSRSupervisorReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string DSRSupervisourReport_SalesManagerCode = (Session["DSRSupervisourReport_SalesManagerCode"] != null) ? CommonFunctions.getStringValue(Session["DSRSupervisourReport_SalesManagerCode"]) : "";
            DateTime DSRSupervisourReport_Date = (Session["DSRSupervisourReport_Date"] != null) ? Convert.ToDateTime(Session["DSRSupervisourReport_Date"]) : DateTime.Now;
            string DSRSupervisourReport_ProductiveType = (Session["DSRSupervisourReport_ProductiveType"] != null) ? CommonFunctions.getStringValue(Session["DSRSupervisourReport_ProductiveType"]) : "";
            string DSRSupervisourReport_UnProductiveType = (Session["DSRSupervisourReport_UnProductiveType"] != null) ? CommonFunctions.getStringValue(Session["DSRSupervisourReport_UnProductiveType"]) : "";
            string DSRSupervisourReport_UserCodes = (Session["DSRSupervisourReport_UserCodes"] != null) ? CommonFunctions.getStringValue(Session["DSRSupervisourReport_UserCodes"]) : "";
            DataTable dt = new DSRSupervisorReportFacade().GetDSRSupervisorReportHeaders(DSRSupervisourReport_Date, DSRSupervisourReport_UserCodes, SessionManager.UserCode);
            strFileContents.Append("Monthly Sales Target" + "\t" + "Monthly Sales" + "\t" + "Target Acheived" + "\t" + "Daily Sales\n");
            string MonthlySalesTarget = "0.00";
            string MonthlySales = "0.00";
            string Achieved = "0.00 %";
            string DailySales = "0.00";
            if (dt != null && dt.Rows.Count > 0)
            {
                MonthlySalesTarget = CommonFunctions.GetCurrencyFormatWithThousands(dt.Rows[0]["MonthlySalesTarget"]);
                MonthlySales = CommonFunctions.GetCurrencyFormatWithThousands(dt.Rows[0]["MonthlySales"]).Replace("-", "- ");
                Achieved = CommonFunctions.GetCurrencyFormatWithThousands(dt.Rows[0]["Achieved"]) + " %";
                DailySales = CommonFunctions.GetCurrencyFormatWithThousands(dt.Rows[0]["DailySales"]).Replace("-", "- ");
            }
            strFileContents.Append(MonthlySalesTarget + "\t" + MonthlySales + "\t" + Achieved + "\t" + DailySales + "\n");
            strFileContents.Append("\n\n\n");
            IList<DSRSupervisorReport> objDSRSupervisorReportList = (new DSRSupervisorReportFacade()).GetDSRSupervisorReportSearch("", 10, 1, "1=1", DSRSupervisourReport_SalesManagerCode, DSRSupervisourReport_Date, DSRSupervisourReport_ProductiveType, DSRSupervisourReport_UnProductiveType, "", SessionManager.UserCode);
            strFileContents.Append("Supervisor" + "\t" + "Total Calls" + "\t" + "Total Productive Calls" + "\t" +
                   "Strike Rate" + "\t" + "Mothly Sales Target" + "\t" + "Coverage Target" + "\t" + "JP Adherence"
                   + "\t" + "Month Achievement" + "\t" + "Month Coverage" + "\t" + "Salable Amount"
                    + "\t" + "Month Achievement(%)" + "\t" + "Month Productive" + "\t" + "Non Salable Amount"
                     + "\t" + "Balance ToGo" + "\t" + "Productive Vs Coverage"
                   + "\n");
            if (objDSRSupervisorReportList != null && objDSRSupervisorReportList.Count > 0)
            {
                foreach (DSRSupervisorReport objItem in objDSRSupervisorReportList)
                {
                    strFileContents.Append(objItem.UserName + "\t");
                    strFileContents.Append(objItem.TotalCalls + "\t");
                    strFileContents.Append(objItem.TotalProductiveCalls + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands(objItem.StrikeRate) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands(objItem.MonthTarget) + "\t");
                    strFileContents.Append(objItem.CoverageTarget + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands(objItem.Achievement) + " %\t");
                    strFileContents.Append("SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objItem.MonthAch) + "\t");
                    strFileContents.Append(objItem.MonthCoverage + " %\t");
                    strFileContents.Append("SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objItem.Salable) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands(objItem.MonthAchPercent) + " %\t");
                    strFileContents.Append(objItem.MonthProductive + "\t");
                    strFileContents.Append("SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objItem.Nonsalable) + "\t");
                    strFileContents.Append("SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objItem.BalanceToGo) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands(objItem.ProVSCov) + " %");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportWeeklyCustomerOrderHistory(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string WeeklyCustomerOrderHistory_SearchString = (Session["WeeklyCustomerOrderHistory_SearchString"] != null) ? CommonFunctions.getStringValue(Session["WeeklyCustomerOrderHistory_SearchString"]) : "1=1";

            IList<TrxHeader> objTrxHeaderList = (new TrxHeaderFacade()).GetTrxHeaderSearch_Export("", 10, 1, WeeklyCustomerOrderHistory_SearchString, SessionManager.UserCode);

            if (objTrxHeaderList != null && objTrxHeaderList.Count > 0)
            {
                strFileContents.Append("Order No" + "\t" + "Salesman" + "\t" + " Customer Name" + "\t" +
                 "Status" + "\t" + "Order Date"
                 + "\n");
                foreach (TrxHeader objItem in objTrxHeaderList)
                {
                    strFileContents.Append(objItem.TrxCode + "\t");
                    strFileContents.Append("[" + objItem.UserCode + "]" + objItem.User.Description + "\t");
                    strFileContents.Append("[" + objItem.ClientCode + "]" + objItem.Client.Description + "\t");
                    strFileContents.Append(objItem.StatusCode + "\t");
                    strFileContents.Append(objItem.TrxDate + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    private void ExportWeeklyOrdersHistory(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string GrvStatus = "";
            string SortExpression = "";
            string Region = "";
            string SalesOrg = "";
            string SearchString = Session["WeeklyOrderHisotrySearchString"].ToString();
            SortExpression = (Session["WeeklyOrderHisotrySortExpression"] != null) ? CommonFunctions.getStringValue(Session["WeeklyOrderHisotrySortExpression"]) : "TrxDate Asc";



            int StartRowIndex = 0;
            if (Session["WeeklyOrderHisotryRegion"] != null)
            {
                Region = Session["WeeklyOrderHisotryRegion"].ToString();
            }

            if (Session["WeeklyOrderHisotryGRVStatus"] != null)
            {
                GrvStatus = Session["WeeklyOrderHisotryGRVStatus"].ToString();
            }
            if (Session["UCCommonFilterSalesOrg"] != null)
            {
                SalesOrg = Session["UCCommonFilterSalesOrg"].ToString();
            }
            string UserCode = Session["WeeklyOrderHisotryUserCode"].ToString();

            if (SearchString != null && Region != null && GrvStatus != null && SalesOrg != null)
            {
                WeeklyOrderHistoryResult objWeeklyOrderHistoryResultList = new WeeklyOrderHistoryFacade().GetWeeklySalesHistory(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, SalesOrg, Region);
                List<WeeklyOrderHistory> lstWeeklyOrderHistory = new List<WeeklyOrderHistory>();
                lstWeeklyOrderHistory = objWeeklyOrderHistoryResultList.WeeklyOrderHistory;

                if (lstWeeklyOrderHistory != null)
                {
                    strFileContents = new StringBuilder();
                    StringBuilder InnerstrFileContents = new StringBuilder();//+ "Run Date" + "\t"
                    InnerstrFileContents.Append("Order No" + "\t" + "Salesman" + "\t" + "Customer" + "\t" + "Order Date" + "\t" + "Amount");
                    strFileContents.Append(InnerstrFileContents);
                    strFileContents.Append("\n");
                    foreach (WeeklyOrderHistory objWeeklyOrderHistory in lstWeeklyOrderHistory)
                    {

                        strFileContents.Append(CommonFunctions.GetStringValue(objWeeklyOrderHistory.TrxCode) != "" ? CommonFunctions.GetStringValue(objWeeklyOrderHistory.TrxCode) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objWeeklyOrderHistory.SalesMan) != "" ? CommonFunctions.GetStringValue(objWeeklyOrderHistory.SalesMan) + "\t" : "N/A" + "\t");
                        strFileContents.Append("[" + objWeeklyOrderHistory.CustomerCode + "]" + objWeeklyOrderHistory.CustomerName + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objWeeklyOrderHistory.TrxDate != "" ? CommonFunctions.GetStringValue(objWeeklyOrderHistory.TrxDate) + "\t" : "N/A" + "\t"));
                        strFileContents.Append(CommonFunctions.GetStringValue(objWeeklyOrderHistory.Amount) != "" ? CommonFunctions.GetStringValue(objWeeklyOrderHistory.Amount) + "\t" : "N/A" + "\t");
                        strFileContents.Append("" + "\t");
                        strFileContents.Append("" + "\t");
                        strFileContents.Append("\n");

                    }

                    sw = System.IO.File.CreateText(strFileName);
                    sw.Write(strFileContents.ToString());
                    sw.Close();
                }


            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportSalesReportsByPreseller(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SalesReportsByPreseller_SearchString = (Session["SalesReportsByPreseller_SearchString"] != null) ? CommonFunctions.getStringValue(Session["SalesReportsByPreseller_SearchString"]) : "1=1";
            strFileContents.Append("Total Order:\t" + Session["SalesPresellerTotalOrder"].ToString() + "\t Total Quantity:\t" + Session["SalesPresellerTotalQuantity"].ToString() + "\t Total Amount:\t" + Session["SalesPresellerTotalAmount"].ToString() + "\n\n");
            IList<SalesReport> objSalesReportList = (new SalesInvoiceFacade()).GetSalesReportByPreseller("INVOICE_AMOUNT DESC", 1000000, 0, SalesReportsByPreseller_SearchString, SessionManager.UserCode, Session["SalesPresellerReportSalesTeam"].ToString());

            if (objSalesReportList != null && objSalesReportList.Count > 0)
            {
                strFileContents.Append("Customer Code" + "\t" + "Sales Org" + "\t" + "Customer Name" + "\t" +
                 "Order Count" + "\t" + "Quantity" + "\t" + "Amount"
                 + "\n");
                foreach (SalesReport objItem in objSalesReportList)
                {
                    strFileContents.Append(objItem.SITE + "\t");
                    strFileContents.Append(objItem.SalesOrgCode + "\t");
                    strFileContents.Append(objItem.SITE_NAME + "\t");
                    strFileContents.Append(objItem.ORDER_COUNT + "\t");
                    strFileContents.Append(Math.Round(CommonFunctions.getDoubleValue(objItem.ACTUAL_QTY_SHIPPED), 0) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands(objItem.INVOICE_AMOUNT));
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportBlockedCustomerReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string BlockedCustomerReportSearchString = (Session["BlockedCustomerReportSearchString"] != null) ? CommonFunctions.getStringValue(Session["BlockedCustomerReportSearchString"]) : "1=1";

            IList<BlockedCustomers> objBlockedCustomersList = (new BlockedCustomersFacade()).GetAllBlockedCustomers("SiteId DESC", 1000000, 1, BlockedCustomerReportSearchString, SessionManager.UserCode);

            string strSelectedParameters = "All";
            if (Session["BlockedCustomerSel"] != null)
            {
                if (Session["BlockedCustomerSel"].ToString() != "")
                {
                    strSelectedParameters = Session["BlockedCustomerSel"].ToString().Split(',').Length + " selected";
                }
            }
            strFileContents.Append("Search Criteria :\t Customer:\t" + strSelectedParameters);
            strSelectedParameters = "All";
            if (Session["BlockedSalesOrg"] != null)
            {
                if (Session["BlockedSalesOrg"].ToString() != "")
                {
                    strSelectedParameters = Session["BlockedSalesOrg"].ToString().Split(',').Length + " selected";
                }
            }
            strFileContents.Append("\t Sales Organization:\t" + strSelectedParameters);
            strSelectedParameters = "All";
            if (Session["BlockedSalesOffice"] != null)
            {
                if (Session["BlockedSalesOffice"].ToString() != "")
                {
                    strSelectedParameters = Session["BlockedSalesOffice"].ToString().Split(',').Length + " selected";
                }
            }
            strFileContents.Append("\t Sales Office:\t" + strSelectedParameters + "\n\n");



            if (objBlockedCustomersList != null && objBlockedCustomersList.Count > 0)
            {
                strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Sales Org" + "\t" + "Sales Office" + "\n");
                foreach (BlockedCustomers objItem in objBlockedCustomersList)
                {

                    strFileContents.Append(objItem.SiteId + "\t");
                    strFileContents.Append(objItem.Site_Name + "\t");
                    strFileContents.Append(objItem.SalesOrg + "\t");
                    strFileContents.Append(objItem.SalesOfficeCode + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportPaymentSummaryDetailsReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string PaymentSummaryReport_ExportToExcel = (Session["PaymentSummaryReport_ExportToExcel"] != null) ? CommonFunctions.getStringValue(Session["PaymentSummaryReport_ExportToExcel"]) : "1=1";

            IList<PaymentSummary> objPaymentSummaryList = (new PaymentSummaryFacade()).GetPaymentSummarySearch("", PaymentSummaryReport_ExportToExcel, SessionManager.UserCode);

            if (objPaymentSummaryList != null && objPaymentSummaryList.Count > 0)
            {
                strFileContents.Append("Customer" + "\t" + "Invoice Number" + "\t" + "Invoice Date" + "\t" +
                 "Payment Mode" + "\t" + "Cash" + "\t" + "Cheque Type" + "\t" + "Cheque No"
                 + "\t" + "Cheque Date" + "\t" + "Cheque Amount" + "\t" + "Bank Name"
                 + "\n");
                foreach (PaymentSummary objItem in objPaymentSummaryList)
                {
                    strFileContents.Append("[" + objItem.CustomerCode + "]" + objItem.CustomerName + "\t");
                    strFileContents.Append(objItem.InvoiceNumber + "\t");
                    strFileContents.Append(objItem.InvoiceDate + "\t");
                    strFileContents.Append(objItem.PaymentMode + "\t");
                    strFileContents.Append("SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objItem.Cash) + "\t");
                    if (string.IsNullOrEmpty(CommonFunctions.getStringValue(objItem.ChequeType)))
                        strFileContents.Append("N/A\t");
                    else
                        strFileContents.Append(objItem.ChequeType + "\t");
                    if (string.IsNullOrEmpty(CommonFunctions.getStringValue(objItem.ChequeNo)))
                        strFileContents.Append("N/A\t");
                    else
                        strFileContents.Append(objItem.ChequeNo + "\t");
                    if (objItem.PaymentMode == "CHEQUE")
                        strFileContents.Append(objItem.ChequeDate + "\t");
                    else
                        strFileContents.Append("N/A\t");
                    strFileContents.Append("SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objItem.ChequeAmount) + "\t");
                    if (string.IsNullOrEmpty(CommonFunctions.getStringValue(objItem.BankName)))
                        strFileContents.Append("N/A\t");
                    else
                        strFileContents.Append(objItem.BankName + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    //private void ExportActualAndTarget(string strFileName)
    //{
    //    System.IO.StreamWriter sw;
    //    try
    //    {
    //        StringBuilder strFileContents = new StringBuilder();
    //        string ActualAndTarget_SearchString = (Session["ActualAndTarget_SearchString"] != null) ? CommonFunctions.getStringValue(Session["ActualAndTarget_SearchString"]) : "1=1";
    //        string ActualAndTarget_Year = (Session["ActualAndTarget_Year"] != null) ? CommonFunctions.getStringValue(Session["ActualAndTarget_Year"]) : DateTime.Now.Year.ToString();
    //        string ActualAndTarget_Month = (Session["ActualAndTarget_Month"] != null) ? CommonFunctions.getStringValue(Session["ActualAndTarget_Month"]) : DateTime.Now.Year.ToString();

    //        IList<ActualTarget> objActualTargetList = (new ActualTargetFacade()).GetActualTargetSearch("", 10, ActualAndTarget_SearchString, ActualAndTarget_Year, ActualAndTarget_Month, 0, SessionManager.UserCode);

    //        if (objActualTargetList != null && objActualTargetList.Count > 0)
    //        {
    //            strFileContents.Append("Salesman Code" + "\t" + "Salesman Name" + "\t" + "Target Amount" + "\t" +
    //             "Achieved Amount" + "\t" + "Percentage (%)"
    //             + "\n");
    //            foreach (ActualTarget objItem in objActualTargetList)
    //            {
    //                strFileContents.Append(objItem.SALESMANCODE + "\t");
    //                strFileContents.Append(objItem.USERNAME + "[" + objItem.USERID + "]" + "\t");
    //                strFileContents.Append(objItem.TargetAmount + "\t");
    //                strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands(objItem.AchievedAmount) + "\t");
    //                strFileContents.Append(objItem.Percentage + "\t");
    //                strFileContents.Append("\n");
    //            }
    //        }
    //        sw = System.IO.File.CreateText(strFileName);
    //        sw.Write(strFileContents.ToString());
    //        sw.Close();
    //    }
    //    catch (Exception ex)
    //    {
    //        CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
    //    }
    //}

    private void ExportFOCReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;

            string SearchString = string.Empty;
            string SortExpression = "Order_Date Desc";
            string UserCode = "";
            SearchString = (Session["FOCReportSearchString"] != null) ? Session["FOCReportSearchString"].ToString() : "1=1";
            IList<FOCReport> objFOCReportList = new FOCReportFacade().GetFOCReportSearch_Export(SortExpression, SearchString, UserCode);

            if (objFOCReportList != null && objFOCReportList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("FOC Quantiy" + "\t" + "Date" + "\t");
                strFileContents.Append("User Code" + "\t" + "Name" + "\t");
                strFileContents.Append("Site Number" + "\t" + "Site Name" + "\t" + " Order Number" + "\t");
                strFileContents.Append("Unit Measurement" + "\t" + "Item Code" + "\t" + "Item Description" + "\t");

                strFileContents.Append("\n");
                foreach (FOCReport objFOCReport in objFOCReportList)
                {



                    int count = 0;
                    foreach (FOCUser objFOCUser in objFOCReport.FOCUsers)
                    {

                        if (count == 0)
                        {
                            strFileContents.Append(objFOCReport.FOCQty + "\t");
                            strFileContents.Append(objFOCReport.Order_Date + "\t");
                            count++;
                        }
                        else
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                        }
                        int UsrCount = 0;
                        strFileContents.Append("\n");
                        // strFileContents.Append("Site Number" + "\t" + "Site Name" + "\t" + " Order Number" + "\t");

                        foreach (FOCCustomer objFOCCustomer in objFOCUser.FOCCustomers)
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            if (UsrCount == 0)
                            {
                                strFileContents.Append(objFOCUser.UserCode + "\t");
                                strFileContents.Append(objFOCUser.UserName + "\t");
                                strFileContents.Append(objFOCUser.FOCQty + "\t");
                            }
                            else
                            {
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                            }
                            int CustCount = 0;
                            //strFileContents.Append("Unit Measurement" + "\t" + "Item Code" + "\t" + "Item Description" + "\t");
                            strFileContents.Append("\n");
                            foreach (FOCOrder objFOCOrder in objFOCCustomer.FOCOrders)
                            {
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                if (CustCount == 0)
                                {
                                    strFileContents.Append(objFOCCustomer.Site + "\t");
                                    strFileContents.Append(objFOCCustomer.SiteName + "\t");
                                    strFileContents.Append(objFOCCustomer.OrderNumber + "\t");
                                }
                                else
                                {
                                    strFileContents.Append("\t");
                                    strFileContents.Append("\t");
                                    strFileContents.Append("\t");
                                }
                                strFileContents.Append(objFOCOrder.UOM + "\t");
                                strFileContents.Append(objFOCOrder.ItemCode + "\t");
                                strFileContents.Append(objFOCOrder.ItemDescription + "\t");

                            }
                        }

                        strFileContents.Append("\n");
                    }
                    strFileContents.Append("\n");
                    strFileContents.Append(Environment.NewLine);
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportVanSalesCoverageReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;

            string SearchString = string.Empty;
            string SortExpression = "MovementDate Desc";
            string UserCode = "";
            string startDate = Convert.ToDateTime(Session["sdate"]).ToString("yyyy-MM-dd");
            string EndDate = Convert.ToDateTime(Session["edate"]).ToString("yyyy-MM-dd");
            IList<VanStockReport> objVanStockReportList = new VanStockFacade().GetVanStockCoverage(startDate, EndDate, Session["salesman"].ToString(), SessionManager.UserCode, Session["salesteam"].ToString());

            if (objVanStockReportList != null && objVanStockReportList.Count > 0)
            {
                strFileContents = new StringBuilder();
                foreach (VanStockReport objVanStockReport in objVanStockReportList)
                {

                    strFileContents.Append("User Code" + "\t" + "User Name" + "\t");

                    strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "No Of Visits" + "\t");
                    strFileContents.Append("\n");
                    int count = 0;

                    foreach (VanStock objVanStock in objVanStockReport.VanStockList)
                    {
                        if (count == 0)
                        {
                            strFileContents.Append(objVanStockReport.VanStock.UserCode + "\t");
                            strFileContents.Append(objVanStockReport.VanStock.User.Name + "\t");
                            count++;
                        }
                        else
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                        }
                        strFileContents.Append(objVanStock.CustomerCode + "\t");
                        strFileContents.Append(objVanStock.Name + "\t");
                        strFileContents.Append(objVanStock.NoOfVisits + "\t");

                        strFileContents.Append("\n");
                    }
                    strFileContents.Append("\n");
                    strFileContents.Append(Environment.NewLine);
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportMaintainJourneyReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;



            string SearchString = string.Empty;

            SearchString = (Session["MaintainJourneySearchString"] != null) ? Session["MaintainJourneySearchString"].ToString() : "";
            string SortExpression = "J.Date Desc";
            IList<Journey> objJourneyList = new JourneyFacade().GetJourneySearch_Export(SortExpression, SearchString, SessionManager.UserCode);

            if (objJourneyList != null && objJourneyList.Count > 0)
            {
                strFileContents = new StringBuilder();
                foreach (Journey objJourney in objJourneyList)
                {

                    strFileContents.Append(objJourney.UserCode + "\t");
                    strFileContents.Append(objJourney.User.UserName + "\t");
                    strFileContents.Append(objJourney.OdometerReadingStart + "\t");
                    strFileContents.Append(objJourney.OdometerReadingEnd + "\t");
                    strFileContents.Append(objJourney.TotKmsTravelled + "\t");
                    strFileContents.Append(objJourney.Date + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportOrderAndDelivary(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            string SalesOrgCodes = "";
            string Sortexp = "UserId ASC";
            StringBuilder strFileContents = new StringBuilder();
            string OrderAndDelivary_SearchString = "1=1";
            if (Session["OrderVsDeliveryReport"] != null)
            {
                string[] arr = CommonFunctions.getStringValue(Session["OrderVsDeliveryReport"]).Split('|');
                if (arr.Length > 0)
                {
                    OrderAndDelivary_SearchString = arr[0];
                }
                if (arr.Length > 1)
                {
                    SalesOrgCodes = arr[1];
                }
            }

            string selectedUsers = (Session["OrderVsDeliveryReportUserCode"] != null) ? CommonFunctions.getStringValue(Session["OrderVsDeliveryReportUserCode"]) : SessionManager.UserCode;
            IList<VanStock> objVanStockList = (new VanStockFacade()).GetOrderVsDelivary(SessionManager.UserCode, OrderAndDelivary_SearchString, SalesOrgCodes, selectedUsers, Sortexp);


            strFileContents.Append("Salesman" + "\t" + "Delivered Orders" + "\t" +
             "Pending Orders" + "\t" + "Delivery Amount" + "\t" + "Pending Amount"
             + "\n");
            if (objVanStockList != null && objVanStockList.Count > 0)
            {
                foreach (VanStock objItem in objVanStockList)
                {
                    strFileContents.Append("[" + objItem.UserCode + "]" + objItem.User.Description + "\t");
                    strFileContents.Append(objItem.SellableQuantity + "\t");
                    strFileContents.Append(objItem.ReturnedQuantity + "\t");
                    strFileContents.Append(objItem.LoadedQuantity + "\t");
                    strFileContents.Append(objItem.NonSellableQuantity + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportCoverageReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string Searchstring = (Session["CoveragePresellerReport"] != null) ? CommonFunctions.getStringValue(Session["CoveragePresellerReport"]) : "1=1";
            string startDate = Session["hndStartDateValue"].ToString();
            string EndDate = Session["hndEndDateValue"].ToString();
            string SortExpression = "USERNAME ASC";
            IList<ProductiveReport> objProductiveReportList = new ProductiveReportFacade().GetProductiveReportSearch_Export1(SortExpression, Searchstring, Session["Type"].ToString(), startDate, EndDate, SessionManager.UserCode);

            if (objProductiveReportList != null && objProductiveReportList.Count > 0)
            {
                strFileContents = new StringBuilder();
                foreach (ProductiveReport objProductiveReport in objProductiveReportList)
                {

                    strFileContents.Append("User Code" + "\t" + "User Name" + "\t" + "Calls Made " + "\t" + "Productive Calls" + "\t");

                    strFileContents.Append("Customer Code" + "\t" + "Sales Org " + "\t" + "Customer Name" + "\t" + "Productivity Status" + "\t");
                    strFileContents.Append("\n");
                    int count = 0;
                    foreach (ProductiveCustomer objProductiveCustomer in objProductiveReport.objProductiveCustomerList)
                    {
                        if (count == 0)
                        {
                            strFileContents.Append(objProductiveReport.EmpNo + "\t");
                            strFileContents.Append(objProductiveReport.USERNAME + "\t");
                            strFileContents.Append(objProductiveReport.CallsMade + "\t");
                            strFileContents.Append(objProductiveReport.ProductiveCalls + "\t");
                            count++;
                        }
                        else
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                        }
                        strFileContents.Append(objProductiveCustomer.CUSTOMERCODE + "\t");
                        strFileContents.Append(objProductiveCustomer.SalesOrgCode + "\t");
                        strFileContents.Append(objProductiveCustomer.CUSTOMERNAME + "\t");
                        if (objProductiveCustomer.STATUS == true)
                        {
                            strFileContents.Append("Productive" + "\t");
                        }
                        else
                        {
                            strFileContents.Append("Non-Productive" + "\t");
                        }
                        strFileContents.Append("\n");
                    }
                    strFileContents.Append("\n");
                    strFileContents.Append(Environment.NewLine);
                }

            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportPendingInvoiceReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string Searchstring2 = (Session["PendingInvoiceReport2"] != null) ? CommonFunctions.getStringValue(Session["PendingInvoiceReport2"]) : "1=1";
            string Searchstring = (Session["PendingInvoiceReport"] != null) ? CommonFunctions.getStringValue(Session["PendingInvoiceReport"]) : "1=1";
            string SortExpression = "InvoiceAmount ASC";
            IList<PendingInvoiceReport> objPendingInvoicesList = new PendingInvoicesFacade().GetPendingInvoiceListByPaging_Export(SortExpression, Searchstring, SessionManager.UserCode, Searchstring2);

            if (objPendingInvoicesList != null && objPendingInvoicesList.Count > 0)
            {
                strFileContents = new StringBuilder();
                foreach (PendingInvoiceReport objPendingInvoiceReport in objPendingInvoicesList)
                {

                    strFileContents.Append("User Code" + "\t" + "Description" + "\t" + "Invoice Amlount " + "\t");

                    strFileContents.Append("Order Number" + "\t" + "Order Date " + "\t" + "Currency" + "\t" + "Original Amount" + "\t" + "Balance Amount" + "\t" + "SAP Ref Code");
                    strFileContents.Append("\n");
                    int count = 0;
                    foreach (PendingInvoices objPendingInvoices in objPendingInvoiceReport.PendingInvoiceList)
                    {
                        if (count == 0)
                        {
                            strFileContents.Append(objPendingInvoiceReport.Client.Code + "\t");
                            strFileContents.Append(objPendingInvoiceReport.Client.Description + "\t");
                            strFileContents.Append(objPendingInvoiceReport.PendingInvoiceCount + "\t");
                            count++;
                        }
                        else
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                        }
                        strFileContents.Append(objPendingInvoices.TrxCode + "\t");
                        strFileContents.Append(objPendingInvoices.TrxDate + "\t");
                        strFileContents.Append(objPendingInvoices.CurrencyCode + "\t");
                        strFileContents.Append(objPendingInvoices.OriginalAmount + "\t");
                        strFileContents.Append(objPendingInvoices.BalanceAmount + "\t");
                        strFileContents.Append(objPendingInvoices.JDEReference + "\t");

                        strFileContents.Append("\n");
                    }
                    strFileContents.Append("\n");
                    strFileContents.Append(Environment.NewLine);
                }

            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportStoreCheckReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SelectedBrands = Session["SelectedBrands"].ToString();
            string SelectedUsers = Session["SelectedUsers"].ToString();
            string searchString = Session["searchString"].ToString();
            searchString = "1=1";
            DateTime StartDate = Convert.ToDateTime(Session["StartDate"].ToString());
            DateTime EndDate = Convert.ToDateTime(Session["EndDate"].ToString());
            IList<StoreCheckUser> objStoreCheckUserList = new StoreCheckFacade().GetStoreCheckByUserCodeAndDate_OOS_ExportExcel(SelectedUsers, DateTime.Now, SelectedBrands, "", StartDate, EndDate, searchString, SessionManager.UserCode);

            if (objStoreCheckUserList != null && objStoreCheckUserList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("User Code" + "\t" + "Name" + "\t" + "OOS " + "\t");
                strFileContents.Append("Client Code" + "\t" + "Client Name" + "\t" + "Date " + "\t" + "OOS" + "\t");
                strFileContents.Append("Brand Code" + "\t" + "Brand Name" + "\t" + "OOS SKU Count" + "\t");
                strFileContents.Append("Item Code" + "\t" + "Item Name" + "\t");
                strFileContents.Append("\n");

                foreach (StoreCheckUser objStoreCheckUser in objStoreCheckUserList)
                {
                    int count = 0;

                    if (count == 0)
                    {
                        strFileContents.Append(objStoreCheckUser.UserCode + "\t");
                        strFileContents.Append(objStoreCheckUser.UserName + "\t");
                        strFileContents.Append(objStoreCheckUser.TotalOOS + "\t");
                        count++;
                    }
                    else
                    {
                        strFileContents.Append("\t");
                        strFileContents.Append("\t");
                        strFileContents.Append("\t");
                    }
                    strFileContents.Append("\n");
                    foreach (StoreCheckCustomer objStoreCheckCustomer in objStoreCheckUser.customerList)
                    {

                        //strFileContents.Append(objStoreCheckCustomer.ClientName + "\t");
                        //strFileContents.Append(objStoreCheckCustomer.ArrivalTime + "\t");
                        //strFileContents.Append(objStoreCheckCustomer.OOS + "\t");
                        // strFileContents.Append("\n");
                        int customercount = 0;

                        foreach (StoreCheckBrand objStoreCheckBrand in objStoreCheckCustomer.brandList)
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            if (customercount == 0)
                            {

                                strFileContents.Append(objStoreCheckCustomer.ClientCode + "\t");
                                strFileContents.Append(objStoreCheckCustomer.ClientName + "\t");
                                strFileContents.Append(objStoreCheckCustomer.Date + "\t");
                                strFileContents.Append(objStoreCheckCustomer.OOS + "\t");
                                customercount++;
                            }
                            else
                            {
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                            }
                            strFileContents.Append("\n");
                            int brandCount = 0;
                            foreach (StoreCheckItemReport objStoreCheckItemReport in objStoreCheckBrand.itemList)
                            {
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                if (brandCount == 0)
                                {


                                    strFileContents.Append(objStoreCheckBrand.BrandCode + "\t");
                                    strFileContents.Append(objStoreCheckBrand.BrandName + "\t");
                                    strFileContents.Append(objStoreCheckBrand.TotalSKU + "/" + objStoreCheckBrand.TotalCountSKU + "\t");
                                }
                                else
                                {

                                    strFileContents.Append("\t");
                                    strFileContents.Append("\t");
                                    strFileContents.Append("\t");

                                }
                                strFileContents.Append(objStoreCheckItemReport.ItemCode + "\t");
                                strFileContents.Append(objStoreCheckItemReport.ItemName + "\t");
                                strFileContents.Append("\n");
                            }
                            strFileContents.Append("\n");
                        }
                        strFileContents.Append("\n");
                    }
                    strFileContents.Append("\n");
                }
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportNewoutletReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;


            string SearchString = string.Empty;
            string SortExpression = "Code DESC";

            SearchString = (Session["NewOutletSearchString"] != null) ? Session["NewOutletSearchString"].ToString() : "1=1";
            string NewOutletFromDate = Session["NewOutletFromDate"].ToString();
            string NewOutletToDate = Session["NewOutletToDate"].ToString();
            IList<Customer> objCustomers = new CustomerFacade().GetNewOutletCustomerSearch_Export(SortExpression, SearchString, NewOutletFromDate, NewOutletToDate, SessionManager.UserCode);

            if (objCustomers != null && objCustomers.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Sales Org" + "\t" + " Added Date" + "\t");

                strFileContents.Append("\n");
                foreach (Customer objCustomer in objCustomers)
                {
                    strFileContents.Append(objCustomer.Site + "\t");
                    strFileContents.Append(objCustomer.SiteName + "\t");
                    strFileContents.Append(objCustomer.SalesOrganization + "\t");
                    strFileContents.Append(objCustomer.CustomerCreatedDate + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportMarketReportByVan(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;


            string SearchString = string.Empty;
            string SortExpression = "Code DESC";

            SearchString = (Session["MarketReturnSearch"] != null) ? Session["MarketReturnSearch"].ToString() : "1=1";

            IList<MarketReturnsUsers> objMarketReturnsUsers = new ReportsFacade().GetMarketRetunsReportXL(SearchString, SessionManager.UserCode);

            if (objMarketReturnsUsers != null && objMarketReturnsUsers.Count > 0)
            {
                strFileContents = new StringBuilder();

                foreach (MarketReturnsUsers objMrUSers in objMarketReturnsUsers)
                {
                    int count = 0;
                    strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Total Quantity" + "\t" + " Total Value" + "\t" + "Salable Quantity" + "\t" + " Salable Value" + "\t" + "Non Salable Quantity" + "\t" + "Non Salable Value" + "\t");
                    strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Total Quantity" + "\t" + " Total Value" + "\t" + "Salable Quantity" + "\t" + " Salable Value" + "\t" + "Non Salable Quantity" + "\t" + "Non Salable Value" + "\t");
                    strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Total Quantity" + "\t" + " Total Value" + "\t" + "Salable Quantity" + "\t" + " Salable Value" + "\t" + "Non Salable Quantity" + "\t" + "Non Salable Value" + "\t");

                    strFileContents.Append("\n");
                    foreach (MarketReturnsCustomers objMarketReturnsCustomers in objMrUSers.Customers)
                    {
                        if (count == 0)
                        {
                            strFileContents.Append(objMrUSers.UserCode + "\t");
                            strFileContents.Append(objMrUSers.UserName + "\t");
                            strFileContents.Append(objMrUSers.TotalQuantity + "\t");
                            strFileContents.Append(objMrUSers.TotalValue + "\t");
                            strFileContents.Append(objMrUSers.SellableQuantity + "\t");
                            strFileContents.Append(objMrUSers.SellableValue + "\t");
                            strFileContents.Append(objMrUSers.NonSellableQuantity + "\t");
                            strFileContents.Append(objMrUSers.NonSellableValue + "\t");

                            count++;
                        }
                        else
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                        }
                        int itemCount = 0;
                        foreach (MarketReturnsItems objMarketReturnsItems in objMarketReturnsCustomers.Items)
                        {
                            if (itemCount == 0)
                            {
                                strFileContents.Append(objMarketReturnsCustomers.ClientCode + "\t");
                                strFileContents.Append(objMarketReturnsCustomers.ClientName + "\t");
                                strFileContents.Append(objMarketReturnsCustomers.TotalQuantity + "\t");
                                strFileContents.Append(objMarketReturnsCustomers.TotalValue + "\t");
                                strFileContents.Append(objMarketReturnsCustomers.SellableQuantity + "\t");
                                strFileContents.Append(objMarketReturnsCustomers.SellableValue + "\t");
                                strFileContents.Append(objMarketReturnsCustomers.NonSellableQuantity + "\t");
                                strFileContents.Append(objMarketReturnsCustomers.NonSellableValue + "\t");

                                itemCount++;
                            }
                            else
                            {
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                                strFileContents.Append("\t");
                            }
                            strFileContents.Append(objMarketReturnsItems.ItemCode + "\t");
                            strFileContents.Append(objMarketReturnsItems.ItemDescription + "\t");
                            strFileContents.Append(objMarketReturnsItems.TotalQuantity + "\t");
                            strFileContents.Append(objMarketReturnsItems.TotalValue + "\t");
                            strFileContents.Append(objMarketReturnsItems.SellableQuantity + "\t");
                            strFileContents.Append(objMarketReturnsItems.SellableValue + "\t");
                            strFileContents.Append(objMarketReturnsItems.NonSellableQuantity + "\t");
                            strFileContents.Append(objMarketReturnsItems.NonSellableValue + "\t");
                            strFileContents.Append("\n");
                        }
                    }
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportLogReport_New(string strFileName)
    {

        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            strFileContents = new StringBuilder();


            string SearchString = string.Empty;
            string SortExpression = "TimeStamp DESC";

            SearchString = (Session["LogReportsearchString"] != null) ? Session["LogReportsearchString"].ToString() : "1=1";
            string FromDate = (Session["LogReportFromDate"] != null) ? Session["LogReportFromDate"].ToString() : "";
            string ToDate = (Session["LogReportToDate"] != null) ? Session["LogReportToDate"].ToString() : "";
            string InvoiceType = (Session["LogReportInvoiceType"] != null) ? Session["LogReportInvoiceType"].ToString() : "";
            string creditNoteType = (Session["LogReportcreditNoteType"] != null) ? Session["LogReportcreditNoteType"].ToString() : "";
            string SelectedChannel = (Session["BindReportSummarySelectedChannel"] != null) ? Session["BindReportSummarySelectedChannel"].ToString() : "";
            string SelectedUser = (Session["BindReportSummarySelectedUsers"] != null) ? Session["BindReportSummarySelectedUsers"].ToString() : "";
            string SelectedRegion = (Session["HieLogReportReport"] != null) ? Session["HieLogReportReport"].ToString().Split('|')[1] : "";
            string SelectedBrand = (Session["LogReportBrand"] != null) ? Session["LogReportBrand"].ToString() : "";
            string SalesOrg = (Session["UCCommonFilterSalesOrg"] != null) ? Session["UCCommonFilterSalesOrg"].ToString() : "";


            string UserCode = "";
            if (Session["LogReportSelectedUser"] != null)
            {
                UserCode = Session["LogReportSelectedUser"].ToString();
            }

            LogReport objLogReport = new LogReportFacade().GetLogReportSummary(UserCode, FromDate, ToDate, Convert.ToInt32(InvoiceType), Convert.ToInt32(creditNoteType), SessionManager.UserCode, SelectedChannel, SalesOrg, SelectedRegion, SelectedBrand);
            strFileContents.Append("Total Scheduled Calls" + "\t" + "Actual Calls" + "\t" + "Total Productive Calls" + "\t" + "Total Sales" + "\t" + "Total Sale Invoice" + "\t" + "Collection Received" + "\n");
            //  string MonthSales = "SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objLogReport.TotalMonthSales);
            string TotalPayment = "SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objLogReport.TotalPayments);
            string TotalCredit = "SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objLogReport.TotalInvoiced);
            string TotalSales = "SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objLogReport.TotalSales);
            //string CollectionDue = "SAR " + CommonFunctions.GetCurrencyFormatWithThousands(objLogReport.CollectionDue);
            string Calls = objLogReport.ScheduledCalls.ToString();
            string ActualCalls = objLogReport.TotalCalls.ToString();
            string ProdCalls = objLogReport.ProductiveCalls.ToString();

            strFileContents.Append(Calls + "\t" + ActualCalls + "\t" + ProdCalls + "\t" + TotalSales + "\t" + TotalCredit + "\t" + TotalPayment + "\n");
            strFileContents.Append("\n\n\n");
            IList<LogReport> objLogReportDetailList = new LogReportFacade().GetLogReportSearch(SortExpression, 1000000, 0, SearchString, FromDate, ToDate, InvoiceType, creditNoteType, UserCode, SelectedChannel, SalesOrg, SelectedBrand);

            if (objLogReportDetailList != null && objLogReportDetailList.Count > 0)
            {
                strFileContents.Append("Customer " + "\t" + "User " + "\t" + "Type" + "\t" + "Doc No." + "\t" + "Amount" + "\t" + "Time Stamp" + "\t");

                strFileContents.Append("\n");

                foreach (LogReport objLogReportNew in objLogReportDetailList)
                {
                    strFileContents.Append("[" + objLogReportNew.Code + "] " + objLogReportNew.CustomerName + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objLogReportNew.UserName) != "" ? CommonFunctions.GetStringValue(objLogReportNew.UserName) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objLogReportNew.Type) != "" ? CommonFunctions.GetStringValue(objLogReportNew.Type) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objLogReportNew.DocNo) != "" ? CommonFunctions.GetStringValue(objLogReportNew.DocNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append("SAR " + CommonFunctions.GetStringValue(CommonFunctions.getDecimalValue(objLogReportNew.Amount)) != "" ? CommonFunctions.GetStringValue(CommonFunctions.getDecimalValue(objLogReportNew.Amount)) + "\t" : "N/A" + "\t");
                    strFileContents.Append(Convert.ToDateTime(objLogReportNew.TimeStamp).ToString("MMM d,yyyy HH:mm tt") + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }

    private void ExportRouteActivityReport(string strFileName)
    {

        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            strFileContents = new StringBuilder();


            string SearchString = string.Empty;
            string SortExpression = "";

            SearchString = (Session["SearchString"] != null) ? Session["SearchString"].ToString() : "1=1";
            string FromDate = (Session["FromDate"] != null) ? Session["FromDate"].ToString() : "";
            string ToDate = (Session["ToDate"] != null) ? Session["ToDate"].ToString() : "";


            string UserCode = "";
            if (Session["UserCode"] != null)
            {
                UserCode = Session["UserCode"].ToString();
            }

            IList<Route> objRouteActivityReport = new RouteFacade().GetRouteActivity(SortExpression, 500000, 0, SearchString, FromDate, ToDate, UserCode, "", "", "");

            if (objRouteActivityReport != null && objRouteActivityReport.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Journey Date" + "\t" + "Route" + "\t" + "ASM Name" + "\t" + "Supervisor" + "\t" + "Salesman" + "\t" + "Time In" + "\t" + "Customer" + "\t" + "Region" + "\t" + "Type" + "\t" + "Doc No." + "\t" + "Amount" + "\t" + "Total Time in Mins." + "\t");
                strFileContents.Append("\n");
                foreach (Route objRoute in objRouteActivityReport)
                {
                    int count = 0;
                    strFileContents.Append(Convert.ToDateTime(objRoute.Journey_Date).ToString("MM/dd/yyyy") + "\t");
                    strFileContents.Append(objRoute.Code == "" ? "N/A" + "\t" : "[" + objRoute.Code + "] " + objRoute.Name + "\t");
                    strFileContents.Append(objRoute.ASMCode == "" ? "N/A" + "\t" : "[" + objRoute.ASMCode + "] " + objRoute.ASMName + "\t");
                    strFileContents.Append(objRoute.SupervisorCode == "" ? "N/A" + "\t" : "[" + objRoute.SupervisorCode + "] " + objRoute.SupervisorName + "\t");
                    strFileContents.Append(objRoute.UserCode == "" ? "N/A" + "\t" : "[" + objRoute.UserCode + "] " + objRoute.UserName + "\t");
                    strFileContents.Append(objRoute.TimeIn == "" ? "N/A" + "\t" : objRoute.TimeIn + "\t");
                    strFileContents.Append(objRoute.CustomerCode == "" ? "N/A" + "\t" : "[" + objRoute.CustomerCode + "] " + objRoute.CustomerName + "\t");
                    strFileContents.Append(objRoute.RegionCode == "" ? "N/A" + "\t" : "[" + objRoute.RegionCode + "] " + objRoute.RegionDescription + "\t");
                    strFileContents.Append(objRoute.RouteType == "" ? "N/A" + "\t" : objRoute.RouteType + "\t");
                    strFileContents.Append(objRoute.DocNo == "" ? "N/A" + "\t" : objRoute.DocNo + "\t");
                    strFileContents.Append(objRoute.Amount == "" ? "N/A" + "\t" : objRoute.Amount + "\t");
                    strFileContents.Append(objRoute.TotalTimeInMins == "" ? "N/A" + "\t" : objRoute.TotalTimeInMins + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
        }
    }
    private void ExportMarketReportBySKU(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            SearchString = (Session["MarketReturnSearch"] != null) ? Session["MarketReturnSearch"].ToString() : "1=1";
            IList<MarketReturnsItems> objMarketReturnsItems = new ReportsFacade().GetMarketRetunsReportBySKUXL(SearchString, SessionManager.UserCode);

            if (objMarketReturnsItems != null && objMarketReturnsItems.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Item Code & Item Description" + "\t" + "Saleable Quantity" + "\t" + "Non Saleable Quantity" + "\t" + "Saleable Value" + "\t" + "Non Saleable Value" + "\t");
                strFileContents.Append("\n");
                foreach (MarketReturnsItems objMarketReturnsItem in objMarketReturnsItems)
                {
                    int count = 0;
                    strFileContents.Append("[" + objMarketReturnsItem.ItemCode + "] " + objMarketReturnsItem.ItemDescription + "\t");
                    strFileContents.Append(objMarketReturnsItem.SellableQuantity + "\t");
                    strFileContents.Append(objMarketReturnsItem.NonSellableQuantity + "\t");
                    strFileContents.Append("SAR " + objMarketReturnsItem.SellableValue + "\t");
                    strFileContents.Append("SAR " + objMarketReturnsItem.NonSellableValue + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();

        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportAllItems(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string SortExpression = "I.Code DESC";

            SearchString = (Session["AllItemsearchstring"] != null) ? Session["AllItemsearchstring"].ToString() : "1=1";

            IList<ItemsAndBrands> objItemsAndBrandsList = new ItemFacade().GetItmesAndBrands_Export(SortExpression, SearchString);

            if (objItemsAndBrandsList != null && objItemsAndBrandsList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Item Code" + "\t" + "Description" + "\t" + "Brand" + "\t");

                strFileContents.Append("\n");
                foreach (ItemsAndBrands objItemsAndBrands in objItemsAndBrandsList)
                {
                    strFileContents.Append(objItemsAndBrands.ItemCode + "\t");
                    strFileContents.Append(objItemsAndBrands.Description + "\t");
                    strFileContents.Append(objItemsAndBrands.Brand + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportAll_Mtdsales(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string SortExpression = "I.Code DESC";

            SearchString = (Session["searchString"] != null) ? Session["searchString"].ToString() : "1=1";
            string DepotCode = "", SuperVisor = "", AreaSMgr = "";

            DepotCode = (Session["MTD_DepotCode"] != null) ? Session["MTD_DepotCode"].ToString() : "";
            SuperVisor = (Session["MTD_SuperVisor"] != null) ? Session["MTD_SuperVisor"].ToString() : "";
            AreaSMgr = (Session["MTD_AreaSMgr"] != null) ? Session["MTD_AreaSMgr"].ToString() : "";


            //DataSet dt = new CategoryFacade().GetSubCategorySearch(Session["RouteCode"].ToString(), Session["Category"].ToString(), Session["CustDate"].ToString(), Session["searchString"].ToString(), "", SessionManager.UserCode);
            DataSet dt = GetSubCategorySearch_Local(Session["RouteCode"].ToString(), Session["Category"].ToString(), Session["CustDate"].ToString(), Session["searchString"].ToString(), "", SessionManager.UserCode, DepotCode, SuperVisor, AreaSMgr);
            if (dt.Tables[0].Rows.Count > 0)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                int x = dt.Tables[0].Columns.Count;
                int y = dt.Tables[0].Rows.Count;
                for (int i = 0; i < dt.Tables[0].Columns.Count; i++)
                {
                    DataColumn cl = dt.Tables[0].Columns[i];
                    InnerstrFileContents.Append(cl.ColumnName.ToString() + "\t");
                }
                InnerstrFileContents.Append("\n");
                for (int i = 0; i <= y - 1; i++)
                {
                    for (int j = 0; j < dt.Tables[0].Columns.Count; j++)
                    {
                        InnerstrFileContents.Append(dt.Tables[0].Rows[i][j].ToString() + "\t");
                    }
                    InnerstrFileContents.Append("\n");
                }


                InnerstrFileContents.Append("\n");
                int Z = dt.Tables[1].Columns.Count;
                int W = dt.Tables[1].Rows.Count;
                for (int i = 0; i < W; i++)
                {

                    InnerstrFileContents.Append("\t");
                    InnerstrFileContents.Append("\t");
                    InnerstrFileContents.Append("Total" + "\t");


                    for (int j = 0; j < dt.Tables[1].Columns.Count; j++)
                    {
                        InnerstrFileContents.Append(dt.Tables[1].Rows[i][j].ToString() + "\t");
                    }
                    InnerstrFileContents.Append("\n");
                }

                int P = dt.Tables[2].Columns.Count;
                int Q = dt.Tables[2].Rows.Count;
                InnerstrFileContents.Append("\n");
                for (int i = 0; i < Q; i++)
                {

                    InnerstrFileContents.Append("\t");
                    InnerstrFileContents.Append("\t");
                    InnerstrFileContents.Append(" % Served" + "\t");
                    for (int j = 0; j < dt.Tables[2].Columns.Count; j++)
                    {
                        InnerstrFileContents.Append(dt.Tables[2].Rows[i][j].ToString() + "%" + "\t");
                    }
                    InnerstrFileContents.Append("\n");
                }

                int R = dt.Tables[3].Columns.Count;
                int S = dt.Tables[3].Rows.Count;
                InnerstrFileContents.Append("\n");
                for (int i = 0; i < S; i++)
                {

                    InnerstrFileContents.Append("\t");
                    InnerstrFileContents.Append("\t");
                    InnerstrFileContents.Append(" Not Served" + " \t");
                    for (int j = 0; j < dt.Tables[3].Columns.Count; j++)
                    {
                        InnerstrFileContents.Append(dt.Tables[3].Rows[i][j].ToString() + "\t");
                    }
                    InnerstrFileContents.Append("\n");
                }
                strFileContents.Append(InnerstrFileContents);
            }


            strFileContents.Append("\n");
            strFileContents.Append(Environment.NewLine);
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportAllUserPermissions(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string UserCode = "";
            if (Request.QueryString["UserCode"] != "")
            {
                UserCode = Request.QueryString["UserCode"].ToString();
            }
            string searchstring = Session["ExportUsersearchString"].ToString();
            UserRolePermissions objUserRolePermissions = new BlaseUserFacade().GetAllUserRolePermission(UserCode, searchstring);

            if (objUserRolePermissions != null)
            {
                strFileContents = new StringBuilder();

                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("UserCode" + "\t" + "Role Code" + "\t" + "Permission Name" + "\t\n");
                foreach (User objUser in objUserRolePermissions.Users)
                {
                    //strFileContents.Append("UserCode" + "\t" + objUser.Code + "\t");
                    ////strFileContents.Append(objUser.UserName + "\t");
                    //strFileContents.Append("\n");
                    //strFileContents.Append(Environment.NewLine);

                    foreach (UserRole objUserRole in objUser.UserRoles)
                    {
                        //strFileContents.Append("Role Code" + "\t" + objUserRole.ROLE + "\t");
                        //strFileContents.Append("\n\n");

                        foreach (RolePermission objRolePermission in objUserRole.RolePermissions)
                        {
                            InnerstrFileContents.Append(objUser.Code + "\t");
                            InnerstrFileContents.Append(objUserRole.ROLE + "\t");
                            InnerstrFileContents.Append(objRolePermission.Permission + "\t");
                            InnerstrFileContents.Append("\n");
                        }

                    }

                }
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                strFileContents.Append(Environment.NewLine);
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportAllUserDetails(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            string UserCode = "";
            StringBuilder strFileContents = null;
            if (Request.QueryString["UserCode"] != null && Request.QueryString["UserCode"] != "")
            {
                UserCode = Request.QueryString["UserCode"].ToString();
            }
            string SearchString = Session["ExportUsersearchString"].ToString();
            if (UserCode != "")
            {
                SearchString = "U.Code = '" + UserCode + "'";
            }
            List<User> objUserlist = new UserFacade().GetAllUserDetials(SearchString, SessionManager.UserCode);



            if (objUserlist != null)
            {
                strFileContents = new StringBuilder();
                //strFileContents.Append("Role Code" + "\t" + "Role Name" + "\t");
                //strFileContents.Append("\n");
                //strFileContents.Append("User Code" + "\t" + "User Name" + "\t" + "ADID" + "\t" + "Email" + "\t" + "Mobile Number" + "\t" + "Emp Code" + "\t" + "User Type" + "\t" + "Department" + "\t" + "Sales Group" + "\t" + "Roles" + "\t" + "SalesOrgCodes" + "\t" + "ReportsTo" + "\t" + "Regions" + "\t" + "Sites" + "\t" + "Agencies" + "\t" + "Brands" + "\t\n");
                strFileContents.Append("User Code" + "\t" + "User Name" + "\t" + "Email" + "\t" + "Mobile Number" + "\t" + "Emp Code" + "\t" + "User Type" + "\t" + "Department" + "\t" + "Sales Group" + "\t" + "Roles" + "\t" + "SalesOrgCodes" + "\t" + "ReportsTo" + "\t" + "Regions" + "\t" + "Sites" + "\t" + "Agencies" + "\t" + "Brands" + "\t\n");
                strFileContents.Append("\n");
                foreach (User objUser in objUserlist)
                {
                    strFileContents.Append(objUser.UserCode + "\t");
                    strFileContents.Append(objUser.Description + "\t");
                    //strFileContents.Append(objUser.UserName + "\t");
                    strFileContents.Append(objUser.Email + "\t");
                    strFileContents.Append(objUser.MobileNumber + "\t");
                    strFileContents.Append(objUser.EmpCode + "\t");
                    strFileContents.Append(objUser.UserType + "\t");
                    strFileContents.Append(objUser.Department + "\t");
                    strFileContents.Append(objUser.SalesGroup + "\t");
                    strFileContents.Append(objUser.Roles + "\t");
                    strFileContents.Append(objUser.SalesOrgCodes + "\t");
                    strFileContents.Append(objUser.ReportsTos + "\t");
                    strFileContents.Append(objUser.Regions + "\t");
                    strFileContents.Append(objUser.Sites + "\t");
                    strFileContents.Append(objUser.Agencies + "\t");
                    strFileContents.Append(objUser.Brands + "\t");
                    strFileContents.Append("\n");
                    strFileContents.Append(Environment.NewLine);
                }
                strFileContents.Append("\n");
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    private void ExportAllRolePermission(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string RoleCode = "";
            if (Request.QueryString["RoleCode"] != "")
            {
                RoleCode = Request.QueryString["RoleCode"].ToString();
            }
            string SearchString = Session["ExportRoleSearchString"].ToString();
            List<Role> objRolelist = new RoleFacade().GetAllRolePermission(RoleCode, SearchString);

            if (objRolelist != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("Role Code" + "\t" + "Role Name" + "\t" + "Module Name" + "\t" + "Sub Module Name" + "\t" + "Permission Name" + "\t\n");

                foreach (Role objRole in objRolelist)
                {
                    foreach (RolePermission objRolePermission in objRole.objRolePermissionlist)
                    {
                        if (objRole.Code != "")
                        {
                            InnerstrFileContents.Append(objRole.Code + "\t");
                            InnerstrFileContents.Append(objRole.RoleName + "\t");
                            InnerstrFileContents.Append(objRolePermission.ModuleName + "\t");
                            InnerstrFileContents.Append(objRolePermission.SubModuleName + "\t");
                            InnerstrFileContents.Append(objRolePermission.Permission + "\t");

                            InnerstrFileContents.Append("\n");
                        }
                    }
                }
                strFileContents.Append(InnerstrFileContents);
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportARSDataReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["ExportARSDataSearchString"].ToString();
            IList<ARSData> objARSDatalist = new ARSDataFacade().GetARSDataSearch("SwipeDatetime Asc", 5000, 0, SearchString);

            if (objARSDatalist != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("Guid" + "\t" + "Employee_code " + "\t" + "Employee_name" + "\t" + "Swipe_datetime" + "\t" + "Swipe_type" + "\t" + "Moved_to_ramco" + "\t" + "Created_by" + "\t" + "Created_date" + "\t" + "Modified_by" + "\t" + "Modified_date");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (ARSData objARSData in objARSDatalist)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objARSData.CustomerVisitId) + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objARSData.EmpCode) + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objARSData.Description) + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objARSData.SwipeDatetime) + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objARSData.swipeType) + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objARSData.MOved_to_ramco) + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objARSData.CreatedBy) + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objARSData.CreatedDate) + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    //----------------------------MIS Reports.................................
    private void ExportPssapOutstandingCompReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["PSSapHhOutstandingCompNameSearchString"].ToString();
            string SortExpression = Session["PSSapHhOutstandingCompNameSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["PSSapHhOutstandingCompNameMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["PSSapHhOutstandingCompNameStartRowIndex"].ToString());
            string UserCode = Session["PSSapHhOutstandingCompNameUserCode"].ToString();
            string VarianceType = Session["PSSapHhOutstandingCompNameVarianceType"].ToString();

            OutstandingComparisionList objOutstandingComparisionList = new PsSapHhOutstandingCompFacade().GetPsSapHhOutstandingCompSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<OutstandingComparision> lstOutstandingComparision = new List<OutstandingComparision>();
            lstOutstandingComparision = objOutstandingComparisionList.lstOutstandingComparision;

            if (objOutstandingComparisionList != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("  Sales Org Code" + "\t" + "Customer" + "\t" + " Pre-Seller" + "\t" + "Total SAP Outstanding" + "\t" + "Total HH Outstanding");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (OutstandingComparision objOutstandingComparision in lstOutstandingComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    //strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.ChannelCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.ChannelCode) + "\t" : "N/A" + "\t");
                    //strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.DivisionCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.DivisionCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.CustomerCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.CustomerCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.TotalSapOutStanding) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.TotalSapOutStanding) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.TotalHhOutStanidng) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.TotalHhOutStanidng) + "\t" : "N/A" + "\t");
                    strFileContents.Append("\n");
                    //foreach (PsSapHhOutstandingCompItem objPsSapHhOutstandingCompItem in objPsSapHhOutstandingComp.Items)
                    //{
                    //    strFileContents.Append(CommonFunctions.GetStringValue(objPsSapHhOutstandingCompItem.DocNo) != "" ? CommonFunctions.GetStringValue(objPsSapHhOutstandingCompItem.DocNo) + "\t" : "N/A" + "\t");
                    //    strFileContents.Append(CommonFunctions.GetStringValue(objPsSapHhOutstandingCompItem.RunDate.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objPsSapHhOutstandingCompItem.RunDate.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    //    strFileContents.Append(CommonFunctions.GetStringValue(objPsSapHhOutstandingCompItem.SapOutStanding) != "" ? CommonFunctions.GetStringValue(objPsSapHhOutstandingCompItem.SapOutStanding) + "\t" : "N/A" + "\t");
                    //    strFileContents.Append(CommonFunctions.GetStringValue(objPsSapHhOutstandingCompItem.HhOutStanidng) != "" ? CommonFunctions.GetStringValue(objPsSapHhOutstandingCompItem.HhOutStanidng) + "\t" : "N/A" + "\t");
                    //    strFileContents.Append("" + "\t");
                    //    strFileContents.Append("" + "\t");
                    //    strFileContents.Append("\n");
                    //}

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportPreSalesOrderReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["PreSalesOrderSearchString"].ToString();
            string SortExpression = Session["PreSalesOrderSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["PreSalesOrderMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["PreSalesOrderStartRowIndex"].ToString());
            string UserCode = Session["PreSalesOrderUserCode"].ToString();
            string VarianceType = Session["PreSalesOrderVarianceType"].ToString();

            PreSalesOrderList objPreSalesOrderList = new PreSalesOrderFacade().GetPreSalesOrderSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<PreSalesOrder> lstPreSalesOrder = new List<PreSalesOrder>();
            lstPreSalesOrder = objPreSalesOrderList.lstPreSalesOrder;

            if (objPreSalesOrderList != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("  AppDoc No" + "\t" + "Customer No " + "\t" + "Customer Name" + "\t" + "Date" + "\t" + " AppInvoice Value" + "\t" + "SAP Order No" + "\t" + "SAP Order Value" + "\t" + "Remarks");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (PreSalesOrder objPreSalesOrder in lstPreSalesOrder)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSalesOrder.AppDocNo) != "" ? CommonFunctions.GetStringValue(objPreSalesOrder.AppDocNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSalesOrder.CustomerNo) != "" ? CommonFunctions.GetStringValue(objPreSalesOrder.CustomerNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSalesOrder.CustomerName) != "" ? CommonFunctions.GetStringValue(objPreSalesOrder.CustomerName) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSalesOrder.Date.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objPreSalesOrder.Date.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSalesOrder.AppInvoiceValue) != "" ? CommonFunctions.GetStringValue(objPreSalesOrder.AppInvoiceValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSalesOrder.SapOrderNo) != "" ? CommonFunctions.GetStringValue(objPreSalesOrder.SapOrderNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSalesOrder.SapOrderValue) != "" ? CommonFunctions.GetStringValue(objPreSalesOrder.SapOrderValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSalesOrder.Remarks) != "" ? CommonFunctions.GetStringValue(objPreSalesOrder.Remarks) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportCashReceiptCreditInvoiceReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["CashReceiptCreditInvoiceSearchString"].ToString();
            string SortExpression = Session["CashReceiptCreditInvoiceSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["CashReceiptCreditInvoiceMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["CashReceiptCreditInvoiceStartRowIndex"].ToString());
            string UserCode = Session["CashReceiptCreditInvoiceUserCode"].ToString();
            string VarianceType = Session["CashReceiptCreditInvoiceVarianceType"].ToString();

            CashReceiptCreditInvoiceList objCashReceiptCreditInvoiceList = new CashReceiptCreditInvoiceFacade().GetCashReceiptCreditInvoiceSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<CashReceiptCreditInvoice> lstCashReceiptCreditInvoice = new List<CashReceiptCreditInvoice>();
            lstCashReceiptCreditInvoice = objCashReceiptCreditInvoiceList.lstCashReceiptCreditInvoice;

            if (lstCashReceiptCreditInvoice != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("  AppDoc No" + "\t" + "Customer No " + "\t" + "Customer Name" + "\t" + "Date" + "\t" + " SAP Invoice No" + "\t" + "App Reciept Amt" + "\t" + "Sales Reciept No" + "\t" + "Sales Reciept Amt" + "\t" + "SAP Cancellation No" + "\t" + "Remarks");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (CashReceiptCreditInvoice objCashReceiptCreditInvoice in lstCashReceiptCreditInvoice)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.AppDocNo) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.AppDocNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.CustomerNo) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.CustomerNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.CustomerName) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.CustomerName) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.Date.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.Date.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.SapInvoiceNo) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.SapInvoiceNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.AppsReceiptAmount) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.AppsReceiptAmount) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.SalesReceiptNo) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.SalesReceiptNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.SalesReceiptAmount) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.SalesReceiptAmount) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.SapCancellationNo) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.SapCancellationNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.Remarks) != "" ? CommonFunctions.GetStringValue(objCashReceiptCreditInvoice.Remarks) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportVSSAPHHOutstandingCompReportReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["VSSAPHHOutstandingCompReportSearchString"].ToString();
            string SortExpression = Session["VSSAPHHOutstandingCompReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["VSSAPHHOutstandingCompReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["VSSAPHHOutstandingCompReportStartRowIndex"].ToString());
            string UserCode = Session["VSSAPHHOutstandingCompReportUserCode"].ToString();
            string VarianceType = Session["VSSAPHHOutstandingCompReportVarianceType"].ToString();

            OutstandingComparisionList objOutstandingComparisionList = new VsSapHhOutstandingCompFacade().GetVsSapHhOutstandingCompSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<OutstandingComparision> lstOutstandingComparision = new List<OutstandingComparision>();
            lstOutstandingComparision = objOutstandingComparisionList.lstOutstandingComparision;

            if (lstOutstandingComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SalesOrg Code" + "\t" + "Division" + "\t" + "Customer" + "\t" + "VanSeller" + "\t" + "Total SAP OutStanding" + "\t" + "Total HH OutStanidng");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (OutstandingComparision objOutstandingComparision in lstOutstandingComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    //strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.ChannelCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.DivisionCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.DivisionCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.CustomerCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.CustomerCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.TotalSapOutStanding) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.TotalSapOutStanding) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparision.TotalHhOutStanidng) != "" ? CommonFunctions.GetStringValue(objOutstandingComparision.TotalHhOutStanidng) + "\t" : "N/A" + "\t");
                    strFileContents.Append("\n");
                    strFileContents.Append("\t\tSAP Document" + "\t" + "Run Date" + "\t" + "SAP Outstanding" + "\t" + "HH Outstanding\n");
                    foreach (OutstandingComparisionItem objOutstandingComparisionItem in objOutstandingComparision.Items)
                    {
                        strFileContents.Append("" + "\t");
                        strFileContents.Append("" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparisionItem.DocNo) != "" ? CommonFunctions.GetStringValue(objOutstandingComparisionItem.DocNo) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparisionItem.RunDate.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objOutstandingComparisionItem.RunDate.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparisionItem.SapOutStanding) != "" ? CommonFunctions.GetStringValue(objOutstandingComparisionItem.SapOutStanding) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingComparisionItem.HhOutStanidng) != "" ? CommonFunctions.GetStringValue(objOutstandingComparisionItem.HhOutStanidng) + "\t" : "N/A" + "\t");
                        strFileContents.Append("\n");
                    }
                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportWhpestockComarisonReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["WhpestockComarisonSearchString"].ToString();
            string SortExpression = Session["WhpestockComarisonSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["WhpestockComarisonMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["WhpestockComarisonStartRowIndex"].ToString());
            string UserCode = Session["WhpestockComarisonUserCode"].ToString();
            string VarianceType = Session["WhpestockComarisonVarianceType"].ToString();

            WhpestockComarisonList objWhpestockComarisonList = new WhpestockComarisonFacade().GetWhpestockComarisonSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<WhpestockComarison> lstWhpestockComarison = new List<WhpestockComarison>();
            lstWhpestockComarison = objWhpestockComarisonList.lstWhpestockComarison;

            if (lstWhpestockComarison != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                if (objWhpestockComarisonList.lstWhpestockComarison != null)
                {
                    strFileContents.Append("\t\t Run Date:: \t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objWhpestockComarisonList.lstWhpestockComarison[0].RunDate.ToString("MMM d,yyyy hh:mm tt")) != "" ? CommonFunctions.GetStringValue(objWhpestockComarisonList.lstWhpestockComarison[0].RunDate.ToString("MMM d,yyyy hh:mm tt")) + "\t" : "N/A" + "\t");
                }
                strFileContents.Append("\n");
                //InnerstrFileContents.Append("Site" + "\t" + "Storage Location" + "\t" + "Run Date" + "\t" + "Article" + "\t" + "SAP Stock Quantity" + "\t" + "HH Stock Quantity" + "\t" + "UOM");
                InnerstrFileContents.Append("Site" + "\t" + "Storage Location" + "\t" + "Article" + "\t" + "SAP Stock Quantity" + "\t" + "HH Stock Quantity" + "\t" + "UOM");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (WhpestockComarison objWhpestockComarison in lstWhpestockComarison)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objWhpestockComarison.Site) != "" ? CommonFunctions.GetStringValue(objWhpestockComarison.Site) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objWhpestockComarison.StorageLocation) != "" ? CommonFunctions.GetStringValue(objWhpestockComarison.StorageLocation) + "\t" : "N/A" + "\t");
                    //strFileContents.Append(CommonFunctions.GetStringValue(objWhpestockComarison.RunDate.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objWhpestockComarison.RunDate.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objWhpestockComarison.Article) != "" ? CommonFunctions.GetStringValue(objWhpestockComarison.Article) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objWhpestockComarison.SAPStockQuantity) != "" ? CommonFunctions.GetStringValue(objWhpestockComarison.SAPStockQuantity) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objWhpestockComarison.HHStockQuantity) != "" ? CommonFunctions.GetStringValue(objWhpestockComarison.HHStockQuantity) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objWhpestockComarison.UOM) != "" ? CommonFunctions.GetStringValue(objWhpestockComarison.UOM) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportVanSalesCashInvoiceReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["VanSalesCashInvoiceeSearchString"].ToString();
            string SortExpression = Session["VanSalesCashInvoiceSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["VanSalesCashInvoiceMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["VanSalesCashInvoiceStartRowIndex"].ToString());
            string UserCode = Session["VanSalesCashInvoiceUserCode"].ToString();
            string VarianceType = Session["VanSalesCashInvoiceVarianceType"].ToString();

            VanSalesCashInvoiceList objVanSalesCashInvoiceList = new VanSalesCashInvoiceFacade().GetVanSalesCashInvoiceSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<VanSalesCashInvoice> lstVanSalesCashInvoice = new List<VanSalesCashInvoice>();
            lstVanSalesCashInvoice = objVanSalesCashInvoiceList.lstVanSalesCashInvoice;

            if (lstVanSalesCashInvoice != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("App Doc #" + "\t" + " Cust No" + "\t" + "Customer Name" + "\t" + "Run Date" + "\t" + "App Inv Value" + "\t" + "SAP Order" + "\t" + "SAP Delivery" + "\t" + " SAP Invoice" + "\t" + "SAP Invoice Amount");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (VanSalesCashInvoice objVanSalesCashInvoice in lstVanSalesCashInvoice)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCashInvoice.AppDoc) != "" ? CommonFunctions.GetStringValue(objVanSalesCashInvoice.AppDoc) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCashInvoice.CustNo) != "" ? CommonFunctions.GetStringValue(objVanSalesCashInvoice.CustNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCashInvoice.CustName) != "" ? CommonFunctions.GetStringValue(objVanSalesCashInvoice.CustName) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCashInvoice.Date.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objVanSalesCashInvoice.Date.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCashInvoice.AppInvoiceValue) != "" ? CommonFunctions.GetStringValue(objVanSalesCashInvoice.AppInvoiceValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCashInvoice.SAPOrder) != "" ? CommonFunctions.GetStringValue(objVanSalesCashInvoice.SAPOrder) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCashInvoice.SAPDelivery) != "" ? CommonFunctions.GetStringValue(objVanSalesCashInvoice.SAPDelivery) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCashInvoice.SAPInvoice) != "" ? CommonFunctions.GetStringValue(objVanSalesCashInvoice.SAPInvoice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCashInvoice.SAPInvoice) == "" ? "N/A" + "\t" : CommonFunctions.GetStringValue(objVanSalesCashInvoice.SAPInvAmount) != "" ? CommonFunctions.GetStringValue(objVanSalesCashInvoice.SAPInvAmount) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportVanSalesCreditInvoiceReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["VanSalesCreditInvoiceeSearchString"].ToString();
            string SortExpression = Session["VanSalesCreditInvoiceSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["VanSalesCreditInvoiceMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["VanSalesCreditInvoiceStartRowIndex"].ToString());
            string UserCode = Session["VanSalesCreditInvoiceUserCode"].ToString();
            string VarianceType = Session["VanSalesCreditInvoiceVarianceType"].ToString();

            VanSalesCreditInvoiceList objVanSalesCreditInvoiceList = new VanSalesCreditInvoiceFacade().GetVanSalesCreditInvoiceSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<VanSalesCreditInvoice> lstVanSalesCreditInvoice = new List<VanSalesCreditInvoice>();
            lstVanSalesCreditInvoice = objVanSalesCreditInvoiceList.lstVanSalesCreditInvoice;

            if (lstVanSalesCreditInvoice != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("App Doc #" + "\t" + " Cust No" + "\t" + "Customer Name" + "\t" + "Run Date" + "\t" + "App Inv Value" + "\t" + "SAP Order" + "\t" + "SAP Delivery" + "\t" + " SAP Invoice" + "\t" + "SAP Invoice Amount");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (VanSalesCreditInvoice objVanSalesCreditInvoice in lstVanSalesCreditInvoice)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCreditInvoice.TrxCode) != "" ? CommonFunctions.GetStringValue(objVanSalesCreditInvoice.TrxCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCreditInvoice.CustNo) != "" ? CommonFunctions.GetStringValue(objVanSalesCreditInvoice.CustNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCreditInvoice.CustName) != "" ? CommonFunctions.GetStringValue(objVanSalesCreditInvoice.CustName) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCreditInvoice.Date.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objVanSalesCreditInvoice.Date.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCreditInvoice.AppInvoiceValue) != "" ? CommonFunctions.GetStringValue(objVanSalesCreditInvoice.AppInvoiceValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCreditInvoice.SAPOrder) != "" ? CommonFunctions.GetStringValue(objVanSalesCreditInvoice.SAPOrder) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCreditInvoice.SAPDelivery) != "" ? CommonFunctions.GetStringValue(objVanSalesCreditInvoice.SAPDelivery) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCreditInvoice.SAPInvoice) != "" ? CommonFunctions.GetStringValue(objVanSalesCreditInvoice.SAPInvoice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSalesCreditInvoice.SAPDelivery) == "" ? "N/A" + "\t" : CommonFunctions.GetStringValue(objVanSalesCreditInvoice.SAPInvAmount) != "" ? CommonFunctions.GetStringValue(objVanSalesCreditInvoice.SAPInvAmount) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportHHSAPInvoicePreSalesStatusReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["HHSAPInvoicePreSalesStatusReportSearchString"].ToString();
            string SortExpression = Session["HHSAPInvoicePreSalesStatusReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["HHSAPInvoicePreSalesStatusReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["HHSAPInvoicePreSalesStatusReportStartRowIndex"].ToString());
            string UserCode = Session["HHSAPInvoicePreSalesStatusReportUserCode"].ToString();
            string VarianceType = Session["HHSAPInvoicePreSalesStatusReportVarianceType"].ToString();

            HHSAPInvoicePreSalesStatusList objHHSAPInvoiceStatusList = new HHSAPInvoicePreSalesStatusFacade().GetHHSAPInvoicePreSalesStatusSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<HHSAPInvoicePreSalesStatus> lstHHSAPInvoicePreSalesStatus = new List<HHSAPInvoicePreSalesStatus>();
            lstHHSAPInvoicePreSalesStatus = objHHSAPInvoiceStatusList.lstHHSAPInvoicePreSalesStatus;

            if (lstHHSAPInvoicePreSalesStatus != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP Inv Doc #" + "\t" + " HH Inv Doc #" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Customer" + "\t" + " Seller" + "\t" + "Sales Group" + "\t" + "SAP Billed" + "\t" + "HH Billed" + "\t" + "Status");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (HHSAPInvoicePreSalesStatus objHHSAPInvoicePreSalesStatus in lstHHSAPInvoicePreSalesStatus)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.ReferenceCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.ReferenceCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.TrxCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.TrxCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.ChannelCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.SalesOffice) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.SalesOffice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.ClientCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.UserCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.SalesGroup) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.SalesGroup) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.SAPBilledValue) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.SAPBilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.BilledValue) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.BilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.Status) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoicePreSalesStatus.Status) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportHHSAPInvoiceVanSalesStatusReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["HHSAPInvoiceVanSalesStatusReportSearchString"].ToString();
            string SortExpression = Session["HHSAPInvoiceVanSalesStatusReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["HHSAPInvoiceVanSalesStatusReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["HHSAPInvoiceVanSalesStatusReportStartRowIndex"].ToString());
            string UserCode = Session["HHSAPInvoiceVanSalesStatusReportUserCode"].ToString();
            string VarianceType = Session["HHSAPInvoiceVanSalesStatusReportVarianceType"].ToString();

            HHSAPInvoiceVanSalesStatusList objHHSAPInvoiceStatusList = new HHSAPInvoiceVanSalesStatusFacade().GetHHSAPInvoiceVanSalesStatusSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<HHSAPInvoiceVanSalesStatus> lstHHSAPInvoiceVanSalesStatus = new List<HHSAPInvoiceVanSalesStatus>();

            lstHHSAPInvoiceVanSalesStatus = objHHSAPInvoiceStatusList.lstHHSAPInvoiceVanSalesStatus;

            if (lstHHSAPInvoiceVanSalesStatus != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP Inv Doc #" + "\t" + " HH Inv Doc #" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Customer" + "\t" + " Seller" + "\t" + "Sales Group" + "\t" + "SAP Billed" + "\t" + "HH Billed" + "\t" + "Status");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (HHSAPInvoiceVanSalesStatus objHHSAPInvoiceVanSalesStatus in lstHHSAPInvoiceVanSalesStatus)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.ReferenceCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.ReferenceCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.TrxCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.TrxCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.ChannelCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.SalesOffice) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.SalesOffice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.ClientCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.UserCode) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.SalesGroup) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.SalesGroup) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.SAPBilledValue) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.SAPBilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.BilledValue) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.BilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.Status) != "" ? CommonFunctions.GetStringValue(objHHSAPInvoiceVanSalesStatus.Status) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportSalesOrderItempricingVarianceReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["SalesOrderItempricingVarianceReportSearchString"].ToString();
            string SortExpression = Session["SalesOrderItempricingVarianceReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["SalesOrderItempricingVarianceReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["SalesOrderItempricingVarianceReportStartRowIndex"].ToString());
            string UserCode = Session["SalesOrderItempricingVarianceReportUserCode"].ToString();
            string VarianceType = Session["SalesOrderItempricingVarianceReportVarianceType"].ToString();

            SalesOrderItempricingCompList objSalesOrderItempricingCompList = new SalesOrderItempricingCompFacade().GetSalesOrderItempricingCompSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<SalesOrderItempricingComp> lstSalesOrderItempricingComp = new List<SalesOrderItempricingComp>();

            lstSalesOrderItempricingComp = objSalesOrderItempricingCompList.lstSalesOrderItempricingComp;

            if (lstSalesOrderItempricingComp != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP Inv Doc #" + "\t" + " HH Inv Doc #" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Customer" + "\t" + " Usercode" + "\t" + "Sales Group" + "\t" + "SAP Site" + "\t" + "Condition Type" + "\t" + "Article" + "\t" + "SAPCondValue" + "\t" + "HHCondValue");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (SalesOrderItempricingComp objSalesOrderItempricingComp in lstSalesOrderItempricingComp)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SAPSalesDocNo) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SAPSalesDocNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.HHDocNo) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.HHDocNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.ChannelCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SalesOffice) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SalesOffice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.ClientCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.UserCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SalesGroup) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SalesGroup) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SAPSite) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SAPSite) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.PricingCondType) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.PricingCondType) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.Article) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.Article) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SAPCondValue) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.SAPCondValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderItempricingComp.HHCondValue) != "" ? CommonFunctions.GetStringValue(objSalesOrderItempricingComp.HHCondValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportOutstandingInvoiceLineItemComparisionReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["OutstandingInvoiceLineItemComparisionReportSearchString"].ToString();
            string SortExpression = Session["OutstandingInvoiceLineItemComparisionReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["OutstandingInvoiceLineItemComparisionReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["OutstandingInvoiceLineItemComparisionReportStartRowIndex"].ToString());
            string UserCode = Session["OutstandingInvoiceLineItemComparisionReportUserCode"].ToString();
            string VarianceType = Session["OutstandingInvoiceLineItemComparisionReportVarianceType"].ToString();

            OutstandingInvoiceLineItemComparisionList objOutstandingInvoiceLineItemComparisionList = new OutstandingInvoiceLineItemComparisionFacade().GetOutstandingInvoiceLineItemComparisionSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<OutstandingInvoiceLineItemComparision> lstOutstandingInvoiceLineItemComparision = new List<OutstandingInvoiceLineItemComparision>();


            lstOutstandingInvoiceLineItemComparision = objOutstandingInvoiceLineItemComparisionList.lstOutstandingInvoiceLineItemComparision;

            if (lstOutstandingInvoiceLineItemComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SalesOrg Code" + "\t" + "Customer" + "\t" + "Seller" + "\t" + "SAP OutStanding Invoice No" + "\t" + " HH OutStanding Invoice No" + "\t" + "SAP OS Invoice Value" + "\t" + "HH Invoice Value");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (OutstandingInvoiceLineItemComparision objOutstandingInvoiceLineItemComparision in lstOutstandingInvoiceLineItemComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.ClientCode) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.SAPOutstandingInvoiceNo) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.SAPOutstandingInvoiceNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.HHOutstandingInvNo) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.HHOutstandingInvNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.SAPOSInvVal) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.SAPOSInvVal) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.HHOSInvVal) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceLineItemComparision.HHOSInvVal) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportInvoiceLineItemValComparisionReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["InvoiceLineItemValComparisionReportSearchString"].ToString();
            string SortExpression = Session["InvoiceLineItemValComparisionReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["InvoiceLineItemValComparisionReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["InvoiceLineItemValComparisionReportStartRowIndex"].ToString());
            string UserCode = Session["InvoiceLineItemValComparisionReportUserCode"].ToString();
            string VarianceType = Session["InvoiceLineItemValComparisionReportVarianceType"].ToString();

            InvoiceLineItemValComparisionList objInvoiceLineItemValComparisionList = new InvoiceLineItemValComparisionFacade().GetInvoiceLineItemValComparisionSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<InvoiceLineItemValComparision> lstInvoiceLineItemValComparision = new List<InvoiceLineItemValComparision>();


            lstInvoiceLineItemValComparision = objInvoiceLineItemValComparisionList.lstInvoiceLineItemValComparision;

            if (lstInvoiceLineItemValComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP Ref #" + "\t" + "HH Ref #" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Customer" + "\t" + "Seller" + "\t" + "Sales Group" + "\t" + "SAP Total Billed Values" + "\t" + "SAP Item Billed Value" + "\t" + "HH Billed Value");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (InvoiceLineItemValComparision objInvoiceLineItemValComparision in lstInvoiceLineItemValComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.ReferenceCode) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.ReferenceCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.TrxCode) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.TrxCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.ChannelCode) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SalesOffice) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SalesOffice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.ClientCode) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SalesGroup) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SalesGroup) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SAPTotalBilledValue) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SAPTotalBilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SAPItemBilledValue) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.SAPItemBilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.HandHeldBilledValue) != "" ? CommonFunctions.GetStringValue(objInvoiceLineItemValComparision.HandHeldBilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportInvoiceItemPricingConditionComparisionReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["InvoiceItemPricingConditionComparisionReportSearchString"].ToString();
            string SortExpression = Session["InvoiceItemPricingConditionComparisionReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["InvoiceItemPricingConditionComparisionReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["InvoiceItemPricingConditionComparisionReportStartRowIndex"].ToString());
            string UserCode = Session["InvoiceItemPricingConditionComparisionReportUserCode"].ToString();
            string VarianceType = Session["InvoiceItemPricingConditionComparisionReportVarianceType"].ToString();

            InvoiceItemPricingConditionComparisionList objInvoiceItemPricingConditionComparisionList = new InvoiceItemPricingConditionComparisionFacade().GetInvoiceItemPricingConditionComparisionSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<InvoiceItemPricingConditionComparision> lstInvoiceItemPricingConditionComparision = new List<InvoiceItemPricingConditionComparision>();


            lstInvoiceItemPricingConditionComparision = objInvoiceItemPricingConditionComparisionList.lstInvoiceItemPricingConditionComparision;

            if (lstInvoiceItemPricingConditionComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP Ref #" + "\t" + "HH Ref #" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Customer" + "\t" + "Seller" + "\t" + "Sales Group" + "\t" + "SAP Site" + "\t" + "Article");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (InvoiceItemPricingConditionComparision objInvoiceItemPricingConditionComparision in lstInvoiceItemPricingConditionComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.ReferenceCode) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.ReferenceCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.TrxCode) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.TrxCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.ChannelCode) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SalesOffice) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SalesOffice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.ClientCode) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SalesGroup) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SalesGroup) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SAPSite) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SAPSite) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.Article) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.Article) + "\t" : "N/A" + "\t");
                    //strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.PricingCondType) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.PricingCondType) + "\t" : "N/A" + "\t");
                    //strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SAPCondValue) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.SAPCondValue) + "\t" : "N/A" + "\t");
                    //strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.HHCondValue) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingConditionComparision.HHCondValue) + "\t" : "N/A" + "\t");
                    //strFileContents.Append("" + "\t");
                    //strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");
                    strFileContents.Append("\t\t\t\t\t\t\t\t\t\t\tPricing Cond Type" + "\t" + "SAP Cond Value" + "\t" + "HH Cond Value\n");
                    foreach (InvoiceItemPricingCondition objInvoiceItemPricingCondition in objInvoiceItemPricingConditionComparision.objInvoiceItemPricingCondition)
                    {
                        strFileContents.Append("" + "\t\t\t\t\t\t\t\t\t\t\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingCondition.PricingCondType) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingCondition.PricingCondType) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingCondition.SAPCondValue) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingCondition.SAPCondValue) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceItemPricingCondition.HHCondValue) != "" ? CommonFunctions.GetStringValue(objInvoiceItemPricingCondition.HHCondValue) + "\t" : "N/A" + "\t");
                        strFileContents.Append("\n");
                    }
                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportHHSAPCashreceiptstatusReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["HHSAPCashreceiptstatusReportSearchString"].ToString();
            string SortExpression = Session["HHSAPCashreceiptstatusReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["HHSAPCashreceiptstatusReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["HHSAPCashreceiptstatusReportStartRowIndex"].ToString());
            string UserCode = Session["HHSAPCashreceiptstatusReportUserCode"].ToString();
            string VarianceType = Session["HHSAPCashreceiptstatusReportVarianceType"].ToString();

            HHSAPCashreceiptstatusList objHHSAPCashreceiptstatusList = new HHSAPCashreceiptstatusFacade().GetHHSAPCashreceiptstatusSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<HHSAPCashreceiptstatus> lstHHSAPCashreceiptstatus = new List<HHSAPCashreceiptstatus>();


            lstHHSAPCashreceiptstatus = objHHSAPCashreceiptstatusList.lstHHSAPCashreceiptstatus;

            if (lstHHSAPCashreceiptstatus != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP FI Doc No" + "\t" + "HH Cash Reciept pt Ref #" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Customer" + "\t" + "Seller" + "\t" + "Sales Group" + "\t" + "HH Invoice Amt" + "\t" + "Status" + "\t" + "Clearing Doc No" + "\t" + "SAP Receipt No");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (HHSAPCashreceiptstatus objHHSAPCashreceiptstatus in lstHHSAPCashreceiptstatus)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SAPInvoiceNo) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SAPInvoiceNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.HHCashRecieptNo) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.HHCashRecieptNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.ChannelCode) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SalesOffice) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SalesOffice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.ClientCode) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.UserCode) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SalesGroup) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SalesGroup) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.HHInvoiceAmount) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.HHInvoiceAmount) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.Status) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.Status) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.ClearingDocNumber) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.ClearingDocNumber) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SAPReceiptNo) != "" ? CommonFunctions.GetStringValue(objHHSAPCashreceiptstatus.SAPReceiptNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportVanSellerSAPHHCreditVarianceReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["VanSellerSAPHHCreditVarianceReportSearchString"].ToString();
            string SortExpression = Session["VanSellerSAPHHCreditVarianceReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["VanSellerSAPHHCreditVarianceReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["VanSellerSAPHHCreditVarianceReportStartRowIndex"].ToString());
            string UserCode = Session["VanSellerSAPHHCreditVarianceReportUserCode"].ToString();
            string VarianceType = Session["VanSellerSAPHHCreditVarianceReportVarianceType"].ToString();

            VanSellerSAPHHCreditValCompList objVanSellerSAPHHCreditValCompList = new VanSellerSAPHHCreditValCompFacade().GetVanSellerSAPHHCreditValCompSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<VanSellerSAPHHCreditValComp> lstVanSellerSAPHHCreditValComp = new List<VanSellerSAPHHCreditValComp>();


            lstVanSellerSAPHHCreditValComp = objVanSellerSAPHHCreditValCompList.lstVanSellerSAPHHCreditValComp;

            if (lstVanSellerSAPHHCreditValComp != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SalesOrg Code" + "\t" + "Channel" + "\t" + "Division" + "\t" + "Customer" + "\t" + "Van Seller" + "\t" + "Customer Overall Credit Limit" + "\t" + "Individual Van seller Limit");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (VanSellerSAPHHCreditValComp objVanSellerSAPHHCreditValComp in lstVanSellerSAPHHCreditValComp)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.ChannelCode) != "" ? CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.Division) != "" ? CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.Division) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.ClientCode) != "" ? CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.VanSeller) != "" ? CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.VanSeller) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.SAPCreditLimit) != "" ? CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.SAPCreditLimit) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.HHCreditLimit) != "" ? CommonFunctions.GetStringValue(objVanSellerSAPHHCreditValComp.HHCreditLimit) + "\t" : "N/A" + "\t");

                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportPreSellerSAPHHCreditVarianceReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["PreSellerSAPHHCreditValCompReportSearchString"].ToString();
            string SortExpression = Session["PreSellerSAPHHCreditValCompReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["PreSellerSAPHHCreditValCompReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["PreSellerSAPHHCreditValCompReportStartRowIndex"].ToString());
            string UserCode = Session["PreSellerSAPHHCreditValCompReportUserCode"].ToString();
            string VarianceType = Session["PreSellerSAPHHCreditValCompReportVarianceType"].ToString();

            PreSellerSAPHHCreditValCompList objPreSellerSAPHHCreditValCompList = new PreSellerSAPHHCreditValCompFacade().GetPreSellerSAPHHCreditValCompSearch(SortExpression, 500000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<PreSellerSAPHHCreditValComp> lstPreSellerSAPHHCreditValComp = new List<PreSellerSAPHHCreditValComp>();


            lstPreSellerSAPHHCreditValComp = objPreSellerSAPHHCreditValCompList.lstPreSellerSAPHHCreditValComp;

            if (lstPreSellerSAPHHCreditValComp != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();// + "\t" + "Pre Seller"
                InnerstrFileContents.Append("SalesOrg Code" + "\t" + "Channel" + "\t" + "Division" + "\t" + "Customer" + "\t" + "SAP Credit Limit" + "\t" + "HH Credit Limit ");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (PreSellerSAPHHCreditValComp objPreSellerSAPHHCreditValComp in lstPreSellerSAPHHCreditValComp)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.ChannelCode) != "" ? CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.Division) != "" ? CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.Division) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.ClientCode) != "" ? CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.ClientCode) + "\t" : "N/A" + "\t");
                    //    strFileContents.Append(CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.PreSeller) != "" ? CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.PreSeller) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.SAPCreditLimit) != "" ? CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.SAPCreditLimit) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.HHCreditLimit) != "" ? CommonFunctions.GetStringValue(objPreSellerSAPHHCreditValComp.HHCreditLimit) + "\t" : "N/A" + "\t");

                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportCashReceiptCashInvoiceReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["CashReceiptCashInvoiceSearchString"].ToString();
            string SortExpression = Session["CashReceiptCashInvoiceSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["CashReceiptCashInvoiceMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["CashReceiptCashInvoiceStartRowIndex"].ToString());
            string UserCode = Session["CashReceiptCashInvoiceUserCode"].ToString();
            string VarianceType = Session["CashReceiptCashInvoiceVarianceType"].ToString();

            ReceiptCashreceiptforCashInvoiceList objReceiptCashreceiptforCashInvoiceList = new ReceiptCashreceiptforCashInvoiceFacade().GetReceiptCashreceiptforCashInvoiceSearch(SortExpression, 500000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<ReceiptCashreceiptforCashInvoice> lstReceiptCashreceiptforCashInvoice = new List<ReceiptCashreceiptforCashInvoice>();
            lstReceiptCashreceiptforCashInvoice = objReceiptCashreceiptforCashInvoiceList.lstReceiptCashreceiptforCashInvoice;

            if (lstReceiptCashreceiptforCashInvoice != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("  App Doc #" + "\t" + "Customer  " + "\t" + "Date" + "\t" + " App Invoice #" + "\t" + "App Reciept Amt" + "\t" + "Sales Reciept #" + "\t" + "SAP Cancellation No" + "\t" + "Remarks");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (ReceiptCashreceiptforCashInvoice objReceiptCashreceiptforCashInvoice in lstReceiptCashreceiptforCashInvoice)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.AppDocNo) != "" ? CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.AppDocNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue("[" + objReceiptCashreceiptforCashInvoice.ClientCode + "] " + objReceiptCashreceiptforCashInvoice.CustName) != "" ? CommonFunctions.GetStringValue("[" + objReceiptCashreceiptforCashInvoice.ClientCode + "] " + objReceiptCashreceiptforCashInvoice.CustName) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.Date.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.Date.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.AppInvoiceNo) != "" ? CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.AppInvoiceNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.AppsReceiptAmt) != "" ? CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.AppsReceiptAmt) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.SapReceiptNo) != "" ? CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.SapReceiptNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.SAPCancellationNo) != "" ? CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.SAPCancellationNo) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.Remarks) != "" ? CommonFunctions.GetStringValue(objReceiptCashreceiptforCashInvoice.Remarks) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportInvoiceHeaderVarianceReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["InvoiceHeaderVarianceReportSearchString"].ToString();
            string SortExpression = Session["InvoiceHeaderVarianceReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["InvoiceHeaderVarianceReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["InvoiceHeaderVarianceReportStartRowIndex"].ToString());
            string UserCode = Session["InvoiceHeaderVarianceReportUserCode"].ToString();
            string VarianceType = Session["InvoiceHeaderVarianceReportVarianceType"].ToString();

            InvoiceHeaderValComparisionList objInvoiceHeaderValComparisionList = new InvoiceHeaderValComparisionFacade().GetInvoiceHeaderValComparisionSearch(SortExpression, 500000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<InvoiceHeaderValComparision> lstInvoiceHeaderValComparision = new List<InvoiceHeaderValComparision>();


            lstInvoiceHeaderValComparision = objInvoiceHeaderValComparisionList.lstInvoiceHeaderValComparision;

            if (lstInvoiceHeaderValComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP Ref #" + "\t" + "HH Ref #" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Customer" + "\t" + "Seller" + "\t" + "Sales Group" + "\t" + "SAP Billed" + "\t" + "HH Billed");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (InvoiceHeaderValComparision objInvoiceHeaderValComparision in lstInvoiceHeaderValComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.ReferenceCode) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.ReferenceCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.TrxCode) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.TrxCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.ChannelCode) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.SalesOffice) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.SalesOffice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.ClientCode) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.SalesGroup) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.SalesGroup) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.SAPBilledValue) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.SAPBilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.BilledValue) != "" ? CommonFunctions.GetStringValue(objInvoiceHeaderValComparision.BilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportSAPPEVanStockComarisionReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["SAPPEVanStockComarisionReportSearchString"].ToString();
            string SortExpression = Session["SAPPEVanStockComarisionReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["SAPPEVanStockComarisionReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["SAPPEVanStockComarisionReportStartRowIndex"].ToString());
            string UserCode = Session["SAPPEVanStockComarisionReportUserCode"].ToString();
            string VarianceType = Session["SAPPEVanStockComarisionReportVarianceType"].ToString();

            SAPPEVanStockComarisionList objSAPPEVanStockComarisionList = new SAPPEVanStockComarisionFacade().GetSAPPEVanStockComarisionSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<SAPPEVanStockComarision> lstSAPPEVanStockComarision = new List<SAPPEVanStockComarision>();
            lstSAPPEVanStockComarision = objSAPPEVanStockComarisionList.lstSAPPEVanStockComarision;

            if (lstSAPPEVanStockComarision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("Sales Org" + "\t" + "Site" + "\t" + "Storage Location" + "\t" + "Article" + "\t" + "Run Date" + "\t" + "SAP Quantity" + "\t" + "HH Quantity" + "\t" + "UOM");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (SAPPEVanStockComarision objSAPPEVanStockComarision in lstSAPPEVanStockComarision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEVanStockComarision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objSAPPEVanStockComarision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEVanStockComarision.Site) != "" ? CommonFunctions.GetStringValue(objSAPPEVanStockComarision.Site) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEVanStockComarision.StorageLocation) != "" ? CommonFunctions.GetStringValue(objSAPPEVanStockComarision.StorageLocation) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEVanStockComarision.ItemCode) != "" ? CommonFunctions.GetStringValue(objSAPPEVanStockComarision.ItemCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEVanStockComarision.RunDate.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objSAPPEVanStockComarision.RunDate.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEVanStockComarision.SAPQty) != "" ? CommonFunctions.GetStringValue(objSAPPEVanStockComarision.SAPQty) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEVanStockComarision.HHQty) != "" ? CommonFunctions.GetStringValue(objSAPPEVanStockComarision.HHQty) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEVanStockComarision.BaseUOM) != "" ? CommonFunctions.GetStringValue(objSAPPEVanStockComarision.BaseUOM) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportLoadNoteQuantityComparision(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["LoadNoteQuantityComparisionSearchString"].ToString();
            string SortExpression = Session["LoadNoteQuantityComparisionSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["LoadNoteQuantityComparisionMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["LoadNoteQuantityComparisionStartRowIndex"].ToString());
            string UserCode = Session["LoadNoteQuantityComparisionUserCode"].ToString();
            string VarianceType = Session["LoadNoteQuantityComparisionVarianceType"].ToString();

            LoadNoteQuantityComparisionList objLoadNoteQuantityComparisionList = new LoadNoteQuantityComparisionFacade().GetLoadNoteQuantityComparisionSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<LoadNoteQuantityComparision> lstLoadNoteQuantityComparision = new List<LoadNoteQuantityComparision>();
            lstLoadNoteQuantityComparision = objLoadNoteQuantityComparisionList.lstLoadNoteQuantityComparision;

            if (lstLoadNoteQuantityComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP Movement #" + "\t" + "Movement Code" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "User Code" + "\t" + "Item Code" + "\t" + "UOM" + "\t" + "Requested Quantity" + "\t" + "Shipped Quantity");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (LoadNoteQuantityComparision objLoadNoteQuantityComparision in lstLoadNoteQuantityComparision)
                {

                    foreach (LoadNoteQuantityItem loadNoteQuantityItem in objLoadNoteQuantityComparision.loadNoteQuantityItem)
                    {
                        strFileContents.Append(CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.SAPMovementCode) != "" ? CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.SAPMovementCode) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.MovementCode) != "" ? CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.MovementCode) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.CreatedOn) != "" ? CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.CreatedOn) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.OrgCode) != "" ? CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.OrgCode) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.UserCode) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.ItemCode) != "" ? CommonFunctions.GetStringValue(loadNoteQuantityItem.ItemCode) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.UOM) != "" ? CommonFunctions.GetStringValue(loadNoteQuantityItem.UOM) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.ShippedQuantity) != "" ? CommonFunctions.GetStringValue(loadNoteQuantityItem.RequestedQuantity) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objLoadNoteQuantityComparision.ShippedQuantity) != "" ? CommonFunctions.GetStringValue(loadNoteQuantityItem.ShippedQuantity) + "\t" : "N/A" + "\t");
                        strFileContents.Append("" + "\t");
                        strFileContents.Append("" + "\t");
                        strFileContents.Append("\n");
                    }



                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportUnLoadNoteQuantityComparision(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["UnLoadNoteQuantityComparisionSearchString"].ToString();
            string SortExpression = Session["UnLoadNoteQuantityComparisionSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["UnLoadNoteQuantityComparisionMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["UnLoadNoteQuantityComparisionStartRowIndex"].ToString());
            string UserCode = Session["UnLoadNoteQuantityComparisionUserCode"].ToString();

            UnLoadNoteQuantityComparisionList objUnLoadNoteQuantityComparisionList = new UnLoadNoteQuantityComparisionFacade().GetUnLoadNoteQuantityComparisionSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode);
            List<UnLoadNoteQuantityComparision> lstUnLoadNoteQuantityComparision = new List<UnLoadNoteQuantityComparision>();
            lstUnLoadNoteQuantityComparision = objUnLoadNoteQuantityComparisionList.lstUnLoadNoteQuantityComparision;

            if (lstUnLoadNoteQuantityComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP Movement #" + "\t" + "Movement Code" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "User Code" + "\t" + "Item Code" + "\t" + "UOM" + "\t" + "Shipped Quantity");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (UnLoadNoteQuantityComparision objUnLoadNoteQuantityComparision in lstUnLoadNoteQuantityComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.SAPMovementCode) != "" ? CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.SAPMovementCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.MovementCode) != "" ? CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.MovementCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.ItemCode) != "" ? CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.ItemCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.UOM) != "" ? CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.UOM) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.ShippedQuantity) != "" ? CommonFunctions.GetStringValue(objUnLoadNoteQuantityComparision.ShippedQuantity) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportSAPAppStockComarisionReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["SAPPEAppStockComparisionReportSearchString"].ToString();
            string SortExpression = Session["SAPPEAppStockComparisionReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["SAPPEAppStockComparisionReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["SAPPEAppStockComparisionReportStartRowIndex"].ToString());
            string UserCode = Session["SAPPEAppStockComparisionReportUserCode"].ToString();
            string VarianceType = Session["SAPPEAppStockComparisionReportVarianceType"].ToString();

            SAPPEAppVanStockComparisionList objSAPPEAppVanStockComparisionList = new SAPPEAppVanStockComparisionFacade().GetSAPPEAppVanStockComparisionSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<SAPPEAppVanStockComparision> lstSAPPEAppVanStockComparision = new List<SAPPEAppVanStockComparision>();
            lstSAPPEAppVanStockComparision = objSAPPEAppVanStockComparisionList.lstSAPPEAppVanStockComparision;

            if (lstSAPPEAppVanStockComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();//+ "Run Date" + "\t"
                InnerstrFileContents.Append("Sales Org" + "\t" + "Site" + "\t" + "Storage Location" + "\t" + "ItemCode" + "\t" + "SAP Quantity" + "\t" + "HH Quantity");//+ "\t" + "UOM"
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (SAPPEAppVanStockComparision objSAPPEAppVanStockComparision in lstSAPPEAppVanStockComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.Site) != "" ? CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.Site) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.StorageLocation) != "" ? CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.StorageLocation) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.ItemCode) != "" ? CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.ItemCode) + "\t" : "N/A" + "\t");
                    // strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.RunDate.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.RunDate.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.SAPQuantity) != "" ? CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.SAPQuantity) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.AppQuantity) != "" ? CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.AppQuantity) + "\t" : "N/A" + "\t");
                    // strFileContents.Append(CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.BaseUOM) != "" ? CommonFunctions.GetStringValue(objSAPPEAppVanStockComparision.BaseUOM) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    private void ExportPromotionArticleReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["PromotionArticleSearchString"].ToString();
            string SortExpression = Session["PromotionArticleSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["PromotionArticleMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["PromotionArticleStartRowIndex"].ToString());
            string SearchString1 = Session["PromotionArticleSearchString1"].ToString();

            PromotionArticlePromotionList objPromotionArticlePromotionList = new PromotionArticleReportFacade().GetPromotionArticlePromotionSearch(SortExpression, MaximumRows, 0, SearchString, SearchString1);

            List<PromotionArticlePromotionReport> lstPromotionArticlePromotionReport = new List<PromotionArticlePromotionReport>();


            lstPromotionArticlePromotionReport = objPromotionArticlePromotionList.lstPromotionArticlePromotion;

            if (lstPromotionArticlePromotionReport != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("Promotion" + "\t" + "Promotion description" + "\t" + "Promo type" + "\t" + "Order from" + "\t" + "Orders to " + "\t" + "Sales Org" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Sales Group" + "\t" + "Article (Condition)" + "\t" + "UOM" + "\t" + "Allocation Val" + "\t" + "CondRecNo." + "\t" + "Status" + "\t" + "Deal Cond" + "\t" + "Deal Status" + "\t" + "Material" + "\t" + "Material Description" + "\t" + "Sales Unit");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (PromotionArticlePromotionReport objSPromotionArticlePromotionReport in lstPromotionArticlePromotionReport)
                {
                    foreach (PromotionArticleItemReport objPromotionArticleItemReport in objSPromotionArticlePromotionReport.PromotionArticleItems)
                    {
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.Promotion) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.Promotion) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.PromotionDescription) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.PromotionDescription) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.PromoType) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.PromoType) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.OrderFrom.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.OrderFrom.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.OrdersTo.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.OrdersTo.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.SalesOrgCode) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.ChannelCode) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.ChannelCode) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.SalesOffice) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.SalesOffice) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.SalesGroup) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.SalesGroup) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.Article) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.Article) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.UOM) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.UOM) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.AllocationVal) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.AllocationVal) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.CondRecNo) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.CondRecNo) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.Status) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.Status) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.DealcondNo) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.DealcondNo) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.DealStatus) != "" ? CommonFunctions.GetStringValue(objSPromotionArticlePromotionReport.DealStatus) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objPromotionArticleItemReport.Material) != "" ? CommonFunctions.GetStringValue(objPromotionArticleItemReport.Material) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objPromotionArticleItemReport.MaterialDescription) != "" ? CommonFunctions.GetStringValue(objPromotionArticleItemReport.MaterialDescription) + "\t" : "N/A" + "\t");
                        strFileContents.Append(CommonFunctions.GetStringValue(objPromotionArticleItemReport.SalesUnit) != "" ? CommonFunctions.GetStringValue(objPromotionArticleItemReport.SalesUnit) + "\t" : "N/A" + "\t");
                        strFileContents.Append("\n");
                    }
                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportSalesOrderHeaderValComparisionReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["SalesOrderHeaderValComparisionReportSearchString"].ToString();
            string SortExpression = Session["SalesOrderHeaderValComparisionReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["SalesOrderHeaderValComparisionReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["SalesOrderHeaderValComparisionReportStartRowIndex"].ToString());
            string UserCode = Session["SalesOrderHeaderValComparisionReportUserCode"].ToString();
            string VarianceType = Session["SalesOrderHeaderValComparisionReportVarianceType"].ToString();

            SalesOrderHeaderValComparisionList objSalesOrderHeaderValComparisionList = new SalesOrderHeaderValComparisionFacade().GetSalesOrderHeaderValComparisionSearch(SortExpression, 500000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<SalesOrderHeaderValComparision> lstSalesOrderHeaderValComparision = new List<SalesOrderHeaderValComparision>();


            lstSalesOrderHeaderValComparision = objSalesOrderHeaderValComparisionList.lstSalesOrderHeaderValComparision;

            if (lstSalesOrderHeaderValComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                InnerstrFileContents.Append("SAP Ref #" + "\t" + "HH Ref #" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Customer" + "\t" + "Seller" + "\t" + "Sales Group" + "\t" + "SAP Billed" + "\t" + "HH Billed");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (SalesOrderHeaderValComparision objSalesOrderHeaderValComparision in lstSalesOrderHeaderValComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.ReferenceCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.ReferenceCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.TrxCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.TrxCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.ChannelCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.SalesOffice) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.SalesOffice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.ClientCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.SalesGroup) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.SalesGroup) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.SAPBilledValue) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.SAPBilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.BilledValue) != "" ? CommonFunctions.GetStringValue(objSalesOrderHeaderValComparision.BilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportSalesOrderLineItemValComparisionReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["SalesOrderLineItemValComparisionReportSearchString"].ToString();
            string SortExpression = Session["SalesOrderLineItemValComparisionReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["SalesOrderLineItemValComparisionReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["SalesOrderLineItemValComparisionReportStartRowIndex"].ToString());
            string UserCode = Session["SalesOrderLineItemValComparisionReportUserCode"].ToString();
            string VarianceType = Session["SalesOrderLineItemValComparisionReportVarianceType"].ToString();

            SalesOrderLineItemValComparisionList objSalesOrderLineItemValComparisionListList = new SalesOrderLineItemValComparisionFacade().GetSalesOrderLineItemValComparisionSearch(SortExpression, 500000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<SalesOrderLineItemValComparision> lstSalesOrderLineItemValComparision = new List<SalesOrderLineItemValComparision>();


            lstSalesOrderLineItemValComparision = objSalesOrderLineItemValComparisionListList.lstSalesOrderLineItemValComparision;

            if (lstSalesOrderLineItemValComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents1 = new StringBuilder();
                InnerstrFileContents.Append("SAP Ref #" + "\t" + "HH Ref #" + "\t" + "Created On" + "\t" + "SalesOrg Code" + "\t" + "Channel" + "\t" + "Sales Office" + "\t" + "Customer" + "\t" + "Seller" + "\t" + "Sales Group" + "\t" + "SAP Total");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (SalesOrderLineItemValComparision objSalesOrderLineItemValComparision in lstSalesOrderLineItemValComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.ReferenceCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.ReferenceCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.TrxCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.TrxCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.CreatedOn.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.ChannelCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.ChannelCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.SalesOffice) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.SalesOffice) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.ClientCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.SalesGroup) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.SalesGroup) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.SAPTotalBilledValue) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItemValComparision.SAPTotalBilledValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append("\n");
                    strFileContents.Append("\n");
                    if (objSalesOrderLineItemValComparision.Items.Count > 0)
                    {
                        InnerstrFileContents1.Append("Article" + "\t" + "Site" + "\t" + "Promotion" + "\t" + "SAP Item Billed Value" + "\t" + "Hand Held");
                        strFileContents.Append(InnerstrFileContents1);
                        strFileContents.Append("\n");
                        strFileContents.Append("\n");
                        foreach (SalesOrderLineItem objSalesOrderLineItem in objSalesOrderLineItemValComparision.Items)
                        {

                            strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItem.Article) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItem.Article) + "\t" : "N/A" + "\t");
                            strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItem.Site) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItem.Site) + "\t" : "N/A" + "\t");
                            strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItem.Promotion) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItem.Promotion) + "\t" : "N/A" + "\t");
                            strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItem.SAPItemBilledValue) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItem.SAPItemBilledValue) + "\t" : "N/A" + "\t");
                            strFileContents.Append(CommonFunctions.GetStringValue(objSalesOrderLineItem.HandHeldBilledValue) != "" ? CommonFunctions.GetStringValue(objSalesOrderLineItem.HandHeldBilledValue) + "\t" : "N/A" + "\t");
                            strFileContents.Append("" + "\t");
                            strFileContents.Append("" + "\t");
                            strFileContents.Append("\n");
                            strFileContents.Append("\n");
                        }
                    }

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportOutstandingInvoiceComparisionReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["OutstandingInvoiceComparisionReportSearchString"].ToString();
            string SortExpression = Session["OutstandingInvoiceComparisionReportSortExpression"].ToString();
            int MaximumRows = Convert.ToInt32(Session["OutstandingInvoiceComparisionReportMaximumRows"].ToString());
            int StartRowIndex = Convert.ToInt32(Session["OutstandingInvoiceComparisionReportStartRowIndex"].ToString());
            string UserCode = Session["OutstandingInvoiceComparisionReportUserCode"].ToString();
            string VarianceType = Session["OutstandingInvoiceComparisionReportVarianceType"].ToString();

            OutstandingInvoiceComparisionList objOutstandingInvoiceComparisionList = new OutstandingInvoiceComparisionFacade().GetOutstandingInvoiceComparisionSearch(SortExpression, 10000000, StartRowIndex, SearchString, UserCode, VarianceType);
            List<OutstandingInvoiceComparision> lstOutstandingInvoiceComparision = new List<OutstandingInvoiceComparision>();
            lstOutstandingInvoiceComparision = objOutstandingInvoiceComparisionList.lstOutstandingInvoiceComparision;

            if (lstOutstandingInvoiceComparision != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();//+ "Run Date" + "\t"
                InnerstrFileContents.Append("SalesOrg Code" + "\t" + "Customer" + "\t" + "Created On" + "\t" + "Seller" + "\t" + "Outstanding Invoices" + "\t" + "Invoice Values");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (OutstandingInvoiceComparision objOutstandingInvoiceComparision in lstOutstandingInvoiceComparision)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.SalesOrgCode) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.SalesOrgCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.ClientCode) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.ClientCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.Createdon.ToString("MMM d,yyyy HH:mm")) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.Createdon.ToString("MMM d,yyyy HH:mm")) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.UserCode) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.UserCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.OutstandingInvoices) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.OutstandingInvoices) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.InvoiceValue) != "" ? CommonFunctions.GetStringValue(objOutstandingInvoiceComparision.InvoiceValue) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportWeeklySalesHistoryReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            int StartRowIndex = 0;
            string UserCode = "", SearchString = "1=1", SelectedUserCode = "", GrvStatus = "", SortExpression = "", SalesOrgCodes = "", Regions = "", ASMs = "", Supervisors = "", Routes = "", StartDate = "", EndDate = "";


            if (SessionManager.UserCode != null)
            {
                UserCode = SessionManager.UserCode;
            }
            if (Session["WeeklySalesReturn_GRVStatus"] != null)
            {
                GrvStatus = Session["WeeklySalesReturn_GRVStatus"].ToString();
            }
            if (Session["WeeklySalesReturn_SalesOrganization"] != null)
            {
                SalesOrgCodes = Session["WeeklySalesReturn_SalesOrganization"].ToString();
            }
            if (Session["WeeklySalesReturn_Region"] != null)
            {
                Regions = Session["WeeklySalesReturn_Region"].ToString();
            }
            if (Session["WeeklySalesReturn_ASM"] != null)
            {
                ASMs = Session["WeeklySalesReturn_ASM"].ToString();
            }
            if (Session["WeeklySalesReturn_Supervisor"] != null)
            {
                Supervisors = Session["WeeklySalesReturn_Supervisor"].ToString();
            }
            if (Session["WeeklySalesReturn_Route"] != null)
            {
                Routes = Session["WeeklySalesReturn_Route"].ToString();
            }
            if (Session["WeeklySalesReturn_StartDate"] != null)
            {
                StartDate = Session["WeeklySalesReturn_StartDate"].ToString();
            }
            if (Session["WeeklySalesReturn_EndDate"] != null)
            {
                EndDate = Session["WeeklySalesReturn_EndDate"].ToString();
            }
            if (Session["WeeklySalesReturn_EndDate"] != null)
            {
                SelectedUserCode = Session["WeeklySalesReturn_SelectedUserCode"].ToString();
            }


            WeeklyOrderHistoryResult objWeeklyOrderHistoryResultList = new WeeklyOrderHistoryFacade().GetWeeklySalesReturn(SortExpression, 10000000, StartRowIndex, SearchString, SelectedUserCode, UserCode, SalesOrgCodes, Regions, ASMs, Supervisors, Routes, StartDate, EndDate, GrvStatus);
            List<WeeklyOrderHistory> lstWeeklyOrderHistory = new List<WeeklyOrderHistory>();
            lstWeeklyOrderHistory = objWeeklyOrderHistoryResultList.WeeklyOrderHistory;

            if (lstWeeklyOrderHistory != null)
            {
                strFileContents = new StringBuilder();
                StringBuilder InnerstrFileContents = new StringBuilder();//+ "Run Date" + "\t"
                InnerstrFileContents.Append("Order No" + "\t" + "Salesman" + "\t" + "Customer" + "\t" + "Order Date" + "\t" + "Quantity");
                strFileContents.Append(InnerstrFileContents);
                strFileContents.Append("\n");
                foreach (WeeklyOrderHistory objWeeklyOrderHistory in lstWeeklyOrderHistory)
                {

                    strFileContents.Append(CommonFunctions.GetStringValue(objWeeklyOrderHistory.TrxCode) != "" ? CommonFunctions.GetStringValue(objWeeklyOrderHistory.TrxCode) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objWeeklyOrderHistory.SalesMan) != "" ? CommonFunctions.GetStringValue(objWeeklyOrderHistory.SalesMan) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objWeeklyOrderHistory.CustomerName) != "" ? CommonFunctions.GetStringValue(objWeeklyOrderHistory.CustomerName) + "\t" : "N/A" + "\t");
                    strFileContents.Append(CommonFunctions.GetStringValue(objWeeklyOrderHistory.TrxDate != "" ? CommonFunctions.GetStringValue(objWeeklyOrderHistory.TrxDate) + "\t" : "N/A" + "\t"));
                    strFileContents.Append(CommonFunctions.GetStringValue(objWeeklyOrderHistory.ReturnQuantity) != "" ? CommonFunctions.GetStringValue(objWeeklyOrderHistory.ReturnQuantity) + "\t" : "N/A" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }

        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportFinalSettlementReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string UserCode = CommonFunctions.getStringValue(Session["FinalSettlementUserCode"]);
            string SearchString = CommonFunctions.getStringValue(Session["FinalSettlementSearchString"]);
            string VarianceType = CommonFunctions.getStringValue(Session["FinalSettlementVarianceType"]);

            FinalSettlement objFinalSettlement = new FinalSettlementFacade().GetFinalSettlement(UserCode, SearchString, VarianceType);
            if (objFinalSettlement != null)
            {
                strFileContents = new StringBuilder();

                string strDate = DateTime.Now.ToString("MMM d,yyyy HH:mm");
                if (Session["FinalSettlementReportDateRange"] != null)
                {
                    strDate = Session["FinalSettlementReportDateRange"].ToString();
                }
                // Header                
                strFileContents.Append("Company Code" + "\t" + objFinalSettlement.SalesOrgCode + "\t\t" + "Site" + "\t" + objFinalSettlement.Site + "\t\n" +
                    "Date" + "\t" + strDate + "\t\t" + "Seller Name" + "\t" + objFinalSettlement.Description + "\t\n" +
                    "Employee Number" + "\t" + objFinalSettlement.EmpCode);
                strFileContents.Append("\n\n");

                //VAN SALES - CREDIT INVOICE
                strFileContents.Append("VAN SALES - CREDIT INVOICE \n");
                strFileContents.Append("Total Van Sales Credit Invoice App \t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalVanSaleCreditInvoicesAPP)
                    + "\t Total Van Sales Credit Invoice SAP \t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalVanSaleCreditInvoicesSAP) + "\n\n");

                strFileContents.Append("App Doc #" + "\t" + "Cust No" + "\t" + "Cust Name" + "\t" + "Date" + "\t" + "App Inv Value" + "\t" + "SAP Order #"
                    + "\t" + "SAP Delivery #" + "\t" + "SAP Invoice#" + "\t" + "SAP Inv Amt");
                strFileContents.Append("\n");
                if (objFinalSettlement.VanSaleCreditInvoices != null && objFinalSettlement.VanSaleCreditInvoices.Count > 0)
                {
                    foreach (TrxHeader objVanSaleCreditInvoices in objFinalSettlement.VanSaleCreditInvoices)
                    {
                        strFileContents.Append(CommonFunctions.getStringNA(objVanSaleCreditInvoices.TrxCode) + "\t" + CommonFunctions.getStringNA(objVanSaleCreditInvoices.ClientCode) + "\t"
                            + CommonFunctions.getStringNA(objVanSaleCreditInvoices.ClientBranchName) + "\t" + objVanSaleCreditInvoices.CreatedOn.ToString("MMM d,yyyy HH:mm") + "\t" +
                            (CommonFunctions.getFormattedDoubleValue(Convert.ToDouble(objVanSaleCreditInvoices.TotalAmount) - Convert.ToDouble(objVanSaleCreditInvoices.TotalDiscountAmount))) + "\t"
                            + CommonFunctions.getStringNA(objVanSaleCreditInvoices.ReferenceCode) + "\t" + CommonFunctions.getStringNA(objVanSaleCreditInvoices.DeliveryNumber) + "\t" +
                            CommonFunctions.getStringNA(objVanSaleCreditInvoices.InvoiceNumber) + "\t" +
                            (CommonFunctions.getFormattedDoubleValue(Convert.ToDouble(objVanSaleCreditInvoices.TotalAmount) - Convert.ToDouble(objVanSaleCreditInvoices.TotalDiscountAmount))));
                        strFileContents.Append("\n");

                    }
                }

                //VAN SALES - CASH INVOICE
                strFileContents.Append("\n");
                strFileContents.Append("VAN SALES - CASH INVOICE \n");
                strFileContents.Append("Total Van Sales Cash Invoice App\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalVanSaleCashInvoicesAPP).ToString()
                    + "\tTotal Van Sales Cash Invoice SAP\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalVanSaleCashInvoicesSAP).ToString() + "\n\n");

                strFileContents.Append("App Doc #" + "\t" + "Cust No" + "\t" + "Cust Name" + "\t" + "Date" + "\t" + "App Inv Value" + "\t" + "SAP Order #"
                    + "\t" + "SAP Delivery #" + "\t" + "SAP Invoice#" + "\t" + "SAP Inv Amt");
                strFileContents.Append("\n");
                if (objFinalSettlement.VanSaleCashInvoices != null && objFinalSettlement.VanSaleCashInvoices.Count > 0)
                {
                    foreach (TrxHeader objVanSaleCreditInvoices in objFinalSettlement.VanSaleCashInvoices)
                    {
                        strFileContents.Append(CommonFunctions.getStringNA(objVanSaleCreditInvoices.TrxCode) + "\t" + CommonFunctions.getStringNA(objVanSaleCreditInvoices.ClientCode) + "\t"
                            + CommonFunctions.getStringNA(objVanSaleCreditInvoices.ClientBranchName) + "\t" + objVanSaleCreditInvoices.CreatedOn.ToString("MMM d,yyyy HH:mm") + "\t" +
                            (CommonFunctions.getFormattedDoubleValue(Convert.ToDouble(objVanSaleCreditInvoices.TotalAmount) - Convert.ToDouble(objVanSaleCreditInvoices.TotalDiscountAmount))) + "\t"
                            + CommonFunctions.getStringNA(objVanSaleCreditInvoices.ReferenceCode) + "\t" + CommonFunctions.getStringNA(objVanSaleCreditInvoices.DeliveryNumber) + "\t" +
                            CommonFunctions.getStringNA(objVanSaleCreditInvoices.InvoiceNumber) + "\t" +
                            (CommonFunctions.getFormattedDoubleValue(Convert.ToDouble(objVanSaleCreditInvoices.TotalAmount) - Convert.ToDouble(objVanSaleCreditInvoices.TotalDiscountAmount))));
                        strFileContents.Append("\n");

                    }
                }

                //PRE SALES ORDER
                strFileContents.Append("\n");
                strFileContents.Append("PRE SALES ORDER \n");
                strFileContents.Append("Total Pre Sales Invoice App\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalPreSaleInvoicesAPP).ToString()
                    + "\tTotal Pre Sales Invoice SAP\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalPreSaleInvoicesSAP).ToString() + "\n\n");

                strFileContents.Append("App Doc #" + "\t" + "Cust No" + "\t" + "Cust Name" + "\t" + "Date" + "\t" + "App Inv Value" + "\t" + "SAP Order #"
                    + "\t" + "SAP Delivery #" + "\t" + "SAP Invoice#" + "\t" + "SAP Inv Amt");
                strFileContents.Append("\n");
                if (objFinalSettlement.PreSaleInvoices != null && objFinalSettlement.PreSaleInvoices.Count > 0)
                {
                    foreach (TrxHeader objVanSaleCreditInvoices in objFinalSettlement.PreSaleInvoices)
                    {
                        strFileContents.Append(CommonFunctions.getStringNA(objVanSaleCreditInvoices.TrxCode) + "\t" + CommonFunctions.getStringNA(objVanSaleCreditInvoices.ClientCode) + "\t"
                            + CommonFunctions.getStringNA(objVanSaleCreditInvoices.ClientBranchName) + "\t" + objVanSaleCreditInvoices.CreatedOn.ToString("MMM d,yyyy HH:mm") + "\t" +
                            (CommonFunctions.getFormattedDoubleValue(Convert.ToDouble(objVanSaleCreditInvoices.TotalAmount) - Convert.ToDouble(objVanSaleCreditInvoices.TotalDiscountAmount))) + "\t"
                            + CommonFunctions.getStringNA(objVanSaleCreditInvoices.ReferenceCode) + "\t" + CommonFunctions.getStringNA(objVanSaleCreditInvoices.DeliveryNumber) + "\t" +
                            CommonFunctions.getStringNA(objVanSaleCreditInvoices.InvoiceNumber) + "\t" +
                            (CommonFunctions.getFormattedDoubleValue(Convert.ToDouble(objVanSaleCreditInvoices.TotalAmount) - Convert.ToDouble(objVanSaleCreditInvoices.TotalDiscountAmount))));
                        strFileContents.Append("\n");

                    }
                }

                //RECEIPT - CASH RECEIPT FOR CASH INVOICE
                strFileContents.Append("\n");
                strFileContents.Append("RECEIPT - CASH RECEIPT FOR CASH INVOICE \n");
                strFileContents.Append("Total Receipt - Cash receipt for Cash App\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalCashRecieptForCashInvoicesAPP).ToString()
                    + "\tTotal Receipt - Cash receipt for Cash SAP\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalCashRecieptForCashInvoicesSAP).ToString() + "\n\n");

                strFileContents.Append("App Doc #" + "\t" + "Cust No" + "\t" + "Cust Name" + "\t" + "Date" + "\t" + "App Invoice Number " + "\t" + "App Receipt Amt"
                    + "\t" + "SAP Receipt #" + "\t" + "Sap Receipt Amt" + "\t" + "SAP Cancellation #");
                strFileContents.Append("\n");
                if (objFinalSettlement.CashRecieptForCashInvoices != null && objFinalSettlement.CashRecieptForCashInvoices.Count > 0)
                {
                    foreach (PaymentHeader objPaymentHeader in objFinalSettlement.CashRecieptForCashInvoices)
                    {
                        strFileContents.Append(CommonFunctions.getStringNA(objPaymentHeader.Receipt_Number) + "\t" + CommonFunctions.getStringNA(objPaymentHeader.SITE_NUMBER) + "\t"
                            + CommonFunctions.getStringNA(objPaymentHeader.objCustomer.SITE_NAME) + "\t" + objPaymentHeader.ReceiptDate.ToString("MMM d,yyyy HH:mm") + "\t" +
                            CommonFunctions.getStringNA(objPaymentHeader.InvoiceNumber) + "\t" +
                            CommonFunctions.getFormattedDoubleValue(objPaymentHeader.Amount) + "\t"
                            + CommonFunctions.getStringNA(objPaymentHeader.SAPReferenceCode) + "\t" + CommonFunctions.getFormattedDoubleValue(objPaymentHeader.Amount) + "\t" +
                            CommonFunctions.getStringNA(objPaymentHeader.CancelledDocumentNumber));
                        strFileContents.Append("\n");
                        /**
                      //Cash Invoices
                      strFileContents.Append("\t" + "Invoice Number" + "\t" + "Trx Type" + "\t" + "Total Amount (SAR)");
                      strFileContents.Append("\n");
                      foreach (PaymentInvoice objPaymentInvoice in objPaymentHeader.PaymentInvoices)
                      {
                          strFileContents.Append("\t" + CommonFunctions.getStringNA(objPaymentInvoice.Invoice_Number) + "\t" + CommonFunctions.getStringNA(objPaymentInvoice.TrxType) + "\t"
                          + CommonFunctions.getFormattedDoubleValue(objPaymentInvoice.Amount));
                          strFileContents.Append("\n");
                      }
                      */
                    }
                }

                //RECEIPT - CASH RECEIPT FOR CREDIT INVOICE
                strFileContents.Append("\n");
                strFileContents.Append("RECEIPT - CASH RECEIPT FOR CREDIT INVOICE\n");
                strFileContents.Append("Total Receipt - Credit receipt for Cash App\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalCashRecieptForCashCreditInvoicesAPP)
                    + "\tTotal Receipt - Credit receipt for Cash SAP\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalCashRecieptForCashCreditInvoicesSAP) + "\n\n");

                strFileContents.Append("App Doc #" + "\t" + "Cust No" + "\t" + "Cust Name" + "\t" + "Date" + "\t" + "App Receipt Amt"
                    + "\t" + "SAP Receipt #" + "\t" + "Sap Receipt Amt" + "\t" + "SAP Cancellation #");
                strFileContents.Append("\n");
                if (objFinalSettlement.CashRecieptForCashInvoices != null && objFinalSettlement.CashRecieptForCashCreditInvoices.Count > 0)
                {
                    foreach (PaymentHeader objPaymentHeader in objFinalSettlement.CashRecieptForCashCreditInvoices)
                    {
                        strFileContents.Append(CommonFunctions.getStringNA(objPaymentHeader.Receipt_Number) + "\t" + CommonFunctions.getStringNA(objPaymentHeader.SITE_NUMBER) + "\t"
                            + CommonFunctions.getStringNA(objPaymentHeader.objCustomer.SITE_NAME) + "\t" + objPaymentHeader.ReceiptDate.ToString("MMM d,yyyy HH:mm") + "\t" +
                            CommonFunctions.getFormattedDoubleValue(objPaymentHeader.Amount) + "\t"
                            + CommonFunctions.getStringNA(objPaymentHeader.SAPReferenceCode) + "\t" + CommonFunctions.getFormattedDoubleValue(objPaymentHeader.Amount) + "\t" +
                            CommonFunctions.getStringNA(objPaymentHeader.CancelledDocumentNumber));
                        strFileContents.Append("\n");
                        //Cash Invoices
                        strFileContents.Append("\t" + "SAP Invoice Number" + "\t" + "Trx Type" + "\t" + "Total Amount (SAR)");
                        strFileContents.Append("\n");
                        foreach (PaymentInvoice objPaymentInvoice in objPaymentHeader.PaymentInvoices)
                        {
                            strFileContents.Append("\t" + CommonFunctions.getStringNA(objPaymentInvoice.Invoice_Number) + "\t" + CommonFunctions.getStringNA(objPaymentInvoice.TrxType) + "\t"
                            + CommonFunctions.getFormattedDoubleValue(objPaymentInvoice.Amount));
                            strFileContents.Append("\n");
                        }
                    }
                }

                // Footer Summary             
                strFileContents.Append("\n");
                strFileContents.Append("SUMMARY" + "\n");
                strFileContents.Append("Total Cash Invoice" + "\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalCashInvoice).ToString() + "\t\t" +
                    "Total Cash Receipt against Credit Invoice" + "\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalCashReceiptForCreditInvoice).ToString() + "\t\n" +
                    "Less - Cancelled Receipts" + "\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalCancelledInvoices).ToString() + "\t\t" +
                    "Total Cash to Remit" + "\t" + CommonFunctions.getFormattedDoubleValue(objFinalSettlement.TotalCashToRemit).ToString());
                strFileContents.Append("\n\n");

                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportStockMovementReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string searchString = string.Empty;
        searchString = (Session["HieStockMovementReport"] != null) ? Session["HieStockMovementReport"].ToString() : "1=1";
        string SalesTeam = string.Empty;
        SalesTeam = (Session["HieStockMovementReportSalesteam"] != null) ? Session["HieStockMovementReportSalesteam"].ToString() : "";
        IList<MovementHeaderReport> objMovementHeaderReports = new MovementHeaderFacade().GetMovementHeaderSearchOptimizedByUserCode(searchString, CommonFunctions.getStringValue(Request.QueryString["UserCode"]), SalesTeam);
        if (objMovementHeaderReports != null && objMovementHeaderReports.Count > 0)
        {
            strFileContents = new StringBuilder();
            foreach (MovementHeaderReport objMovementHeaderReport in objMovementHeaderReports)
            {
                strFileContents.Append("User Code" + "\t" + "User Name" + "\t" + "Movement Count" + "\n");
                strFileContents.Append(objMovementHeaderReport.UserCode + "\t");
                strFileContents.Append(objMovementHeaderReport.UserName + "\t");
                strFileContents.Append(objMovementHeaderReport.UserCount + "\t");
                strFileContents.Append("\n");
                strFileContents.Append(Environment.NewLine);
                strFileContents.Append("Movement Code " + "\t" + "Type" + "\t" + "Movement Date " + "\t" + "Status");
                strFileContents.Append("\n");
                IList<MovementHeader> objMovementHeaderList = new MovementHeaderFacade().GetMovementHeaderByUserCode(searchString, objMovementHeaderReport.UserCode);
                foreach (MovementHeader objMovementHeader in objMovementHeaderList)
                {
                    strFileContents.Append(objMovementHeader.MovementCode + "\t");
                    strFileContents.Append(bindMomentumType(objMovementHeader.MovementType) + "\t");
                    strFileContents.Append(objMovementHeader.MovementDate.ToShortDateString() + "\t");
                    strFileContents.Append(movementstatus(objMovementHeader.MovementStatus) + "\t");
                    strFileContents.Append("\n");

                }
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(_stFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    public string bindMomentumType(int x)
    {
        if (x == 1)
        {
            return "Load";
        }
        else if (x == 2)
        {
            return "Unload";
        }
        else
        {
            return "Return Unload";
        }
    }
    public string movementstatus(int val)
    {
        if (val == 2)
            return "Pending";
        if (val == 99 || val == 150)
            return "Processed";
        if (val == 100)
            return "Shipped";
        if (val == -13)
            return "Rejected";
        else return "N/A";
    }
    private void ExportTotalSalesGraphDetailsReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            string searchString = string.Empty;
            searchString = "TH.TrxType in(" + Convert.ToInt32(TrxType.Sales_Order) + ")" + " AND TH.TrxStatus in(" + Convert.ToInt32(TrxStatusCode.GRV_Exchange_Collected) + ")";
            string searchStringExp = "";
            string Sdate = DateTime.Now.AddMonths(-1).AddDays(1).ToString("MMM d, yyyy");
            string Edate = DateTime.Now.ToString("dd MMM, yyyy");
            string ttype = "";
            string ss = "";
            string ss1 = "";
            string searchstring1 = "1=1";
            if (Request["StartDate"] != null)
            {
                Sdate = Request["StartDate"].ToString();
            }
            if (Request["EndDate"] != null)
            {
                Edate = Request["EndDate"].ToString();
            }
            if (Request["Ttype"] != null)
            {
                ttype = Request["Ttype"].ToString();
            }
            if (Request["ss"] != null)
            {
                ss = Request["ss"].ToString();
            }
            if (Request["ss1"] != null)
            {
                ss1 = Request["ss1"].ToString();
            }
            if (Request["UserCode"] != null)
            {
            }
            string Salesman = Session["UCCommonFilter"].ToString();
            // searchStringExp = "TH.TrxStatus in(" + Convert.ToInt32(TrxStatusCode.GRV_Exchange_Collected) + ")";
            if (ss != "")
            {
                searchStringExp += (searchStringExp.Length > 0) ? " AND " : "";
                searchStringExp += ss + " AND U.Code in(" + Convert.ToString(Salesman) + ")";
            }

            string SalesPerformanceSalesTeam = "";
            if (System.Web.HttpContext.Current.Session["TotalSalesgrapghSalesTeam"] != null)
                SalesPerformanceSalesTeam = System.Web.HttpContext.Current.Session["TotalSalesgrapghSalesTeam"].ToString();

            StringBuilder strFileContents = new StringBuilder();
            //strFileContents.Append("Search Criteria :" + "\t" + "Date- " + Sdate.Replace(",", " ") + "\t" + "To: " + Edate.Replace(",", " ") + "\n");
            strFileContents.Append("\n");
            if (ttype == "Van")
            {
                Vansale.VanSalesWithTotalAverage vswta = new Vansale.VanSalesWithTotalAverage();
                vswta = VanWiseSales(searchStringExp);
                if (vswta.lstVanSales != null && vswta.lstVanSales.Count > 0)
                {
                    strFileContents.Append("ROUTE WISE SALES" + "\n");
                    strFileContents.Append("Total Finalized Order Value(SAR)" + "\t" + "Total Sales Value(SAR)" + "\n");
                    strFileContents.Append(vswta.TotalVanSales == "" ? "0.00" : CommonFunctions.GetCurrencyFormatWithThousands_New(vswta.TotalVanSales) + "\t" + (vswta.AverageVanSales == "" ? "0.00" : CommonFunctions.GetCurrencyFormatWithThousands_New(vswta.AverageVanSales)) + "\n");
                    strFileContents.Append("\n");
                    strFileContents.Append("Salesman Code" + "\t" + "Salesman Name" + "\t" + "Finalized Order Value(SAR)" + "\t" + "Sales Value(SAR)" + "\n");
                    foreach (Vansale.VanSales vs in vswta.lstVanSales)
                    {
                        strFileContents.Append(vs.VehicleNumber + "\t" + vs.Description.Replace(",", " ") + "\t" + CommonFunctions.GetCurrencyFormatWithThousands_New(vs.TotalSales) + "\t" + CommonFunctions.GetCurrencyFormatWithThousands_New(vs.InvoiceSales) + "\n");
                    }
                }
            }
            if (ttype == "Customer")
            {
                CustomerWiseTotalSalesDetails cwts = new CustomerWiseTotalSalesDetails();
                string HieSalesPerformanceBrandCode = "";
                if (System.Web.HttpContext.Current.Session["HieSalesPerformanceBrandCode"] != null)
                    HieSalesPerformanceBrandCode = System.Web.HttpContext.Current.Session["HieSalesPerformanceBrandCode"].ToString();
                string HieSalesPerformanceRegionCode = "";
                if (System.Web.HttpContext.Current.Session["HieSalesPerformanceRegionCode"] != null)
                    HieSalesPerformanceRegionCode = System.Web.HttpContext.Current.Session["HieSalesPerformanceRegionCode"].ToString();
                string HieSalesPerformanceCustomers = "";
                if (System.Web.HttpContext.Current.Session["HieSalesPerformanceCustomers"] != null)
                    HieSalesPerformanceCustomers = System.Web.HttpContext.Current.Session["HieSalesPerformanceCustomers"].ToString();



                cwts = new ChartReportFacade().GetCustomerWiseSalesForGrid(searchStringExp, searchstring1, SessionManager.UserCode, SalesPerformanceSalesTeam, "", HieSalesPerformanceBrandCode, HieSalesPerformanceRegionCode, HieSalesPerformanceCustomers);
                if (cwts.CustomerWiseTotalSalesList != null && cwts.CustomerWiseTotalSalesList.Count > 0)
                {
                    strFileContents.Append("\n\n");
                    strFileContents.Append("CUSTOMER WISE SALES" + "\n");
                    strFileContents.Append("Total Finalized Order Value(SAR)" + "\t" + "Total Sales Value(SAR)" + "\n");
                    strFileContents.Append(cwts.TotalVanSales.ToString() == "" ? "0.00" : CommonFunctions.GetCurrencyFormatWithThousands_New(cwts.TotalVanSales)
                        + "\t" + (cwts.AverageVanSales.ToString() == "" ? "0.00" : CommonFunctions.GetCurrencyFormatWithThousands_New(cwts.AverageVanSales)) + "\n");
                    strFileContents.Append("\n");
                    strFileContents.Append("CustomerCode & Name" + "\t" + "Finalized Order Value(SAR)" + "\t" + "Sales Value(SAR)" + "\n");
                    foreach (CustomerWiseTotalSales cts in cwts.CustomerWiseTotalSalesList)
                    {
                        strFileContents.Append(" [" + cts.ClientCode + "] " + cts.Description.Replace(",", " ") + "\t" + CommonFunctions.GetCurrencyFormatWithThousands_New(cts.TotalSales) + "\t" + CommonFunctions.GetCurrencyFormatWithThousands_New(cts.InvoiceSales) + "\n");
                    }
                }
            }
            if (ttype == "Day")
            {
                DayWiseTotalSalesDetails awts = new DayWiseTotalSalesDetails();
                string HieSalesPerformanceBrandCode = "";
                if (System.Web.HttpContext.Current.Session["HieSalesPerformanceBrandCode"] != null)
                    HieSalesPerformanceBrandCode = System.Web.HttpContext.Current.Session["HieSalesPerformanceBrandCode"].ToString();
                string HieSalesPerformanceRegionCode = "";
                if (System.Web.HttpContext.Current.Session["HieSalesPerformanceRegionCode"] != null)
                    HieSalesPerformanceRegionCode = System.Web.HttpContext.Current.Session["HieSalesPerformanceRegionCode"].ToString();
                string HieSalesPerformanceCustomers = "";
                if (System.Web.HttpContext.Current.Session["HieSalesPerformanceCustomers"] != null)
                    HieSalesPerformanceCustomers = System.Web.HttpContext.Current.Session["HieSalesPerformanceCustomers"].ToString();
                awts = new ChartReportFacade().GetDayWiseSalesForGrid(searchStringExp, "", searchstring1, SessionManager.UserCode, SalesPerformanceSalesTeam, "", HieSalesPerformanceBrandCode, HieSalesPerformanceRegionCode, HieSalesPerformanceCustomers);
                if (awts.DayWiseTotalSalesDetailsList != null && awts.DayWiseTotalSalesDetailsList.Count > 0)
                {
                    strFileContents.Append("\n\n");
                    strFileContents.Append("DAY WISE SALES" + "\n");
                    strFileContents.Append("Total Finalized Order Value(SAR)" + "\t" + "Total Sales Valu(SAR)e" + "\n");
                    strFileContents.Append(awts.TotalSales.ToString() == "" ? "0.00" : CommonFunctions.GetCurrencyFormatWithThousands_New(awts.TotalSales)
                        + "\t" + (awts.AverageSales.ToString() == "" ? "0.00" : CommonFunctions.GetCurrencyFormatWithThousands_New(awts.AverageSales)) + "\n");
                    strFileContents.Append("\n");
                    strFileContents.Append("Day" + "\t" + "Finalized Order Value(SAR)" + "\t" + "Sales Value(SAR)" + "\n");
                    foreach (DayWiseTotalSales ats in awts.DayWiseTotalSalesDetailsList)
                    {
                        strFileContents.Append(ats.Day.ToShortDateString() + "\t" + CommonFunctions.GetCurrencyFormatWithThousands_New(ats.DaySales) + "\t" + CommonFunctions.GetCurrencyFormatWithThousands_New(ats.InvoiceSales) + "\n");
                    }
                }
            }


            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    public Vansale.VanSalesWithTotalAverage VanWiseSales(string Searchstring1)
    {
        ChartReportFacade objChartReportFacade = new ChartReportFacade();
        DataSet ds = new DataSet();
        string searchString = string.Empty;

        //searchString = "1=1 AND TrxType=" + Convert.ToInt32(TrxType.Sales_Order);

        //if (Searchstring1 != "")
        //{
        //    searchString += (searchString.Length > 0) ? " AND " : "";
        //    searchString += Searchstring1;
        //}

        int Type = 3;

        string HieSalesPerformanceBrandCode = "";
        if (System.Web.HttpContext.Current.Session["HieSalesPerformanceBrandCode"] != null)
            HieSalesPerformanceBrandCode = System.Web.HttpContext.Current.Session["HieSalesPerformanceBrandCode"].ToString();
        string HieSalesPerformanceRegionCode = "";
        if (System.Web.HttpContext.Current.Session["HieSalesPerformanceRegionCode"] != null)
            HieSalesPerformanceRegionCode = System.Web.HttpContext.Current.Session["HieSalesPerformanceRegionCode"].ToString();
        string HieSalesPerformanceCustomers = "";
        if (System.Web.HttpContext.Current.Session["HieSalesPerformanceCustomers"] != null)
            HieSalesPerformanceCustomers = System.Web.HttpContext.Current.Session["HieSalesPerformanceCustomers"].ToString();
        string SalesPerformanceSalesTeam = "";
        if (System.Web.HttpContext.Current.Session["TotalSalesgrapghSalesTeam"] != null)
            SalesPerformanceSalesTeam = System.Web.HttpContext.Current.Session["TotalSalesgrapghSalesTeam"].ToString();
        string SalesPerformanceChannels = "";
        if (System.Web.HttpContext.Current.Session["TotalSalesgrapghChannels"] != null)
            SalesPerformanceChannels = System.Web.HttpContext.Current.Session["TotalSalesgrapghChannels"].ToString();

        ds = objChartReportFacade.GetVanWiseSales(Searchstring1, Type, SessionManager.UserCode, SalesPerformanceSalesTeam, SalesPerformanceChannels, HieSalesPerformanceBrandCode, HieSalesPerformanceRegionCode, HieSalesPerformanceCustomers);

        Vansale.VanSalesWithTotalAverage VanSalesWithTotalAverageObj = new Vansale.VanSalesWithTotalAverage();
        if (ds.Tables[1] != null)
        {
            if (ds.Tables[1].Rows.Count > 0)
            {
                VanSalesWithTotalAverageObj.TotalVanSales = ds.Tables[1].Rows[0]["TotalSales"].ToString();
                VanSalesWithTotalAverageObj.AverageVanSales = ds.Tables[1].Rows[0]["Invoicesales"].ToString();
            }
        }
        foreach (DataRow dr in ds.Tables[0].Rows)
        {
            Vansale.VanSales vs = new Vansale.VanSales();
            vs.Description = dr["Description"].ToString();
            vs.VehicleNumber = dr["UserCode"].ToString();
            vs.TotalSales = Convert.ToString(dr["TotalSales"]);
            vs.InvoiceSales = Convert.ToString(dr["Invoicesales"]);
            VanSalesWithTotalAverageObj.lstVanSales.Add(vs);
        }
        return VanSalesWithTotalAverageObj;
    }


    private void ExportNearExpiryItem(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string searchString = Session["HieNearExpiryItemReport"].ToString();
            IList<NearExpiryItemReport> NearExpiryItems = new ItemFacade().GetNearExpiryItemSearchPaging_KR("Code DESC", 5000, 0, searchString, SessionManager.UserCode, "");
            if (NearExpiryItems != null && NearExpiryItems.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Customer Code" + "\t" + "Item Code " + "\t" + "Item Description" + "\t" + "Quantity" + "\t" + "Expiry Date" + "\t" + "Visited Date" + "\t" + "Brand");
                strFileContents.Append("\n");
                int i = 1;
                foreach (NearExpiryItemReport objNearExpiryItems in NearExpiryItems)
                {
                    strFileContents.Append("[" + objNearExpiryItems.CustomerCode + "]" + objNearExpiryItems.CustomerName + "\t");
                    //strFileContents.Append(objNearExpiryItems.NearExpiryItemList + "\t");
                    foreach (NearExpiryItem objNearExpiryItem in objNearExpiryItems.NearExpiryItemList)
                    {
                        strFileContents.Append(objNearExpiryItem.ItemCode + "\t");
                        strFileContents.Append(objNearExpiryItem.ItemDescription + "\t");
                        strFileContents.Append(objNearExpiryItem.Quantity + "\t");
                        strFileContents.Append(objNearExpiryItem.ExpiryDate.ToString("MMM dd,yyyy") + "\t");
                        strFileContents.Append(objNearExpiryItem.VisitedDate.ToString("MMM dd,yyyy") + "\t");
                        strFileContents.Append(CommonFunctions.getStringNA(objNearExpiryItem.BrandName) + "\t");
                        strFileContents.Append("\n");
                        strFileContents.Append("\t");
                    }
                    strFileContents.Append("\n");
                    i = i + 1;
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    #region [Export To Excel User Log Report]
    private void ExportUserLogReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SortExpression = "UL.ModifiedOn DESC";
            string UserCode = (Session["UserLog_UCode"] != null) ? Session["UserLog_UCode"].ToString() : "1=1";
            string searchString = (Session["UserLog_searchString"] != null) ? Session["UserLog_searchString"].ToString() : "1=1";
            string SalesOrgCodes = (Session["UserLog_SalesOrgCodes"] != null) ? Session["UserLog_SalesOrgCodes"].ToString() : "";
            string Salesmans = (Session["UserLog_Salesmans"] != null) ? Session["UserLog_Salesmans"].ToString() : "1=1";

            int maximumrows = 1000;
            int startrowindex = 0;
            //SearchString = (Session["Export_AuditReport"] != null) ? Session["Export_AuditReport"].ToString() : "1=1";
            UserLogReportList objUserLogReportList = new UserLogReportFacade().GetUserLogSearch(SortExpression, maximumrows, startrowindex, searchString, UserCode, SalesOrgCodes, Salesmans);
            List<UserLogReport> lstUserLogReport = new List<UserLogReport>();
            if (objUserLogReportList != null)
            {
                strFileContents.Append( //"ADID " + "\t" +
                    "Date " + "\t" + "UserCode" + "\t" + " FieldName " + "\t" + " Previous Value " + "\t" + " New Value " + "\t");
                strFileContents.Append("\n");
                foreach (UserLogReport UserLogReport in objUserLogReportList.lstUserLog)
                {
                    //strFileContents.Append(UserLogReport.ADID + "\t");
                    strFileContents.Append(UserLogReport.Date.ToString("MMMM dd,yyyy") + "\t");
                    strFileContents.Append(UserLogReport.UserCode + "\t");
                    strFileContents.Append(UserLogReport.FieldName + "\t");
                    strFileContents.Append(UserLogReport.PreviousValue + "\t");
                    strFileContents.Append(UserLogReport.NewValue + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    #endregion

    #region [Export To Excel Export View User Device LogIn]
    private void ExportViewUserDeviceLogIn(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SortExpression = "UN.UserCode DESC";
            string UserCode = (Session["UserDeviceLogIn_UserCode"] != null) ? Session["UserDeviceLogIn_UserCode"].ToString() : SessionManager.UserCode;
            string searchString = (Session["UserDeviceLogIn_SearchString"] != null) ? Session["UserDeviceLogIn_SearchString"].ToString() : "1=1";

            int maximumRows = 1000;
            int startRowIndex = 0;
            IList<UserDeviceLogInLog> objUserDeviceLogInLogList = new UserDeviceLogInLogFacade().GetUserDeviceLogInLogSearch(SortExpression, searchString, UserCode, maximumRows, startRowIndex);
            if (objUserDeviceLogInLogList != null)
            {
                strFileContents.Append("Salesman" + "\t" + "Mac Address" + "\t" + " Login Time " + "\t" + " Session Id");
                strFileContents.Append("\n");
                foreach (UserDeviceLogInLog UserDeviceLogInLog in objUserDeviceLogInLogList)
                {
                    strFileContents.Append((UserDeviceLogInLog.UserCode == "" ? "" : ("[" + UserDeviceLogInLog.UserCode + "]")) + UserDeviceLogInLog.ADID + "\t");
                    strFileContents.Append("[" + UserDeviceLogInLog.MacAddress.ToString() + "]" + "\t");
                    strFileContents.Append(UserDeviceLogInLog.LoginTime.ToString("dd/MM/yyyy hh:mm tt") + "\t");
                    strFileContents.Append(UserDeviceLogInLog.SessionId + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    #endregion

    private void ExportAuditReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string SortExpression = "AuditDate Desc";
            // string UserCode = "";
            int maximumrows = 1000;
            int startrowindex = 0;
            SearchString = (Session["Export_AuditReport"] != null) ? Session["Export_AuditReport"].ToString() : "1=1";
            IList<Audit> objAuditList = new AuditFacade().GetAuditSearch(SortExpression, maximumrows, startrowindex, SearchString, SessionManager.UserCode);
            if (objAuditList != null && objAuditList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("AuditNumber" + "\t" + "Auditor" + "\t" + "User" + "\t" + "AuditDate" + "\t");
                strFileContents.Append("\n");
                foreach (Audit objobjAudit in objAuditList)
                {
                    strFileContents.Append(objobjAudit.AuditNumber + "\t");
                    strFileContents.Append(objobjAudit.AuditorName + " " + "[" + objobjAudit.AuditorCode + "]" + "\t");
                    strFileContents.Append(objobjAudit.UserName + " " + "[" + objobjAudit.UserCode + "]" + "\t");
                    strFileContents.Append(objobjAudit.AuditDate.ToString("MMMM dd,yyyy") + "\t");
                    strFileContents.Append("\n");
                }
                strFileContents.Append("\n\n");
                sw = System.IO.File.CreateText(_stFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportManageAuditReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SearchString = string.Empty;
            string SortExpression = "AuditDate Desc";
            // string UserCode = "";
            int maximumrows = 1000;
            int startrowindex = 0;
            SearchString = (Session["Export_AuditReport"] != null) ? Session["Export_AuditReport"].ToString() : "1=1";
            IList<Audit> objAuditList = new AuditFacade().GetAuditSearchExport(SortExpression, maximumrows, startrowindex, SearchString, SessionManager.UserCode);
            if (objAuditList != null)
            {
                strFileContents.Append("Date " + "\t" + "Auditor Code" + "\t" + "Auditor Number" + "\t" + "Route Code" + "\t" + "User Code" + "\t"
                     + "User Name" + "\t" + "Item Code" + "\t" + "Item Name" + "\t" + "UOM" + "\t" + "Actual Aduit QTY" + "\t" + "Van Qty" + "\t"
                      + "Variance" + "\t");
                strFileContents.Append("\n");
                foreach (Audit objobjAudit in objAuditList)
                {
                    strFileContents.Append(objobjAudit.AuditDate.ToString("MMMM dd,yyyy") + "\t");
                    strFileContents.Append((objobjAudit.AuditorCode == "" ? "N/A" : objobjAudit.AuditorCode) + "\t");
                    //  strFileContents.Append(objobjAudit.AuditorName + "\t");
                    strFileContents.Append(objobjAudit.AuditNumber + "\t");
                    strFileContents.Append(objobjAudit.RouteCode + "\t");
                    strFileContents.Append(objobjAudit.UserCode + "\t");
                    strFileContents.Append(objobjAudit.UserName + "\t");
                    strFileContents.Append(objobjAudit.ItemCode + "\t");
                    strFileContents.Append(objobjAudit.ItemName + "\t");
                    strFileContents.Append(objobjAudit.UOM + "\t");
                    strFileContents.Append(objobjAudit.ActualQty + "\t");
                    strFileContents.Append(objobjAudit.VanQty + "\t");
                    strFileContents.Append(objobjAudit.ActualQty - objobjAudit.VanQty + "\t");


                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportManageReturnAuditReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SearchString = string.Empty;
            string SortExpression = "AuditDate Desc";
            // string UserCode = "";
            int maximumrows = 1000;
            int startrowindex = 0;
            SearchString = (Session["Export_ReturnAuditReport"] != null) ? Session["Export_ReturnAuditReport"].ToString() : "1=1";
            IList<Audit> objAuditList = new AuditFacade().GetReturnAuditSearchExport(SortExpression, maximumrows, startrowindex, SearchString, SessionManager.UserCode);
            if (objAuditList != null)
            {
                strFileContents.Append("Date " + "\t" + "Auditor Code" + "\t" + "Auditor Number" + "\t" + "Route Code" + "\t" + "User Code" + "\t"
                     + "User Name" + "\t" + "Item Code" + "\t" + "Item Name" + "\t" + "UOM" + "\t" + "Actual Aduit QTY" + "\t" + "Van Qty" + "\t" + "Variance" + "\t");
                strFileContents.Append("\n");
                foreach (Audit objobjAudit in objAuditList)
                {
                    strFileContents.Append(objobjAudit.AuditDate.ToString("MMMM dd,yyyy") + "\t");
                    strFileContents.Append((objobjAudit.AuditorCode == "" ? "N/A" : objobjAudit.AuditorCode) + "\t");
                    //strFileContents.Append(objobjAudit.AuditorName + "\t");
                    strFileContents.Append(objobjAudit.AuditNumber + "\t");
                    strFileContents.Append(objobjAudit.RouteCode + "\t");
                    strFileContents.Append(objobjAudit.UserCode + "\t");
                    strFileContents.Append(objobjAudit.UserName + "\t");
                    strFileContents.Append(objobjAudit.ItemCode + "\t");
                    strFileContents.Append(objobjAudit.ItemName + "\t");
                    strFileContents.Append(objobjAudit.UOM + "\t");
                    strFileContents.Append(objobjAudit.Updated_NonSellableQuantity + "\t");
                    strFileContents.Append(objobjAudit.Actual_NonSellableQuantity + "\t");
                    strFileContents.Append(objobjAudit.Updated_NonSellableQuantity - objobjAudit.Actual_NonSellableQuantity + "\t");


                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportMaintainPromotion(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SearchString = string.Empty;
            string SortExpression = "P.ModifiedDate DESC,P.ModifiedTime DESC";
            // string UserCode = "";
            int maximumrows = 1000;
            int startrowindex = 0;
            SearchString = (Session["MaintainBankReport"] != null) ? Session["MaintainBankReport"].ToString() : "1=1";
            string promotionStatus = (Session["PromotionStatus"] != null) ? Session["PromotionStatus"].ToString() : "1";
            IList<PromotionExport> objPromotionList = new PromotionSCFacade().GetPromotionSearchExport(SortExpression, maximumrows, startrowindex, SearchString, promotionStatus);
            if (objPromotionList != null)
            {
                strFileContents.Append("CUST ID" + "," + "DESCRIPTION" + "," + "FROM" + "," + "TO" + ","
                     + "PROMO DESC" + "," + "ITEM CODE" + "," + "Item Name" + "," + "PROMO TYPE" + "," + "% DISCOUNT" + "," + "STATUS" + ",");
                strFileContents.Append("\n");

                foreach (PromotionExport objPromotion in objPromotionList)
                {
                    strFileContents.Append(objPromotion.CustId + ",");
                    strFileContents.Append(objPromotion.CustName + ",");
                    strFileContents.Append(objPromotion.StartDate.ToString("MMMM dd yyyy") + ",");
                    strFileContents.Append(objPromotion.EndDate.ToString("MMMM dd yyyy") + ",");
                    //strFileContents.Append(objobjAudit.AuditorCode + "\t");
                    //strFileContents.Append(objobjAudit.AuditorName + "\t");
                    strFileContents.Append(objPromotion.Description + ",");
                    strFileContents.Append(objPromotion.ItemCode + ",");
                    strFileContents.Append(objPromotion.ItemName + ",");
                    strFileContents.Append(objPromotion.PromoType + ",");
                    strFileContents.Append(objPromotion.Offered + ",");
                    strFileContents.Append(objPromotion.IsActive + ",");


                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportMaintainRoute(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SearchString = string.Empty;
            string SortExpression = "R.Code";
            // string UserCode = "";
            int maximumrows = 1000;
            int startrowindex = 0;
            SearchString = (Session["RoutesFilter"] != null) ? Session["RoutesFilter"].ToString() : "1=1";
            IList<Route> objPromotionList = GetRoutes(SortExpression, maximumrows, startrowindex, SearchString);
            if (objPromotionList != null)
            {


                strFileContents.Append("Sales org" + "\t" + "RegionCode/Name" + "\t" + "City Code/Name" + "\t" + "RouteCode/Name" + "\t"
                     + "Warehouse code/Name" + "\t" + "Supervisor code/Name" + "\t" + "Salesman code/Name" + "\t" + "Loading days" +
                     "\t" + "Stock audit days" + "\t" + "Cashier days" + "\t" + "Route Type" + "\t" + "Route Category" + "\t");
                strFileContents.Append("\n");

                foreach (Route objPromotion in objPromotionList)
                {
                    strFileContents.Append("[" + objPromotion.SalesOrgCode + "] " + objPromotion.SalesOrgName + "\t");
                    strFileContents.Append("[" + objPromotion.AreaCode + "] " + objPromotion.AreaName + "\t");
                    strFileContents.Append("[" + objPromotion.SubAreaCode + "] " + objPromotion.SubAreaName + "\t");
                    strFileContents.Append("[" + objPromotion.Code + "] " + objPromotion.Name + "\t");
                    strFileContents.Append(objPromotion.WHCode + "\t");
                    strFileContents.Append("[" + objPromotion.SupervisorCode + "] " + objPromotion.SupervisorName + "\t");
                    strFileContents.Append(objPromotion.SalesmanName + "\t");
                    strFileContents.Append(objPromotion.LoadingDays + "\t");
                    strFileContents.Append(objPromotion.Attribute1 + "\t");
                    strFileContents.Append(objPromotion.Attribute2 + "\t");
                    strFileContents.Append(objPromotion.RouteType + "\t");
                    strFileContents.Append(objPromotion.RouteCategory + "\t");



                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportOrderAdjustment(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string strMessage = "";
            //gvMovement.HeaderRow.Cells[6].Text = DateTime.Now.AddDays(1).ToString("yyyy/MM/dd");
            //gvMovement.HeaderRow.Cells[7].Text = DateTime.Now.AddDays(2).ToString("yyyy/MM/dd");
            //gvMovement.HeaderRow.Cells[8].Text = DateTime.Now.AddDays(3).ToString("yyyy/MM/dd");
            //gvMovement.HeaderRow.Cells[9].Text = DateTime.Now.AddDays(4).ToString("yyyy/MM/dd");
            //gvMovement.HeaderRow.Cells[10].Text = DateTime.Now.AddDays(5).ToString("yyyy/MM/dd");
            //gvMovement.HeaderRow.Cells[11].Text = DateTime.Now.AddDays(6).ToString("yyyy/MM/dd");
            //gvMovement.HeaderRow.Cells[12].Text = DateTime.Now.AddDays(7).ToString("yyyy/MM/dd");
            IList<OrderAdjustment> orderAdjustments = GetOrderAdjustmenySearch("", 0, 0, "", "admin", Session["OA_ItemCode"].ToString(),
            Session["OA_RouteCode"].ToString(), Convert.ToDateTime(Session["OA_StartDate"]), Session["OA_RegionCode"].ToString(), Session["OA_Org"].ToString(), Session["OA_ASM"].ToString(), Session["OA_Sup"].ToString(), Session["OA_Category"].ToString(),
            out strMessage);
            if (strMessage == "")
            {
                if (orderAdjustments != null)
                {
                    strFileContents.Append("Supervisor" + "\t" + "Route No" + "\t" + "Product Category" + "\t" + "SKU Code" + "\t"
                                         + "SKU Description" + "\t" + "UOM" + "\t" + DateTime.Now.AddDays(1).ToString("yyyy/MM/dd") + "\t" + DateTime.Now.AddDays(2).ToString("yyyy/MM/dd") +
                                         "\t" + DateTime.Now.AddDays(3).ToString("yyyy/MM/dd") + "\t" + DateTime.Now.AddDays(4).ToString("yyyy/MM/dd") + "\t" + DateTime.Now.AddDays(5).ToString("yyyy/MM/dd") + "\t" + DateTime.Now.AddDays(6).ToString("yyyy/MM/dd") + "\t" + DateTime.Now.AddDays(7).ToString("yyyy/MM/dd") + "\t" + "Day Sale Qty BS/BX" + "\t" + "Day Sale Net Val" + "\t" + "Wstg%" + "\t" + "MTD Sale Net Val" + "\t" + "MTD Tgt Net Val" + "\t" + "Var" + "\t" + "MTD Sale Qty BS/BX" + "\t" + "MTD Tgt Qty BS/BX" + "\t" + "Var" + "\t" + "MTD Wstg%" + "\t" + "ClosingStock BS/BX" + "\t" + "Pre ClosingStock BS/BX" + "\t");
                    strFileContents.Append("\n");

                    foreach (OrderAdjustment objOrderAdjustment in orderAdjustments)
                    {

                        strFileContents.Append(objOrderAdjustment.SupervisorCodeName + "\t");
                        strFileContents.Append(objOrderAdjustment.RouteNo + "\t");
                        strFileContents.Append(objOrderAdjustment.CategoryName + "\t");
                        strFileContents.Append(objOrderAdjustment.SkuDescription + "\t");
                        strFileContents.Append(objOrderAdjustment.SkuDescriptionFull + "\t");
                        strFileContents.Append(objOrderAdjustment.UOM + "\t");
                        strFileContents.Append(objOrderAdjustment.Day1 + "\t");
                        strFileContents.Append(objOrderAdjustment.Day2 + "\t");
                        strFileContents.Append(objOrderAdjustment.Day3 + "\t");
                        strFileContents.Append(objOrderAdjustment.Day4 + "\t");
                        strFileContents.Append(objOrderAdjustment.Day5 + "\t");
                        strFileContents.Append(objOrderAdjustment.Day6 + "\t");
                        strFileContents.Append(objOrderAdjustment.Day7 + "\t");
                        strFileContents.Append(objOrderAdjustment.SalesForTheDayInBasketCases + "\t");
                        strFileContents.Append(objOrderAdjustment.NetSalesForTheDayInSR + "\t");
                        strFileContents.Append(objOrderAdjustment.WastagePercentage + "\t");
                        strFileContents.Append(objOrderAdjustment.NetSalesMTDInSR + "\t");
                        strFileContents.Append(objOrderAdjustment.MTDTargetSalesSR + "\t");
                        strFileContents.Append(objOrderAdjustment.Varience + "\t");
                        strFileContents.Append(objOrderAdjustment.NetSalesMTDInBC + "\t");
                        strFileContents.Append(objOrderAdjustment.TargetSalesMTDInBC + "\t");
                        strFileContents.Append(objOrderAdjustment.VarienceMTD + "\t");
                        strFileContents.Append(objOrderAdjustment.MTDWastagePercentage + "\t");
                        strFileContents.Append(objOrderAdjustment.ClosingStockTodayInBaskets + "\t");
                        strFileContents.Append(objOrderAdjustment.ClosingStockPreviousInBaskets + "\t");



                        strFileContents.Append("\n");
                    }
                }
            }
            else
            {
                strFileContents.Append("Error Message" + "\t");
                strFileContents.Append("\n");
                strFileContents.Append(strMessage + "\t");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    public class OrderAdjustment
    {
        public OrderAdjustment()
        {

        }
        public string Region { get; set; }
        public string Depot { get; set; }
        public string DepotName { get; set; }
        public string RouteNo { get; set; }
        public string ProductCategory { get; set; }
        public string SkuDescription { get; set; }
        public string SkuDescriptionFull { get; set; }
        public string SalesForTheDayInBasketCases { get; set; }
        public string NetSalesForTheDayInSR { get; set; }
        public string WastagePercentage { get; set; }
        public string NetSalesMTDInSR { get; set; }
        public string MTDTargetSalesSR { get; set; }
        public string Varience { get; set; }
        public string NetSalesMTDInBC { get; set; }
        public string TargetSalesMTDInBC { get; set; }
        public string VarienceMTD { get; set; }
        public string MTDWastagePercentage { get; set; }
        public string ClosingStockTodayInBaskets { get; set; }
        public string ClosingStockPreviousInBaskets { get; set; }
        public string Rolling7DaysWastagePercentage { get; set; }
        public string SystemForecastInBC { get; set; }
        public string BalanceRequiredTATIBCBD { get; set; }
        public string Previous3MonthADTIC { get; set; }
        public string Day1MovementCode { get; set; }
        public string Day2MovementCode { get; set; }
        public string Day3MovementCode { get; set; }
        public string Day4MovementCode { get; set; }
        public string Day5MovementCode { get; set; }
        public string Day6MovementCode { get; set; }
        public string Day7MovementCode { get; set; }
        public string UOM { get; set; }
        public string Day1 { get; set; }
        public string Day2 { get; set; }
        public string Day3 { get; set; }
        public string Day4 { get; set; }
        public string Day5 { get; set; }
        public string Day6 { get; set; }
        public string Day7 { get; set; }
        public string TotalBasketPerCase { get; set; }
        public string Rolling7DaysOrderInSR { get; set; }
        public string ProjectedSalesMTDinBasketsCases { get; set; }
        public string ProjectedSalesMTDinSR { get; set; }
        public string VarProjected { get; set; }
        public string TargetInSRMTD { get; set; }
        public string VarFinal { get; set; }
        public string Supervisor { get; set; }
        public string SupervisorName { get; set; }
        public string SupervisorCodeName { get; set; }
        public string CategoryName { get; set; }
        public string RegionName { get; set; }
        public string IsAllowEditDay1 { get; set; }
        public string IsAllowEditDay2 { get; set; }
        public string IsAllowEditDay3 { get; set; }
        public string IsAllowEditDay4 { get; set; }
        public string IsAllowEditDay5 { get; set; }
        public string IsAllowEditDay6 { get; set; }
        public string IsAllowEditDay7 { get; set; }

        public string Day1MovementDate { get; set; }
        public string Day2MovementDate { get; set; }
        public string Day3MovementDate { get; set; }
        public string Day4MovementDate { get; set; }
        public string Day5MovementDate { get; set; }
        public string Day6MovementDate { get; set; }
        public string Day7MovementDate { get; set; }
        public string Day1DeliveryDate { get; set; }
        public string Day2DeliveryDate { get; set; }
        public string Day3DeliveryDate { get; set; }
        public string Day4DeliveryDate { get; set; }
        public string Day5DeliveryDate { get; set; }
        public string Day6DeliveryDate { get; set; }
        public string Day7DeliveryDate { get; set; }
    }
    public IList<OrderAdjustment> GetOrderAdjustmenySearch(string SortExpression, int maximumRows, int startRowIndex, string searchString, string UserCode, string ItemCode,
        string RouteCode, DateTime Date, string RegionCode, string Org, string ASM, string Supervisor, string Category, out string strMessage)
    {
        strMessage = "";
        IList<OrderAdjustment> objMovementHeaders = new List<OrderAdjustment>();
        try
        {
            DbParam[] param = new DbParam[9];
            DataSet ds;

            param[0] = new DbParam("@UserCode", UserCode, SqlDbType.VarChar);
            param[1] = new DbParam("@ItemCode", ItemCode, SqlDbType.VarChar);
            param[2] = new DbParam("@RouteCode", RouteCode, SqlDbType.VarChar);
            param[3] = new DbParam("@Date", Date, SqlDbType.DateTime);
            param[4] = new DbParam("@RegionCode", RegionCode, SqlDbType.VarChar);
            param[5] = new DbParam("@Org", Org, SqlDbType.VarChar);
            param[6] = new DbParam("@ASM", ASM, SqlDbType.VarChar);
            param[7] = new DbParam("@Supervisor", Supervisor, SqlDbType.VarChar);
            param[8] = new DbParam("@Category", Category, SqlDbType.VarChar);

            ds = Db.GetDataSet("sp_OrderAdjustment_SELALL_Search_New", param);
            //ds = Db.GetDataSet("sp_OrderAdjustment_SELALL_Search_New_01042022", param);
            OrderAdjustment objMovementHeader = null;
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                objMovementHeader = GetOrderAdjustmentrObject(dr);
                objMovementHeaders.Add(objMovementHeader);
            }
            foreach (DataRow dr in ds.Tables[1].Rows)
            {
                if (dr.Table.Columns.Contains("strMessage"))
                {
                    strMessage = Db.ToString(dr["strMessage"]);
                }

            }
        }
        catch (Exception ex)
        {
            WINIT.ErrorLog.ErrorLogger.GetInstance().Log(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
        return objMovementHeaders;
    }
    public OrderAdjustment GetOrderAdjustmentrObject(DataRow dr)
    {
        OrderAdjustment objMovementHeader = new OrderAdjustment();
        if (dr.Table.Columns.Contains("Region")) objMovementHeader.Region = Db.ToString(dr["Region"]);
        if (dr.Table.Columns.Contains("RegionName")) objMovementHeader.RegionName = Db.ToString(dr["RegionName"]);
        if (dr.Table.Columns.Contains("Depot")) objMovementHeader.Depot = Db.ToString(dr["Depot"]);
        if (dr.Table.Columns.Contains("DepotName")) objMovementHeader.DepotName = Db.ToString(dr["DepotName"]);
        if (dr.Table.Columns.Contains("Supervisor")) objMovementHeader.Supervisor = Db.ToString(dr["Supervisor"]);
        if (dr.Table.Columns.Contains("SupervisorName")) objMovementHeader.SupervisorName = Db.ToString(dr["SupervisorName"]);
        if (dr.Table.Columns.Contains("SupervisorCodeName")) objMovementHeader.SupervisorCodeName = Db.ToString(dr["SupervisorCodeName"]);
        if (dr.Table.Columns.Contains("RouteNo")) objMovementHeader.RouteNo = Db.ToString(dr["RouteNo"]);
        if (dr.Table.Columns.Contains("ProductCategory")) objMovementHeader.ProductCategory = Db.ToString(dr["ProductCategory"]);
        if (dr.Table.Columns.Contains("CategoryName")) objMovementHeader.CategoryName = Db.ToString(dr["CategoryName"]);
        if (dr.Table.Columns.Contains("SkuDescription")) objMovementHeader.SkuDescription = Db.ToString(dr["SkuDescription"]);
        if (dr.Table.Columns.Contains("SkuDescriptionFull")) objMovementHeader.SkuDescriptionFull = Db.ToString(dr["SkuDescriptionFull"]);
        if (dr.Table.Columns.Contains("Day1MovementCode")) objMovementHeader.Day1MovementCode = Db.ToString(dr["Day1MovementCode"]);
        if (dr.Table.Columns.Contains("Day2MovementCode")) objMovementHeader.Day2MovementCode = Db.ToString(dr["Day2MovementCode"]);
        if (dr.Table.Columns.Contains("Day3MovementCode")) objMovementHeader.Day3MovementCode = Db.ToString(dr["Day3MovementCode"]);
        if (dr.Table.Columns.Contains("Day4MovementCode")) objMovementHeader.Day4MovementCode = Db.ToString(dr["Day4MovementCode"]);
        if (dr.Table.Columns.Contains("Day5MovementCode")) objMovementHeader.Day5MovementCode = Db.ToString(dr["Day5MovementCode"]);
        if (dr.Table.Columns.Contains("Day6MovementCode")) objMovementHeader.Day6MovementCode = Db.ToString(dr["Day6MovementCode"]);
        if (dr.Table.Columns.Contains("Day7MovementCode")) objMovementHeader.Day7MovementCode = Db.ToString(dr["Day7MovementCode"]);
        if (dr.Table.Columns.Contains("UOM")) objMovementHeader.UOM = Db.ToString(dr["UOM"]);
        if (dr.Table.Columns.Contains("SalesForTheDayInBasketCases")) objMovementHeader.SalesForTheDayInBasketCases = Db.ToString(dr["SalesForTheDayInBasketCases"]);
        if (dr.Table.Columns.Contains("NetSalesForTheDayInSR")) objMovementHeader.NetSalesForTheDayInSR = Db.ToString(dr["NetSalesForTheDayInSR"]);
        if (dr.Table.Columns.Contains("WastagePercentage")) objMovementHeader.WastagePercentage = Db.ToString(dr["WastagePercentage"]);
        if (dr.Table.Columns.Contains("NetSalesMTDInSR")) objMovementHeader.NetSalesMTDInSR = Db.ToString(dr["NetSalesMTDInSR"]);
        if (dr.Table.Columns.Contains("MTDTargetSalesSR")) objMovementHeader.MTDTargetSalesSR = Db.ToString(dr["MTDTargetSalesSR"]);
        if (dr.Table.Columns.Contains("Varience")) objMovementHeader.Varience = Db.ToString(dr["Varience"]);
        if (dr.Table.Columns.Contains("NetSalesMTDInBC")) objMovementHeader.NetSalesMTDInBC = Db.ToString(dr["NetSalesMTDInBC"]);
        if (dr.Table.Columns.Contains("TargetSalesMTDInBC")) objMovementHeader.TargetSalesMTDInBC = Db.ToString(dr["TargetSalesMTDInBC"]);
        if (dr.Table.Columns.Contains("VarienceMTD")) objMovementHeader.VarienceMTD = Db.ToString(dr["VarienceMTD"]);
        if (dr.Table.Columns.Contains("MTDWastagePercentage")) objMovementHeader.MTDWastagePercentage = Db.ToString(dr["MTDWastagePercentage"]);
        if (dr.Table.Columns.Contains("ClosingStockTodayInBaskets")) objMovementHeader.ClosingStockTodayInBaskets = Db.ToString(dr["ClosingStockTodayInBaskets"]);
        if (dr.Table.Columns.Contains("Rolling7DaysWastagePercentage")) objMovementHeader.Rolling7DaysWastagePercentage = Db.ToString(dr["Rolling7DaysWastagePercentage"]);
        if (dr.Table.Columns.Contains("SystemForecastInBC")) objMovementHeader.SystemForecastInBC = Db.ToString(dr["SystemForecastInBC"]);
        if (dr.Table.Columns.Contains("BalanceRequiredTATIBCBD")) objMovementHeader.BalanceRequiredTATIBCBD = Db.ToString(dr["BalanceRequiredTATIBCBD"]);
        if (dr.Table.Columns.Contains("Previous3MonthADTIC")) objMovementHeader.Previous3MonthADTIC = Db.ToString(dr["Previous3MonthADTIC"]);
        if (dr.Table.Columns.Contains("Day1")) objMovementHeader.Day1 = Db.ToString(dr["Day1"]);
        if (dr.Table.Columns.Contains("Day2")) objMovementHeader.Day2 = Db.ToString(dr["Day2"]);
        if (dr.Table.Columns.Contains("Day3")) objMovementHeader.Day3 = Db.ToString(dr["Day3"]);
        if (dr.Table.Columns.Contains("Day4")) objMovementHeader.Day4 = Db.ToString(dr["Day4"]);
        if (dr.Table.Columns.Contains("Day5")) objMovementHeader.Day5 = Db.ToString(dr["Day5"]);
        if (dr.Table.Columns.Contains("Day6")) objMovementHeader.Day6 = Db.ToString(dr["Day6"]);
        if (dr.Table.Columns.Contains("Day7")) objMovementHeader.Day7 = Db.ToString(dr["Day7"]);
        if (dr.Table.Columns.Contains("TotalBasketPerCase")) objMovementHeader.TotalBasketPerCase = Db.ToString(dr["TotalBasketPerCase"]);
        if (dr.Table.Columns.Contains("Rolling7DaysOrderInSR")) objMovementHeader.Rolling7DaysOrderInSR = Db.ToString(dr["Rolling7DaysOrderInSR"]);
        if (dr.Table.Columns.Contains("ProjectedSalesMTDinBasketsCases")) objMovementHeader.ProjectedSalesMTDinBasketsCases = Db.ToString(dr["ProjectedSalesMTDinBasketsCases"]);
        if (dr.Table.Columns.Contains("ProjectedSalesMTDinSR")) objMovementHeader.ProjectedSalesMTDinSR = Db.ToString(dr["ProjectedSalesMTDinSR"]);
        if (dr.Table.Columns.Contains("VarProjected")) objMovementHeader.VarProjected = Db.ToString(dr["VarProjected"]);
        if (dr.Table.Columns.Contains("TargetInSRMTD")) objMovementHeader.TargetInSRMTD = Db.ToString(dr["TargetInSRMTD"]);
        if (dr.Table.Columns.Contains("VarFinal")) objMovementHeader.VarFinal = Db.ToString(dr["VarFinal"]);

        if (dr.Table.Columns.Contains("IsAllowEditDay1")) objMovementHeader.IsAllowEditDay1 = Db.ToString(dr["IsAllowEditDay1"]);
        if (dr.Table.Columns.Contains("IsAllowEditDay2")) objMovementHeader.IsAllowEditDay2 = Db.ToString(dr["IsAllowEditDay2"]);
        if (dr.Table.Columns.Contains("IsAllowEditDay3")) objMovementHeader.IsAllowEditDay3 = Db.ToString(dr["IsAllowEditDay3"]);
        if (dr.Table.Columns.Contains("IsAllowEditDay4")) objMovementHeader.IsAllowEditDay4 = Db.ToString(dr["IsAllowEditDay4"]);
        if (dr.Table.Columns.Contains("IsAllowEditDay5")) objMovementHeader.IsAllowEditDay5 = Db.ToString(dr["IsAllowEditDay5"]);
        if (dr.Table.Columns.Contains("IsAllowEditDay6")) objMovementHeader.IsAllowEditDay6 = Db.ToString(dr["IsAllowEditDay6"]);
        if (dr.Table.Columns.Contains("IsAllowEditDay7")) objMovementHeader.IsAllowEditDay7 = Db.ToString(dr["IsAllowEditDay7"]);

        if (dr.Table.Columns.Contains("Day1MovementDate")) objMovementHeader.Day1MovementDate = Db.ToString(dr["Day1MovementDate"]);
        if (dr.Table.Columns.Contains("Day2MovementDate")) objMovementHeader.Day2MovementDate = Db.ToString(dr["Day2MovementDate"]);
        if (dr.Table.Columns.Contains("Day3MovementDate")) objMovementHeader.Day3MovementDate = Db.ToString(dr["Day3MovementDate"]);
        if (dr.Table.Columns.Contains("Day4MovementDate")) objMovementHeader.Day4MovementDate = Db.ToString(dr["Day4MovementDate"]);
        if (dr.Table.Columns.Contains("Day5MovementDate")) objMovementHeader.Day5MovementDate = Db.ToString(dr["Day5MovementDate"]);
        if (dr.Table.Columns.Contains("Day6MovementDate")) objMovementHeader.Day6MovementDate = Db.ToString(dr["Day6MovementDate"]);
        if (dr.Table.Columns.Contains("Day7MovementDate")) objMovementHeader.Day7MovementDate = Db.ToString(dr["Day7MovementDate"]);

        if (dr.Table.Columns.Contains("Day1DeliveryDate")) objMovementHeader.Day1DeliveryDate = Db.ToString(dr["Day1DeliveryDate"]);
        if (dr.Table.Columns.Contains("Day2DeliveryDate")) objMovementHeader.Day2DeliveryDate = Db.ToString(dr["Day2DeliveryDate"]);
        if (dr.Table.Columns.Contains("Day3DeliveryDate")) objMovementHeader.Day3DeliveryDate = Db.ToString(dr["Day3DeliveryDate"]);
        if (dr.Table.Columns.Contains("Day4DeliveryDate")) objMovementHeader.Day4DeliveryDate = Db.ToString(dr["Day4DeliveryDate"]);
        if (dr.Table.Columns.Contains("Day5DeliveryDate")) objMovementHeader.Day5DeliveryDate = Db.ToString(dr["Day5DeliveryDate"]);
        if (dr.Table.Columns.Contains("Day6DeliveryDate")) objMovementHeader.Day6DeliveryDate = Db.ToString(dr["Day6DeliveryDate"]);
        if (dr.Table.Columns.Contains("Day7DeliveryDate")) objMovementHeader.Day7DeliveryDate = Db.ToString(dr["Day7DeliveryDate"]);
        if (dr.Table.Columns.Contains("ClosingStockPreviousInBaskets")) objMovementHeader.ClosingStockPreviousInBaskets = Db.ToString(dr["ClosingStockPreviousInBaskets"]);

        return objMovementHeader;
    }
    private void ExportHieOrderFulfillmentReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;

            string SearchString = string.Empty;
            string SortExpression = "MovementDate Desc";
            // string UserCode = "";
            int maximumrows = 100;
            int startrowindex = 0;
            SearchString = (Session["OrderFulfillmentReport"] != null) ? Session["OrderFulfillmentReport"].ToString() : "1=1";
            IList<MovementHeaderReport> objMovementHeaderList = new MovementHeaderFacade().GetMovementHeaderSearchFulFill(SortExpression, maximumrows, startrowindex, SearchString, SessionManager.UserCode, SessionManager.SalesOrgCode);

            if (objMovementHeaderList != null && objMovementHeaderList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Movement Date" + "\t" + " Avg Fulfill Percent" + "\t");
                strFileContents.Append("Salesman" + "\t" + "Requested Quantity" + "\t" + "Shipped Quantity" + "\t" + "Fulfill Percent" + "\t");
                strFileContents.Append("\n");
                foreach (MovementHeaderReport objMovementHeaderReport in objMovementHeaderList)
                {
                    int count = 0;
                    foreach (MovementHeader objMovementHeader in objMovementHeaderReport.MovementHeaderList)
                    {
                        if (count == 0)
                        {
                            strFileContents.Append(objMovementHeaderReport.MovementDate.ToString("MMMM dd,yyyy") + "\t");
                            strFileContents.Append(objMovementHeaderReport.FulfillPercent + "\t");
                            count++;
                        }
                        else
                        {
                            strFileContents.Append("\t");
                            strFileContents.Append("\t");
                        }
                        strFileContents.Append(objMovementHeader.UserName + " " + "[" + objMovementHeader.UserCode + "]" + "\t");
                        strFileContents.Append(objMovementHeader.RequestedQuantity + "\t");
                        strFileContents.Append(objMovementHeader.ShippedQuantity + "\t");
                        strFileContents.Append(objMovementHeader.FulfillPercent + "\t");
                        strFileContents.Append("\n");
                    }
                    // strFileContents.Append("\n");
                    strFileContents.Append(Environment.NewLine);
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportActualAndTarget(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string ActualAndTarget_SearchString = (Session["ActualAndTarget_SearchString"] != null) ? CommonFunctions.getStringValue(Session["ActualAndTarget_SearchString"]) : "1=1";
            string ActualAndTarget_Year = (Session["ActualAndTarget_Year"] != null) ? CommonFunctions.getStringValue(Session["ActualAndTarget_Year"]) : DateTime.Now.Year.ToString();
            string ActualAndTarget_Month = (Session["ActualAndTarget_Month"] != null) ? CommonFunctions.getStringValue(Session["ActualAndTarget_Month"]) : DateTime.Now.Year.ToString();
            string ActualAndTarget_UserCode = Session["ActualTagetUserCode"].ToString();
            string ActualAndTarget_Brands = (Session["ActualAndTarget_Brands"] != null) ? CommonFunctions.getStringValue(Session["ActualAndTarget_Brands"]) : "";
            string ActualAndTarget_Regions = (Session["ActualAndTarget_Regions"] != null) ? CommonFunctions.getStringValue(Session["ActualAndTarget_Regions"]) : "";

            ActualTargetReport objActualTargetlst = (new ActualTargetFacade().GetActualTarget("AchievedAmount DESC", "1=1", ActualAndTarget_Year, ActualAndTarget_Month, 500000, 0, SessionManager.UserCode, SessionManager.SalesOrgCode, ActualAndTarget_UserCode, ActualAndTarget_SearchString, ActualAndTarget_Brands, ActualAndTarget_Regions));
            if (objActualTargetlst != null)
            {
                strFileContents.Append("Salesman Code" + "\t" + "Salesman Name" + "\t" + "Target Amount" + "\t" +
                 "Achieved Amount" + "\t" + "Percentage (%)"
                 + "\n");
                foreach (ActualTarget objItem in objActualTargetlst.objActualTargetList)
                {
                    strFileContents.Append(objItem.SALESMANCODE + "\t");
                    strFileContents.Append(objItem.USERNAME + "[" + objItem.USERID + "]" + "\t");
                    strFileContents.Append(objItem.TargetAmount + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands(objItem.AchievedAmount) + "\t");
                    strFileContents.Append(objItem.Percentage + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportActualAndBudget(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string ActualAndBudget_SearchString = (Session["ActualAndBudget_SearchString"] != null) ? CommonFunctions.getStringValue(Session["ActualAndBudget_SearchString"]) : "1=1";
            string ActualAndBudget_Year = (Session["ActualAndBudget_Year"] != null) ? CommonFunctions.getStringValue(Session["ActualAndBudget_Year"]) : DateTime.Now.Year.ToString();
            string ActualAndBudget_Month = (Session["ActualAndBudget_Month"] != null) ? CommonFunctions.getStringValue(Session["ActualAndBudget_Month"]) : DateTime.Now.Year.ToString();
            string ActualAndBudget_UserCode = Session["ActualTagetUserCode"].ToString();
            string ActualAndBudget_Brands = (Session["ActualAndBudget_Brands"] != null) ? CommonFunctions.getStringValue(Session["ActualAndBudget_Brands"]) : "";
            string ActualAndBudget_Regions = (Session["ActualAndBudget_Regions"] != null) ? CommonFunctions.getStringValue(Session["ActualAndBudget_Regions"]) : "";
            ActualTargetReport objActualTargetlst = (new ActualTargetFacade().GetActualBudget("AchievedAmount DESC", "1=1", ActualAndBudget_Year, ActualAndBudget_Month, 1000000, 0, SessionManager.UserCode, SessionManager.SalesOrgCode, ActualAndBudget_UserCode, ActualAndBudget_SearchString, ActualAndBudget_Brands, ActualAndBudget_Regions));
            if (objActualTargetlst != null)
            {
                strFileContents.Append("Salesman Code" + "\t" + "Salesman Name" + "\t" + "Target Amount" + "\t" +
                 "Achieved Amount" + "\t" + "Percentage (%)"
                 + "\n");
                foreach (ActualTarget objItem in objActualTargetlst.objActualTargetList)
                {
                    strFileContents.Append(objItem.SALESMANCODE + "\t");
                    strFileContents.Append(objItem.USERNAME + "[" + objItem.USERID + "]" + "\t");
                    strFileContents.Append(objItem.TargetAmount + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands(objItem.AchievedAmount) + "\t");
                    strFileContents.Append(objItem.Percentage + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportAdherenceReportJourneyPlan(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {

            StringBuilder strFileContents = new StringBuilder();
            string SortExpression = "UserCode DESC", SelectedUserCode = "", SearchString = "1=1", UserCode = "", SalesOrganizations = "", Regions = "", ASMs = "", Supervisors = "", Routes = "", StartDate = "", EndDate = "";
            int TrxType = 0;
            int MaximumRows = 99999, StartRowIndex = 0;
            if (Session["UCCommonFilter_SelectedUserCode"] != null)
            {
                SelectedUserCode = Session["UCCommonFilter_SelectedUserCode"].ToString();
            }
            if (SessionManager.UserCode != null)
            {
                UserCode = SessionManager.UserCode.ToString();
            }
            if (Session["UCCommonFilter_TrxType"] != null)
            {
                TrxType = Convert.ToInt32(Session["UCCommonFilter_TrxType"].ToString());
            }
            if (Session["UCCommonFilter_SalesOrganization"] != null)
            {
                SalesOrganizations = Session["UCCommonFilter_SalesOrganization"].ToString();
            }
            if (Session["UCCommonFilter_Region"] != null)
            {
                Regions = Session["UCCommonFilter_Region"].ToString();
            }
            if (Session["UCCommonFilter_ASM"] != null)
            {
                ASMs = Session["UCCommonFilter_ASM"].ToString();
            }
            if (Session["UCCommonFilter_Supervisor"] != null)
            {
                Supervisors = Session["UCCommonFilter_Supervisor"].ToString();
            }
            if (Session["UCCommonFilter_Route"] != null)
            {
                Routes = Session["UCCommonFilter_Route"].ToString();
            }
            if (Session["UCCommonFilter_StartDate"] != null)
            {
                StartDate = Session["UCCommonFilter_StartDate"].ToString();
            }
            if (Session["UCCommonFilter_EndDate"] != null)
            {
                EndDate = Session["UCCommonFilter_EndDate"].ToString();
            }
            List<MarketReturnsUsers> objMarketReturnsUserslst = (new ReportsFacade().GetJPAdherenceReport_Paging(SortExpression, SearchString, SelectedUserCode, SalesOrganizations, Regions, ASMs, Supervisors, Routes, StartDate, EndDate, UserCode, MaximumRows, StartRowIndex));
            if (objMarketReturnsUserslst != null && objMarketReturnsUserslst.Count > 0)
            {
                strFileContents.Append("UserCode" + "\t" + "UserName" + "\t" + "Scheduled" + "\t" + "Visited" + "\t" +
                 "Assigned" + "\t" + "UnAssigned " + "\t" + "Adherence" + "\n");
                foreach (MarketReturnsUsers objMarketReturnsUsers in objMarketReturnsUserslst)
                {

                    strFileContents.Append(objMarketReturnsUsers.UserCode + "\t");
                    strFileContents.Append(objMarketReturnsUsers.UserName + "\t");
                    strFileContents.Append(objMarketReturnsUsers.SellableQuantity + "\t");
                    strFileContents.Append(objMarketReturnsUsers.Visited + "\t");
                    strFileContents.Append(objMarketReturnsUsers.Assigned + "\t");
                    strFileContents.Append(objMarketReturnsUsers.UnAssigned + "\t");
                    strFileContents.Append(objMarketReturnsUsers.Percentage + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }

        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportCustomerGeoCodeReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;
        //string UserCode1= Session["CustomerGeoCodeUserCode"].ToString()!=null?Session["CustomerGeoCodeUserCode"].ToString():SessionManager.UserCode;
        SearchString = (Session["CustomerGeoCodeReports"] != null) ? Session["CustomerGeoCodeReports"].ToString() : "1=1";
        // IList<Customer> objCustomer = new CustomerFacade().GetCustomerGeoCodeReportExport(SearchString);
        IList<Customer> objCustomer = new CustomerFacade().GetCustomerGeoCodeSearch("C.Code ASC", 1000000, 0, SearchString, SessionManager.UserCode, "");
        if (objCustomer != null && objCustomer.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Site No" + "\t" + "Customer Name" + "\t" + "Sales Organization " + "\t" + "Latitude " + "\t" + "Longitude ");
            strFileContents.Append("\n");
            foreach (Customer obCustomer in objCustomer)
            {
                strFileContents.Append(obCustomer.Site + "\t");
                strFileContents.Append(obCustomer.CustomerName + "\t");
                strFileContents.Append(obCustomer.SalesOrgCode + "\t");
                strFileContents.Append(obCustomer.GEO_CODE_X + "\t");
                strFileContents.Append(obCustomer.GEO_CODE_Y + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportCustomersWithoutJP(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string searchString = string.Empty;
        searchString = (Session["UnAssignedCustomersFilter"] != null) ? Session["UnAssignedCustomersFilter"].ToString() : "1=1";
        IList<Customer> objCustomer = new CustomerFacade().GetCustomerUnAssignedSearch("ModifiedDate DESC", 500000, 0, searchString, "");
        if (objCustomer != null && objCustomer.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Customer Name" + "\t" + "Customer Code" + "\t" + "CustomerGroup" + "\t" + "Region" + "\t" + "Country" + "\t" + "Channel");
            strFileContents.Append("\n");

            foreach (Customer obCustomer in objCustomer)
            {
                strFileContents.Append(obCustomer.SiteName + "\t");
                strFileContents.Append(obCustomer.Site + "\t");
                strFileContents.Append(obCustomer.CustomerGroupCode + "\t");
                strFileContents.Append(obCustomer.RegionName + "\t");
                strFileContents.Append(obCustomer.CountryName + "\t");
                strFileContents.Append(obCustomer.ChannelName + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    private void ExportJourneyReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SearchString = string.Empty;
            SearchString = (Session["MaintainJourneySearchString"] != null) ? Session["MaintainJourneySearchString"].ToString() : "";
            string SortExpression = "J.Date Desc";
            IList<Journey> objJourneyList = new JourneyFacade().GetJourneySearch(SortExpression, 500000, 0, SearchString, SessionManager.UserCode, "");
            strFileContents.Append("UserCode " + "\t" + "UserName" + "\t" + "Odometer Start Reading " + "\t" + "Odometer End Reading " + "\t" + "Total  Kms Travelled " + "\t" + "Journey Date " + "\t");
            strFileContents.Append("\n");
            if (objJourneyList != null && objJourneyList.Count > 0)
            {
                string JourneyOdsEndDate = "";
                foreach (Journey objJourney in objJourneyList)
                {
                    JourneyOdsEndDate = objJourney.OdometerReadingEnd == "0" ? objJourney.OdometerReadingStart : objJourney.OdometerReadingEnd;
                    strFileContents.Append(objJourney.UserCode + "\t");
                    strFileContents.Append(objJourney.User.UserName + "\t");
                    strFileContents.Append(objJourney.OdometerReadingStart + "\t");
                    //strFileContents.Append((objJourney.OdometerReadingEnd == "" || objJourney.OdometerReadingEnd=="0") ? objJourney.OdometerReadingStart : objJourney.OdometerReadingStart + "\t");
                    strFileContents.Append(JourneyOdsEndDate + "\t");
                    strFileContents.Append(objJourney.TotKmsTravelled + "\t");
                    strFileContents.Append(objJourney.Date.ToString("MMMM dd,yyyy") + "\t");
                    //strFileContents.Append("\n");
                    strFileContents.Append(Environment.NewLine);
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportOutletsCoveredVsOutletsBilledReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string Fromdate = Session["OutletCoverageVsBilledFromDate"].ToString() == null ? "" : DateTime.Parse(Session["OutletCoverageVsBilledFromDate"].ToString()).ToString("yyyy-MM-dd");
        string Todate = Session["OutletCoverageVsBilledToDate"].ToString() == null ? "" : DateTime.Parse(Session["OutletCoverageVsBilledToDate"].ToString()).ToString("yyyy-MM-dd");
        string searchString = Session["OutletCoverageVsBilledSearch"].ToString() == null ? "" : Session["OutletCoverageVsBilledSearch"].ToString(); ;
        string userCodes = Request.QueryString["UserCode"];
        // string SelectedUsers= Session["OutletsCoveregeSelectedUser"].ToString(); 
        string CustomerIds = Session["OutletCoverageVsBilledCustomerIds"].ToString() == null ? "" : Session["OutletCoverageVsBilledCustomerIds"].ToString();
        string CustomerGroup = Session["OutletCoverageVsBilledCustomerGroup"].ToString() == null ? "" : Session["OutletCoverageVsBilledCustomerGroup"].ToString();
        string Chanal = Session["OutletCoverageVsBilledChanal"].ToString() == null ? "" : Session["OutletCoverageVsBilledChanal"].ToString();
        string Brand = Session["OutletCoverageVsBilledBrand"].ToString() == null ? "" : Session["OutletCoverageVsBilledBrand"].ToString();
        string ItemCode = Session["OutletCoverageVsBilledItemCode"].ToString() == null ? "" : Session["OutletCoverageVsBilledItemCode"].ToString();
        string Region = Session["OutletCoverageVsBilledRegion"].ToString() == null ? "" : Session["OutletCoverageVsBilledRegion"].ToString();


        string SalesTeams = Session["SalesTeam"].ToString() == null ? "" : Session["SalesTeam"].ToString();
        IList<ProductiveReport> ProductiveReports = new ProductiveReportFacade().GetOutletsCoveredVsOutletsBilled_Search("UserCode Asc", searchString, userCodes, Fromdate, Todate, userCodes, SalesTeams, CustomerIds, CustomerGroup, Chanal, Brand, ItemCode, Region, 1000000, 0);

        if (ProductiveReports != null && ProductiveReports.Count > 0)
        {
            strFileContents = new StringBuilder();

            foreach (ProductiveReport objProductiveReport in ProductiveReports)
            {
                strFileContents.Append("User Name" + "\t" + "(No.of) # Outlets Covered" + "\t" + "(No.of) # Outlets Billed" + "\t" + "Productivity %" + "\n");
                strFileContents.Append("[" + objProductiveReport.EmpNo + "]" + objProductiveReport.USERNAME + "\t");
                strFileContents.Append(objProductiveReport.OutletsCovered + "\t");
                strFileContents.Append(objProductiveReport.OutletsBilled + "\t");
                strFileContents.Append(Math.Round(CommonFunctions.getDecimalValue(objProductiveReport.PercentageProduction), 4) + "\t");
                strFileContents.Append("\n");
                IList<ProductiveReport> GetItems = new ProductiveReportFacade().GetOutletCoveredVsBilled_UserCustomersByUserCode(userCodes, Fromdate, Todate, "", searchString, SalesTeams, CustomerIds, CustomerGroup, Chanal, Brand, ItemCode, Region, objProductiveReport.EmpNo);
                strFileContents.Append("Customer" + "\t" + "Type" + "\t" + "Visit Date" + "\n");
                foreach (ProductiveReport objProductiveReportItem in GetItems)
                {
                    strFileContents.Append(objProductiveReportItem.USERNAME + "\t");
                    strFileContents.Append(objProductiveReportItem.OutletsType + "\t");
                    strFileContents.Append(objProductiveReportItem.EmpNo + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(_stFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }


    private void ExportUniqueOutletCoverageReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string[] searchstring = Session["UniqueOutlet"].ToString().Split('|');
        string searchString = searchstring[0] == null ? "1=1" : CommonFunctions.getStringValue(searchstring[0]);
        string SalesmanCode = string.Empty;
        string UserCode = CommonFunctions.getStringValue(Request.QueryString["UserCode"]);
        string StartDate = CommonFunctions.getStringValue(Session["StartDate"]),
                 EndDate = CommonFunctions.getStringValue(Session["EndDate"]),
                 SalesTeam = string.Empty,
                 SalesOrg = string.Empty, Region = string.Empty, Brand = string.Empty, Chanal = string.Empty, CustomerGroup = string.Empty, ItemCode = string.Empty;
        if (searchstring.Length >= 9)
        {
            StartDate = searchstring[1];
            EndDate = searchstring[2];
            SalesmanCode = searchString = searchstring[0].Length > 0 ? searchstring[0] + " AND " + searchstring[3].Replace("A.UserCode", "UC.UserCode") : searchstring[3].Replace("A.UserCode", "UC.UserCode");
            SalesOrg = searchstring[4];

            //R,B,C,CG,I
            Region = searchstring[5];
            Brand = searchstring[6];
            Chanal = searchstring[7];
            CustomerGroup = searchstring[8];
            ItemCode = searchstring[9];
        }



        IList<UniqueOutletCoverage> objUniqueOutletCoverageReports =
            new VanStockFacade().GetUniqueOutletCoverage_User(StartDate, EndDate,
            SalesmanCode, UserCode, SalesTeam, SalesOrg, Region, Brand
            , Chanal, CustomerGroup, ItemCode);
        if (objUniqueOutletCoverageReports != null && objUniqueOutletCoverageReports.Count > 0)
        {
            strFileContents = new StringBuilder();
            foreach (UniqueOutletCoverage objUniqueOutletCoverageReport in objUniqueOutletCoverageReports)
            {
                strFileContents.Append("User Code" + "\t" + "User Name" + "\t" + "Unique Outlet Visits" + "\n");
                strFileContents.Append(objUniqueOutletCoverageReport.UserCode + "\t");
                strFileContents.Append(objUniqueOutletCoverageReport.UserName + "\t");
                strFileContents.Append(objUniqueOutletCoverageReport.NoOfVisits + "\t");
                strFileContents.Append("\n");
                strFileContents.Append(Environment.NewLine);

                IList<UniqueOutletCoverage> objUniqueOutletCoverages = new VanStockFacade().GetUniqueOutletCoverage_Customer(StartDate,
                    EndDate, objUniqueOutletCoverageReport.UserCode, UserCode, SalesTeam, searchString.Replace("||||||", " "));

                strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "No Of Visits" + "\t" + "Visited Dates");
                strFileContents.Append("\n");
                foreach (UniqueOutletCoverage objUniqueOutletCoverage in objUniqueOutletCoverages)
                {

                    strFileContents.Append(objUniqueOutletCoverage.CustomerCode + "\t");
                    strFileContents.Append(objUniqueOutletCoverage.Name + "\t");
                    strFileContents.Append(objUniqueOutletCoverage.NoOfVisits + "\t");
                    strFileContents.Append(objUniqueOutletCoverage.VisitedDates + "\t");
                    strFileContents.Append("\n");

                }
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(_stFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    private void ExportSalesmanJourneyReport(string _stFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        string UserCode = "", SelectedUserCode = "", SearchString = "1=1", SortExpression = "UserName ASC", SalesOrganizations = "", Regions = "", ASMs = "", Supervisors = "", Routes = "", StartDate = "";


        if (SessionManager.UserCode != null)
        {
            UserCode = SessionManager.UserCode.ToString();
        }
        if (Session["UCCommonFilter_SalesOrganization"] != null)
        {
            SelectedUserCode = Session["UCCommonFilter_SelectedUserCode"].ToString();
        }
        if (Session["UCCommonFilter_SalesOrganization"] != null)
        {
            SalesOrganizations = Session["UCCommonFilter_SalesOrganization"].ToString();
        }
        if (Session["UCCommonFilter_Region"] != null)
        {
            Regions = Session["UCCommonFilter_Region"].ToString();
        }
        if (Session["UCCommonFilter_ASM"] != null)
        {
            ASMs = Session["UCCommonFilter_ASM"].ToString();
        }
        if (Session["UCCommonFilter_Supervisor"] != null)
        {
            Supervisors = Session["UCCommonFilter_Supervisor"].ToString();
        }
        if (Session["UCCommonFilter_Route"] != null)
        {
            Routes = Session["UCCommonFilter_Route"].ToString();
        }
        if (Session["UCCommonFilter_StartDate"] != null)
        {
            StartDate = Session["UCCommonFilter_StartDate"].ToString();
        }


        IList<JourneyWiseSalesman> objJourneyWiseSalesmanReports = new EOTFacade().GetSalesManWiseJourney_Report(SortExpression, UserCode, SelectedUserCode, SalesOrganizations, Regions, ASMs, Supervisors, Routes, StartDate);
        if (objJourneyWiseSalesmanReports != null && objJourneyWiseSalesmanReports.Count > 0)
        {
            strFileContents = new StringBuilder();
            foreach (JourneyWiseSalesman objJourneyWiseSalesmanReport in objJourneyWiseSalesmanReports)
            {
                strFileContents.Append("User Code" + "\t" + "User Name" + "\n");
                strFileContents.Append(objJourneyWiseSalesmanReport.Code + "\t");
                strFileContents.Append(objJourneyWiseSalesmanReport.Name + "\t");
                strFileContents.Append("\n");
                strFileContents.Append(Environment.NewLine);
                //IList<SalesmanLocationForJourney> objSalesmanLocationForJourneys = (new EOTFacade()).GetSalesManWiseUsers(objJourneyWiseSalesmanReport.Code, "1=1", date);
                IList<SalesmanLocationForJourney> objSalesmanLocationForJourneys = (new EOTFacade()).GetSalesManWiseUsers(UserCode, objJourneyWiseSalesmanReport.Code, SalesOrganizations, Regions, ASMs, Supervisors, Routes, StartDate);
                strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Has Journey Plan (JP) "
                    + "\t" + "Visit Date " + "\t" + "Arrival Time" + "\t" + "Out Time" + "\t" + "Total Time(Minutes)");
                strFileContents.Append("\n");
                foreach (SalesmanLocationForJourney objSalesmanLocationForJourney in objSalesmanLocationForJourneys)
                {
                    strFileContents.Append(objSalesmanLocationForJourney.Site + "\t");
                    strFileContents.Append(objSalesmanLocationForJourney.SiteName + "\t");
                    strFileContents.Append(objSalesmanLocationForJourney.IsHasJourney + "\t");
                    strFileContents.Append(objSalesmanLocationForJourney.VisitDate + "\t");
                    strFileContents.Append(objSalesmanLocationForJourney.ArrivalTime + "\t");
                    strFileContents.Append(objSalesmanLocationForJourney.OutTime + "\t");
                    strFileContents.Append(objSalesmanLocationForJourney.TotalTime + "\t");
                    strFileContents.Append("\n");

                }
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(_stFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    private void ExportAssetTracking(string strFileName, string status)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SearchString = string.Empty;
            SearchString = (Session["AssetTracking_SearchString"] != null) ? Session["AssetTracking_SearchString"].ToString() + " " + status : "1=1 AND" + "" + status;
            string SortExpression = "AssetId Desc";
            IList<MovementHeader> objMovementHeaderList = new MovementHeaderFacade().GettblAssetSELALLSearch(SortExpression, 500000, 0, SearchString, SessionManager.UserCode);
            strFileContents.Append("AssetName" + "\t" + "AssetCode " + "\t" + "BarCode" + "\t" + "UserCode " + "\t" + "UserName" + "\t" + "CustomerCode" + "\t" + "CustomerName" + "\t" + "SalesOrgCode" + "\t" + "SalesOrgName" + "\t");
            strFileContents.Append("\n");
            if (objMovementHeaderList != null && objMovementHeaderList.Count > 0)
            {
                foreach (MovementHeader objMovementHeader in objMovementHeaderList)
                {
                    strFileContents.Append(objMovementHeader.AssetName + "\t");
                    strFileContents.Append(objMovementHeader.AssetCode + "\t");
                    strFileContents.Append(objMovementHeader.BarCode + "\t");
                    strFileContents.Append(objMovementHeader.UserCode + "\t");
                    strFileContents.Append(objMovementHeader.UserName + "\t");
                    strFileContents.Append(objMovementHeader.CustomerCode + "\t");
                    strFileContents.Append(objMovementHeader.CustomerName + "\t");
                    strFileContents.Append(objMovementHeader.SalesOrgCode + "\t");
                    strFileContents.Append(objMovementHeader.SalesOrgName + "\t");
                    strFileContents.Append(Environment.NewLine);
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    private void ExportZeroSalesOutletReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;

            string SearchString = string.Empty;
            string SortExpression = "MovementDate Desc";
            string UserCode = "";
            string startDate = Convert.ToDateTime(Session["sdate"]).ToString("yyyy-MM-dd");
            string EndDate = Convert.ToDateTime(Session["edate"]).ToString("yyyy-MM-dd");
            //  string[] searchcriteria = Session["ZeroSalesOutletSearchCriteria"].ToString().Split('^');
            string divid = Session["PanelId"].ToString();

            if (Session["ZeroSalesUserCode"] != null)
            {
                UserCode = Session["ZeroSalesUserCode"].ToString();
            }
            else if (SessionManager.UserCode != null)
            {
                UserCode = SessionManager.UserCode;
            }

            strFileContents = new StringBuilder();
            IList<UniqueOutletCoverage> objVanStockReportList = new VanStockFacade().GetZeroSalesOutlets_CustomerWise_User(Session["salesman"].ToString(), startDate, EndDate, UserCode, Session["salesteam"].ToString(), "", "", "", "");


            if (objVanStockReportList != null && objVanStockReportList.Count > 0)
            {
                foreach (UniqueOutletCoverage objVanStockReport in objVanStockReportList)
                {

                    strFileContents.Append("User" + "\t" + "No Of Visit" + "\t" + " No of Customer" + "\n");
                    strFileContents.Append("[" + objVanStockReport.UserCode + "] " + objVanStockReport.UserName + "\t");
                    strFileContents.Append(objVanStockReport.TotalNoOfVisits + "\t");
                    strFileContents.Append(objVanStockReport.TotalCustomerCount + "\t");
                    strFileContents.Append("\n\n");


                    IList<UniqueOutletCoverage> objVanStockReportListByDate = new VanStockFacade().GetCustomersBySalesMan_ZeroSales(startDate, EndDate, objVanStockReport.UserCode, SessionManager.UserCode, Session["salesteam"].ToString(), "", "", "");
                    if (objVanStockReportListByDate != null && objVanStockReportListByDate.Count > 0)
                    {
                        foreach (UniqueOutletCoverage UniqueOutletCoverage in objVanStockReportListByDate)
                        {
                            strFileContents.Append("Customer" + "\t" + "No Of Visits (Store)" + "\t" + "\n");
                            strFileContents.Append("[" + UniqueOutletCoverage.CustomerCode + "] " + UniqueOutletCoverage.Name + "\t" + UniqueOutletCoverage.NoOfVisits + "\n");

                            strFileContents.Append("Customer Visit" + "\t" + "Date & Time" + "\t" + "Reason" + "\n");
                            foreach (ZeroSalesReason objZeroSalesReason in UniqueOutletCoverage.Reasons)
                            {
                                strFileContents.Append("[" + objZeroSalesReason.CustomerCode + "] " + objZeroSalesReason.CustomerName + "\t");
                                strFileContents.Append(objZeroSalesReason.ZeroSalesDateTime + "\t");
                                strFileContents.Append(objZeroSalesReason.Reason + "\n");
                            }

                        }
                        strFileContents.Append("\n");
                    }

                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }


        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportAdherenceReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            StringBuilder strFileContent = new StringBuilder();
            string Salesman = SessionManager.UserCode;
            string SalesOrg = Session["AdherentReportDetailsSalesOrg"].ToString();
            string Customer = Session["AdherentReportDetailsCustomer"].ToString();
            string StartDate = Session["AdherentReportStartDate"].ToString();
            string EndDate = Session["AdherentReportEndDate"].ToString();

            IList<OrdervsRecFst> objOrdervsRecFstlst = new OrdervsRecFacade().GetOrdervsRecNew(StartDate, EndDate, SalesOrg, Salesman, "", "", Customer);
            if (objOrdervsRecFstlst != null && objOrdervsRecFstlst.Count > 0)
            {


                foreach (OrdervsRecFst objOrdervsRecFst in objOrdervsRecFstlst)
                {
                    strFileContents.Append("Customer" + "\t" + "Total Order" + "\n");

                    strFileContents.Append("[" + objOrdervsRecFst.CustomerCode + "]" + objOrdervsRecFst.CustomerName + "\t");
                    strFileContents.Append(Math.Round(CommonFunctions.getDecimalValue(objOrdervsRecFst.OrderQuantity), 2) + "\t");
                    strFileContents.Append("\n");
                    strFileContents.Append("Order No" + "\t" + "Adherence Percentage" + "\n");
                    foreach (TrxHeaderRec objTrxHeaderRec in objOrdervsRecFst.OrderList)
                    {
                        strFileContents.Append(objTrxHeaderRec.TrxCode + "\t");
                        strFileContents.Append(objOrdervsRecFst.AdherencePercentage + "\t");
                        strFileContents.Append("\n");
                        strFileContents.Append("Item Code" + "\t" + "Item Description" + "\t" + "Recomended Quantity" + "\t" + "Order Quantity" + "\n");

                        foreach (TrxDetailRec objTrxDetailRec in objTrxHeaderRec.objTrxDetailRecs)
                        {

                            strFileContents.Append(objTrxDetailRec.ItemCode + "\t");
                            strFileContents.Append(objTrxDetailRec.ItemDescription + "\t");
                            strFileContents.Append(Math.Round(CommonFunctions.getDecimalValue(objTrxDetailRec.RecQty), 2) + "\t");
                            strFileContents.Append(Math.Round(CommonFunctions.getDecimalValue(objTrxDetailRec.OrdQty), 2) + "\t");
                            strFileContents.Append("\n");

                        }
                    }
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }

        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportPendingInvoiceReport_New(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string Year = (Session["DailyCollectionYear"] != null) ? CommonFunctions.getStringValue(Session["DailyCollectionYear"]) : DateTime.Now.Year.ToString();
            string Month = (Session["DailyCollectionMonth"] != null) ? CommonFunctions.getStringValue(Session["DailyCollectionMonth"]) : DateTime.Now.Month.ToString();
            string UserCode = (Session["DailyCollectionUserCode"] != null) ? CommonFunctions.getStringValue(Session["DailyCollectionUserCode"]) : "";
            string Salesorg = (Session["DailyCollectionSalesorg"] != null) ? CommonFunctions.getStringValue(Session["DailyCollectionSalesorg"]) : "";
            string RouteCode = (Session["DailyCollectionRouteCode"] != null) ? CommonFunctions.getStringValue(Session["DailyCollectionRouteCode"]) : "";
            string DepoCode = (Session["DailyCollectionDepoCode"] != null) ? CommonFunctions.getStringValue(Session["DailyCollectionDepoCode"]) : "";
            string SupervisorCode = (Session["DailyCollectionSupervisorCode"] != null) ? CommonFunctions.getStringValue(Session["DailyCollectionSupervisorCode"]) : "";
            //IList<PendingInvoiceReport> objPendingInvoicesList = new PendingInvoicesFacade().GetPendingInvoiceListByPaging_Export("", Searchstring, SessionManager.UserCode, Searchstring2);
            DataSet ds = new SettlementFacade().GetDailySalesmanCollectionReportExport("", 500000, 0, UserCode, Salesorg, RouteCode, Month, Year, DepoCode, "", SupervisorCode);
            int count = 0, DateCount = 0;
            double TotalMTDSales = 0.00, TotalMTDCollection = 0.00, TotalOpeningLastMonth = 0.00, TotalMTDShortage = 0.00;
            if (ds != null && ds.Tables.Count > 0)
            {
                DailyCollectionExport obj = new DailyCollectionExport();
                strFileContents = new StringBuilder();
                strFileContents.Append("\t\t\t\t");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ds.Tables[0].Columns.Add("Status");
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        obj.Date = Db.ToDateTime(row["Date"]);
                        strFileContents.Append(Db.ToDateTime(row["Date"]).ToString("dd/MM/yyyy") + "\t\t");
                        DateCount++;
                    }
                }
                strFileContents.Append("\n");
                strFileContents.Append("Route Code" + "\t" + "Salesman Name" + "\t" + "Region" + "\t" + "Receivable Balance" + "\t");
                while (count < DateCount)
                {
                    strFileContents.Append("Sales" + "\t" + "Collection" + "\t");
                    count++;
                }
                strFileContents.Append("\tSales MTD" + "\t" + "Collection MTD" + "\t" + "Shortage MTD");
                strFileContents.Append("\n");
                if (ds.Tables[1].Rows.Count > 0)
                {
                    int needZero = 0;
                    foreach (DataRow row in ds.Tables[1].Rows)
                    {
                        needZero = 0;
                        int tabValues = 0;
                        DailyCollectionExportDetails objdetails = new DailyCollectionExportDetails();
                        objdetails.RouteCode = Db.ToString(row["RouteCode"]);
                        objdetails.SalesmanCode = Db.ToString(row["SalesmanCode"]);
                        objdetails.RegionCode = Db.ToString(row["RegionCode"]);

                        strFileContents.Append(Db.ToString(row["RouteCode"]) != null ? (Db.ToString(row["RouteCode"]) != "" ? Db.ToString(row["RouteCode"]) : "N/A") + "\t" : "N/A" + "\t");
                        strFileContents.Append(Db.ToString(row["SalesmanName"]) != null ? (Db.ToString(row["SalesmanName"]) != "" ? Db.ToString(row["SalesmanName"]) : "N/A") + "\t" : "N/A" + "\t");
                        strFileContents.Append(Db.ToString(row["RegionName"]) != null ? (Db.ToString(row["RegionName"]) != "" ? Db.ToString(row["RegionName"]) : "N/A") + "\t" : "N/A" + "\t");
                        strFileContents.Append(Db.ToString(row["ReceiveableAmount"]) + "\t");

                        DataRow[] drAmount = ds.Tables[2].Select("RouteCode='" + objdetails.RouteCode.Replace("'", "''") + "' and SalesmanCode = '" + objdetails.SalesmanCode + "'");
                        if (drAmount != null)
                        {
                            DateTime date = DateTime.Today.Date;
                            foreach (DataRow row1 in drAmount)
                            {

                                if (needZero == 1 && date.AddDays(1) != Db.ToDateTime(row1["Date"]))
                                {
                                    strFileContents.Append(Db.ToString("0") + "\t");
                                    strFileContents.Append(Db.ToString("0") + "\t");
                                    tabValues++;
                                }
                                foreach (DataRow rowDate in ds.Tables[0].Rows)
                                {
                                    if (Db.ToString(rowDate["Date"]) == Db.ToString(row1["Date"]))
                                    {
                                        tabValues++;
                                        strFileContents.Append(Db.ToString(row1["TotalSales"]) + "\t");
                                        strFileContents.Append(Db.ToString(row1["Collection"]) + "\t");
                                        needZero = 1;
                                        date = Db.ToDateTime(row1["Date"]);
                                    }
                                    else if (needZero == 0)
                                    {
                                        tabValues++;
                                        strFileContents.Append(Db.ToString("0") + "\t");
                                        strFileContents.Append(Db.ToString("0") + "\t");
                                    }
                                }

                            }
                        }
                        int Totaltabs = Convert.ToInt32(ds.Tables[0].Rows.Count);
                        int totalRowtabs = drAmount.Count();
                        if (Totaltabs > tabValues)
                        {
                            for (int i = 0; i < Totaltabs - tabValues; i++)
                            {
                                strFileContents.Append("\t\t");
                            }
                        }
                        TotalMTDSales += Db.ToDouble(row["SalesMTD"]);
                        TotalMTDCollection += Db.ToDouble(row["CollectionMTD"]);
                        TotalMTDShortage += Db.ToDouble(row["ShortageMTD"]);
                        TotalOpeningLastMonth += Db.ToDouble(row["ReceiveableAmount"]);

                        strFileContents.Append("\t" + Db.ToString(row["SalesMTD"]) + "\t");
                        strFileContents.Append(Db.ToString(row["CollectionMTD"]) + "\t");
                        strFileContents.Append(Db.ToString(row["ShortageMTD"]) + "\t");
                        strFileContents.Append("\n");
                    }
                    strFileContents.Append("\n");
                    strFileContents.Append("\tGrand Total\t\t");
                    strFileContents.Append(TotalOpeningLastMonth.ToString() + "\t");
                    foreach (DataRow rowDate in ds.Tables[0].Rows)
                    {
                        double TotalSales = 0.00;
                        double TotalCollection = 0.00;
                        DataRow[] row = ds.Tables[2].Select("Date='" + Db.ToString(rowDate["Date"]) + "'");
                        foreach (DataRow rowdata in row)
                        {
                            TotalSales += Db.ToDouble(rowdata["TotalSales"]);
                            TotalCollection += Db.ToDouble(rowdata["Collection"]);
                        }
                        strFileContents.Append(TotalSales.ToString() + "\t");
                        strFileContents.Append(TotalCollection.ToString() + "\t");
                    }

                    strFileContents.Append("\t" + TotalMTDSales.ToString() + "\t");
                    strFileContents.Append(TotalMTDCollection.ToString() + "\t");
                    strFileContents.Append(TotalMTDShortage.ToString() + "\t");
                }

            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportMarketSalesPerformance(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SearchString = "1=1", SortExpression = "KeyNamePriority ASC", SalesOrganizations = "", Regions = "", ASMs = "", Supervisors = "", Routes = "";
            int maximumrows = 1000, startrowindex = 0;

            if (Session["UCCommonFilter_SalesOrganization"] != null)
            {
                SalesOrganizations = Session["UCCommonFilter_SalesOrganization"].ToString();
            }
            if (Session["UCCommonFilter_Region"] != null)
            {
                Regions = Session["UCCommonFilter_Region"].ToString();
            }
            if (Session["UCCommonFilter_ASM"] != null)
            {
                ASMs = Session["UCCommonFilter_ASM"].ToString();
            }
            if (Session["UCCommonFilter_Supervisor"] != null)
            {
                Supervisors = Session["UCCommonFilter_Supervisor"].ToString();
            }
            if (Session["UCCommonFilter_Route"] != null)
            {
                Routes = Session["UCCommonFilter_Route"].ToString();
            }

            IList<MarketSalesPerformance1> lstMarketSalesPerformance = new TrxDetailFacade().GetMarketSalesPerformance(SortExpression, maximumrows, startrowindex, SearchString, SalesOrganizations, Regions, ASMs, Supervisors, Routes);
            if (lstMarketSalesPerformance != null)
            {

                strFileContents.Append("Key Name" + "\t" + "YTD" + "\t" + "Jan" + "\t" + "Feb" + "\t" + "Mar" + "\t"
                     + "Apr" + "\t" + "May" + "\t" + "Jun" + "\t" + "Jul" +
                     "\t" + "Aug" + "\t" + "Sep" + "\t" + "Oct" + "\t" + "Nov" + "\t" + "Dec" + "\t");
                strFileContents.Append("\n");

                foreach (MarketSalesPerformance1 objMarketSalesPerformance in lstMarketSalesPerformance)
                {
                    strFileContents.Append(objMarketSalesPerformance.Name + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.YTD) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Jan) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Feb) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Mar) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Apr) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.May) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Jun) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Jul) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Aug) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Sep) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Oct) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Nov) + "\t");
                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objMarketSalesPerformance.Dec) + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    //private void ExportMonthlySalesStockReport(string strFileName)
    //{
    //    System.IO.StreamWriter sw;
    //    try
    //    {
    //        StringBuilder strFileContents = new StringBuilder();
    //        string SearchString = "1=1", SortExpression = "ItemCode ASC", UserCode = "", Category = "", ReportValueType = "", SalesOrganizations = "", Regions = "", ASMs = "", Supervisors = "", Routes = "", StartMonth = "";
    //        int maximumRows = 99999, startRowIndex = 0;
    //        List<GetHeader> lstHeader = null;

    //        if (SessionManager.UserCode != null)
    //        {
    //            UserCode = SessionManager.UserCode.ToString();
    //        }

    //        if (Session["UCCommonFilter_SalesOrganization"] != null)
    //        {
    //            SalesOrganizations = Session["UCCommonFilter_SalesOrganization"].ToString();
    //        }
    //        if (Session["UCCommonFilter_Region"] != null)
    //        {
    //            Regions = Session["UCCommonFilter_Region"].ToString();
    //        }
    //        if (Session["UCCommonFilter_ASM"] != null)
    //        {
    //            ASMs = Session["UCCommonFilter_ASM"].ToString();
    //        }
    //        if (Session["UCCommonFilter_Supervisor"] != null)
    //        {
    //            Supervisors = Session["UCCommonFilter_Supervisor"].ToString();
    //        }
    //        if (Session["UCCommonFilter_Route"] != null)
    //        {
    //            Routes = Session["UCCommonFilter_Route"].ToString();
    //        }
    //        if (Session["UCCommonFilter_StartMonth"] != null)
    //        {
    //            StartMonth = Session["UCCommonFilter_StartMonth"].ToString();
    //        }

    //        if (Session["UCCommonFilter_Category"] != null)
    //        {
    //            Category = Session["UCCommonFilter_Category"].ToString();
    //        }
    //        IList<MonthlySalesStockResult> lstMonthlySalesStockReport = new MonthlySalesStockFacade().MonthlySalesStockReport(SortExpression, SearchString, out lstHeader, SalesOrganizations, Regions, ASMs, Supervisors, Routes, StartMonth, Category, ReportValueType, UserCode, maximumRows, startRowIndex);
    //        if (lstMonthlySalesStockReport != null)
    //        {
    //            strFileContents.Append("Sales Class\t\t");
    //            foreach (GetHeader objHeader in lstHeader)
    //            {
    //                strFileContents.Append(objHeader.HeaderName + "\t\t\t\t");
    //            }
    //            strFileContents.Append("\n");

    //            strFileContents.Append("\t\t");
    //            foreach (GetHeader objHeader in lstHeader)
    //            {
    //                strFileContents.Append("MTD Amount\tMTD Units\tYTD Amount\tYTD Units\t");
    //            }
    //            strFileContents.Append("\n");

    //            foreach (MonthlySalesStockResult objMonthlySalesStockResult in lstMonthlySalesStockReport)
    //            {
    //                strFileContents.Append(objMonthlySalesStockResult.ItemCode + "\t");
    //                strFileContents.Append(objMonthlySalesStockResult.ItemDescription + "\t");
    //                foreach (ChildClass objChildClass in objMonthlySalesStockResult.objChildClassList)
    //                {
    //                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objChildClass.MTDAmount) + "\t");
    //                    strFileContents.Append(objChildClass.MTDUnits + "\t");
    //                    strFileContents.Append(CommonFunctions.GetCurrencyFormatWithThousands_OMR(objChildClass.YTDAmount) + "\t");
    //                    strFileContents.Append(objChildClass.YTDUnits + "\t");
    //                }
    //                strFileContents.Append("\n");
    //            }
    //        }
    //        sw = System.IO.File.CreateText(strFileName);
    //        sw.Write(strFileContents.ToString());
    //        sw.Close();
    //    }
    //    catch (Exception ex)
    //    {
    //        CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
    //    }
    //}
    private void ExportTopSKUs(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SearchString = "1=1", UserCode = "", SalesOrganizations = "", Regions = "", ASMs = "", Supervisors = "", Routes = "", StartMonth = "", EndMonth = "", Category = "";
            int TrxType = 0;
            int maximumRows = 20, startRowIndex = 0;
            if (SessionManager.UserCode != null)
            {
                UserCode = SessionManager.UserCode.ToString();
            }
            if (Session["UCCommonFilter_TrxType"] != null)
            {
                TrxType = Convert.ToInt32(Session["UCCommonFilter_TrxType"].ToString());
            }
            if (Session["UCCommonFilter_SalesOrganization"] != null)
            {
                SalesOrganizations = Session["UCCommonFilter_SalesOrganization"].ToString();
            }
            if (Session["UCCommonFilter_Region"] != null)
            {
                Regions = Session["UCCommonFilter_Region"].ToString();
            }
            if (Session["UCCommonFilter_ASM"] != null)
            {
                ASMs = Session["UCCommonFilter_ASM"].ToString();
            }
            if (Session["UCCommonFilter_Supervisor"] != null)
            {
                Supervisors = Session["UCCommonFilter_Supervisor"].ToString();
            }
            if (Session["UCCommonFilter_Route"] != null)
            {
                Routes = Session["UCCommonFilter_Route"].ToString();
            }
            if (Session["UCCommonFilter_StartMonth"] != null)
            {
                StartMonth = Session["UCCommonFilter_StartMonth"].ToString();
            }
            if (Session["UCCommonFilter_EndMonth"] != null)
            {
                EndMonth = Session["UCCommonFilter_EndMonth"].ToString();
            }
            if (Session["UCCommonFilter_Category"] != null)
            {
                Category = Session["UCCommonFilter_Category"].ToString();
            }
            TopItemsList lstTopItems = (new ReportsFacade()).SelTopItemsList(SearchString, SalesOrganizations, Regions, ASMs, Supervisors, Routes, StartMonth, EndMonth, TrxType, Category, UserCode, maximumRows, startRowIndex);
            if (lstTopItems != null)
            {
                strFileContents.Append("Item Code\tItem Description\tAmount\tReach Count");

                strFileContents.Append("\n");

                foreach (TopItem objTopItemsList in lstTopItems.lstTopItems)
                {
                    strFileContents.Append(objTopItemsList.ItemId + "\t");
                    strFileContents.Append(objTopItemsList.Name + "\t");
                    strFileContents.Append(objTopItemsList.TotalAmount + "\t");
                    strFileContents.Append(objTopItemsList.ReachCount + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportTopCustomers(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string SearchString = "1=1", UserCode = "", SalesOrganizations = "", Regions = "", ASMs = "", Supervisors = "", Routes = "", StartMonth = "", EndMonth = "";
            int TrxType = 0;
            int maximumRows = 20, startRowIndex = 0;
            if (SessionManager.UserCode != null)
            {
                UserCode = SessionManager.UserCode.ToString();
            }
            if (Session["UCCommonFilter_TrxType"] != null)
            {
                TrxType = Convert.ToInt32(Session["UCCommonFilter_TrxType"].ToString());
            }
            if (Session["UCCommonFilter_SalesOrganization"] != null)
            {
                SalesOrganizations = Session["UCCommonFilter_SalesOrganization"].ToString();
            }
            if (Session["UCCommonFilter_Region"] != null)
            {
                Regions = Session["UCCommonFilter_Region"].ToString();
            }
            if (Session["UCCommonFilter_ASM"] != null)
            {
                ASMs = Session["UCCommonFilter_ASM"].ToString();
            }
            if (Session["UCCommonFilter_Supervisor"] != null)
            {
                Supervisors = Session["UCCommonFilter_Supervisor"].ToString();
            }
            if (Session["UCCommonFilter_Route"] != null)
            {
                Routes = Session["UCCommonFilter_Route"].ToString();
            }
            if (Session["UCCommonFilter_StartMonth"] != null)
            {
                StartMonth = Session["UCCommonFilter_StartMonth"].ToString();
            }
            if (Session["UCCommonFilter_EndMonth"] != null)
            {
                EndMonth = Session["UCCommonFilter_EndMonth"].ToString();
            }
            TopCustomersList lstTopCustomers = (new ReportsFacade()).SelTopCustomersList(SearchString, SalesOrganizations, Regions, ASMs, Supervisors, Routes, StartMonth, EndMonth, TrxType, UserCode, maximumRows, startRowIndex);

            if (lstTopCustomers != null)
            {
                strFileContents.Append("Customer Code\tCustomer Description\tAmount\tReach Count");

                strFileContents.Append("\n");

                foreach (TopCustomer objTopCustomer in lstTopCustomers.lstTopCustomers)
                {
                    strFileContents.Append(objTopCustomer.CustomerId + "\t");
                    strFileContents.Append(objTopCustomer.Name + "\t");
                    strFileContents.Append(objTopCustomer.TotalAmount + "\t");
                    strFileContents.Append(objTopCustomer.ReachCount + "\t");
                    strFileContents.Append("\n");
                }
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    public class DailyCollectionExport
    {
        public DailyCollectionExport()
        {
            lstDailyCollectionExportDetails = new List<DailyCollectionExportDetails>();
        }
        public DateTime Date { set; get; }
        public IList<DailyCollectionExportDetails> lstDailyCollectionExportDetails { get; set; }


    }
    public class DailyCollectionExportDetails
    {
        public DateTime Date { set; get; }
        public string RouteCode { get; set; }
        public string SalesmanCode { get; set; }
        public string RegionCode { get; set; }


        public string SupervisorCode { get; set; }

        public string SupervisorName { get; set; }

        public string ASMCode { get; set; }

        public string ASMName { get; set; }
    }
    private void ExportRevenueDispersion(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = "1=1";

            string cSalesOrg = Session["UCCommonFilter_SalesOrganization"] != null ? Session["UCCommonFilter_SalesOrganization"].ToString() : "";
            string cRegions = Session["UCCommonFilter_Region"] != null ? Session["UCCommonFilter_Region"].ToString() : ""; ;
            string cASMs = Session["UCCommonFilter_ASM"] != null ? Session["UCCommonFilter_ASM"].ToString() : ""; ;
            string cSupervisors = Session["UCCommonFilter_Supervisor"] != null ? Session["UCCommonFilter_Supervisor"].ToString() : ""; ;
            string cRoutes = Session["UCCommonFilter_Route"] != null ? Session["UCCommonFilter_Route"].ToString() : ""; ;
            string cStartMonth = Session["UCCommonFilter_StartMonth"] != null ? Session["UCCommonFilter_StartMonth"].ToString() : "";
            string cEndMonth = Session["UCCommonFilter_EndMonth"] != null ? Session["UCCommonFilter_EndMonth"].ToString() : "";
            string UserCode = SessionManager.UserCode != null ? SessionManager.UserCode : "";



            //IList<RevenueDespersion> objRevenueDespersionlst = new RevenueDespersionFacade().GetRevenueDespersionSearch(cSalesOrg, cRegions, cASMs, cSupervisors, cRoutes, cStartMonth, cEndMonth, UserCode);
            IList<RevenueDespersionDetails> objRevenueDespersionlst = new RevenueDespersionFacade().GetRevenueDispersionDetails(SearchString, cSalesOrg, cRegions, cASMs, cSupervisors, cRoutes, UserCode, cStartMonth, cEndMonth);
            if (objRevenueDespersionlst != null && objRevenueDespersionlst.Count > 0)
            {
                strFileContents = new StringBuilder();

                strFileContents.Append("Month" + "\t" + "Billing (SAR)" + "\t" + "No Of Invoices" + "\t" + "No Of Customers" + "\t" + "Total No Of Invoices" + "\t" + "Total No Of Customers" + "\t" + "Invoices %" + "\t" + "Customers %");
                strFileContents.Append("\n");

                foreach (RevenueDespersionDetails objRevenueDespersion in objRevenueDespersionlst)
                {
                    foreach (MonthDispersion objMonthDispersion in objRevenueDespersion.objMonthDispersions)
                    {
                        Double CustomerPercentage = 0, CustomerDenominator = 0, CustomerNumerator = 0, InvoicePercentage = 0, InvoiceDenominator = 0, InvoiceNumerator = 0;
                        CustomerDenominator = objRevenueDespersion.TotalCustomersNumber;
                        CustomerNumerator = objMonthDispersion.CustomersNumber;
                        if (CustomerDenominator > 0)
                        {
                            CustomerPercentage = (CustomerNumerator * 100.00 / CustomerDenominator);
                        }

                        InvoiceDenominator = objRevenueDespersion.TotalCustomersNumber;
                        InvoiceNumerator = objMonthDispersion.InvoicesNumber;
                        if (InvoiceDenominator > 0)
                        {
                            InvoicePercentage = (InvoiceNumerator * 100.00 / InvoiceDenominator);
                        }

                        strFileContents.Append(objRevenueDespersion.Month + "\t");
                        strFileContents.Append(objMonthDispersion.Billing + "\t");
                        strFileContents.Append(objMonthDispersion.InvoicesNumber + "\t");
                        strFileContents.Append(objMonthDispersion.CustomersNumber + "\t");
                        strFileContents.Append(InvoiceDenominator + "\t");
                        strFileContents.Append(CustomerDenominator + "\t");
                        strFileContents.Append(InvoicePercentage + "\t");
                        strFileContents.Append(CustomerPercentage + "\t");
                        strFileContents.Append("\n");
                    }
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportSurveyDetails(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        int SurveyId = 0;
        if (Request.QueryString["SurveyId"] != null)
        {
            SurveyId = CommonFunctions.GetIntValue(Request.QueryString["SurveyId"]);
        }
        DataSet dsSurvey = new SurveyFacade().GetSurveyDetailForExportBySurveyId(SurveyId);

        if (dsSurvey.Tables.Count > 0)
        {
            strFileContents = new StringBuilder();
            //Survey Details
            strFileContents.Append(CommonFunctions.getStringValue(dsSurvey.Tables[0].Rows[0]["SurveyName"]) + "\t  Valid From\t " + CommonFunctions.getStringValue(dsSurvey.Tables[0].Rows[0]["StartDate"]) + "\t Valid To \t" + CommonFunctions.getStringValue(dsSurvey.Tables[0].Rows[0]["EndDate"]));
            strFileContents.Append("\n\n");
            DataTable dtQuestion = dsSurvey.Tables[1];
            DataTable dtUserCustomer = dsSurvey.Tables[2];
            DataTable dtUserCustomerAnswer = dsSurvey.Tables[3];
            //Header User custromer
            strFileContents.Append("Questions \t");
            foreach (DataRow drUc in dtUserCustomer.Rows)
            {
                strFileContents.Append(CommonFunctions.getStringValue(drUc["UserCustomer"]) + " \t");
            }
            strFileContents.Append("\n");
            //Rows 

            foreach (DataRow drQ in dtQuestion.Rows)
            {
                int QuestionId = CommonFunctions.GetIntValue(drQ["SurveyQuestionId"]);
                string Question = CommonFunctions.getStringValue(drQ["Question"]) + CommonFunctions.getStringValue(drQ["OptionNames"]);
                strFileContents.Append(Question + "\t");
                foreach (DataRow drUc in dtUserCustomer.Rows)
                {
                    string userCustomer = CommonFunctions.getStringValue(drUc["UserCustomer"]);
                    DataRow[] drAnswers = dtUserCustomerAnswer.Select("UserCustomer='" + userCustomer + "' AND SurveyQuestionId=" + QuestionId);
                    string AnswerVal = "";
                    foreach (DataRow drAnswer in drAnswers)
                    {
                        AnswerVal += CommonFunctions.getStringValue(drAnswer["SurveyAnswer"]) == "" ? "" : (CommonFunctions.getStringValue(drAnswer["SurveyAnswer"]) + ",");
                    }
                    strFileContents.Append(AnswerVal.Substring(0, (AnswerVal.Length > 0 ? AnswerVal.Length - 1 : 0)) + "\t");
                }
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }

    }
    private void ExportItemDetails(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string SearchString = string.Empty;

        SearchString = (Session["MaintainItemReport"] != null) ? Session["MaintainItemReport"].ToString() : " DATEDIFF(D, R.RECEIPT_DATE, GETDATE()) = 0";

        IList<Item> items = (new ItemFacade()).GetItemDetails_Export(SearchString, SessionManager.UserCode);

        if (items != null && items.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Item Code" + "\t" + "Item Description" + "\t" + "Agency  Code" + "\t" + "Agency Name" + "\t"
                + "Brand Code" + "\t" + "Brand Name" + "\t" + "Category Code" + "\t" + "Category Name" + "\t" + "UOM" + "\t" +
                  "Item Group Code" + "\t" + "UnitsPerCase" + "\t" + "DefaultSalesPrice" + "\t" + "ARBItemDescription" + "\t" + "IsActive" + "\t" +
                  "CasePrice" + "\t" + "AlternateCode" + "\t" + "Liter" + "\t" + "LiterPerUnit" + "\t" + "ItemTaxKey1");
            strFileContents.Append("\n");
            int i = 1;
            foreach (Item objItem in items)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append(objItem.ItemCode + "\t");
                strFileContents.Append(objItem.Description + "\t");
                strFileContents.Append(objItem.objAgency.Code + "\t");
                strFileContents.Append(objItem.objAgency.Name + "\t");
                strFileContents.Append(objItem.objbrand.Code + "\t");
                strFileContents.Append(objItem.objbrand.Name + "\t");
                strFileContents.Append(objItem.objCategory.Code + "\t");
                strFileContents.Append(objItem.objCategory.Name + "\t");
                strFileContents.Append(objItem.UOM + "\t");
                strFileContents.Append(objItem.ItemGroupCode + "\t");
                strFileContents.Append(objItem.UnitPerCase + "\t");
                strFileContents.Append(objItem.DefaultSalesPrice + "\t");
                strFileContents.Append(objItem.ARBItemDescription + "\t");
                strFileContents.Append(objItem.IsActive + "\t");
                strFileContents.Append(objItem.CasePrice + "\t");
                strFileContents.Append(objItem.AlternateCode + "\t");
                strFileContents.Append(objItem.Liter + "\t");
                strFileContents.Append(objItem.LiterPerUnit + "\t");
                strFileContents.Append(objItem.ItemTaxKey1 + "\t");
                strFileContents.Append("\n");
                i = i + 1;
            }

            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportHybridBackendLoadRequestDetails(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;
        bool IsFinalApprover = false;

        string MovementCode = (Session["MovementCode_Consolidated"] != null) ? Session["MovementCode_Consolidated"].ToString() : "";

        List<MovementDetail> lstMovementDetail = new MovementHeaderFacade().GetConsolidatedMovementDetail(MovementCode);

        if (lstMovementDetail != null && lstMovementDetail.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("MovementCode" + "\t" + "ItemCode" + "\t" + "UOM" + "\t" + "Quantity" + "\t");
            strFileContents.Append("\n");
            foreach (MovementDetail objMovementDetail in lstMovementDetail)
            {
                strFileContents.Append(objMovementDetail.MovementCode + "\t");
                strFileContents.Append(objMovementDetail.ItemCode + "\t");
                strFileContents.Append(objMovementDetail.UOM + "\t");
                strFileContents.Append(objMovementDetail.InProcessQuantity + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }

    }
    private void ExportCustomerDetails(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        StringBuilder strFileInnerContents = null;
        string SearchString = "1=1";
        string withoutVat = "";
        string withoutJourneyPlan = "";
        if (Session["CustomerDetails"] != null)
        {
            SearchString = CommonFunctions.getStringValue(Session["CustomerDetails"]);
        }
        if (Session["withoutJourneyPlan"] != null)
        {
            withoutJourneyPlan = CommonFunctions.getStringValue(Session["withoutJourneyPlan"]);
        }
        if (Session["withoutVat"] != null)
        {
            withoutVat = CommonFunctions.getStringValue(Session["withoutVat"]);
        }
        //List<Customer> objCustomersList = (new CustomerFacade()).GetCustomerAndCustomerDetailsByUser_Export(SearchString, SessionManager.UserCode);
        List<Customer> objCustomersList = GetCustomerAndCustomerDetailsByUser_Export(SearchString, SessionManager.UserCode, withoutVat, withoutJourneyPlan);

        if (objCustomersList != null && objCustomersList.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SL No" + "\t" + "Company" + "\t" + "Cust_Number" + "\t" + "Cust_Name in English" + "\t"

                + "Parent_Number" + "\t" + "Parent_Name in English" + "\t"
                + "Customer VAT No:" + "\t"
                + "Route" + "\t" + "Customer_Price_Group" + "\t"
                + "Lattitude" + "\t" + "Longitude" + "\t" + "Contact Person Name:" + "\t"
                + "Contact Person No" + "\t" + "Customer Address:" + "\t" + "Region Name" + "\t" + "City" + "\t" + "Customer_Type" + "\t" + "Channel_Code" + "\t"
                 + "Channel_Desc" + "\t"
                + "Classification" + "\t" + "CREDIT LIMIT" + "\t" + "CREDIT DAYS" + "\t" + "IsActive" + "\t" + "Allow good returns" + "\t"
                + "Allow bad returns" + "\t" + "Negative invoice allowed" + "\t" + "Is Tax Applicable" + "\t" + "Number of Invoices");
            strFileContents.Append("\n");
            int i = 1;

            foreach (Customer objCustomer in objCustomersList)
            {
                strFileContents.Append(i + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.SalesOrgCode) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.SalesOrgCode)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.Code) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.Code)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.CustomerName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.CustomerName)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.ParentCode) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.ParentCode)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.ParentName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.ParentName)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.TaxKeyField) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.TaxKeyField)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.RouteCode) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.RouteCode)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.PriceList) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.PriceList)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.GEO_CODE_Y) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.GEO_CODE_Y)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.GEO_CODE_X) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.GEO_CODE_X)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.ContactPersonName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.ContactPersonName)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.ContactNo1) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.ContactNo1)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.Address1) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.Address1)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.RegionName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.RegionName)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.City) == "" ? "N/A" : "[" + CommonFunctions.GetStringValue(objCustomer.CityCode) + "] " + CommonFunctions.GetStringValue(objCustomer.City)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.PAYMENT_TYPE) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.PAYMENT_TYPE)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.ChannelCode) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.ChannelCode)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.ChannelName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.ChannelName)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.Classification) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.Classification)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.CreditLimit) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.CreditLimit)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.CreditDays) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.CreditDays)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.IsActive) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.IsActive == true ? "True" : "False")) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.AllowGoodReturns) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.AllowGoodReturns == 1 ? "true" : "False")) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.AllowBadReturns) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.AllowBadReturns == 1 ? "true" : "False")) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.IsNegativeStockAllowed) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.IsNegativeStockAllowed == 1 ? "true" : "False")) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.Att5) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.Att5)) + "\t");
                strFileContents.Append((CommonFunctions.GetStringValue(objCustomer.NoofOutstandingInvoices) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomer.NoofOutstandingInvoices)) + "\t");
                strFileContents.Append("\n");
                i++;
                //// strFileContents.Append("\t\t\t\tCustomer Details\n");

                //strFileInnerContents = new StringBuilder();
                //strFileContents.Append(strFileInnerContents.ToString());
                //if (objCustomer.objCustomerDetails != null)
                //{
                //    int j = 1;
                //    strFileInnerContents.Append("\t\tSales Organiaztin Details\n");
                //    strFileInnerContents.Append("\tCustomer Code" + "\t" + "SalesOrganization Code" + "\t" + "Customer Site Status" + "\t" + "SalesOffice" + "\t" + "Channel Code" + "\t" + "Channel" + "\t" +
                //    "Sub Channel Code" + "\t" + "Sub Channel  Name" + "\t" +
                //    "Sub Sub Channel Code" + "\t" + "Sub Sub Channel  Name" + "\t" +
                //    "CustomerTypeCode " + "\t" + "CustomerType Name" + "\t" + "Payment Type" + "\t" +
                //    "Payment Mode" + "\t" + "Credit Days " + "\t" + "Credit Limit" + "\t" + "No of OutStanding Invoices" + "\t" + "Authorized Item GRPKey" + "\t" + "MessageKey" + "\t" + "TaxKeyField" + "\t"
                //    + "Promotion Key" + "\t" + "Seller Credit Limit" + "\t" + "DistributorCode" + "\t" + "DistributorName" + "\t"
                //    + "Customer Group Code" + "\t" + "Customer Group" + "\t" + "Price List Code" + "\t" + "Price List Name" + "\t"
                //    + "Bill To" + "\t" + "Ship To" + "\t" + "Is Allow Cash On Credit Exceed" + "\t"
                //    + "Is Outstanding Bill Control" + "\t" + "Blocked Reason");
                //    strFileInnerContents.Append("\n");
                //    foreach (CustomerDetails objCustomerDetails in objCustomer.objCustomerDetails)
                //    {
                //        strFileInnerContents.Append("\t");
                //        //strFileInnerContents.Append(j + "\t");
                //        strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.CustomerId) + "\t");
                //        strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.SalesOrganizationCode) + "\t");
                //        // strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.SalesOrganization)  + "\t");
                //        strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.CustomerStatus) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.SalesOffice) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.SalesOffice)) + "\t");
                //        strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.ChannelCode) + "\t");
                //        //                      strFileInnerContents

                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.ChannelName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.ChannelName)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.SubChannelCode) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.SubChannelCode)) + "\t");
                //        strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.SubChannelName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.SubChannelName) + "\t");
                //        strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.SubSubChannelCode) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.SubSubChannelCode) + "\t");
                //        strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.SubSubChannelName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.SubSubChannelName) + "\t");
                //        //                      strFileInnerContents
                //        strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.CustomerTypeCode) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.CustomerTypeCode) + "\t");
                //        strFileInnerContents.Append(CommonFunctions.GetStringValue(objCustomerDetails.CustomerTypeName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.CustomerTypeName) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.PAYMENT_TYPE) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.PAYMENT_TYPE)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.PAYMENT_MODE) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.PAYMENT_MODE)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetIntValue(objCustomerDetails.CreditDays) == 0 ? "0" : CommonFunctions.GetStringValue(objCustomerDetails.CreditDays)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.getDoubleValue(objCustomerDetails.CreditLimit) <= 0 ? 0.0 : CommonFunctions.getDoubleValue(objCustomerDetails.CreditLimit)) + "\t");
                //        //                      strFileInnerContents
                //        strFileInnerContents.Append((CommonFunctions.GetIntValue(objCustomerDetails.NoofOutstandingInvoices) == 0 ? "0" : CommonFunctions.GetStringValue(objCustomerDetails.NoofOutstandingInvoices)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.AuthorizedItemGRPKey) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.AuthorizedItemGRPKey)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.MessageKey) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.MessageKey)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.TaxKeyField) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.TaxKeyField)) + "\t");
                //        //  strFileInnerContents
                //        //  strFileInnerContents

                //        // CommonFunctions.GetStringValue(objCustomerDetails.SellerCreditLimit) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.SellerCreditLimit) + "\t") ;
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.PromotionKey) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.PromotionKey)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.getDoubleValue(objCustomerDetails.SellerCreditLimit) <= 0 ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.SellerCreditLimit)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.DistributorCode) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.DistributorCode)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.DistributorName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.DistributorName)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.CustomerGroupCode) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.CustomerGroupCode)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.CustomerGroupName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.CustomerGroupName)) + "\t");
                //        //  strFileInnerContents

                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.PriceList) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.PriceList)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.PriceListName) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.PriceListName)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.BillTo) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.BillTo)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.ShipTo) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.ShipTo)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.getBooleanValue(objCustomerDetails.IsAllowCashOnCreditExceed) == false ? "false" : CommonFunctions.GetStringValue(objCustomerDetails.IsAllowCashOnCreditExceed)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.getBooleanValue(objCustomerDetails.IsOutstandingBillControl) == false ? "false" : CommonFunctions.GetStringValue(objCustomerDetails.IsOutstandingBillControl)) + "\t");
                //        strFileInnerContents.Append((CommonFunctions.GetStringValue(objCustomerDetails.BlockedReason) == "" ? "N/A" : CommonFunctions.GetStringValue(objCustomerDetails.BlockedReason)));
                //        strFileInnerContents.Append("\n");
                //        //strFileContents.Append(strFileInnerContents.ToString());
                //        j = j + 1;
                //    }
                //    strFileInnerContents.Append("\n");
                //}
                //else
                //{
                //    strFileInnerContents.Append("No  customer Details\n");
                //}
                //strFileContents.Append(strFileInnerContents.ToString());
                //i = i + 1;
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString(), UTF32Encoding.Unicode);
            sw.Close();
        }
    }

    public List<Customer> GetCustomerAndCustomerDetailsByUser_Export(string SearchString, string UserCode, string withoutvat, string withoutJourneyPlan)
    {
        Customer objCustomer = null;
        CustomerDetails objCustomerDetail = null;
        List<Customer> objCustomerList = new List<Customer>();
        DbParam[] param = new DbParam[4];
        DataSet ds;

        param[0] = new DbParam("@searchString", SearchString, SqlDbType.VarChar);
        param[1] = new DbParam("@UserCode", UserCode, SqlDbType.VarChar);
        param[2] = new DbParam("@withoutVat", withoutvat, SqlDbType.VarChar);
        param[3] = new DbParam("@withoutJourneyPlan", withoutJourneyPlan, SqlDbType.VarChar);

        ds = Db.GetDataSet("sp_tblCustomer_SELALL_Search_Export_V1", param);
        if (ds != null && ds.Tables.Count > 0)
        {
            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow drCustomer in ds.Tables[0].Rows)
                {
                    objCustomer = new Customer();
                    objCustomer.CustomerName = Db.ToString(drCustomer["CustomerName"]);
                    objCustomer.ArabicName = Db.ToString(drCustomer["CustomerArabicName"]);
                    objCustomer.Code = Db.ToString(drCustomer["Code"]);
                    objCustomer.CountryName = Db.ToString(drCustomer["Country"]);
                    objCustomer.CountryCode = Db.ToString(drCustomer["CountryCode"]);
                    //objCustomer.City = Db.ToString(drCustomer["City"]);
                    //objCustomer.CityCode = Db.ToString(drCustomer["CityCode"]);
                    objCustomer.RegionName = Db.ToString(drCustomer["Region"]);
                    objCustomer.RegionCode = Db.ToString(drCustomer["RegionCode"]);
                    objCustomer.CreatedBy = Db.ToString(drCustomer["CreatedBY"]);
                    objCustomer.ModifiedBy = Db.ToString(drCustomer["ModifiedBy"]);
                    if (drCustomer.Table.Columns.Contains("ContactPersonName"))
                        objCustomer.ContactPersonName = Db.ToString(drCustomer["ContactPersonName"]);
                    if (drCustomer.Table.Columns.Contains("ContactNo1"))
                        objCustomer.ContactNo1 = Db.ToString(drCustomer["ContactNo1"]);
                    if (drCustomer.Table.Columns.Contains("Address1"))
                        objCustomer.Address1 = Db.ToString(drCustomer["Address1"]);
                    if (drCustomer.Table.Columns.Contains("Address2"))
                        objCustomer.Address2 = Db.ToString(drCustomer["Address2"]);
                    objCustomer.EMAIL = Db.ToString(drCustomer["Email"]);
                    objCustomer.GEO_CODE_X = Db.ToString(drCustomer["Latitude"]);
                    objCustomer.GEO_CODE_Y = Db.ToString(drCustomer["Longitude"]);
                    objCustomer.CustomerStatus = Db.ToString(drCustomer["CustomerStatus"]);
                    objCustomer.ParentCode = Db.ToString(drCustomer["ParentCode"]);
                    objCustomer.ParentName = Db.ToString(drCustomer["ParentName"]);
                    objCustomer.ParentArabicName = Db.ToString(drCustomer["ParentArabicName"]);
                    objCustomer.IsNegativeStockAllowed = Db.ToInteger(drCustomer["IsNegativeStockAllowed"]);
                    objCustomer.Classification = Db.ToString(drCustomer["Classification"]);


                    objCustomer.CityCode = Db.ToString(drCustomer["CityCode"]);
                    objCustomer.City = Db.ToString(drCustomer["City"]);
                    objCustomer.SalesOrgCode = Db.ToString(drCustomer["SalesOrgCode"]);
                    objCustomer.CustomerStatus = Db.ToString(drCustomer["CustomerStatus"]);
                    objCustomer.SalesOffice = Db.ToString(drCustomer["SalesOfficeCode"]);
                    objCustomer.ChannelCode = Db.ToString(drCustomer["ChannelCode"]);
                    objCustomer.ChannelName = Db.ToString(drCustomer["ChannelName"]);
                    objCustomer.SubChannelCode = Db.ToString(drCustomer["SubChannelCode"]);
                    objCustomer.SubChannelName = Db.ToString(drCustomer["SubChannelName"]);
                    objCustomer.SubSubChannelCode = Db.ToString(drCustomer["SubSubChannelCode"]);
                    objCustomer.SubSubChannelName = Db.ToString(drCustomer["SubSubChannelName"]);
                    objCustomer.CustomerTypeName = Db.ToString(drCustomer["CustomerTypeDescription"]);
                    objCustomer.CustomerType = Db.ToString(drCustomer["CustomerTypeCode"]);
                    objCustomer.PAYMENT_TYPE = Db.ToString(drCustomer["PaymentType"]);
                    objCustomer.PAYMENT_MODE = Db.ToString(drCustomer["PaymentMode"]);
                    objCustomer.CreditDays = Db.ToInteger(drCustomer["CreditDays"]);
                    objCustomer.CreditLimit = Db.ToFloat(drCustomer["CreditLimit"]);
                    objCustomer.NoofOutstandingInvoices = Db.ToInteger(drCustomer["NoofOutstandingInvoices"]);
                    objCustomer.AuthorizedItemGRPKey = Db.ToString(drCustomer["AuthorizedItemGRPKey"]);
                    objCustomer.TaxKeyField = Db.ToString(drCustomer["TaxKeyField"]);
                    objCustomer.PromotionKey = Db.ToString(drCustomer["PromotionKey"]);
                    objCustomer.MessageKey = Db.ToString(drCustomer["MessageKey1"]);
                    objCustomer.Distributor = Db.ToString(drCustomer["Distributor"]);
                    objCustomer.RouteCode = Db.ToString(drCustomer["RouteCode"]);
                    objCustomer.RouteName = Db.ToString(drCustomer["RouteName"]);
                    objCustomer.CustomerGroupCode = Db.ToString(drCustomer["CustomerGroupCode"]);
                    objCustomer.PriceList = Db.ToString(drCustomer["PriceListCode"]);
                    objCustomer.PriceListName = Db.ToString(drCustomer["PriceListDescription"]);
                    objCustomer.BillTo = Db.ToString(drCustomer["BillTo"]);
                    objCustomer.ShipTo = Db.ToString(drCustomer["ShipTo"]);
                    objCustomer.IsAllowCashOnCreditExceed = Db.ToBoolean(drCustomer["IsAllowCashOnCreditExceed"]);
                    objCustomer.IsOutstandingBillControl = Db.ToBoolean(drCustomer["IsOutstandingBillControl"]);
                    objCustomer.BlockedReason = Db.ToString(drCustomer["BlockedReason"]);
                    objCustomer.CustomerGroupName = Db.ToString(drCustomer["CustomerGroupName"]);
                    objCustomer.Att5 = Db.ToString(drCustomer["Att5"]);
                    objCustomer.AllowBadReturns = Db.ToInteger(drCustomer["AllowBadReturns"]);
                    objCustomer.AllowGoodReturns = Db.ToInteger(drCustomer["AllowGoodReturns"]);
                    objCustomer.IsActive = Db.ToBoolean(drCustomer["IsActive"]);


                    //if (ds.Tables.Count > 1 && ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                    //{
                    //    DataRow[] drCustomerDetailsList = ds.Tables[1].Select("CustomerCode='" + objCustomer.Code + "'");
                    //    foreach (DataRow drCustumerDetail in drCustomerDetailsList)
                    //    {
                    //        objCustomerDetail = new CustomerDetails();
                    //        objCustomerDetail.CustomerId = Db.ToString(drCustumerDetail["CustomerCode"]);
                    //        objCustomerDetail.SalesOrganization = Db.ToString(drCustumerDetail["SalesOrganization"]);
                    //        objCustomerDetail.SalesOrganizationCode = Db.ToString(drCustumerDetail["SalesOrganizationCode"]);
                    //        objCustomerDetail.CustomerStatus = Db.ToString(drCustumerDetail["CustomerStatus"]);
                    //        objCustomerDetail.SalesOffice = Db.ToString(drCustumerDetail["SalesOfficeCode"]);
                    //        objCustomerDetail.ChannelCode = Db.ToString(drCustumerDetail["ChannelCode"]);
                    //        objCustomerDetail.ChannelName = Db.ToString(drCustumerDetail["ChannelName"]);
                    //        objCustomerDetail.SubChannelCode = Db.ToString(drCustumerDetail["SubChannelCode"]);
                    //        objCustomerDetail.SubChannelName = Db.ToString(drCustumerDetail["SubChannelName"]);
                    //        objCustomerDetail.SubSubChannelCode = Db.ToString(drCustumerDetail["SubSubChannelCode"]);
                    //        objCustomerDetail.SubSubChannelName = Db.ToString(drCustumerDetail["SubSubChannelName"]);
                    //        objCustomerDetail.CustomerTypeName = Db.ToString(drCustumerDetail["CustomerTypeDescription"]);
                    //        objCustomerDetail.CustomerTypeCode = Db.ToString(drCustumerDetail["CustomerTypeCode"]);
                    //        objCustomerDetail.PAYMENT_TYPE = Db.ToString(drCustumerDetail["PaymentType"]);
                    //        objCustomerDetail.PAYMENT_MODE = Db.ToString(drCustumerDetail["PaymentMode"]);
                    //        objCustomerDetail.CreditDays = Db.ToInteger(drCustumerDetail["CreditDays"]);
                    //        objCustomerDetail.CreditLimit = Db.ToDouble(drCustumerDetail["CreditLimit"]);
                    //        objCustomerDetail.NoofOutstandingInvoices = Db.ToInteger(drCustumerDetail["NoofOutstandingInvoices"]);
                    //        objCustomerDetail.AuthorizedItemGRPKey = Db.ToString(drCustumerDetail["AuthorizedItemGRPKey"]);
                    //        objCustomerDetail.TaxKeyField = Db.ToString(drCustumerDetail["TaxKeyField"]);
                    //        objCustomerDetail.PromotionKey = Db.ToString(drCustumerDetail["PromotionKey"]);
                    //        objCustomerDetail.MessageKey = Db.ToString(drCustumerDetail["MessageKey1"]);
                    //        objCustomerDetail.SellerCreditLimit = Db.ToFloat(drCustumerDetail["SellerCreditLimit"]);
                    //        objCustomerDetail.Distributor = Db.ToString(drCustumerDetail["Distributor"]);
                    //        objCustomerDetail.DistributorCode = Db.ToString(drCustumerDetail["DistributorCode"]);
                    //        objCustomerDetail.DistributorName = Db.ToString(drCustumerDetail["DistributorName"]);
                    //        objCustomerDetail.Route = Db.ToString(drCustumerDetail["RouteCode"]);
                    //        objCustomerDetail.RouteName = Db.ToString(drCustumerDetail["RouteName"]);
                    //        objCustomerDetail.CustomerGroupCode = Db.ToString(drCustumerDetail["CustomerGroupCode"]);
                    //        objCustomerDetail.PriceList = Db.ToString(drCustumerDetail["PriceListCode"]);
                    //        objCustomerDetail.PriceListName = Db.ToString(drCustumerDetail["PriceListDescription"]);
                    //        objCustomerDetail.BillTo = Db.ToString(drCustumerDetail["BillTo"]);
                    //        objCustomerDetail.ShipTo = Db.ToString(drCustumerDetail["ShipTo"]);
                    //        objCustomerDetail.IsAllowCashOnCreditExceed = Db.ToBoolean(drCustumerDetail["IsAllowCashOnCreditExceed"]);
                    //        objCustomerDetail.IsOutstandingBillControl = Db.ToBoolean(drCustumerDetail["IsOutstandingBillControl"]);
                    //        objCustomerDetail.BlockedReason = Db.ToString(drCustumerDetail["BlockedReason"]);
                    //        objCustomerDetail.CustomerGroupName = Db.ToString(drCustumerDetail["CustomerGroupName"]);
                    //        objCustomer.objCustomerDetails.Add(objCustomerDetail);
                    //    }
                    //}
                    objCustomerList.Add(objCustomer);
                }

            }

        }
        return objCustomerList;
    }

    public List<Route> GetRoutes(string SortExpression, int maximumrows, int startrowindex, string SearchString)
    {
        Route Route = null;
        List<Route> objRouteList = new List<Route>();
        DbParam[] param = new DbParam[4];
        DataSet ds;

        param[0] = new DbParam("@SortExpression", SortExpression, SqlDbType.VarChar);
        param[1] = new DbParam("@maximumrows", maximumrows, SqlDbType.Int);
        param[2] = new DbParam("@startrowindex", startrowindex, SqlDbType.Int);
        param[3] = new DbParam("@searchString", SearchString, SqlDbType.VarChar);

        ds = Db.GetDataSet("sp_tblGetRoutes_SELALL_Search_Export", param);
        if (ds != null && ds.Tables.Count > 0)
        {
            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    Route = new Route();

                    Route.RouteId = Db.ToInteger(row["RouteId"]);
                    Route.Name = Db.ToString(row["Name"]);
                    Route.Code = Db.ToString(row["Code"]);
                    Route.SalesOrgCode = Db.ToString(row["SalesOrgCode"]);
                    Route.SalesOrgName = Db.ToString(row["SalesOrgName"]);
                    Route.AreaCode = Db.ToString(row["AreaCode"]);
                    Route.AreaName = Db.ToString(row["AreaName"]);
                    Route.SubAreaCode = Db.ToString(row["SubAreaCode"]);
                    Route.IsForceJPOnly = Db.ToInteger(row["IsForceJPOnly"]);
                    Route.SubAreaName = Db.ToString(row["SubAreaName"]);
                    Route.ArabicName = Db.ToString(row["ArabicName"]);
                    Route.SalesmanCode = Db.ToString(row["SalesmanCode"]);
                    Route.CreditLimit = Db.ToFloat(row["CreditLimit"]);
                    Route.IsActive = Db.ToBoolean(row["IsActive"]);
                    Route.RouteItemGroupCode = Db.ToString(row["RouteItemGroupCode"]);
                    Route.RouteCatCode = Db.ToString(row["RouteCatCode"]);
                    Route.Capacity = Db.ToInteger(row["Capacity"]);
                    Route.CreatedOn = Db.ToDateTime(row["CreatedOn"]);
                    Route.SalesmanName = Db.ToString(row["SalesmanName"]);
                    Route.SupervisorCode = Db.ToString(row["SupervisorCode"]);
                    Route.SupervisorName = Db.ToString(row["SupervisorName"]);
                    Route.WHCode = Db.ToString(row["WHCode"]);
                    Route.LoadingDays = Db.ToString(row["LoadingDays"]);
                    Route.RouteCategory = Db.ToString(row["RouteCategorys"]);
                    string Attribute15 = Db.ToString(row["Attribute15"]);
                    string[] Attribute4Arr = Attribute15.Split(',');

                    if (Attribute4Arr.Count() >= 6)
                        Route.RouteType = "Short route";
                    else if (Attribute4Arr.Count() <= 3)
                        Route.RouteType = "Long route";
                    else if (Attribute4Arr.Count() < 6 && Attribute4Arr.Count() > 3)
                        Route.RouteType = "Long and short route";
                    //Stock audit days
                    Route.Attribute1 = Db.ToString(row["Attribute14"]);
                    //Cashier days
                    Route.Attribute2 = Db.ToString(row["Attribute15"]);

                    if (row.Table.Columns.Contains("WHCode"))
                        Route.TripDateType = "[" + Db.ToString(row["WHCode"]) + "] " + Db.ToString(row["WHName"]);
                    if (row.Table.Columns.Contains("AllowEditGeoCode"))
                        Route.AllowEditGeoCode = Db.ToBoolean(row["AllowEditGeoCode"]);
                    if (row.Table.Columns.Contains("IsSKUQtyNeedtoCheck"))
                        Route.IsSKUQtyNeedtoCheck = Db.ToInteger(row["IsSKUQtyNeedtoCheck"]);
                    if (row.Table.Columns.Contains("AssetTracking"))
                        Route.AssetTracking = Db.ToBoolean(row["AssetTracking"]);

                    objRouteList.Add(Route);
                }

            }

        }
        return objRouteList;
    }
    private void ExportJourneyPlan(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        int JourneyPlanId = Convert.ToInt32(Session["JourneyPlanId"].ToString());


        JPHeader objJPHeader = new JourneyPlanFacadeNew().GetJourneyPlanExport(JourneyPlanId);

        if (objJPHeader != null)
        {
            strFileContents = new StringBuilder();

            strFileContents.Append("Journey Plan Name\t" + objJPHeader.Name + "\n");
            strFileContents.Append("Description\t" + objJPHeader.Description + "\n");
            strFileContents.Append("Starts On\t" + objJPHeader.StartDate + "\n");
            strFileContents.Append("Ends On\t" + objJPHeader.EndDate + "\n");
            strFileContents.Append("Country\t" + objJPHeader.Country + "\n");
            strFileContents.Append("Route Code\t" + objJPHeader.UserCode + "\n");
            strFileContents.Append("Route Name\t" + objJPHeader.UserName + "\n");
            strFileContents.Append("Division Code\t" + objJPHeader.DivisionCode + "\n");
            strFileContents.Append("Division \t" + objJPHeader.DivisionName + "\n");
            strFileContents.Append("Schedule \t" + objJPHeader.Type + "\n");

            if (objJPHeader.JPDetails != null && objJPHeader.JPDetails.Count > 0)
            {
                strFileContents.Append("\n\nCustomer Code\t Customer Name \t");
                if (objJPHeader.Type.ToLower() == "week")
                {
                    strFileContents.Append("Week\tDay\n");
                }
                else
                {
                    strFileContents.Append("Day\n");
                }

                foreach (JPDetail objJPDetail in objJPHeader.JPDetails)
                {
                    strFileContents.Append(objJPDetail.CustomerCode + "\t");
                    strFileContents.Append(objJPDetail.Description + "\t");
                    if (objJPHeader.Type.ToLower() == "week")
                    {
                        strFileContents.Append(objJPDetail.Type + "\t");
                        strFileContents.Append(objJPDetail.JpDay + "\n");

                    }
                    else
                    {
                        strFileContents.Append(objJPDetail.Type + " " + objJPDetail.JpDay + "\n");
                    }
                }
            }
            strFileContents.Append("\n");
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }

    }



    private void ExportCustomerReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;
        bool IsFinalApprover = false;

        if (Request.QueryString["searchString"] != null)
        {
            FilterValue = Request.QueryString["searchString"].ToString();
        }

        string hndSalesmanCode = CommonFunctions.getStringValue(Session["hndSalesmanCode"]);
        string hndSalesManagerCode = CommonFunctions.getStringValue(Session["hndSalesManagerCode"]);
        string hndDivision = CommonFunctions.getStringValue(Session["hndDivision"]);
        string hndLocation = CommonFunctions.getStringValue(Session["hndLocation"]);
        string hndSearchValue = CommonFunctions.getStringValue(Session["hndSearchValue"]);
        string hndRoute = CommonFunctions.getStringValue(Session["hndRoute"]);

        DateTime hndStartDate = Convert.ToDateTime(Session["hndStartDate"]);
        DateTime hndEndDate = Convert.ToDateTime(Session["hndEndDate"]);


        IList<CustomerReport> lst = new CustomerReportFacade().GetCustomerReportSearch_Export("U.CODE ASC", hndSearchValue, hndSalesmanCode, hndSalesManagerCode, hndStartDate, hndEndDate, hndLocation, hndDivision, hndRoute);

        if (lst != null && lst.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SalesManCode" + "\t" + "SalesMan Name" + "\t" + "TotalCustomers" + "\t" + "Active Customers" + "\t" + "Perfect Customers" + "\t" + "New Customers" + "\t" + "Cash Customers" + "\t" + "Credit Customers" + "\t" + "Blocked Customers" + "\t" + "Skipped Customers" + "\t");
            strFileContents.Append("\n");
            foreach (CustomerReport obj in lst)
            {
                strFileContents.Append(obj.SalesmanCode + "\t");
                strFileContents.Append(obj.SalesmanName + "\t");
                strFileContents.Append(obj.TotalCustomers + "\t");
                strFileContents.Append(obj.TotalActiveCustomers + "\t");
                strFileContents.Append(obj.TotalPerfectCustomers + "\t");
                strFileContents.Append(obj.TotalNewCustomers + "\t");
                strFileContents.Append(obj.TotalCashCustomers + "\t");
                strFileContents.Append(obj.TotalCreditCustomers + "\t");
                strFileContents.Append(obj.TotalBlokedCustomers + "\t");
                strFileContents.Append(obj.TotalSkippedCustomers + "\t");
                strFileContents.Append("\n");
                if (obj.Customers.Count > 0)
                {
                    strFileContents.Append("CustomerCode" + "\t" + "Description" + "\t" + "CustomerType" + "\t" + "IsActive" + "\t" + "IsBlocked" + "\t" + "VisitStatus" + "\t");
                    strFileContents.Append("\n");

                    foreach (var objCustomer in obj.Customers)
                    {
                        strFileContents.Append(objCustomer.Code + "\t");
                        strFileContents.Append(objCustomer.Description + "\t");
                        strFileContents.Append(objCustomer.CustomerType + "\t");
                        strFileContents.Append(objCustomer.IsActive + "\t");
                        strFileContents.Append(objCustomer.IsBlocked + "\t");
                        strFileContents.Append(objCustomer.VisitStatus + "\t");
                        strFileContents.Append("\n");
                    }
                }


            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportPricing(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;
        bool IsFinalApprover = false;

        if (Request.QueryString["searchString"] != null)
        {
            FilterValue = Request.QueryString["searchString"].ToString();
        }
        if (Request.QueryString["IsFinalApprover"] != null)
        {
            IsFinalApprover = (Request.QueryString["IsFinalApprover"].ToString() == "1") ? true : false;
        }

        List<Pricing> lst = new PriceListFacade().GetPricingsForExport(FilterValue, "", IsFinalApprover);

        if (lst != null && lst.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("ItemCode" + "\t" + "Item Description" + "\t" + "UOM" + "\t" + "Price" + "\t" + "Start Date" + "\t" + "End Date" + "\t");
            strFileContents.Append("\n");
            foreach (Pricing obj in lst)
            {
                strFileContents.Append(obj.ItemCode + "\t");
                strFileContents.Append(obj.ItemDescription + "\t");
                strFileContents.Append(obj.UOM + "\t");
                //strFileContents.Append(obj.PriceListClassification + "\t");
                //strFileContents.Append(obj.PriceListClassificationCode + "\t");
                strFileContents.Append(obj.Price.ToString() + "\t");
                //strFileContents.Append(obj.DummyPrice.ToString() + "\t");
                //strFileContents.Append(obj.MinQty.ToString() + "\t");
                //strFileContents.Append(obj.MaxQty.ToString() + "\t");
                strFileContents.Append((obj.StartDate.Year != 1900 ? Convert.ToDateTime(obj.StartDate.ToShortDateString()).ToString("dd-MM-yyyy") : "") + "\t");
                strFileContents.Append((obj.EndDate.Year != 1900 ? Convert.ToDateTime(obj.EndDate.ToShortDateString()).ToString("dd-MM-yyyy") : "") + "\t");
                //strFileContents.Append(obj.PriceProtctionPeriod.ToString() + "\t");
                //strFileContents.Append(obj.CreditDays.ToString() + "\t");
                //strFileContents.Append((obj.ProtectionApprovalRequired ? "Yes" : "No") + "\t");
                // strFileContents.Append((obj.ProtectionByPrincipal ? "Yes" : "No") + "\t");
                //strFileContents.Append(obj.PriceListCode.ToString() + "\t");
                //strFileContents.Append(obj.CurrencyCode.ToString() + "\t");
                //strFileContents.Append(obj.DummyPrice.ToString() + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }


    private void ExportFrozenReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FrozenSdate = "";

        FrozenSdate = Session["FrozenSdate"].ToString() == null ? "" : Session["FrozenSdate"].ToString();

        string FrozenEDate = Session["FrozenEDate"].ToString() == null ? "" : Session["FrozenEDate"].ToString();
        string FrozenDepot = Session["FrozenDepot"].ToString() == null ? "" : Session["FrozenDepot"].ToString();
        string FrozenRoute = Session["FrozenRoute"].ToString() == null ? "" : Session["FrozenRoute"].ToString();
        string FrozenItem = Session["FrozenItem"].ToString() == null ? "" : Session["FrozenItem"].ToString();
        string FrozenCustomer = Session["FrozenCustomer"].ToString() == null ? "" : Session["FrozenCustomer"].ToString();

        List<FrozenCheckStore> lst = new FrozenStoreFacade().GetFrozenCheckStoreSearchExport(FrozenCustomer, FrozenItem, FrozenRoute, FrozenDepot, FrozenSdate, FrozenEDate);

        if (lst != null && lst.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("ItemCode" + "\t" + "ItemName" + "\t" + "SubChannelCode" + "\t" + "RouteCode" + "\t" + "CustomerCode" + "\t" + "CustomerName" + "\tItemAvailable" + "\tStoreCheckDate" + "\n");
            strFileContents.Append("\n");
            foreach (FrozenCheckStore obj in lst)
            {
                strFileContents.Append(obj.ItemCode + "\t");
                strFileContents.Append(obj.ItemName + "\t");
                strFileContents.Append(obj.SubChannelCode + "\t");
                strFileContents.Append(obj.RouteCode.ToString() + "\t");
                strFileContents.Append(obj.CustomerCode.ToString() + "\t");
                strFileContents.Append(obj.CustomerName.ToString() + "\t");
                strFileContents.Append(((obj.ItemAvailable.ToString()) == "0" ? "Avialable" : "Not Avialable") + "\t");
                strFileContents.Append(Convert.ToDateTime(obj.StoreCheckDate.ToShortDateString()).ToString("dd-MM-yyyy") + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportAmbientReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FrozenSdate = "";

        FrozenSdate = Session["AmbientSdate"].ToString() == null ? "" : Session["AmbientSdate"].ToString();

        string FrozenEDate = Session["AmbientEDate"].ToString() == null ? "" : Session["AmbientEDate"].ToString();
        string FrozenDepot = Session["AmbientDepot"].ToString() == null ? "" : Session["AmbientDepot"].ToString();
        string FrozenRoute = Session["AmbientRoute"].ToString() == null ? "" : Session["AmbientRoute"].ToString();
        string FrozenItem = Session["AmbientItem"].ToString() == null ? "" : Session["AmbientItem"].ToString();
        string FrozenCustomer = Session["AmbientCustomer"].ToString() == null ? "" : Session["AmbientCustomer"].ToString();

        List<FrozenCheckStore> lst = new FrozenStoreFacade().GetAmbientStoreSearchExport(FrozenCustomer, FrozenItem, FrozenRoute, FrozenDepot, FrozenSdate, FrozenEDate);

        if (lst != null && lst.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("ItemCode" + "\t" + "ItemName" + "\t" + "RouteCode" + "\t" + "CustomerCode" + "\t" + "CustomerName" + "\t ShelfQty" + "\t ShelfUOM" + "\t StoreCheckDate" + "\t ExpiryDate" + "\n");

            foreach (FrozenCheckStore obj in lst)
            {
                strFileContents.Append(obj.ItemCode.Trim() + "\t");
                strFileContents.Append(obj.ItemName.Trim() + "\t");
                strFileContents.Append(obj.RouteCode.ToString().Trim() + "\t");
                strFileContents.Append(obj.CustomerCode.ToString().Trim() + "\t");
                strFileContents.Append(obj.CustomerName.ToString().Trim() + "\t");
                strFileContents.Append(obj.StockQuantity.ToString().Trim() + "\t");
                strFileContents.Append(obj.ShelfUOM.ToString().Trim() + "\t");
                strFileContents.Append(Convert.ToDateTime(obj.StoreCheckDate.ToShortDateString()).ToString("dd-MM-yyyy") + "\t");
                strFileContents.Append(obj.Expirydate.ToString() == "" ? "NA" : obj.Expirydate.ToString() + "\t");

                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ShareofShelfReportExportExcel(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            string SortExpression = "CreatedOn DESC";
            StringBuilder strFileContents = null;
            int MaximumRows = 1000000;
            int StartRowIndex = 0;
            string searchString = Session["SessionShareofShelfReportSearch"] != null ? Session["SessionShareofShelfReportSearch"].ToString() : "1=1";
            strFileContents = new StringBuilder();
            IList<ShareOfShelfReport> lst = new ShareofShelfReportDao().GetShareofShelfReportSearch(SortExpression, MaximumRows, StartRowIndex, searchString, SessionManager.UserCode);
            strFileContents.Append("Date\t RouteName \tMerchandiser Code \tMerchandiser Name \tCustomer Code \tCustomer Name  \tCategory \tTarget% \tAchieved%  \tOur Area \tCompetitor Area ");
            strFileContents.Append("\n");
            int i = 0;
            foreach (ShareOfShelfReport obj in lst)
            {

                strFileContents.Append(obj.CreatedOn != null ? Convert.ToDateTime(obj.CreatedOn).ToString("yyyy-MM-dd") + "\t" : "N/A" + "\t ");
                //strFileContents.Append(obj.RouteCode != null ? (obj.RouteCode != "" ? CommonFunctions.GetStringValue(obj.RouteCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.RouteName != null ? (obj.RouteName != "" ? CommonFunctions.GetStringValue(obj.RouteName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.UserCode != null ? (obj.UserCode != "" ? CommonFunctions.GetStringValue(obj.UserCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.UserName != null ? (obj.UserName != "" ? CommonFunctions.GetStringValue(obj.UserName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.CustomerCode != null ? (obj.CustomerCode != "" ? CommonFunctions.GetStringValue(obj.CustomerCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.CustomerName != null ? (obj.CustomerName != "" ? CommonFunctions.GetStringValue(obj.CustomerName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.CategoryCode != null ? (obj.CategoryCode != "" ? CommonFunctions.GetStringValue(obj.CategoryCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.TargetPercentage + "\t");
                strFileContents.Append(obj.AchievedPercentage + "\t");
                //strFileContents.Append(obj.TargetPercentage != null ? (obj.TargetPercentage != "" ? CommonFunctions.GetStringValue(obj.TargetPercentage) : "N/A") + "\t" : "N/A" + "\t ");
                //strFileContents.Append(obj.AchievedPercentage != null ? (obj.AchievedPercentage != "" ? CommonFunctions.GetStringValue(obj.AchievedPercentage) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.OurArea != null ? (obj.OurArea != "" ? CommonFunctions.GetStringValue(obj.OurArea) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.OtherArea != null ? (obj.OtherArea != "" ? CommonFunctions.GetStringValue(obj.OtherArea) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append("\n");

            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    private void ExpiryCheckReportExportExcel(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            string SortExpression = "CP.CustomerCode, CP.ItemCode ASC";
            StringBuilder strFileContents = null;
            int MaximumRows = 1000000;
            int StartRowIndex = 0;
            string searchString = Session["SessionExpiryCheckReportSearch"] != null ? Session["SessionExpiryCheckReportSearch"].ToString() : "1=1";
            strFileContents = new StringBuilder();
            IList<ExpiryCheckReport> lst = new ExpiryCheckReportDao().GetExpiryCheckReportSearch(SortExpression, MaximumRows, StartRowIndex, searchString, SessionManager.UserCode);
            strFileContents.Append("Date\tRouteCode \tRouteName \tMerchandiser Code \tMerchandiser Name \tCustomer Code \tCustomer Name  \tCategory \tItemCode \tItemName \tUOM \tQTY  \tExpiryDate");
            strFileContents.Append("\n");
            int i = 0;
            foreach (ExpiryCheckReport obj in lst)
            {
                // Safe DateTime parsing for VisitedDate
                string visitedDateStr = "N/A";
                if (obj.VisitedDate != null && !string.IsNullOrWhiteSpace(obj.VisitedDate))
                {
                    DateTime visitedDate;
                    if (DateTime.TryParse(obj.VisitedDate, out visitedDate))
                    {
                        visitedDateStr = visitedDate.ToString("yyyy-MM-dd");
                    }
                }
                strFileContents.Append(visitedDateStr + "\t");

                strFileContents.Append(obj.RouteCode != null ? (obj.RouteCode != "" ? CommonFunctions.GetStringValue(obj.RouteCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.RouteName != null ? (obj.RouteName != "" ? CommonFunctions.GetStringValue(obj.RouteName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.UserCode != null ? (obj.UserCode != "" ? CommonFunctions.GetStringValue(obj.UserCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.UserName != null ? (obj.UserName != "" ? CommonFunctions.GetStringValue(obj.UserName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.CustomerCode != null ? (obj.CustomerCode != "" ? CommonFunctions.GetStringValue(obj.CustomerCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.CustomerName != null ? (obj.CustomerName != "" ? CommonFunctions.GetStringValue(obj.CustomerName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.Category != null ? (obj.Category != "" ? CommonFunctions.GetStringValue(obj.Category) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.ItemCode != null ? (obj.ItemCode != "" ? CommonFunctions.GetStringValue(obj.ItemCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.ItemName != null ? (obj.ItemName != "" ? CommonFunctions.GetStringValue(obj.ItemName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.UOM != null ? (obj.UOM != "" ? CommonFunctions.GetStringValue(obj.UOM) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.QTY != null ? (obj.QTY != "" ? CommonFunctions.GetStringValue(obj.QTY) : "N/A") + "\t" : "N/A" + "\t ");

                // Safe DateTime parsing for ExpiryDate
                string expiryDateStr = "N/A";
                if (obj.ExpiryDate != null && !string.IsNullOrWhiteSpace(obj.ExpiryDate))
                {
                    DateTime expiryDate;
                    if (DateTime.TryParse(obj.ExpiryDate, out expiryDate))
                    {
                        expiryDateStr = expiryDate.ToString("yyyy-MM-dd");
                    }
                }
                strFileContents.Append(expiryDateStr + "\t");
                strFileContents.Append("\n");

            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void PriceCheckReportExportExcel(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            string SortExpression = "VisitedDate DESC";
            StringBuilder strFileContents = null;
            int MaximumRows = 1000000;
            int StartRowIndex = 0;
            string searchString = Session["SessionPriceCheckReportSearch"] != null ? Session["SessionPriceCheckReportSearch"].ToString() : "1=1";
            strFileContents = new StringBuilder();
            // Use the new export method that includes competitor information
            IList<PriceCheckReport> lst = new PriceCheckReportFacade().GetPriceCheckReportExport(SortExpression, MaximumRows, StartRowIndex, searchString, SessionManager.UserCode);
            // Updated header with competitor columns
            strFileContents.Append("Date\tRouteCode \tRouteName \tUser Code \tUser Name \tCustomer Code \tCustomer Name  \tCategory \tItemCode \tItemName \tYaumiPrice  \tCompetitorBrand \tCompetitorInfo \tCompetitorPrice");
            strFileContents.Append("\n");
            int i = 0;
            foreach (PriceCheckReport obj in lst)
            {
                strFileContents.Append(obj.VisitedDate != null ? Convert.ToDateTime(obj.VisitedDate).ToString("yyyy-MM-dd") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.RouteCode != null ? (obj.RouteCode != "" ? CommonFunctions.GetStringValue(obj.RouteCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.RouteName != null ? (obj.RouteName != "" ? CommonFunctions.GetStringValue(obj.RouteName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.UserCode != null ? (obj.UserCode != "" ? CommonFunctions.GetStringValue(obj.UserCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.UserName != null ? (obj.UserName != "" ? CommonFunctions.GetStringValue(obj.UserName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.CustomerCode != null ? (obj.CustomerCode != "" ? CommonFunctions.GetStringValue(obj.CustomerCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.CustomerName != null ? (obj.CustomerName != "" ? CommonFunctions.GetStringValue(obj.CustomerName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.Category != null ? (obj.Category != "" ? CommonFunctions.GetStringValue(obj.Category) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.ItemCode != null ? (obj.ItemCode != "" ? CommonFunctions.GetStringValue(obj.ItemCode) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.ItemName != null ? (obj.ItemName != "" ? CommonFunctions.GetStringValue(obj.ItemName) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.LastVisitPrice != null ? (obj.LastVisitPrice != "" ? CommonFunctions.GetStringValue(obj.LastVisitPrice) : "N/A") + "\t" : "N/A" + "\t ");
                //strFileContents.Append(obj.RSP != null ? (obj.RSP != "" ? CommonFunctions.GetStringValue(obj.RSP) : "N/A") + "\t" : "N/A" + "\t ");
                //strFileContents.Append(obj.ShelfPrice != null ? (obj.ShelfPrice != "" ? CommonFunctions.GetStringValue(obj.ShelfPrice) : "N/A") + "\t" : "N/A" + "\t ");
                // Competitor columns
                strFileContents.Append(obj.CompetitorBrand != null ? (obj.CompetitorBrand != "" ? CommonFunctions.GetStringValue(obj.CompetitorBrand) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.CompetitorInfo != null ? (obj.CompetitorInfo != "" ? CommonFunctions.GetStringValue(obj.CompetitorInfo) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append(obj.CompetitorPrice != null ? (obj.CompetitorPrice != "" ? CommonFunctions.GetStringValue(obj.CompetitorPrice) : "N/A") + "\t" : "N/A" + "\t ");
                strFileContents.Append("\n");

            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }



    private void ExportSellingSKusDataGrid(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string GroupType = string.Empty;
            SearchString = (Session["SKU_SearchString"] != null) ? Session["SKU_SearchString"].ToString() : "1=1";
            GroupType = (Session["SKU_SKUTypeCode"] != null) ? Session["SKU_SKUTypeCode"].ToString() : "SKUC002";
            string SubSubChannelCode = (Session["SK_SSCHCode"] != null) ? Session["SK_SSCHCode"].ToString() : "N/A";
            string SubSubChannelName = (Session["SK_SSCHName"] != null) ? Session["SK_SSCHName"].ToString() : "N/A";
            SellingSKUResult objSellingSKUResult = new SellingSKUResult();
            objSellingSKUResult = new SellingSKUClassificationFacade().GetSellingSKUQtyResultExport(SearchString);

            if (objSellingSKUResult != null)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("ItemCode" + "\t" + "MinQty" + "\t" + "MaxQty" + "\t" + "Priority" + "\t" +
                   "MSL" + "\t" + "Item Description" + "\t" + "Item Type" + "\t" + "Category" + "\t" + "SubCategory" + "\t" + "SubSubChannelCode" + "\t" + "SubSubChannelName"
                   );

                //strFileContents.Append("Item Code" + "\t" + "Item Description" + "\t" + " Is MSL" + "\t" + "Item Type" + "\t" +
                //   "Min Qty" + "\t" + "Max Qty" + "\t" + "Category" + "\t" + "SubCategory" + "\t" + "SubSubChannelCode" + "\t" + "SubSubChannelName");
                //strFileContents.Append("Item Code" + "\t" + "Item Description" + "\t" + "Item Type" + "\t" +
                // "Min Qty" + "\t" + "Max Qty" + "\t" + "Category" + "\t" + "SubCategory");
                strFileContents.Append("\n");
                foreach (SellingSKUReport objSellingSKUReport in objSellingSKUResult.lstSellingSKUReport)
                {
                    strFileContents.Append(objSellingSKUReport.ItemCode + "\t");
                    strFileContents.Append(objSellingSKUReport.MinQty.ToString() + "\t");
                    strFileContents.Append(objSellingSKUReport.MaxQty.ToString() + "\t");
                    strFileContents.Append(objSellingSKUReport.Priority.ToString() + "\t");
                    strFileContents.Append((objSellingSKUReport.IsChecked == "checked" ? "1" : "0") + "\t");
                    strFileContents.Append(objSellingSKUReport.ItemName + "\t");
                    strFileContents.Append(objSellingSKUReport.ItemType + "\t");
                    strFileContents.Append(objSellingSKUReport.CategoryCode + "\t");
                    strFileContents.Append(objSellingSKUReport.SubCategoryCode + "\t");
                    strFileContents.Append(SubSubChannelCode + "\t");
                    strFileContents.Append(SubSubChannelName + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    #region [Journey Plan]
    private void ExportJourneyPlanReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        int JourneyPlanId = Convert.ToInt32(Session["JourneyPlanId"].ToString());


        JPHeader objJPHeader = new JourneyPlanFacadeNew().GetJourneyPlanExport(JourneyPlanId);

        if (objJPHeader != null)
        {
            strFileContents = new StringBuilder();

            strFileContents.Append("Journey Plan Name\t" + objJPHeader.Name + "\n");
            strFileContents.Append("Description\t" + objJPHeader.Description + "\n");
            strFileContents.Append("Starts On\t" + objJPHeader.StartDate + "\n");
            strFileContents.Append("Ends On\t" + objJPHeader.EndDate + "\n");
            strFileContents.Append("Country\t" + objJPHeader.Country + "\n");
            strFileContents.Append("Route Code\t" + objJPHeader.UserCode + "\n");
            strFileContents.Append("Route Name\t" + objJPHeader.UserName + "\n");
            strFileContents.Append("Schedule \t" + objJPHeader.Type + "\n");

            if (objJPHeader.JPDetails != null && objJPHeader.JPDetails.Count > 0)
            {
                strFileContents.Append("\n\nCustomer Code\t Customer Name \t");
                if (objJPHeader.Type.ToLower() == "week")
                {
                    strFileContents.Append("Week\tDay\n");
                }
                else
                {
                    strFileContents.Append("Day\n");
                }

                foreach (JPDetail objJPDetail in objJPHeader.JPDetails)
                {
                    strFileContents.Append(objJPDetail.CustomerCode + "\t");
                    strFileContents.Append(objJPDetail.Description + "\t");
                    if (objJPHeader.Type.ToLower() == "week")
                    {
                        strFileContents.Append(objJPDetail.Type + "\t");
                        strFileContents.Append(objJPDetail.JpDay + "\n");

                    }
                    else
                    {
                        strFileContents.Append(objJPDetail.Type + " " + objJPDetail.JpDay + "\n");
                    }
                }
            }
            strFileContents.Append("\n");
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }

    }


    private void ExportJourneyPlanRouteCustomers(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        int JourneyPlanId = Convert.ToInt32(Session["NewJourneyPlanId"].ToString());


        JPHeader objJPHeader = new JourneyPlanFacadeNew().GetJourneyPlanCustomersExport(JourneyPlanId);

        if (objJPHeader != null)
        {
            strFileContents = new StringBuilder();


            if (objJPHeader.JPDetails != null && objJPHeader.JPDetails.Count > 0)
            {
                strFileContents.Append("Code\t WorkingDay \t Week\n");


                foreach (JPDetail objJPDetail in objJPHeader.JPDetails)
                {
                    strFileContents.Append(objJPDetail.CustomerCode + "\t");
                    strFileContents.Append(objJPDetail.JpDay + "\t");
                    strFileContents.Append(objJPDetail.week + "\t\n");

                }
            }
            strFileContents.Append("\n");
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }

    }

    #endregion
    private void ExportCompetitorReportV1(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string SortExpression = "ModifiedOn DESC";

            SearchString = (Session["CompetitorReportSearchStringV1"] != null) ? Session["CompetitorReportSearchStringV1"].ToString() : "1=1";

            IList<CompetitorBrand> objCompetitorList = new CompetitorFacade().GetViewCompetitorSearchV1_Export(SortExpression, SearchString);

            if (objCompetitorList != null && objCompetitorList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Date" + "\t" + "Store Name" + "\t" + "Our Brand" + "\t" + "Competitor Brand" + "\t" + "Competitor Company" + "\t");

                strFileContents.Append("\n");
                foreach (CompetitorBrand objCompetitorBrand in objCompetitorList)
                {
                    strFileContents.Append(objCompetitorBrand.ModifiedOn + "\t");
                    strFileContents.Append(objCompetitorBrand.Store + "\t");
                    strFileContents.Append(objCompetitorBrand.BrandCode + "\t");
                    strFileContents.Append(objCompetitorBrand.BrandName + "\t");
                    strFileContents.Append(objCompetitorBrand.Company + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    public DataSet GetSubCategorySearch_Local(string RouteCode, string Category, string Date, string searchString, string CustomerCode, string UserCode, string DepotCode, string Supervisor, string AreaSMgr)
    {
        IList<Category> objCategoryList = new List<Category>();
        DataSet dt = null;
        try
        {
            DbParam[] param = new DbParam[9];
            param[0] = new DbParam("@RouteCode", RouteCode, SqlDbType.VarChar);
            param[1] = new DbParam("@Category", Category.ToString(), SqlDbType.VarChar);
            param[2] = new DbParam("@Date", Date.ToString(), SqlDbType.VarChar);
            param[3] = new DbParam("@searchString", searchString, SqlDbType.VarChar);
            param[4] = new DbParam("@CustomerCode", CustomerCode, SqlDbType.VarChar);
            param[5] = new DbParam("@UserCode", UserCode, SqlDbType.VarChar);
            param[6] = new DbParam("@DepotCode", DepotCode, SqlDbType.VarChar);
            param[7] = new DbParam("@Supervisor", Supervisor, SqlDbType.VarChar);
            param[8] = new DbParam("@AreaSMgr", AreaSMgr, SqlDbType.VarChar);

            dt = Db.GetDataSet("SP_GetMTDSaleDetailByCustomer", param);
        }
        catch (Exception ex)
        {
            Db.LogError(ex, "SP_GetMTDSaleDetailByCustomer", "CategoryDao");
        }
        return dt;
    }

    //private void ExportDailyStockStatusByRoutReport(string strFileName)
    //{
    //    System.IO.StreamWriter sw;
    //    try
    //    {
    //        StringBuilder strFileContents = null;
    //        string SearchString = string.Empty;
    //        string SortExpression = "CreatedOn DESC";


    //        SearchString = (Session["DailyStockStatus_SearchString"]  != null) ? Session["DailyStockStatus_SearchString"].ToString() : "1=1";
    //        string Route=(Session["DailyStockStatus_Route"]  != null) ? Session["DailyStockStatus_Route"].ToString() : "";
    //        DateTime Date =(Session["DailyStockStatus_StartDate"]  != null) ?  Convert.ToDateTime(Session["DailyStockStatus_StartDate"]):DateTime.Now;


    //        IList<GatePassStatus> objGatePassStatuslist = new MovementHeaderFacade().GetDailyStockStatusByRoute_Export(SortExpression, SearchString, SessionManager.UserCode, Date, Route, 10000000, 0);

    //        if (objGatePassStatuslist != null && objGatePassStatuslist.Count > 0)
    //        {
    //            strFileContents = new StringBuilder();
    //            strFileContents.Append("Item" +"\t"+ "ItemName"+ "\t" + "GP CS" + "\t" + " GP PC" + "\t" + " Sold CS" + "\t" + "Sold PC" + "\t" +"Remaining CS"+ "\t" +"Remaining PC"+ "\t" +"BR CS"+"\t" +"BR  PC"+"\t"+"GR CS"+"\t" +"GR PC"+"\t"+"Left Over Stock CS"+"\t"+"Left Over Stock PC"+"\t"+"Total Return CS "+"\t"+"Total Return PC"+ "\t"+"Route Code"+"\t"+"GatePassDate"+"\t"+"SalesmanName");

    //            strFileContents.Append("\n");
    //            foreach (GatePassStatus objGatePassStatus in objGatePassStatuslist)
    //            {
    //                strFileContents.Append(objGatePassStatus.ItemCode + "\t");
    //                strFileContents.Append(objGatePassStatus.ItemName + "\t");
    //                strFileContents.Append(objGatePassStatus.GatePassCS + "\t");
    //                strFileContents.Append(objGatePassStatus.GatePassPC + "\t");
    //                strFileContents.Append(objGatePassStatus.AllocatedCS + "\t");
    //                strFileContents.Append(objGatePassStatus.AllocatedPC + "\t");
    //                strFileContents.Append(objGatePassStatus.RemainingCS + "\t");
    //                strFileContents.Append(objGatePassStatus.RemainingPC + "\t");
    //                strFileContents.Append(objGatePassStatus.SoldCS + "\t");
    //                strFileContents.Append(objGatePassStatus.SoldPC + "\t");
    //                strFileContents.Append(objGatePassStatus.GoodReturnsCS + "\t");
    //                strFileContents.Append(objGatePassStatus.GoodReturnsPC + "\t");
    //                strFileContents.Append(objGatePassStatus.BadReturnsCS + "\t");
    //                strFileContents.Append(objGatePassStatus.BadReturnsPC + "\t");
    //                strFileContents.Append(objGatePassStatus.LeftOverStockCS + "\t");
    //                strFileContents.Append(objGatePassStatus.LeftOverStockPC + "\t");
    //                strFileContents.Append(objGatePassStatus.RouteCode + "\t");
    //                strFileContents.Append(objGatePassStatus.GatePassDate + "\t");
    //                strFileContents.Append(objGatePassStatus.SalesmanName + "\t");

    //                strFileContents.Append("\n");
    //            }
    //            sw = System.IO.File.CreateText(strFileName);
    //            sw.Write(strFileContents.ToString());
    //            sw.Close();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
    //    }
    //}

    private void ExportFileGeneration(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string UserCode, DepotCode, RouteCode, Date;
        UserCode = Session["FG_UserCode"].ToString() == null ? "" : Session["FG_UserCode"].ToString();
        DepotCode = Session["FG_DepotCode"].ToString() == null ? "" : Session["FG_DepotCode"].ToString();
        RouteCode = Session["FG_RouteCode"].ToString() == null ? "" : Session["FG_RouteCode"].ToString();
        Date = Session["FG_Date"].ToString() == null ? "" : Session["FG_Date"].ToString();
        List<SFA.Export.IntegrationFileGeneration> lst = GetIntegrationFileGeneration_Local(UserCode, DepotCode, RouteCode, Date);

        if (lst != null && lst.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("CheckingDate" + "\t" + "Depot" + "\t" + "UserCode" + "\t" + "RouteType" + "\t" + "RouteCode" + "\t" + "TripStartDate" + "\t" + "TripEndDate" + "\t Supervisor" +
                "\t LastEOTTime" + "\t IVFile" + "\t ARFile" + "\t RSFile" + "\t TripDateType" + "\t PreviousEOT" + "\t NextEOT" + "\n");
            strFileContents.Append("\n");
            foreach (SFA.Export.IntegrationFileGeneration obj in lst)
            {
                strFileContents.Append(obj.CheckingDate + "\t");
                strFileContents.Append(obj.Depot + "\t");
                strFileContents.Append(obj.UserCode + "\t");
                strFileContents.Append(obj.RouteType + "\t");
                strFileContents.Append(obj.RouteCode.ToString() + "\t");
                strFileContents.Append((obj.TripStartDate == "N/A" ? "N/A" : DateTime.Parse(obj.TripStartDate).ToString("dd-MM-yyyy")) + "\t");
                strFileContents.Append((obj.TripEndDate == "N/A" ? "N/A" : DateTime.Parse(obj.TripEndDate).ToString("dd-MM-yyyy")) + "\t");
                strFileContents.Append(obj.Supervisor.ToString() + "\t");
                strFileContents.Append((obj.LastEOTTime == "N/A" ? "N/A" : DateTime.Parse(obj.LastEOTTime).ToString("dd-MM-yyyy")) + "\t");
                strFileContents.Append(obj.IVFile.ToString() + "\t");
                strFileContents.Append(obj.ARFile.ToString() + "\t");
                strFileContents.Append(obj.RSFile.ToString() + "\t");
                strFileContents.Append(obj.TripDateType.ToString() + "\t");
                strFileContents.Append(obj.PreviousEOT.ToString() + "\t");
                strFileContents.Append(obj.NextEOT.ToString() + "\t");
                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }

    private void ExportFileScratchCardUsage(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string ToDate = Session["ScratchToDate"] == null ? "" : Convert.ToDateTime(Session["ScratchToDate"]).ToString("yyyy-MM-dd");
            string fromDate = Session["ScratchFromDate"] == null ? "" : Convert.ToDateTime(Session["ScratchFromDate"]).ToString("yyyy-MM-dd");
            string SalesOrg = Session["ScratchSalesOrg"] == null ? "" : Session["ScratchSalesOrg"].ToString();
            string Customer = Session["ScratchCustomer"] == null ? "" : Session["ScratchCustomer"].ToString();
            string ScratchNo = Session["ScratchScratchNo"] == null ? "" : Session["ScratchScratchNo"].ToString();
            string ScratchDepots = Session["ScratcgDepots"] == null ? "" : Session["ScratcgDepots"].ToString();
            string ScratchRoutess = Session["ScratchRoutes"] == null ? "" : Session["ScratchRoutes"].ToString();
            string Salesman = Session["ScratchSalesman"] == null ? "" : Session["ScratchSalesman"].ToString();
            string ScratchTrxCode = Session["ScratchTrxCode"] == null ? "" : Session["ScratchTrxCode"].ToString();


            IList<ScratchCard> objlstScratchCard = new ScratchCardFacade().GetScratchCardDetailSearch_Export("TrxCode ASC", ScratchRoutess, ScratchDepots, Salesman, ScratchNo
                , ScratchTrxCode, fromDate, ToDate, SalesOrg, Customer);



            if (objlstScratchCard != null && objlstScratchCard.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Invoice Number " + "\t" + "Scratch Card No" + "\t" + "Invoice Date" + "\t" + "Route" + "\t"
                    + "User Code" + "\t" + "User Name" + "\t" + "Customer Code" + "\t" + "Customer Name" + "\t" + "Gift Item Code" + "\t" + "Gift Item Name" + "\n");
                strFileContents.Append("\n");
                foreach (ScratchCard objScratchCard in objlstScratchCard)
                {
                    strFileContents.Append(objScratchCard.trxCode + "\t");
                    strFileContents.Append(objScratchCard.ScratchCardNo.ToString() == "" ? "N/A" : objScratchCard.ScratchCardNo.ToString() + "\t");
                    strFileContents.Append(objScratchCard.TRxDate + "\t");
                    strFileContents.Append(objScratchCard.RouteCode.ToString() == "" ? "N/A" : objScratchCard.RouteCode + "\t");
                    strFileContents.Append(objScratchCard.UserCode.ToString() == "" ? "N/A" : objScratchCard.UserCode + "\t");


                    strFileContents.Append(objScratchCard.UserName.ToString() == "" ? "N/A" : objScratchCard.UserName + "\t");
                    strFileContents.Append(objScratchCard.CustomerCode.ToString() == "" ? "N/A" : objScratchCard.CustomerCode + "\t");
                    strFileContents.Append(objScratchCard.CustomerName.ToString() == "" ? "N/A" : objScratchCard.CustomerName + "\t");
                    strFileContents.Append(objScratchCard.GiftItemCode.ToString() == "" ? "N/A" : objScratchCard.GiftItemCode + "\t");
                    strFileContents.Append(objScratchCard.GiftItemName.ToString() == "" ? "N/A" : objScratchCard.GiftItemName + "\t");


                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }

        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }


    }
    public List<SFA.Export.IntegrationFileGeneration> GetIntegrationFileGeneration_Local(string UserCode, string DepotCode, string RouteCode, string Date)
    {
        List<SFA.Export.IntegrationFileGeneration> lstIntegrationFileGeneration = null;

        DbParam[] Param = new DbParam[4];
        Param[0] = new DbParam("@LoginUserCode", UserCode, SqlDbType.VarChar);
        Param[1] = new DbParam("@DepotCode", DepotCode, SqlDbType.VarChar);
        Param[2] = new DbParam("@RouteCode", RouteCode, SqlDbType.VarChar);
        Param[3] = new DbParam("@Date", Date, SqlDbType.VarChar);

        DataSet ds = Db.GetDataSet("usp_GetIntegrationFileGenerationStatus", Param);

        if (ds != null && ds.Tables.Count > 0)
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                lstIntegrationFileGeneration = new List<SFA.Export.IntegrationFileGeneration>();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    lstIntegrationFileGeneration.Add(GetObject(row));
                }
            }
        }
        return lstIntegrationFileGeneration;
    }
    public SFA.Export.IntegrationFileGeneration GetObject(DataRow dr)
    {
        SFA.Export.IntegrationFileGeneration objIntegrationFileGeneration = new SFA.Export.IntegrationFileGeneration();

        if (dr != null)
        {
            if (dr.Table.Columns.Contains("CheckingDate")) objIntegrationFileGeneration.CheckingDate = Db.ToString(dr["CheckingDate"]);
            if (dr.Table.Columns.Contains("Depot")) objIntegrationFileGeneration.Depot = Db.ToString(dr["Depot"]);
            if (dr.Table.Columns.Contains("UserCode")) objIntegrationFileGeneration.UserCode = Db.ToString(dr["UserCode"]);
            if (dr.Table.Columns.Contains("RouteCode")) objIntegrationFileGeneration.RouteCode = Db.ToString(dr["RouteCode"]);
            if (dr.Table.Columns.Contains("TripStartDate")) objIntegrationFileGeneration.TripStartDate = Db.ToString(dr["TripStartDate"]);
            if (dr.Table.Columns.Contains("TripEndDate")) objIntegrationFileGeneration.TripEndDate = Db.ToString(dr["TripEndDate"]);
            if (dr.Table.Columns.Contains("Supervisor")) objIntegrationFileGeneration.Supervisor = Db.ToString(dr["Supervisor"]);
            if (dr.Table.Columns.Contains("LastEOTTime")) objIntegrationFileGeneration.LastEOTTime = Db.ToString(dr["LastEOTTime"]);
            if (dr.Table.Columns.Contains("IVFile")) objIntegrationFileGeneration.IVFile = Db.ToString(dr["IVFile"]);
            if (dr.Table.Columns.Contains("ARFile")) objIntegrationFileGeneration.ARFile = Db.ToString(dr["ARFile"]);
            if (dr.Table.Columns.Contains("RSFile")) objIntegrationFileGeneration.RSFile = Db.ToString(dr["RSFile"]);
            if (dr.Table.Columns.Contains("TripDateType")) objIntegrationFileGeneration.TripDateType = Db.ToString(dr["TripDateType"]);
            if (dr.Table.Columns.Contains("PreviousEOT")) objIntegrationFileGeneration.PreviousEOT = Db.ToString(dr["PreviousEOT"]);
            if (dr.Table.Columns.Contains("NextEOT")) objIntegrationFileGeneration.NextEOT = Db.ToString(dr["NextEOT"]);
            if (dr.Table.Columns.Contains("Attribute4")) objIntegrationFileGeneration.Attribute4 = Db.ToString(dr["Attribute4"]);
            if (dr.Table.Columns.Contains("Attribute5")) objIntegrationFileGeneration.Attribute5 = Db.ToString(dr["Attribute5"]);
            if (dr.Table.Columns.Contains("RouteType")) objIntegrationFileGeneration.RouteType = Db.ToString(dr["RouteType"]);
        }
        return objIntegrationFileGeneration;
    }


    private void ExportCustomerItemData(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string GroupType = string.Empty;

            SearchString = (Session["CutomerItemSearch"] != null) ? Session["CutomerItemSearch"].ToString() : "1=1";
            //GroupType = (Session["SKU_SKUTypeCode"] != null) ? Session["SKU_SKUTypeCode"].ToString() : "SKUC002";
            //string SubSubChannelCode = (Session["SK_SSCHCode"] != null) ? Session["SK_SSCHCode"].ToString() : "N/A";
            //string SubSubChannelName = (Session["SK_SSCHName"] != null) ? Session["SK_SSCHName"].ToString() : "N/A";
            SellingSKUResult objSellingSKUResult = new SellingSKUResult();
            objSellingSKUResult = new SellingSKUClassificationFacade().GetCustomerItemExport(SearchString);

            if (objSellingSKUResult != null)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("CutomerCode" + "\t" + "ItemCode" + "\t" + "MinQty" + "\t" + "MaxQty \t" + "RouteType" + "\t" + "SalesOrgCode");

                strFileContents.Append("\n");
                foreach (SellingSKUReport objSellingSKUReport in objSellingSKUResult.lstSellingSKUReport)
                {
                    strFileContents.Append(objSellingSKUReport.GroupCode + "\t");
                    strFileContents.Append(objSellingSKUReport.ItemCode + "\t");
                    strFileContents.Append(objSellingSKUReport.MinQty.ToString() + "\t");
                    strFileContents.Append(objSellingSKUReport.MaxQty.ToString() + "\t");
                    strFileContents.Append(objSellingSKUReport.RouteType + "\t");
                    strFileContents.Append(objSellingSKUReport.SalesOrgCode + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportItemSubGroupReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        string FilterValue = string.Empty;

        if (Request.QueryString["searchString"] != null)
        {
            FilterValue = Request.QueryString["searchString"].ToString();
        }

        string hndSearchValue = CommonFunctions.getStringValue(Session["hndSearchValue"]);

        IList<ItemSubGroup> lst = new ItemSubGroupFacade().GetItemSubGroupSearch_New("Id ASC", 5000000, 0, hndSearchValue, SessionManager.UserCode);

        if (lst != null && lst.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("SalesOrg" + "\t" + "GroupCode" + "\t" + "RouteType" + "\t" + "Item" + "\t" + "ItemSubGroupDescription" + "\t" + "IsStockTakingItem");
            strFileContents.Append("\n");
            foreach (ItemSubGroup obj in lst)
            {
                strFileContents.Append("[" + obj.SalesOrgCode + "] " + obj.SalesOrgName + "\t");
                strFileContents.Append("[" + obj.GroupName + "] " + obj.GroupCode + "\t");
                strFileContents.Append(obj.RouteType + "\t");
                strFileContents.Append("[" + obj.ItemName + "] " + obj.ItemCode + "\t");
                strFileContents.Append(obj.ItemSubGroupDescription + "\t");
                strFileContents.Append(obj.IsSTockTakingItem + "\t");
                //strFileContents.Append(obj.IsActive + "\t");

                strFileContents.Append("\n");

            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    private void ExportCurrentVanStock(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = Session["VanStock_SearchString"].ToString();

            IList<WareHouse> ObjItem = new List<WareHouse>();
            ObjItem = new WarehouseFacade().GetVanStockAll("RouteCode Desc", 10000000, 0, SearchString, SessionManager.UserCode);

            if (ObjItem != null)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Route" + "\t" + "Description" + "\t" + "ItemCode" + "\t" + "ItemDescription" + "\t" + "UOM" + "\t" + "Qty");

                strFileContents.Append("\n");
                foreach (WareHouse row in ObjItem)
                {
                    strFileContents.Append(row.Route + "\t");
                    strFileContents.Append(row.Description + "\t");
                    strFileContents.Append(row.ItemCode + "\t");
                    strFileContents.Append(row.ItemDescription + "\t");
                    strFileContents.Append(row.UOM + "\t");
                    strFileContents.Append(row.Qty + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportItemFrequencyData(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string SKUTypeCode = string.Empty;

            SearchString = (Session["ItemSearch"] != null) ? Session["ItemSearch"].ToString() : "1=1";
            SKUTypeCode = (Session["SKUTypeCode"] != null) ? Session["SKUTypeCode"].ToString() : "SKUC002";
            //string SubSubChannelCode = (Session["SK_SSCHCode"] != null) ? Session["SK_SSCHCode"].ToString() : "N/A";
            //string SubSubChannelName = (Session["SK_SSCHName"] != null) ? Session["SK_SSCHName"].ToString() : "N/A";
            List<SellingSKUQty> ObjItem = new List<SellingSKUQty>();
            ObjItem = new SellingSKUClassificationFacade().GetItemFrequencySellingSkuQty_Search("ItemCode ASC", SearchString, 0, 0, SKUTypeCode, SessionManager.UserCode);

            if (ObjItem != null)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("ItemCode" + "\t" + "Frequency" + "\t" + "RouteType" + "\t" + "SalesOrgCode");

                strFileContents.Append("\n");
                foreach (SellingSKUQty row in ObjItem)
                {
                    strFileContents.Append(row.ItemCode + "\t");
                    strFileContents.Append(row.Attribute1 + "\t");
                    strFileContents.Append("[" + row.RouteTypeCode + "]" + row.RouteDesc + "\t");
                    strFileContents.Append("[" + row.SalesOrgCode + "]" + row.SalesOrgName + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportInnerCustomerItem_Export(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = null;
            string SearchString = string.Empty;
            string GroupType = string.Empty;
            SearchString = (Session["Item_SearchString"] != null) ? Session["Item_SearchString"].ToString() : "1=1";
            GroupType = (Session["Item_SKUTypeCode"] != null) ? Session["Item_SKUTypeCode"].ToString() : "SKUC002";
            string SubSubChannelCode = (Session["Item_SSCHCode"] != null) ? Session["SK_SSCHCode"].ToString() : "N/A";
            string SubSubChannelName = (Session["Item_SSCHName"] != null) ? Session["SK_SSCHName"].ToString() : "N/A";
            SellingSKUResult objSellingSKUResult = new SellingSKUResult();
            objSellingSKUResult = new SellingSKUClassificationFacade().GetCustomerSellingSKUQtyResultExport(SearchString);

            if (objSellingSKUResult != null)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("CustomerCode" + "\t" + "ItemCode" + "\t" + "MinQty" + "\t" + "MaxQty" + "\t"
                     + "Route" + "\t" + "SalesOrg"
                   );

                strFileContents.Append("\n");
                foreach (SellingSKUReport objSellingSKUReport in objSellingSKUResult.lstSellingSKUReport)
                {
                    strFileContents.Append(objSellingSKUReport.GroupCode + "\t");
                    strFileContents.Append(objSellingSKUReport.ItemCode + "\t");
                    strFileContents.Append(objSellingSKUReport.MinQty.ToString() + "\t");
                    strFileContents.Append(objSellingSKUReport.MaxQty.ToString() + "\t");
                    strFileContents.Append("[" + objSellingSKUReport.RouteType + "]" + objSellingSKUReport.RouteDesc + "\t");
                    strFileContents.Append(objSellingSKUReport.SalesOrgCode + "\t");

                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    public void ExportAttendanceReportExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        string searchString = Convert.ToString(Session["AttendanceSearchString"]);

        IList<Attandence> objTrxDetails = (new AttendanceFacade()).GetAttandenceSearch("LoginDate DESC", 500000, 0, searchString, SessionManager.UserCode);
        if ((objTrxDetails != null && objTrxDetails.Count > 0))
        {
            strFileContents = new StringBuilder();
            if (objTrxDetails != null && objTrxDetails.Count > 0)
            {
                //int Count =Convert.ToInt16(lstobj[0].Count);
                strFileContents.Append("Salesman code\t" + "Salesman Name\t" + " Date\t" + "Start Time\t" + "\n");
                foreach (Attandence objOrder in objTrxDetails)
                {
                    strFileContents.Append(objOrder.UserCode1 + "\t");
                    strFileContents.Append(objOrder.UserDescription + "\t");
                    strFileContents.Append(objOrder.LoginDate + "\t");
                    strFileContents.Append(objOrder.LoginTime + "\t");
                    //strFileContents.Append(objOrder.LogOutTime == "00:00:00 AM" ? "N/A" + "\t" : objOrder.LogOutTime + "\t");
                    // strFileContents.Append(objOrder.UserCode + "\t");
                    //strFileContents.Append(objOrder.JourneyDate.ToString() + "\t");


                    strFileContents.Append("\n");
                }
                strFileContents.Append("\n");
                strFileContents.Append("\n\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    public void ExportTargetReportReportExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        string searchString = Convert.ToString(HttpContext.Current.Session["CommonTargetSearch"]);
        string TimeFrame = Convert.ToString(HttpContext.Current.Session["TimeFrame"]);

        ClientCommonTarget objTrxDetails = (new CommonTargetFacade()).GetTargetReportReportExport(searchString, TimeFrame);
        if ((objTrxDetails != null && objTrxDetails.CommonTargets.Count > 0))
        {
            strFileContents = new StringBuilder();
            if (objTrxDetails != null && objTrxDetails.CommonTargets.Count > 0)
            {
                //int Count =Convert.ToInt16(lstobj[0].Count);
                strFileContents.Append("TargetId\t" + "TimeFrame\t" + " StartDate\t" + "EndDate\t" + "Year\t" + "Semister\t"
                    + "Quarter\t" + "Month\t" + "Week\t" + "Day\t" + "Salesman\t" + "Route\t" + "SalesorgCode\t" + "Currency\t"
                     + "Amount\t" + "Quantity\t" + "UOM\t" + "ItemLevel\t" + "ItemKey\t" + "CustomerLevel\t" + "CustomerKey\t"
                      + "WastageTarget\t" + "\n");
                foreach (CommonTarget objOrder in objTrxDetails.CommonTargets)
                {
                    strFileContents.Append(objOrder.TargetId + "\t");
                    strFileContents.Append(objOrder.TimeFrame + "\t");
                    strFileContents.Append(objOrder.StartDate + "\t");
                    strFileContents.Append(objOrder.EndDate + "\t");
                    strFileContents.Append(objOrder.Year + "\t");
                    strFileContents.Append(objOrder.Semister + "\t");
                    strFileContents.Append(objOrder.Quarter + "\t");
                    strFileContents.Append(objOrder.Month + "\t");
                    strFileContents.Append(objOrder.Week + "\t");
                    strFileContents.Append(objOrder.Day + "\t");
                    strFileContents.Append("[" + objOrder.SalesmanCode + "]" + objOrder.SalesmanName + "\t");
                    strFileContents.Append("[" + objOrder.RouteCode + "]" + objOrder.RouteName + "\t");
                    strFileContents.Append(objOrder.SalesorgCode + "\t");
                    strFileContents.Append(objOrder.Currency + "\t");
                    strFileContents.Append(objOrder.Amount + "\t");
                    strFileContents.Append(objOrder.Quantity + "\t");
                    strFileContents.Append(objOrder.UOM + "\t");
                    strFileContents.Append(objOrder.ItemLevel + "\t");
                    strFileContents.Append(objOrder.ItemKey + "\t");
                    strFileContents.Append(objOrder.CustomerLevel + "\t");
                    strFileContents.Append(objOrder.CustomerKey + "\t");
                    strFileContents.Append(objOrder.WastageTarget + "\t");

                    strFileContents.Append("\n");
                }
                strFileContents.Append("\n");
                strFileContents.Append("\n\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }




    private void ExportFileCustomerItemwiseSalesAndWastageData(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {


            string ToDate = Session["CustomerwiseSalesToDate"] == null ? "" : Convert.ToDateTime(Session["CustomerwiseSalesToDate"]).ToString("yyyy-MM-dd");
            string fromDate = Session["CustomerwiseSalesFromDate"] == null ? "" : Convert.ToDateTime(Session["CustomerwiseSalesFromDate"]).ToString("yyyy-MM-dd");
            string SalesOrg = Session["CustomeriseSalesSalesOrg"] == null ? "" : Session["CustomeriseSalesSalesOrg"].ToString();
            string ScratchDepots = Session["CustomerwiseSalesDepots"] == null ? "" : Session["CustomerwiseSalesDepots"].ToString();
            string ScratchRoutess = Session["CustomerwiseSalesRoutes"] == null ? "" : Session["CustomerwiseSalesRoutes"].ToString();
            string Salesman = Session["CustomerwiseSalesSalesman"] == null ? "" : Session["CustomerwiseSalesSalesman"].ToString();
            string Supervisor = Session["CustomerwiseSalesSupervisor"] == null ? "" : Session["CustomerwiseSalesSupervisor"].ToString();





            IList<ItemwiseSalesAndWastageData> objlstItemwiseSalesAndWastageData = new ItemwiseSalesAndWastageDataFacade().CustomerItemwiseSalesAndWastageDataSearch("TrxCode ASC", 500000, 0, ScratchRoutess, Salesman
                        , fromDate, ToDate, SalesOrg, Supervisor, SessionManager.UserCode.ToString(), "");



            if (objlstItemwiseSalesAndWastageData != null && objlstItemwiseSalesAndWastageData.Count > 0)
            {



                strFileContents = new StringBuilder();
                strFileContents.Append("TrxDate " + "\t" + "RouteCode" + "\t"
                    + "SupervisorCode" + "\t"
                    + "SupervisorName" + "\t"
                    + "CustomerClassification" + "\t"
                    + "CustomerCode" + "\t"
                    + "CustomerName" + "\t"
                    + "CustomerType" + "\t"
                    + "CustomerPriceGroup" + "\t"
                    + "SubCategoryName" + "\t"
                    + "ItemCode" + "\t" + "ItemName" + "\t" + "SubCategoryCode" + "\t" +
                    "SubCategoryName" + "\t" + "SalesQty" + "\t" + "UOM"
                    + "\t" + "NetSales" + "\t" + "GrossSales" + "\t" + "Wastage" + "\t" +
                    "SalesTarget" + "\n");
                //strFileContents.Append("\n");
                foreach (ItemwiseSalesAndWastageData objScratchCard in objlstItemwiseSalesAndWastageData)
                {
                    strFileContents.Append(objScratchCard.TrxDate + "\t");
                    strFileContents.Append(objScratchCard.RouteCode.ToString() == "" ? "N/A" : objScratchCard.RouteCode.ToString() + "\t");
                    strFileContents.Append(objScratchCard.SupervisorCode + "\t");
                    strFileContents.Append(objScratchCard.SupervisorName + "\t");
                    strFileContents.Append(objScratchCard.CustomerClassification + "\t");
                    strFileContents.Append(objScratchCard.CustomerCode + "\t");
                    strFileContents.Append(objScratchCard.CustomerName + "\t");
                    strFileContents.Append(objScratchCard.CustomerType + "\t");
                    strFileContents.Append(objScratchCard.CustomerPriceGroup + "\t");
                    strFileContents.Append(objScratchCard.SubCategoryName + "\t");
                    strFileContents.Append(objScratchCard.ItemCode.ToString() == "" ? "N/A" : objScratchCard.ItemCode + "\t");
                    strFileContents.Append(objScratchCard.ItemName.ToString() == "" ? "N/A" : objScratchCard.ItemName + "\t");
                    strFileContents.Append(objScratchCard.SubCategoryCode.ToString() == "" ? "N/A" : objScratchCard.SubCategoryCode + "\t");
                    strFileContents.Append(objScratchCard.SubCategoryName.ToString() == "" ? "N/A" : objScratchCard.SubCategoryName + "\t");
                    strFileContents.Append(objScratchCard.SalesQty.ToString() == "" ? "N/A" : objScratchCard.SalesQty + "\t");
                    strFileContents.Append(objScratchCard.UOM.ToString() == "" ? "N/A" : objScratchCard.UOM + "\t");
                    strFileContents.Append(objScratchCard.NetSales.ToString() == "" ? "N/A" : objScratchCard.NetSales + "\t");
                    strFileContents.Append(objScratchCard.GrossSales.ToString() == "" ? "N/A" : objScratchCard.GrossSales + "\t");
                    strFileContents.Append(objScratchCard.Wastage.ToString() == "" ? "N/A" : objScratchCard.Wastage + "\t");
                    strFileContents.Append(objScratchCard.SalesTarget.ToString() == "" ? "N/A" : objScratchCard.SalesTarget + "\t");


                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }

        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }


    }

    private void ExportManageSalesOrders(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string sortString = Session["sortString"].ToString();
            string SearchString = Session["SearchString"].ToString();
            //SearchString = SearchString.Replace("TrxDate", "TH.TrxDate");
            bool flag;
            bool IsLoaded = Boolean.TryParse(Session["IsLoaded"].ToString(), out flag);
            string _userCode = SessionManager.UserCode;

            OrdersReport objOrdersReport = new TrxHeaderFacade().GetTrxHeaderSearchReportExport(sortString, SearchString, _userCode, IsLoaded);
            if (objOrdersReport.OrderDetailsList != null && objOrdersReport.OrderDetailsList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "WarehouseCode" + "\t" + "RouteCode" + "\t" + "SFA Route Code" + "\t"
                    + "Invoice Code" + "\t" + "Invoice Date" + "\t" + "Reference Number" + "\t" + "LPO Code" + "\t" + "SalesmanCode"
                    + "\t" + "CustomerCode" + "\t" + "CustomerName" + "\t" + "CustomerType" + "\t" + "ItemType" + "\t" + "Type" + "\t" + "Category Code"
                    + "\t" + "Category Name" + "\t" + "ItemCode" + "\t"
                    + "UOM" + "\t" + "UnitPrice" + "\t" + "Quantity" + "\t" + "Price" + "\t"
                    + "TotalDiscountAmount" + "\t" + "TotalTAXAmount" + "\t" + "Sales" + "\t" + "Net sales" + "\t" + "ConsildatedNo" + "\t" + "OrderStatus" + "\n");
                foreach (OrderDetails objOrderdetails in objOrdersReport.OrderDetailsList)
                {
                    strFileContents.Append(objOrderdetails.SalesOrgCode + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.MFA_RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    //strFileContents.Append(objOrderdetails.TrxDate + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate1.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(objOrderdetails.Attribute7 == "" ? "N/A" + "\t" : objOrderdetails.Attribute7 + "\t");
                    strFileContents.Append(objOrderdetails.LPOCode + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.ClientCode + "\t");
                    strFileContents.Append(objOrderdetails.ClientDescription + "\t");
                    strFileContents.Append(objOrderdetails.CustomerType + "\t");
                    strFileContents.Append(objOrderdetails.ItemType + "\t");
                    strFileContents.Append(objOrderdetails.OrderType + "\t");
                    strFileContents.Append(objOrderdetails.CategoryCode + "\t");
                    strFileContents.Append(objOrderdetails.CategoryName + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.UOM + "\t");
                    strFileContents.Append(objOrderdetails.UnitPrice + "\t");
                    strFileContents.Append(objOrderdetails.QuantityBU + "\t");
                    strFileContents.Append(objOrderdetails.TotalAmount + "\t");
                    strFileContents.Append(objOrderdetails.DiscountAmount + "\t");
                    strFileContents.Append(objOrderdetails.TaxAmount + "\t");
                    strFileContents.Append(objOrderdetails.SalesInvoice + "\t");
                    strFileContents.Append(objOrderdetails.NetSalesInvoice + "\t");
                    strFileContents.Append(objOrderdetails.ConsildatedNo + "\t");
                    strFileContents.Append(objOrderdetails.OrderStatus + "\t");


                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }


    }
    private void ExportManagePresellerOrders(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string sortString = Session["sortString"].ToString();
            string SearchString = Session["SearchString"].ToString();
            bool flag;
            bool IsLoaded = Boolean.TryParse(Session["IsLoaded"].ToString(), out flag);
            string _userCode = SessionManager.UserCode;

            OrdersReport objOrdersReport = new TrxHeaderFacade().GetTrxHeaderSearchReportExport(sortString, SearchString, _userCode, IsLoaded);
            bool isInvoiceTab = SearchString.Contains("TrxType in (1)") || SearchString.Contains("TrxType IN (1)");
            if (objOrdersReport.OrderDetailsList != null && objOrdersReport.OrderDetailsList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "WarehouseCode" + "\t" + "RouteCode" + "\t" + "SFA Route Code"
                    + "\t" + "ASM Code" + "\t" + "ASM Name"
                    + "\t" + "PreOrderNo" + "\t" + "InvoiceNo"
                    + "\t" + "Order Date" +  "\t" + "Delivery Date" + "\t" + "Reference Number" + "\t" + "LPO Code" + "\t" + "SalesmanCode"
                    + "\t" + "CustomerCode" + "\t" + "CustomerName" + "\t" + "CustomerType" + "\t" + "ItemType" + "\t" + "Type" + "\t" + "Category Code"
                    + "\t" + "Category Name" + "\t" + "ItemCode" + "\t"
                    + "UOM" + "\t" + "UnitPrice" + "\t" + "Quantity" + "\t" + "Price" + "\t"
                    + "TotalDiscountAmount" + "\t" + "TotalTAXAmount" + "\t" + "Sales" + "\t" + "Net sales" + "\t" + "ConsildatedNo" + "\t" + "OrderStatus" + "\t" + "PreOrderStatus" + "\n");
                foreach (OrderDetails objOrderdetails in objOrdersReport.OrderDetailsList)
                {
                    strFileContents.Append(objOrderdetails.SalesOrgCode + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.MFA_RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMName + "\t");
                    string preOrderNo = isInvoiceTab ? objOrderdetails.InvoiceNumber : objOrderdetails.TrxCode;
                    string invoiceNo = isInvoiceTab ? objOrderdetails.TrxCode : objOrderdetails.InvoiceNumber;
                    strFileContents.Append(preOrderNo + "\t");
                    strFileContents.Append(invoiceNo + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate1.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append((objOrderdetails.DeliveryDate != null ? Convert.ToDateTime(objOrderdetails.DeliveryDate).ToString("yyyy-MM-dd") : "") + "\t");
                    strFileContents.Append(objOrderdetails.Attribute7 == "" ? "N/A" + "\t" : objOrderdetails.Attribute7 + "\t");
                    strFileContents.Append(objOrderdetails.LPOCode + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.ClientCode + "\t");
                    strFileContents.Append(objOrderdetails.ClientDescription + "\t");
                    strFileContents.Append(objOrderdetails.CustomerType + "\t");
                    strFileContents.Append(objOrderdetails.ItemType + "\t");
                    strFileContents.Append(objOrderdetails.OrderType + "\t");
                    strFileContents.Append(objOrderdetails.CategoryCode + "\t");
                    strFileContents.Append(objOrderdetails.CategoryName + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.UOM + "\t");
                    strFileContents.Append(objOrderdetails.UnitPrice + "\t");
                    strFileContents.Append(objOrderdetails.QuantityBU + "\t");
                    strFileContents.Append(objOrderdetails.TotalAmount + "\t");
                    strFileContents.Append(objOrderdetails.DiscountAmount + "\t");
                    strFileContents.Append(objOrderdetails.TaxAmount + "\t");
                    strFileContents.Append(objOrderdetails.SalesInvoice + "\t");
                    strFileContents.Append(objOrderdetails.NetSalesInvoice + "\t");
                    strFileContents.Append(objOrderdetails.ConsildatedNo + "\t");
                    strFileContents.Append(objOrderdetails.OrderStatus + "\t");
                    strFileContents.Append(objOrderdetails.Status);

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportManageDamageOrders(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string sortString = Session["sortString"].ToString();
            string SearchString = Session["SearchString"].ToString();
            SearchString = SearchString.Replace("TrxDate", "TH.TrxDate");
            bool flag;
            bool IsLoaded = Boolean.TryParse(Session["IsLoaded"].ToString(), out flag);
            string _userCode = SessionManager.UserCode;

            OrdersReport objOrdersReport = new TrxHeaderFacade().GetTrxHeaderSearchReportExport(sortString, SearchString, _userCode, IsLoaded);
            if (objOrdersReport.OrderDetailsList != null && objOrdersReport.OrderDetailsList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "WarehouseCode" + "\t" + "RouteCode" + "\t" + "Invoice Code" + "\t" + "Invoice Date" + "\t" + "Reference Number" + "\t" + "SalesmanCode"
                    + "\t" + "CustomerCode" + "\t" + "CustomerType" + "\t" + "ItemType" + "\t" + "Type" + "\t" + "Category Code" + "\t" + "Category Name" + "\t" + "ItemCode" + "\t"
                    + "UOM" + "\t" + "UnitPrice" + "\t" + "Quantity" + "\t" + "Price" + "\t"
                    + "TotalDiscountAmount" + "\t" + "TotalTAXAmount" + "\t" + "Sales" + "\t" + "Net sales" + "\n");
                foreach (OrderDetails objOrderdetails in objOrdersReport.OrderDetailsList)
                {
                    strFileContents.Append(objOrderdetails.SalesOrgCode + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate + "\t");
                    strFileContents.Append(objOrderdetails.Attribute7 == "" ? "N/A" + "\t" : objOrderdetails.Attribute7 + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.ClientCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerType + "\t");
                    strFileContents.Append(objOrderdetails.ItemType + "\t");
                    strFileContents.Append("Damage Order" + "\t");//objOrderdetails.OrderType + "\t");
                    strFileContents.Append(objOrderdetails.CategoryCode + "\t");
                    strFileContents.Append(objOrderdetails.CategoryName + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.UOM + "\t");
                    strFileContents.Append(objOrderdetails.UnitPrice + "\t");
                    strFileContents.Append(objOrderdetails.QuantityBU + "\t");
                    strFileContents.Append(objOrderdetails.TotalAmount + "\t");
                    strFileContents.Append(objOrderdetails.DiscountAmount + "\t");
                    strFileContents.Append(objOrderdetails.TaxAmount + "\t");
                    strFileContents.Append(objOrderdetails.SalesInvoice + "\t");
                    strFileContents.Append(objOrderdetails.NetSalesInvoice + "\t");



                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }


    }

    private void ExportDailySalesReportMTD(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string sortString = Session["sortString"].ToString();
            string SearchString = Session["SearchString"].ToString();
            bool flag;
            bool IsLoaded = Boolean.TryParse(Session["IsLoaded"].ToString(), out flag);
            string _userCode = SessionManager.UserCode;

            OrdersReport objOrdersReport = new TrxHeaderFacade().GetMTDdailySalesReportExport(sortString, SearchString, _userCode, IsLoaded);
            if (objOrdersReport.OrderDetailsList != null && objOrdersReport.OrderDetailsList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "WarehouseCode" + "\t" + "WarehouseName" + "\t" + "RouteCode" + "\t" + "RouteName" + "\t" + "Invoice Number"
                    + "\t" + "Invoice Date" + "\t" + "SalesmanCode" + "\t" + "SalesmanName"
                    + "\t" + "SupervisorCode" + "\t" + "SupervisorName"
                    + "\t" + "ASMCode" + "\t" + "ASMName"
                    + "\t" + "CustomerCode" + "\t" + "CustomerName" + "\t" + "CustomerType" + "\t" + "ItemType" + "\t" + "ItemCode" + "\t"
                    + "ItemName" + "\t" + "UOM" + "\t" + "UnitPrice" + "\t" + "Quantity" + "\t"
                    + "Discount Amount" + "\t" + "TAX Amount" + "\t" + "Total Amount" + "\t" + "Total Gross Amount" + "\n");
                foreach (OrderDetails objOrderdetails in objOrdersReport.OrderDetailsList)
                {
                    strFileContents.Append(objOrderdetails.SalesOrgCode + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.WHName + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.SalesmanName + "\t");

                    strFileContents.Append(objOrderdetails.SupervisorCode + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorName + "\t");
                    strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMName + "\t");


                    strFileContents.Append(objOrderdetails.ClientCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName + "\t");
                    strFileContents.Append(objOrderdetails.CustomerType + "\t");
                    strFileContents.Append(objOrderdetails.ItemType + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.UOM + "\t");
                    strFileContents.Append(objOrderdetails.UnitPrice + "\t");
                    strFileContents.Append(objOrderdetails.QuantityBU + "\t");
                    strFileContents.Append(objOrderdetails.DiscountAmount + "\t");
                    strFileContents.Append(objOrderdetails.TaxAmount + "\t");
                    strFileContents.Append(objOrderdetails.TotalAmount + "\t");
                    strFileContents.Append(objOrderdetails.TotalGrossAmount + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }


    }

    private void NonstampedinvoiceExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string sortString = Session["sortString"].ToString();
            string SearchString = Session["SearchString"].ToString();
            bool flag;
            bool IsLoaded = Boolean.TryParse(Session["IsLoaded"].ToString(), out flag);
            string _userCode = SessionManager.UserCode;

            OrdersReport objOrdersReport = new TrxHeaderFacade().NonStampingInvoiceExport(sortString, SearchString, _userCode, IsLoaded);
            if (objOrdersReport.OrderDetailsList != null && objOrdersReport.OrderDetailsList.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "RouteCode" + "\t" + "RouteName" + "\t" + "Invoice Number"
                    + "\t" + "Invoice Date" + "\t" + "SalesmanCode" + "\t" + "SalesmanName"
                    + "\t" + "SupervisorCode" + "\t" + "SupervisorName"
                    + "\t" + "ASMCode" + "\t" + "ASMName"
                    + "\t" + "CustomerCode" + "\t" + "CustomerName" + "\t"
                    + "IsStamped" + "\t" + "TotalAmount"+ "\n");
                foreach (OrderDetails objOrderdetails in objOrdersReport.OrderDetailsList)
                {
                    strFileContents.Append(objOrderdetails.SalesOrgCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.SalesmanName + "\t");

                    strFileContents.Append(objOrderdetails.SupervisorCode + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorName + "\t");
                    strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMName + "\t");


                    strFileContents.Append(objOrderdetails.ClientCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName + "\t");

                    strFileContents.Append(objOrderdetails.IsStamp + "\t");
                    strFileContents.Append(objOrderdetails.TotalAmount + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }


    }

    private void ExportLoadRequestchnageLogreport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["PassCode_searchString"].ToString();
            string StartDate = Session["PassCode_StartDate"].ToString();
            string itemcode = Session["Itemcode_LogReport"].ToString();


            List<Updateddate> objReports = null;

            objReports = (new UpdatedDateDao()).GetLoadReQuestChangeReport("", 50000, 0, SearchString, StartDate, "", "");
            if (objReports != null && objReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents
                    .Append("DepotCode" + "\t")
                    .Append("RouteCode" + "\t")
                    .Append("MovementDate" + "\t")
                    .Append("MovementCode" + "\t")
                    .Append("UpdatedBy" + "\t")
                    .Append("UpdatedOn" + "\t")
                    .Append("ItemCode" + "\t")
                    .Append("UOM" + "\t")
                    .Append("Original_Quantity" + "\t")
                    .Append("Quantity_Updated" + "\n");
                //  .Append("ModifiedBy" + "\t")
                //  .Append("Description "+ "\n");

                foreach (Updateddate objOrderdetails in objReports)
                {
                    strFileContents.Append(objOrderdetails.DepotCode != null ? objOrderdetails.DepotCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode != null ? objOrderdetails.RouteCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.MovementDate.ToString() != "1/1/0001 12:00:00 AM" ? objOrderdetails.MovementDate + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.MovementCode != null ? objOrderdetails.MovementCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ModifiedBy != null ? ("[" + objOrderdetails.ModifiedBy + "] " + objOrderdetails.Description) + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.UpdatedOn != null ? objOrderdetails.UpdatedOn + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode != null ? objOrderdetails.ItemCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.UOM != null ? objOrderdetails.UOM + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.Quantity != null ? objOrderdetails.Quantity + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.Quantity_Updated != null ? objOrderdetails.Quantity_Updated + "\t" : "N/A" + "\t");
                    //  strFileContents.Append(objOrderdetails.ModifiedBy != null ? objOrderdetails.ModifiedBy + "\t" : "N/A" + "\t");
                    // strFileContents.Append(objOrderdetails.Description != null ? objOrderdetails.Description + "\t" : "N/A" + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportViewLoaditem(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["MaintainLoadItems"].ToString();
            //string StartDate = Session["PassCode_StartDate"].ToString();
            //string itemcode = Session["Itemcode_LogReport"].ToString();
            string ActivityType = Session["ActivityType"].ToString();

            IList<VanLoadItemReport> objReports = null;

            objReports = (new RouteFacade()).GetLoadItemSearch("ItemCode ASC", 50000, 0, SearchString, "admin");
            if (objReports != null && objReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents
                    .Append("Selection Type" + "\t")
                    .Append("Selection Value" + "\t");

                    if (ActivityType != "StoreCheck") {
                    strFileContents.Append("ItemCode" + "\t")
                    .Append("Allow Qty Edit (24Hrs)" + "\t")
                    .Append("Allow Qty Edit (48Hrs)" + "\t")
                    .Append("Allow Qty Edit (72Hrs)" + "\t")
                    .Append("Cutoff time fro 24hrs(HH)" + "\n");
                }
                else
                {
                    strFileContents.Append("ItemCode" + "\n");
                }
                //  .Append("ModifiedBy" + "\t")
                //  .Append("Description "+ "\n");

                foreach (VanLoadItemReport objOrderdetails in objReports)
                {
                    strFileContents.Append(objOrderdetails.SelectionType != null ? objOrderdetails.SelectionType + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.SelectionValue != null ? objOrderdetails.SelectionValue + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode != null ? objOrderdetails.ItemCode + "\t" : "N/A" + "\t");
                    if (ActivityType != "StoreCheck")
                    {
                        strFileContents.Append(objOrderdetails.AllowQuantityEdit != null ? objOrderdetails.AllowQuantityEdit + "\t" : "N/A" + "\t");
                        strFileContents.Append(objOrderdetails.AllowQuantityEdit48Hours != null ? objOrderdetails.AllowQuantityEdit48Hours + "\t" : "N/A" + "\t");
                        strFileContents.Append(objOrderdetails.AllowQuantityEdit72Hours != null ? objOrderdetails.AllowQuantityEdit72Hours + "\t" : "N/A" + "\t");
                        strFileContents.Append(objOrderdetails.CutOfTimeInHours_for24Hrs != null ? objOrderdetails.CutOfTimeInHours_for24Hrs + "\t" : "N/A" + "\t");
                    }
                    //  strFileContents.Append(objOrderdetails.ModifiedBy != null ? objOrderdetails.ModifiedBy + "\t" : "N/A" + "\t");
                    // strFileContents.Append(objOrderdetails.Description != null ? objOrderdetails.Description + "\t" : "N/A" + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }
    private void ExportUnplannedCustomers(string strFileName)
    {
        System.IO.StreamWriter sw = null;
        StringBuilder strFileContents = new StringBuilder();

        try
        {
            //// Retrieve filters from session
            string Customers = (HttpContext.Current.Session["Customers"] != null) ? HttpContext.Current.Session["Customers"].ToString() : "";
            //string Salesman = (HttpContext.Current.Session["Salesman"] != null) ? HttpContext.Current.Session["Salesman"].ToString() : "";
            string Routes = (HttpContext.Current.Session["Routes"] != null) ? HttpContext.Current.Session["Routes"].ToString() : "";

            List<unplannedCustomer> unplannedCustomers = GetUnplannedCustomers(Customers, "", Routes, 1, 50000);

            if (unplannedCustomers != null && unplannedCustomers.Count > 0)
            {
                strFileContents.Append("CustomerCode\tCustomerName\tUserCode\tUserName\tRouteCode\tSales Category\tLatitude\tLongitude\n");

                foreach (unplannedCustomer customer in unplannedCustomers)
                {
                    strFileContents.Append((customer.CustomerCode ?? "N/A") + "\t");
                    strFileContents.Append((customer.CustomerName ?? "N/A") + "\t");
                    strFileContents.Append((customer.UserCode ?? "N/A") + "\t");
                    strFileContents.Append((customer.UserName ?? "N/A") + "\t");
                    strFileContents.Append((customer.RouteCode ?? "N/A") + "\t");
                    strFileContents.Append((customer.SubCategoryCode ?? "N/A") + "\t");
                    strFileContents.Append((customer.Latitude ?? "0") + "\t");
                    strFileContents.Append((customer.Longitude ?? "0") + "\n");
                }

                sw = new System.IO.StreamWriter(strFileName);
                sw.Write(strFileContents.ToString());
            }
        }
        catch (Exception ex)
        {
            // Log the error with custom logging function
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
        finally
        {
            // Ensure the file stream is closed properly
            if (sw != null)
            {
                sw.Close();
            }
        }
    }

    public static List<unplannedCustomer> GetUnplannedCustomers(string Customers, string Salesman, string Routes, int pageNumber, int pageSize)
    {
        List<unplannedCustomer> unplannedCustomers = new List<unplannedCustomer>();
        DbParam[] param = new DbParam[6];
        DataSet ds = new DataSet();
        param[0] = new DbParam("@CustomerCode", Customers, SqlDbType.VarChar);
        param[1] = new DbParam("@SalesmanCode", Salesman, SqlDbType.VarChar);
        param[2] = new DbParam("@RouteCode", Routes, SqlDbType.VarChar);
        param[3] = new DbParam("@UserCode", SessionManager.UserCode, SqlDbType.VarChar);
        param[4] = new DbParam("@PageNumber", pageNumber, SqlDbType.Int);
        param[5] = new DbParam("@PageSize", pageSize, SqlDbType.Int);

        ds = Db.GetDataSet("Sp_UnPlannedCustomers", param);


        if (ds.Tables[0].Rows.Count > 0)
        {
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                unplannedCustomer Cust = new unplannedCustomer();

                if (dr.Table.Columns.Contains("CustomerCode"))
                    Cust.CustomerCode = Db.ToString(dr["CustomerCode"]);

                if (dr.Table.Columns.Contains("CustomerName"))
                    Cust.CustomerName = Db.ToString(dr["CustomerName"]);
                if (dr.Table.Columns.Contains("UserCode"))
                    Cust.UserCode = Db.ToString(dr["UserCode"]);
                if (dr.Table.Columns.Contains("UserName"))
                    Cust.UserName = Db.ToString(dr["UserName"]);
                if (dr.Table.Columns.Contains("RouteCode"))
                    Cust.RouteCode = Db.ToString(dr["RouteCode"]);
                if (dr.Table.Columns.Contains("SubCategoryCode"))
                    Cust.SubCategoryCode = !string.IsNullOrEmpty(Db.ToString(dr["SubCategoryCode"])) ? Db.ToString(dr["SubCategoryCode"]) : "N/A";
                if (dr.Table.Columns.Contains("Latitude"))
                    Cust.Latitude = !string.IsNullOrEmpty(Db.ToString(dr["Latitude"])) ? Db.ToString(dr["Latitude"]) : "0";
                if (dr.Table.Columns.Contains("Longitude"))
                    Cust.Longitude = !string.IsNullOrEmpty(Db.ToString(dr["Longitude"])) ? Db.ToString(dr["Longitude"]) : "0";

                unplannedCustomers.Add(Cust);
            }

        }
        if (ds.Tables[1].Rows.Count > 0)
        {

            unplannedCustomer.TotalCount = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalCount"]);
        }
        return unplannedCustomers;
    }
    public class unplannedCustomer
    {
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string UserCode { get; set; }
        public string UserName { get; set; }
        public string RouteCode { get; set; }
        public string SubCategoryCode { get; set; }
        public static int TotalCount { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }

    private void ExportLoadTemplateByRouteAndDay(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["LoadTemplateByRouteAndDaySearchString"].ToString();


            IList<VanLoadTemplateByRouteAndDay> objReports = null;

            objReports = (new RouteFacade()).GetLoadTemplateByRouteAndDaySearch("ItemCode ASC", 50000, 0, SearchString, "admin");
            if (objReports != null && objReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents
                    .Append("SalesOrgCode" + "\t")
                    .Append("RouteCode" + "\t")
                    .Append("Day" + "\t")
                    .Append("ItemCode" + "\t")
                    .Append("UOM" + "\t")
                    .Append("Quantity" + "\t")
                    .Append("Allow Edit" + "\n");

                foreach (VanLoadTemplateByRouteAndDay objOrderdetails in objReports)
                {
                    strFileContents.Append(objOrderdetails.SalesOrgCode != null ? objOrderdetails.SalesOrgCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode != null ? objOrderdetails.RouteCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.Day != null ? objOrderdetails.Day + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode != null ? objOrderdetails.ItemCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.UOM != null ? objOrderdetails.UOM + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.Quantity + "\t");
                    strFileContents.Append((objOrderdetails.IsEditable == 1 ? "Yes" : "No") + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void GatePassGenerationExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["PassCode_searchString"].ToString();
            string StartDate = Session["PassCode_StartDate"].ToString();
            string EndDate = Session["PassCode_EndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetGatePassCodeSearch("EmpId ASC", 10000000, 0, SearchString, SessionManager.UserCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("UserCode" + "\t" + "UserName" + "\t" + "User_Department" + "\t" + "RouteCode" + "\t" + "RouteName" + "\t" + "CustomerCode" + "\t" + "CustomerName" +
                    "\t" + "ASM_Code" + "\t" + "ASM_Name" + "\t" + "ASM_Department" + "\t" + "RegionCode" + "\t" + "RegionName" + "\t" + "CountryCode" + "\t" + "CountryName" +
                    "\t" + "SalesOrgCode" + "\t" + "PassCode" + "\t" + "IsUsed" + "\t" + "UsedDate" + "\t" + "PassCode Type" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.EmpId != null ? objOrderdetails.EmpId + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.EmpName != null ? objOrderdetails.EmpName + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.User_Department != null ? objOrderdetails.User_Department + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode != null ? objOrderdetails.RouteCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RouteName != null ? objOrderdetails.RouteName + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.CustomerCode != null ? objOrderdetails.CustomerCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName != null ? objOrderdetails.CustomerName + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ASM_Code != null ? objOrderdetails.ASM_Code + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ASM_Name != null ? objOrderdetails.ASM_Name + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ASM_Department != null ? objOrderdetails.ASM_Department + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RegionCode != null ? objOrderdetails.RegionCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RegionName != null ? objOrderdetails.RegionName + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objOrderdetails.ASM_Description != null ? objOrderdetails.ASM_Description + "\t" : "N/A"+ "\t");
                    strFileContents.Append(objOrderdetails.Code != null ? objOrderdetails.Code + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.CountryName != null ? objOrderdetails.CountryName + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.SalesOrgCode != null ? objOrderdetails.SalesOrgCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.DAPassCode != null ? objOrderdetails.DAPassCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.IsUsed != null ? objOrderdetails.IsUsed + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.UsedDate != null ? objOrderdetails.UsedDate + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.PassCodeType != null ? objOrderdetails.PassCodeType + "\t" : "N/A" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ExportMainUnloadRequest(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["UnloadSearchString"].ToString();
            string StartDate = Session["UnloadStartDate"].ToString();
            DateTime StartingDate = Convert.ToDateTime(StartDate);
            string EndDate = Session["UnloadEndDateDate"].ToString();
            DateTime EndingDate = Convert.ToDateTime(EndDate);

            IList<MovementHeader> objOrdersReports = new MovementHeaderFacade().GetMovementHeaderSearchUnLoadExcel("RouteNewCode ASC", 10000000, 0, SearchString, SessionManager.UserCode, StartingDate, EndingDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("MovementCode" + "\t" + "SalesmanCode" + "\t" + "SalesmanName" + "\t" + "RouteCode" + "\t" + "RouteName" + "\t" +
                    "MovementDate" + "\t" + "itemcode" +
                    "\t" + "ItemName" + "\t" + "UOM" + "\t" + "Quantity" + "\n");
                foreach (MovementHeader objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.MovementCode != null ? objOrderdetails.MovementCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.UserCode != null ? objOrderdetails.UserCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.UserName != null ? objOrderdetails.UserName + "\t" : "N/A" + "\t");


                    strFileContents.Append(objOrderdetails.RouteCode != null ? objOrderdetails.RouteCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RouteName != null ? objOrderdetails.RouteName + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.MovementDate != null ? objOrderdetails.MovementDate + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode != null ? objOrderdetails.ItemCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ItemDescription != null ? objOrderdetails.ItemDescription + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.UOM != null ? objOrderdetails.UOM + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.WHQuantity != null ? objOrderdetails.WHQuantity + "\t" : "N/A" + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    private void LoAd(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["PassCode_searchString"].ToString();
            string StartDate = Session["PassCode_StartDate"].ToString();
            string EndDate = Session["PassCode_EndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetGatePassCodeSearch("EmpId ASC", 10000000, 0, SearchString, SessionManager.UserCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("UserCode" + "\t" + "UserName" + "\t" + "User_Department" + "\t" + "RouteCode" + "\t" + "RouteName" + "\t" + "CustomerCode" + "\t" + "CustomerName" +
                    "\t" + "ASM_Code" + "\t" + "ASM_Name" + "\t" + "ASM_Department" + "\t" + "RegionCode" + "\t" + "RegionName" + "\t" + "CountryCode" + "\t" + "CountryName" +
                    "\t" + "SalesOrgCode" + "\t" + "PassCode" + "\t" + "IsUsed" + "\t" + "UsedDate" + "\t" + "PassCode Type" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.EmpId != null ? objOrderdetails.EmpId + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.EmpName != null ? objOrderdetails.EmpName + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.User_Department != null ? objOrderdetails.User_Department + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode != null ? objOrderdetails.RouteCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RouteName != null ? objOrderdetails.RouteName + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.CustomerCode != null ? objOrderdetails.CustomerCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName != null ? objOrderdetails.CustomerName + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ASM_Code != null ? objOrderdetails.ASM_Code + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ASM_Name != null ? objOrderdetails.ASM_Name + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.ASM_Department != null ? objOrderdetails.ASM_Department + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RegionCode != null ? objOrderdetails.RegionCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.RegionName != null ? objOrderdetails.RegionName + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objOrderdetails.ASM_Description != null ? objOrderdetails.ASM_Description + "\t" : "N/A"+ "\t");
                    strFileContents.Append(objOrderdetails.Code != null ? objOrderdetails.Code + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.CountryName != null ? objOrderdetails.CountryName + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.SalesOrgCode != null ? objOrderdetails.SalesOrgCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.DAPassCode != null ? objOrderdetails.DAPassCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.IsUsed != null ? objOrderdetails.IsUsed + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.UsedDate != null ? objOrderdetails.UsedDate + "\t" : "N/A" + "\t");
                    strFileContents.Append(objOrderdetails.PassCodeType != null ? objOrderdetails.PassCodeType + "\t" : "N/A" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }



    private void DropSizeByCustomerExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["DropSizeByCustomer_searchString"].ToString();
            //string StartDate = Session["DropSizeByCustomer_StartDate"].ToString();
            //string EndDate = Session["DropSizeByCustomer_EndDate"].ToString();

            IList<DropSizeByCustomer> objDropSizeByCustomers = new DropSizeByCustomerFacade().GetDropSizeByCustomer("DropSizeID ASC", 10000000, 0, SearchString);
            if (objDropSizeByCustomers != null && objDropSizeByCustomers.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "SelectionType" + "\t" + "SelectionValue" + "\t" + "ItemCode" + "\t" + "MaxQty" + "\t" + "IsActive" +
                    "\t" + "ThresholdPercentage" + "\t" + "DayOftheWeek" + "\t" + "PromoQty" +"\t" + "StartDate" +"\t" + "EndDate" + "\n");
                foreach (DropSizeByCustomer objDropSizeByCustomersdetails in objDropSizeByCustomers)
                {
                    //strFileContents.Append(objDropSizeByCustomersdetails.DropSizeID + "\t");
                    strFileContents.Append(objDropSizeByCustomersdetails.SalesOrgCode != null ? objDropSizeByCustomersdetails.SalesOrgCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objDropSizeByCustomersdetails.SelectionType != null ? objDropSizeByCustomersdetails.SelectionType + "\t" : "N/A" + "\t");
                    strFileContents.Append(objDropSizeByCustomersdetails.SelectionValue != null ? objDropSizeByCustomersdetails.SelectionValue + "\t" : "N/A" + "\t");
                    strFileContents.Append(objDropSizeByCustomersdetails.ItemCode != null ? objDropSizeByCustomersdetails.ItemCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objDropSizeByCustomersdetails.MaxQuantity + "\t");
                    //strFileContents.Append((CommonFunctions.GetStringValue(objDropSizeByCustomersdetails.IsActive) == "" ? "N/A" : CommonFunctions.GetStringValue(objDropSizeByCustomersdetails.IsActive == 1 ? "true" : "False")) + "\t");
                    strFileContents.Append(objDropSizeByCustomersdetails.IsActives + "\t");
                    strFileContents.Append(objDropSizeByCustomersdetails.ThresholdPercentages + "\t");
                    strFileContents.Append(objDropSizeByCustomersdetails.DayOftheWeek != null ? objDropSizeByCustomersdetails.DayOftheWeek + "\t" : "N/A" + "\t");
                    strFileContents.Append(string.IsNullOrEmpty(objDropSizeByCustomersdetails.Attribute1) ? "0" + "\t" : objDropSizeByCustomersdetails.Attribute1 + "\t");
                    strFileContents.Append(string.IsNullOrEmpty(objDropSizeByCustomersdetails.StartDate) ? "N/A" + "\t" : (Db.ToDateTime(objDropSizeByCustomersdetails.StartDate)).ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(string.IsNullOrEmpty(objDropSizeByCustomersdetails.EndDate) ? "N/A" + "\t" : (Db.ToDateTime(objDropSizeByCustomersdetails.EndDate)).ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ActivityLogExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["ActivityLog_searchString"].ToString();
            //string StartDate = Session["DropSizeByCustomer_StartDate"].ToString();
            //string EndDate = Session["DropSizeByCustomer_EndDate"].ToString();

            List<ActivityCapture> GetActivitySearch = new ActivityLogFacade().GetActivitySearchExport("SalesOrgCode ASC", SearchString, "", 10000000, 0);
            if (GetActivitySearch != null && GetActivitySearch.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "User Name" + "\t" + "User Code" + "\t" + "Route Name" + "\t" + "Route Code" + "\t" + "Activity Name" + "\t" + "Activity Date" + "\t" + "Activity StartTime" +
                    "\t" + "Activity EndTime" + "\n");
                foreach (ActivityCapture activity in GetActivitySearch)
                {
                    //strFileContents.Append(objDropSizeByCustomersdetails.DropSizeID + "\t");
                    strFileContents.Append(activity.SalesOrgCode != null ? activity.SalesOrgCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(activity.UserName != null ? activity.UserName + "\t" : "N/A" + "\t");
                    strFileContents.Append(activity.UserCode != null ? activity.UserCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(activity.RouteName != null ? activity.RouteName + "\t" : "N/A" + "\t");
                    strFileContents.Append(activity.RouteCode != null ? activity.RouteCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(activity.ActivityName != null ? activity.ActivityName + "\t" : "N/A" + "\t");
                    strFileContents.Append(activity.ActivityDate != null ? activity.ActivityDate + "\t" : "N/A" + "\t");
                    strFileContents.Append(activity.ActivityStartTime != null ? activity.ActivityStartTime + "\t" : "N/A" + "\t");
                    strFileContents.Append(activity.ActivityEndTime != null ? activity.ActivityEndTime + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objDropSizeByCustomersdetails.ActivityDate != null ? objDropSizeByCustomersdetails.ActivityDate + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objDropSizeByCustomersdetails.MaxQuantity + "\t");
                    ////strFileContents.Append((CommonFunctions.GetStringValue(objDropSizeByCustomersdetails.IsActive) == "" ? "N/A" : CommonFunctions.GetStringValue(objDropSizeByCustomersdetails.IsActive == 1 ? "true" : "False")) + "\t");
                    //strFileContents.Append(objDropSizeByCustomersdetails.IsActives + "\t");
                    //strFileContents.Append(objDropSizeByCustomersdetails.ThresholdPercentages + "\t");
                    //strFileContents.Append(objDropSizeByCustomersdetails.DayOftheWeek != null ? objDropSizeByCustomersdetails.DayOftheWeek + "\t" : "N/A" + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }


    private void DropSizeByRouteExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["DropSizeByCustomer_searchString"].ToString();
            //string StartDate = Session["DropSizeByCustomer_StartDate"].ToString();
            //string EndDate = Session["DropSizeByCustomer_EndDate"].ToString();

            IList<DropSizeByRoutes> objDropSizeByRoutes = new DropSizeByRoutesFacade().GetDropSizeByRoutes("ID ASC", 10000000, 0, SearchString);
            if (objDropSizeByRoutes != null && objDropSizeByRoutes.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "SelectionType" + "\t" + "SelectionValue" + "\t" + "ItemCode" + "\t" + "MaxQty" + "\t" + "IsActive" +
                    "\t" + "ThresholdPercentage" + "\t" + "DayOftheWeek" + "\n");
                foreach (DropSizeByRoutes objDropSizeByRoutesdetails in objDropSizeByRoutes)
                {
                    //strFileContents.Append(objDropSizeByRoutesdetails.ID + "\t");
                    strFileContents.Append(objDropSizeByRoutesdetails.SalesOrgCode != null ? objDropSizeByRoutesdetails.SalesOrgCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objDropSizeByRoutesdetails.SelectionType != null ? objDropSizeByRoutesdetails.SelectionType + "\t" : "N/A" + "\t");
                    strFileContents.Append(objDropSizeByRoutesdetails.SelectionValue != null ? objDropSizeByRoutesdetails.SelectionValue + "\t" : "N/A" + "\t");
                    strFileContents.Append(objDropSizeByRoutesdetails.ItemCode != null ? objDropSizeByRoutesdetails.ItemCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objDropSizeByRoutesdetails.Max_Quantity + "\t");
                    //strFileContents.Append(objDropSizeByRoutesdetails.IsActive + "\t");
                    strFileContents.Append(objDropSizeByRoutesdetails.IsActives + "\t");
                    strFileContents.Append(objDropSizeByRoutesdetails.ThresholdPercentages + "\t");
                    strFileContents.Append(objDropSizeByRoutesdetails.DayOftheWeek != null ? objDropSizeByRoutesdetails.DayOftheWeek + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objDropSizeByRoutesdetails.CreatedBy != null ? objDropSizeByRoutesdetails.CreatedBy + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objDropSizeByRoutesdetails.ModifiedBy != null ? objDropSizeByRoutesdetails.ModifiedBy + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objDropSizeByRoutesdetails.CreatedOn + "\t");
                    //strFileContents.Append(objDropSizeByRoutesdetails.ModifiedDate + "\t");
                    //strFileContents.Append(objDropSizeByRoutesdetails.ModifiedTime + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void EnforceLoadRequestExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["DropSizeByCustomer_searchString"].ToString();
            //string StartDate = Session["DropSizeByCustomer_StartDate"].ToString();
            //string EndDate = Session["DropSizeByCustomer_EndDate"].ToString();

            IList<EnforceLoadRequest> objEnforceLoadRequest = new EnforceLoadRequestFacade().GetEnforceLoadRequest("ID ASC", 10000000, 0, SearchString);
            if (objEnforceLoadRequest != null && objEnforceLoadRequest.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "SelectionType" + "\t" + "SelectionValue" + "\t" + "ItemCode" + "\t" + "MaxQty" + "\t" + "IsActive" +
                    "\t" + "ThresholdDays" + "\t" + "DayOftheWeek" + "\n");
                foreach (EnforceLoadRequest objEnforceLoadRequestdetails in objEnforceLoadRequest)
                {
                    //strFileContents.Append(objEnforceLoadRequestdetails.ID + "\t");
                    strFileContents.Append(objEnforceLoadRequestdetails.SalesOrgCode != null ? objEnforceLoadRequestdetails.SalesOrgCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objEnforceLoadRequestdetails.SelectionType != null ? objEnforceLoadRequestdetails.SelectionType + "\t" : "N/A" + "\t");
                    strFileContents.Append(objEnforceLoadRequestdetails.SelectionValue != null ? objEnforceLoadRequestdetails.SelectionValue + "\t" : "N/A" + "\t");
                    strFileContents.Append(objEnforceLoadRequestdetails.ItemCode != null ? objEnforceLoadRequestdetails.ItemCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objEnforceLoadRequestdetails.Quantity + "\t");
                    strFileContents.Append(objEnforceLoadRequestdetails.IsActives + "\t");
                    strFileContents.Append(objEnforceLoadRequestdetails.ThresholdDays + "\t");
                    strFileContents.Append(objEnforceLoadRequestdetails.DayOftheWeek != null ? objEnforceLoadRequestdetails.DayOftheWeek + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objEnforceLoadRequestdetails.CreatedBy != null ? objEnforceLoadRequestdetails.CreatedBy + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objEnforceLoadRequestdetails.ModifiedBy != null ? objEnforceLoadRequestdetails.ModifiedBy + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objEnforceLoadRequestdetails.CreatedOn + "\t");
                    //strFileContents.Append(objEnforceLoadRequestdetails.ModifiedDate + "\t");
                    //strFileContents.Append(objEnforceLoadRequestdetails.ModifiedTime + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }

    private void ItemCarryOverStockDuringEOTExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["DropSizeByCustomer_searchString"].ToString();
            //string StartDate = Session["DropSizeByCustomer_StartDate"].ToString();
            //string EndDate = Session["DropSizeByCustomer_EndDate"].ToString();

            IList<ItemCarryOverStockDuringEOT> objItemCarryOverStockDuringEOT = new ItemCarryOverStockDuringEOTFacade().GetItemCarryOverStockDuringEOT("ID ASC", 10000000, 0, SearchString);
            if (objItemCarryOverStockDuringEOT != null && objItemCarryOverStockDuringEOT.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode" + "\t" + "SelectionType" + "\t" + "SelectionValue" + "\t" + "ItemCode" + "\t" + "MaxQty" + "\t" + "IsActive" +
                    "\t" + "UOM" + "\t" + "\n");
                foreach (ItemCarryOverStockDuringEOT objItemCarryOverStockDuringEOTdetails in objItemCarryOverStockDuringEOT)
                {
                    //strFileContents.Append(objItemCarryOverStockDuringEOTdetails.ID + "\t");
                    strFileContents.Append(objItemCarryOverStockDuringEOTdetails.SalesOrgCode != null ? objItemCarryOverStockDuringEOTdetails.SalesOrgCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objItemCarryOverStockDuringEOTdetails.SelectionType != null ? objItemCarryOverStockDuringEOTdetails.SelectionType + "\t" : "N/A" + "\t");
                    strFileContents.Append(objItemCarryOverStockDuringEOTdetails.SelectionValue != null ? objItemCarryOverStockDuringEOTdetails.SelectionValue + "\t" : "N/A" + "\t");
                    strFileContents.Append(objItemCarryOverStockDuringEOTdetails.ItemCode != null ? objItemCarryOverStockDuringEOTdetails.ItemCode + "\t" : "N/A" + "\t");
                    strFileContents.Append(objItemCarryOverStockDuringEOTdetails.CaryOverStockLimit + "\t");
                    strFileContents.Append(objItemCarryOverStockDuringEOTdetails.IsActive + "\t");
                    strFileContents.Append(objItemCarryOverStockDuringEOTdetails.UOM + "\t");
                    //strFileContents.Append(objItemCarryOverStockDuringEOTdetails.DayOftheWeek != null ? objItemCarryOverStockDuringEOTdetails.DayOftheWeek + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objItemCarryOverStockDuringEOTdetails.CreatedBy != null ? objItemCarryOverStockDuringEOTdetails.CreatedBy + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objItemCarryOverStockDuringEOTdetails.ModifiedBy != null ? objItemCarryOverStockDuringEOTdetails.ModifiedBy + "\t" : "N/A" + "\t");
                    //strFileContents.Append(objItemCarryOverStockDuringEOTdetails.CreatedOn + "\t");
                    //strFileContents.Append(objItemCarryOverStockDuringEOTdetails.ModifiedDate + "\t");
                    //strFileContents.Append(objItemCarryOverStockDuringEOTdetails.ModifiedTime + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
    }



    private void WastageExceptionExportReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["WastageExceptionSearchString"].ToString();
            string StartDate = Session["WastageExceptionStartDate"].ToString();
            string EndDate = Session["WastageExceptionEndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetWastageExceptionSearch("TrxDate Desc", 10000000, 0, SearchString, SessionManager.UserCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("ASMCode" + "\t" + "ASMName" + "\t" + "SupervisorCode" + "\t" + "SupervisorName" + "\t" + "UserCode"
                    + "\t" + "UserName" + "\t" + "RouteCode" + "\t" + "RouteName" + "\t" + "Date"
                    + "\t" + "ReturnInvoice" + "\t" + "OriginalInvoice" + "\t" + "OriginalInvoiceDate" + "\t" + "ItemCode" + "\t" + "ItemName"
                    + "\t" + "Days Exceeded Threshold (shelf life + 20%) " + "\t" + "Quantity" + "\t" + "UnitPrice" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMName + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorCode + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorName + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(objOrderdetails.ReturnInvoice + "\t");
                    strFileContents.Append(objOrderdetails.OriginalInvoice + "\t");
                    strFileContents.Append(objOrderdetails.OriginalInvoiceDate.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.DaysExced + "\t");
                    strFileContents.Append(objOrderdetails.Quantity + "\t");
                    strFileContents.Append(objOrderdetails.UnitPrice + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void MTDSO_Export(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string RouteCode = Session["Route_EndorseRoute"] == null ? "" : Session["Route_EndorseRoute"].ToString();
            DateTime Date = Session["Report_EndorseDate"] == null ? DateTime.Now : Db.ToDateTime(Session["Report_EndorseDate"]);

            IList<MTDSO_V1> lstMTDSO = new List<MTDSO_V1>();
            lstMTDSO = GetMTDSO(RouteCode, SessionManager.UserCode, Date);
            if (lstMTDSO != null && lstMTDSO.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Route Code" + "\t" + "Selected Date" + "\t" + "JP Date" + "\t" + "Net Sales" + "\t" + "Target Value" + "\t" + "Daily SalesVar" + "\t" + "Daily SalesVar Percent"
                    + "\t" + "Wastage Percentage" + "\t" + "MTD NetSales" + "\t" + "MTD WastagePer" + "\t" + "JourneyCount"
                    + "\t" + "Variance Call" + "\t" + "First Inv" + "\t" + "Last Inv" + "\t" + "Productive Min" + "\t" + "InVoiceLess Than 50 SAR "
                    + "\t" + "Total Unique Item " + "\n");
                foreach (MTDSO_V1 objMTDSO_V1 in lstMTDSO)
                {
                    strFileContents.Append(RouteCode + "\t");
                    strFileContents.Append(Date.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(objMTDSO_V1.JPDate + "\t");
                    strFileContents.Append(objMTDSO_V1.NetSales + "\t");
                    strFileContents.Append(objMTDSO_V1.TargetValue + "\t");
                    strFileContents.Append(objMTDSO_V1.DailySalesVar + "\t");
                    strFileContents.Append(objMTDSO_V1.DailySalesVarPercent + "%" + "\t");
                    strFileContents.Append(objMTDSO_V1.WastagePer + "%" + "\t");
                    strFileContents.Append(objMTDSO_V1.MTDNetSales + "\t");
                    strFileContents.Append(objMTDSO_V1.MTDWastagePer + "%" + "\t");
                    strFileContents.Append(objMTDSO_V1.JourneyCount + "\t");
                    strFileContents.Append(objMTDSO_V1.ActualCall + "\t");
                    strFileContents.Append((objMTDSO_V1.FirstInv == "" ? "N/A" : objMTDSO_V1.FirstInv) + "\t");
                    strFileContents.Append((objMTDSO_V1.LastInv == "" ? "N/A" : objMTDSO_V1.LastInv) + "\t");
                    strFileContents.Append(objMTDSO_V1.ProductiveMin + "\t");
                    strFileContents.Append(objMTDSO_V1.InVoiceLessThan50 + "\t");
                    strFileContents.Append(objMTDSO_V1.TotalNoofItem + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    public IList<MTDSO_V1> GetMTDSO(string RouteCode, string UserCode, DateTime Date)
    {
        DataSet ds = null;
        IList<MTDSO_V1> objMTDSOList = null;
        MTDSO_V1 obMTDSO = new MTDSO_V1();
        // RouteActivityHeader objGetMTDSOHeader = new RouteActivityHeader();
        DbParam[] param = new DbParam[]
            {
                    new DbParam("@RouteCode", RouteCode, SqlDbType.VarChar),
                    new DbParam("@UserCode", UserCode, SqlDbType.VarChar),
                    new DbParam("@Date", Date, SqlDbType.DateTime)
            };

        ds = Db.GetDataSet("usp_MTDSO", param);

        if (ds.Tables.Count > 0)
        {
            int i = 1;
            objMTDSOList = new List<MTDSO_V1>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                obMTDSO = new MTDSO_V1();
                obMTDSO.JPDate = Db.ToString(dr["JPDate"]);
                obMTDSO.NetSales = Db.ToDecimal(dr["NetSales"]);
                obMTDSO.TargetValue = Db.ToDecimal(dr["TargetValue"]);
                obMTDSO.DailySalesVar = Db.ToDecimal(dr["DailySalesVar"]);
                obMTDSO.DailySalesVarPercent = Math.Ceiling(Db.ToDecimal(dr["DailySalesVar"]) * 100 / (Db.ToDecimal(dr["NetSales"]) == 0 ? 1 : Db.ToDecimal(dr["NetSales"])));
                obMTDSO.MTDWastagePer = Math.Ceiling((Db.ToDecimal(dr["MTDWastagePer"]) * 100 / (Db.ToDecimal(dr["MTDNetSales"]) == 0 ? 1 : Db.ToDecimal(dr["MTDNetSales"]))));
                obMTDSO.MTDNetSales = Db.ToDecimal(dr["MTDNetSales"]);
                obMTDSO.JourneyCount = Db.ToDecimal(dr["JourneyCount"]);
                obMTDSO.ActualCall = Db.ToDecimal(dr["ActualCall"]);
                obMTDSO.ProductiveMin = Db.ToInteger(dr["ProductiveMin"]);
                obMTDSO.LastInv = Db.ToString(dr["LastInv"]);
                obMTDSO.FirstInv = Db.ToString(dr["FirstInv"]);
                obMTDSO.InVoiceLessThan50 = Db.ToInteger(dr["InVoiceLessThan50"]);
                obMTDSO.TotalNoofItem = Db.ToInteger(dr["TotalNoofItem"]);
                obMTDSO.WastagePer = Math.Ceiling((Db.ToDecimal(dr["Wastage"]) * 100 / (Db.ToDecimal(dr["NetSales"]) == 0 ? 1 : Db.ToDecimal(dr["NetSales"])))); ;

                objMTDSOList.Add(obMTDSO);

            }
        }



        return objMTDSOList;
    }
    private void DailySalesDetailInvoiceReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["WastageExceptionSearchString"].ToString();
            string StartDate = Session["WastageExceptionStartDate"].ToString();
            string EndDate = Session["WastageExceptionEndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetDailySalesSearch("TrxDate Desc", 10000000, 0, SearchString, SessionManager.UserCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrg Code" + "\t" + "Warehouse Code" + "\t" + "Route Code" + "\t" + "Route Name" + "\t" + "Invoice Code"
                    + "\t" + "Invoice Date" + "\t" + "Reference Number" + "\t" + "Salesman Code" + "\t" + "Salesman Name"
                    + "\t" + "Supervisor Code" + "\t" + "Supervisor Name" + "\t" + "ASM Code" + "\t" + "ASM Name" + "\t" + "Customer Code"
                    + "\t" + "Customer Name " + "\t" + "Customer Type" + "\t" + "Item Type" + "\t" + "Category Code"
                    + "\t" + "Category Name " + "\t" + "Item Code" + "\t" + "Item Name" + "\t" + "UOM"
                    + "\t" + "Unit Price " + "\t" + "Quantity" + "\t" + "Price" + "\t" + "Total Discount Amount"
                    + "\t" + "Total TAX Amount " + "\t" + "Sales Invoice" + "\t" + "Net Sales Invoice" + "\t"
                    + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.SalesOrgCode + "\t");
                    strFileContents.Append(objOrderdetails.WarehouseCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(objOrderdetails.Attribute7 + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorCode + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorName + "\t");
                    strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMName + "\t");
                    strFileContents.Append(objOrderdetails.CustomerCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName + "\t");
                    strFileContents.Append(objOrderdetails.CustomerType + "\t");
                    strFileContents.Append(objOrderdetails.ItemType + "\t");
                    strFileContents.Append(objOrderdetails.CategoryCode + "\t");
                    strFileContents.Append(objOrderdetails.CategoryName + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.UOM + "\t");
                    strFileContents.Append(objOrderdetails.UnitPrice + "\t");
                    strFileContents.Append(objOrderdetails.QuantityBU + "\t");
                    strFileContents.Append(objOrderdetails.Price + "\t");
                    strFileContents.Append(objOrderdetails.TotalDiscountAmount + "\t");
                    strFileContents.Append(objOrderdetails.TotalTAXAmount + "\t");
                    strFileContents.Append(objOrderdetails.SalesInvoice + "\t");
                    strFileContents.Append(objOrderdetails.NetSalesInvoice + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void NonStampDateForMailExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string DateTime = HttpContext.Current.Session["NonStampDateForMail"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetNonStampDetailForMail(DateTime);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrg Code" + "\t" + "Route Code" + "\t" + "Route Name" + "\t" + "Invoice Code"
                    + "\t" + "Invoice Date" + "\t" + "Salesman Code" + "\t" + "Salesman Name"
                    + "\t" + "Supervisor Code" + "\t" + "Supervisor Name" + "\t" + "ASM Code" + "\t" + "ASM Name" + "\t" + "Customer Code"
                    + "\t" + "Customer Name " + "\t" + "IsStamped" + "\t"
                    + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.SalesOrgCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorCode + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorName + "\t");
                    strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMName + "\t");
                    strFileContents.Append(objOrderdetails.CustomerCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName + "\t");
                    strFileContents.Append(objOrderdetails.isStamped + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void CustomerCategoryClassificationExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SalesOrgCode = Session["CustomerCategorySalesOrgCode"].ToString();
            string SubRegion = Session["CustomerCategorySubRegion"].ToString();
            string StartMonth = Session["CustomerCategoryStartMonth"].ToString();
            string EndMonth = Session["CustomerCategoryEndMonth"].ToString();

            IList<PassCode> objPaymentDetails = (new PassCodeFacade()).GetCustomerCategoryClassification("UserCode ASC", 1000000, 0, SalesOrgCode, SubRegion, StartMonth, EndMonth, SessionManager.UserCode);
            if (objPaymentDetails != null && objPaymentDetails.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SubArea" + "\t" + "StartPeriod" + "\t" + "EndPeriod" + "\t" + "Rank"
                    + "\t" + "RouteCode" + "\t" + "RouteName" + "\t" + "ExistingSalesClassCode"
                    + "\t" + "ExistingSalesClassName" + "\t" + "ExistingClassificationCode" + "\t" + "ExistingClassificationName" + "\t" + "CustomerCode" + "\t" + "CustomerName"
                    + "\t" + "Price ListCode " + "\t" + "CustomerType " + "\t" + "CustomerGroupCode" + "\t" + "NetSalesAmount" + "\t"
                     + "Category_Percent " + "\t" + "InvoiceCount" + "\t" + "NewClassificationCode" + "\t"
                      + "NewClassificationName " + "\t" + "NewSalesClassCode" + "\t" + "NewSalesClassName" + "\t"
                       + "Latitude " + "\t" + "Longitude" + "\t" + "SupervisorCode" + "\t" + "SupervisorName" + "\t"
                       + "ASMCode" + "\t" + "ASMName" + "\t"
                      + "Contribution %" + "\t"

                    + "\n");
                foreach (PassCode objOrderdetails in objPaymentDetails)
                {
                    strFileContents.Append(objOrderdetails.Region + "\t");
                    strFileContents.Append(objOrderdetails.StartPeriod + "\t");
                    strFileContents.Append(objOrderdetails.EndPeriod + "\t");
                    strFileContents.Append(objOrderdetails.Rnk + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.ExistingSalesClassCode + "\t");
                    strFileContents.Append(objOrderdetails.ExistingSalesClassName + "\t");
                    strFileContents.Append(objOrderdetails.ExistingClassificationCode + "\t");
                    strFileContents.Append(objOrderdetails.ExistingClassificationName + "\t");

                    strFileContents.Append(objOrderdetails.CustomerCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName + "\t");
                    strFileContents.Append(objOrderdetails.PriceListCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerType + "\t");
                    strFileContents.Append(objOrderdetails.CustomerGroupCode + "\t");
                    strFileContents.Append(objOrderdetails.NetSalesAmount + "\t");
                    strFileContents.Append(objOrderdetails.Category_Percent + "\t");
                    strFileContents.Append(objOrderdetails.InvoiceCount + "\t");
                    strFileContents.Append(objOrderdetails.NewClassificationCode + "\t");
                    strFileContents.Append(objOrderdetails.NewClassificationName + "\t");
                    strFileContents.Append(objOrderdetails.NewSalesClassCode + "\t");
                    strFileContents.Append(objOrderdetails.NewSalesClassName + "\t");
                    strFileContents.Append(objOrderdetails.Latitude + "\t");
                    strFileContents.Append(objOrderdetails.Longitude + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorCode + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorName + "\t");
                    strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMName + "\t");
                    strFileContents.Append(objOrderdetails.Contribution + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void StockMovementExportMTDReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["StockMovementSearchString"].ToString();
            string StartDate = Session["StockMovementStartDate"].ToString();
            string EndDate = Session["StockMovementEndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetStockMovementDetailMTD(StartDate, EndDate, SearchString, SessionManager.UserCode);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("RouteCode" + "\t" + "CategoryCode" + "\t" + "ItemCode" + "\t" + "ItemName" + "\t" + "UOM" + "\t" + "Openingstockqty" + "\t" + "Loadedstockqty" + "\t" + "Van To Van qty"
                    + "\t" + "Soldstockqty" + "\t" + "GRVqty" + "\t" + "UnLoaded stock qty" + "\t" + "Excess qty" + "\t" + "Available stockqty" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.CategoryCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.InternalUOM + "\t");
                    strFileContents.Append(objOrderdetails.Openingstockqty + "\t");
                    strFileContents.Append(objOrderdetails.Loadedstockqty + "\t");
                    strFileContents.Append(objOrderdetails.VanToVanstockqty + "\t");

                    strFileContents.Append(objOrderdetails.Soldstockqty + "\t");
                    strFileContents.Append(objOrderdetails.GRVqty + "\t");
                    strFileContents.Append(objOrderdetails.UnLoadedstockqty + "\t");
                    strFileContents.Append(objOrderdetails.ExcessQty + "\t");
                    strFileContents.Append(objOrderdetails.Closingstockqty + "\t");


                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void StockMovementExportReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["StockMovementSearchString"].ToString();
            string StartDate = Session["StockMovementStartDate"].ToString();
            string EndDate = Session["StockMovementEndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetStockMovementDetail(StartDate, EndDate, SearchString, SessionManager.UserCode);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("RouteCode" + "\t" + "CategoryCode" + "\t" + "ItemCode" + "\t" + "ItemName" + "\t" + "UOM" + "\t" + "Opening Qty" + "\t" + "Loaded Qty" + "\t" + "Van To Van Qty"
                    + "\t" + "Sold Qty" + "\t" + "G.Returns Qty" + "\t" + "Audit Qty" + "\t" + "UnLoaded  Qty" + "\t" + "Available Qty" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.CategoryCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.InternalUOM + "\t");
                    strFileContents.Append(objOrderdetails.Openingstockqty + "\t");
                    strFileContents.Append(objOrderdetails.Loadedstockqty + "\t");
                    strFileContents.Append(objOrderdetails.VanToVanstockqty + "\t");

                    strFileContents.Append(objOrderdetails.Soldstockqty + "\t");
                    strFileContents.Append(objOrderdetails.GRVqty + "\t");
                    strFileContents.Append(objOrderdetails.ExcessQty + "\t");
                    strFileContents.Append(objOrderdetails.UnLoadedstockqty + "\t");

                    strFileContents.Append(objOrderdetails.Closingstockqty + "\t");


                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    public IList<PassCode> GetStockMovementMulDetail(string StartDate, string EndDate, string SearchString, string UserCode, string items)
    {
        IList<PassCode> objPassCodes = new List<PassCode>();

        DbParam[] param = new DbParam[5];
        DataTable dt;

        param[0] = new DbParam("@StartDate", StartDate, SqlDbType.VarChar);
        param[1] = new DbParam("@EndDate", EndDate, SqlDbType.VarChar);
        param[2] = new DbParam("@SearchString", SearchString, SqlDbType.VarChar);
        param[3] = new DbParam("@UserCode", UserCode, SqlDbType.VarChar);
        param[4] = new DbParam("@ItemCodes", items, SqlDbType.VarChar);

        dt = Db.GetDataTable("sp_StockMovementDetail_Multiple_Route_FlatTable_V1", param);

        foreach (DataRow row in dt.Rows)
        {
            PassCode objPassCode = new PassCode();

            objPassCode.RouteCode = Db.ToString(row["RouteCode"]);
            objPassCode.ItemCode = Db.ToString(row["ItemCode"]);
            objPassCode.ItemName = Db.ToString(row["ItemName"]);
            objPassCode.Conversion = Db.ToFloat(row["Conversion"]);
            objPassCode.Openingstockqty = Db.ToFloat(row["Openingstockqty"]);
            objPassCode.Loadedstockqty = Db.ToFloat(row["Loadedstockqty"]);
            objPassCode.Soldstockqty = Db.ToFloat(row["Soldstockqty"]);
            objPassCode.Closingstockqty = Db.ToFloat(row["Closingstockqty"]);
            objPassCode.GRVqty = Db.ToFloat(row["GRVqty"]);
            objPassCode.InternalUOM = Db.ToString(row["InternalUOM"]);
            objPassCode.UnLoadedstockqty = Db.ToFloat(row["UnLoadedstockqty"]);
            objPassCode.VanToVanstockqty = Db.ToFloat(row["VanToVanstockqty"]);
            objPassCode.ExcessQty = Db.ToFloat(row["Excessqty"]);



            objPassCodes.Add(objPassCode);
        }
        return objPassCodes;
    }
    private void StockMovementMultiRouteExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["StockMovementMulSearchString"].ToString();
            string StartDate = Session["StockMovementMulStartDate"].ToString();
            string EndDate = Session["StockMovementMulEndDate"].ToString();
            string ItemCodes = Session["StockMovementMulItemCodes"].ToString();

            IList<PassCode> objOrdersReports = GetStockMovementMulDetail(StartDate, EndDate, SearchString, SessionManager.UserCode, ItemCodes);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("RouteCode" + "\t" + "ItemCode" + "\t" + "ItemName" + "\t" + "UOM" + "\t" +
                "Opening Qty" + "\t" + "Loaded Qty" + "\t" + "Van2Van Qty" + "\t" + "Sold Qty" + "\t" +
                "GRV Qty" + "\t" + "Audit Qty" + "\t" + "Unloaded Qty" + "\t"  +
                "Available Qty" + "\n");

                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.InternalUOM + "\t");
                    strFileContents.Append(objOrderdetails.Openingstockqty + "\t");
                    strFileContents.Append(objOrderdetails.Loadedstockqty + "\t");
                    strFileContents.Append(objOrderdetails.VanToVanstockqty + "\t");
                    strFileContents.Append(objOrderdetails.Soldstockqty + "\t");
                    strFileContents.Append(objOrderdetails.GRVqty + "\t");
                    strFileContents.Append(objOrderdetails.ExcessQty + "\t");
                    strFileContents.Append(objOrderdetails.UnLoadedstockqty + "\t");
                    strFileContents.Append(objOrderdetails.Closingstockqty + "\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void StockMovementExportMulReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["StockMovementSearchString"].ToString();
            string StartDate = Session["StockMovementStartDate"].ToString();
            string EndDate = Session["StockMovementEndDate"].ToString();

            IList<PassCode> objOrdersReports = GetStockMovementDetail(StartDate, EndDate, SearchString, SessionManager.UserCode);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("RouteCode" + "\t" + "ItemCode" + "\t" + "ItemName" + "\t" + "UOM" + "\t" + "Openingstockqty" + "\t" + "Loadedstockqty" + "\t" + "Van To Van qty"
                    + "\t" + "Soldstockqty" + "\t" + "GRVqty" + "\t" + "UnLoaded stock qty" + "\t" + "Excess qty" + "\t" + "Available stockqty" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.InternalUOM + "\t");
                    strFileContents.Append(objOrderdetails.Openingstockqty + "\t");
                    strFileContents.Append(objOrderdetails.Loadedstockqty + "\t");
                    strFileContents.Append(objOrderdetails.VanToVanstockqty + "\t");

                    strFileContents.Append(objOrderdetails.Soldstockqty + "\t");
                    strFileContents.Append(objOrderdetails.GRVqty + "\t");
                    strFileContents.Append(objOrderdetails.UnLoadedstockqty + "\t");
                    strFileContents.Append(objOrderdetails.ExcessQty + "\t");
                    strFileContents.Append(objOrderdetails.Closingstockqty + "\t");


                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    public IList<PassCode> GetStockMovementDetail(string StartDate, string EndDate, string SearchString, string UserCode)
    {
        IList<PassCode> objPassCodes = new List<PassCode>();

        DbParam[] param = new DbParam[4];
        DataTable dt;

        param[0] = new DbParam("@StartDate", StartDate, SqlDbType.VarChar);
        param[1] = new DbParam("@EndDate", EndDate, SqlDbType.VarChar);
        param[2] = new DbParam("@SearchString", SearchString, SqlDbType.VarChar);
        param[3] = new DbParam("@UserCode", UserCode, SqlDbType.VarChar);

        dt = Db.GetDataTable("sp_StockMovementDetail_Multiple_Route_FlatTable", param);

        foreach (DataRow row in dt.Rows)
        {
            PassCode objPassCode = new PassCode();

            objPassCode.Conversion = Db.ToFloat(row["Conversion"]);
            objPassCode.ItemCode = Db.ToString(row["ItemCode"]);
            objPassCode.ItemName = Db.ToString(row["ItemName"]);
            objPassCode.Openingstockqty = Db.ToFloat(row["Openingstockqty"]);
            objPassCode.Loadedstockqty = Db.ToFloat(row["Loadedstockqty"]);
            objPassCode.Soldstockqty = Db.ToFloat(row["Soldstockqty"]);
            objPassCode.Closingstockqty = Db.ToFloat(row["Closingstockqty"]);
            objPassCode.GRVqty = Db.ToFloat(row["GRVqty"]);
            objPassCode.InternalUOM = Db.ToString(row["InternalUOM"]);
            objPassCode.RouteCode = Db.ToString(row["RouteCode"]);
            objPassCode.UnLoadedstockqty = Db.ToFloat(row["UnLoadedstockqty"]);
            objPassCode.VanToVanstockqty = Db.ToFloat(row["VanToVanstockqty"]);
            objPassCode.ExcessQty = Db.ToFloat(row["Excessqty"]);



            objPassCodes.Add(objPassCode);
        }
        return objPassCodes;
    }
    private void StockMovementValueExportReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["StockMovementValueSearchString"].ToString();
            string StartDate = Session["StockMovementValueStartDate"].ToString();
            string EndDate = Session["StockMovementValueEndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetStockMovementValueWiseDetail(StartDate, EndDate, SearchString, SessionManager.UserCode);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Date" + "\t" + "Route Code" + "\t" + "Route Name" + "\t" + "Salesman Code" + "\t" + "Salesman Name" + "\t" + "Opening Value"
                    + "\t" + "Loaded Value" + "\t" + "Sold Value" + "\t" + "G. Return value" + "\t" + "Avl Stock value " + "\t" + "Avg sales per day " + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.TransactionDate + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.OpeningstockValue + "\t");
                    strFileContents.Append(objOrderdetails.LoadedstockValue + "\t");
                    strFileContents.Append(objOrderdetails.SoldstockValue + "\t");
                    strFileContents.Append(objOrderdetails.GrvValue + "\t");
                    strFileContents.Append(objOrderdetails.ClosingstockValue + "\t");
                    strFileContents.Append(objOrderdetails.AvgstockValue + "\t");


                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void VehicleHistoryExportReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["VehicleHistorySearchString"].ToString();
            string StartDate = Session["VehicleHistoryStartDate"].ToString();
            string EndDate = Session["VehicleHistoryEndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetVehicleHistorySearch("UserCode Desc", 10000000, 0, SearchString, SessionManager.UserCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("RouteCode" + "\t" + "RouteName" + "\t" + "UserCode" + "\t" + "UserName" + "\t" + "StartDate"
                    + "\t" + "EndDate" + "\t" + "VehicleCode" + "\t" + "Plate Number" + "\t" + "VehicleName" + "\t" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.StartDate.ToString("MM-dd-yyyy") + "\t");
                    strFileContents.Append(objOrderdetails.EndDate.ToString("MM-dd-yyyy") + "\t");
                    strFileContents.Append(objOrderdetails.VehicleCode + "\t");
                    strFileContents.Append(objOrderdetails.EQP + "\t");
                    strFileContents.Append(objOrderdetails.VehicleName + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void InventoryLocationReportExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["InventoryLocationSearchString"].ToString();
            string StartDate = Session["InventoryLocationStartDate"].ToString();
            string EndDate = Session["InventoryLocationEndDate"].ToString();
            string InventoryCode = Session["InventoryCode"].ToString();
            string ItemCode = Session["ItemCode"].ToString();
            string RouteCode = Session["RouteCode"].ToString();
            string WHCode = Session["WHCode"].ToString();
            IList<PassCode> objOrdersReports = new PassCodeFacade().GetInventoryLocationSearch("InventoryCode Desc", 10000000, 0, SearchString, SessionManager.UserCode, InventoryCode, ItemCode, RouteCode, WHCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("InventoryCode" + "\t" + "LoadDate" + "\t" + "WHCode" + "\t" + "RouteCode" + "\t" + "ItemCode" + "\t" + "ItemName"
                    + "\t" + "UOM" + "\t" + "Qunatity" + "\t" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.InventoryCode + "\t");
                    strFileContents.Append(objOrderdetails.LoadDate.ToString("MMM d, yyyy") + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.L_UOM + "\t");
                    strFileContents.Append(objOrderdetails.Alloc_QtyINLUOM + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void SalesBackInvoicechargeExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["VehicleHistorySearchString"].ToString();
            string StartDate = Session["VehicleHistoryStartDate"].ToString();
            string EndDate = Session["VehicleHistoryEndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetNonStampedInvoiceSearch("UserCode Desc", 10000000, 0, SearchString, SessionManager.UserCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("OrgCode" + "\t" + " Non Stamped Invoice Number" + "\t" + " Non Stamped Invoice Date" + "\t" + "UserCode" + "\t" + "UserName"
                     + "\t" + "SupervisorCode" + "\t" + "SupervisorName" + "\t" + "ASMCode" + "\t" + "ASMName" + "\t" + "RouteCode"
                    + "\t" + "RouteName" + "\t" + "Customer Code" + "\t" + "Customer Name" + "\t" + "Original Invoice No" + "\t" + "Original Invoice Date" + "\t" + "TotalAmount" + "\t" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.OrgCode + "\t");
                    strFileContents.Append(objOrderdetails.NonStampedInvoice_number + "\t");
                    strFileContents.Append(objOrderdetails.CreatedON.ToString("MMM d, yyyy") + "\t");

                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorCode + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorName + "\t");
                    strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMName + "\t");

                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.CustomerCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName + "\t");
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate.ToString("MMM d, yyyy") + "\t");


                    strFileContents.Append(objOrderdetails.TotalAmountDetail + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void NonStampedInvoiceExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["NonStampsearchString"].ToString();

            IList<TrxHeader> objOrdersReports = new PaymentHeaderFacade().GetPaymentHeaderCollection_V1_New("TrxCode Desc", 10000000, 0, SearchString, SessionManager.UserCode);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Order Number" + "\t" + " UserCode" + "\t" + " UserName" + "\t" + "SupervisorCode" + "\t" + "SupervisorName"
                     + "\t" + "ASMCode" + "\t" + "ASMName" + "\t" + "Customer Code" + "\t" + "CustomerName" + "\t" + "RouteCode"
                    + "\t" + "Date" + "\t" + "TotalAmount" + "\t" + "DayCount" + "\t" + "\n");
                foreach (TrxHeader objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorCode + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorName + "\t");
                    strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    strFileContents.Append(objOrderdetails.ASMName + "\t");
                    strFileContents.Append(objOrderdetails.ClientCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate.ToString("MMM d, yyyy") + "\t");
                    strFileContents.Append(objOrderdetails.TotalAmount + "\t");
                    strFileContents.Append(objOrderdetails.DayCount + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }

    private void ExportPendingforstampedInvoices(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string SalemanCodes = Session["SalesmanCodes"].ToString();
            string trxdate = Session["trxdate"].ToString();
            string SessionUserCode = SessionManager.UserCode;
            string SalesOrgCodes = Session["SalesOrgCodes"].ToString();
            string SettledStatus = Session["SettledStatus"].ToString();
            string RouteCode = Session["Route"].ToString();
            string DepotCode = Session["DepotCode"].ToString();
            string Supervisor = Session["Supervisor"].ToString();
            string StartDate = string.Empty;
            string EndDate = string.Empty;
            if (Session["CS_StartDate"] != null)
            {
                StartDate = Session["CS_StartDate"].ToString();
            }
            if (Session["CS_EndDate"] != null)
            {
                EndDate = Session["CS_EndDate"].ToString();
            }


            IList<TrxHeader> objOrdersReports = GetCollectionSettlement_pendingforstampedinvoices_SearchAll("Cashier_UpdatedOn DESC", 500000, 0, SalemanCodes,
              trxdate, SessionUserCode, SalesOrgCodes, SettledStatus, RouteCode, DepotCode, Supervisor, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Invoice Code" + "\t" + " Salesman" + "\t" + " Supervisor" + "\t" + "Customer Code"
                     + "\t" + "Route Code" + "\t" + " Invoice Date" + "\t" + "Amount" + "\t" + "No Of Days" + "\t" + "Sup Stamped Date/Time"+ "\n");
                foreach (TrxHeader objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    strFileContents.Append("[" + objOrderdetails.UserCode + "] " + objOrderdetails.UserName + "\t");
                    strFileContents.Append("[" + objOrderdetails.SupervisorCode + "] " + objOrderdetails.SupervisorName + "\t");
                    //strFileContents.Append("[" + objOrderdetails.ASMCode + "] " + objOrderdetails.ASMName + "\t");
                    strFileContents.Append("[" + objOrderdetails.ClientCode + "] " + objOrderdetails.CustomerName + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate.ToString("MMM d, yyyy HH:mm") + "\t");
                    strFileContents.Append(objOrderdetails.TotalAmount + "\t");
                    strFileContents.Append(objOrderdetails.DayCount + "\t");
                    strFileContents.Append(CommonFunctions.getDateTimeHoursFormat(objOrderdetails.Attribute1, "MMM d, yyyy HH:mm") + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void StampedInvoiceExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string SalemanCodes = Session["SalesmanCodes"].ToString();
            string trxdate = Session["ReceiptDate"].ToString();
            string SessionUserCode = SessionManager.UserCode;
            string SalesOrgCodes = Session["SalesOrgCodes"].ToString();
            string SettledStatus = Session["SettledStatus"].ToString();
            string RouteCode = Session["Route"].ToString();
            string DepotCode = Session["DepotCode"].ToString();
            string Supervisor = Session["Supervisor"].ToString();

            //IList<TrxHeader> objOrdersReports = new PaymentHeaderFacade().GetPaymentHeaderCollection_V1_SI("TrxCode DESC", 500000, 0, SalemanCodes,
            IList<TrxHeader> objOrdersReports = new PaymentHeaderFacade().GetPaymentHeaderCollection_V1_SI_Stamp_Approval("Cashier_UpdatedOn DESC", 500000, 0, SalemanCodes,
              trxdate, SessionUserCode, SalesOrgCodes, SettledStatus, RouteCode, DepotCode, Supervisor);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Order Number" + "\t" + " UserCode" + "\t" + " UserName" + "\t" + "SupervisorCode" + "\t" + "SupervisorName"
                     + "\t" + "Customer Code" + "\t" + "CustomerName" + "\t" + "RouteCode"
                    + "\t" + "Date" + "\t" + "TotalAmount" + "\t" + "DayCount" + "\t" + "Cashier_UpdatedOn" + "\t" + "Comments" + "\t" + "\n");
                foreach (TrxHeader objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.TrxCode + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorCode + "\t");
                    strFileContents.Append(objOrderdetails.SupervisorName + "\t");
                    //strFileContents.Append(objOrderdetails.ASMCode + "\t");
                    //strFileContents.Append(objOrderdetails.ASMName + "\t");
                    strFileContents.Append(objOrderdetails.ClientCode + "\t");
                    strFileContents.Append(objOrderdetails.CustomerName + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.TrxDate.ToString("MMM d, yyyy") + "\t");
                    strFileContents.Append(objOrderdetails.TotalAmount + "\t");
                    strFileContents.Append(objOrderdetails.DayCount + "\t");
                    strFileContents.Append(objOrderdetails.Cashier_UpdatedOn.ToString("MMM d, yyyy") + "\t");
                    strFileContents.Append((objOrderdetails.Reason==null || objOrderdetails.Reason == "")? "No Comments" : objOrderdetails.Reason + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void RouteWiseLoadRequestReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["RouteWiseLoadRequestSearchString"].ToString();
            string StartDate = Session["RouteWiseLoadRequestStartDate"].ToString();
            string EndDate = Session["RouteWiseLoadRequestEndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetRouteWiseLoadRequestSearch("MovementDate Desc", 10000000, 0, SearchString, SessionManager.UserCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Date" + "\t" + "OrgCode" + "\t" + "RouteCode" + "\t" + "UserCode" + "\t" + "WHCode"
                    + "\t" + "ItemCode" + "\t" + "ItemName" + "\t" + "UOM" + "\t" + "Quantity" + "\t" + "Load Delivery Date" + "\t" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.MovementDate.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(objOrderdetails.OrgCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.UOM + "\t");
                    strFileContents.Append(objOrderdetails.Quantity + "\t");
                    strFileContents.Append(objOrderdetails.OrderedDate.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }

    private void DepotWiseLoadRequestReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["DepotWiseLoadRequestSearchString"].ToString();
            string StartDate = Session["DepotWiseLoadRequestStartDate"].ToString();
            string EndDate = Session["DepotWiseLoadRequestEndDate"].ToString();
            string DepotCode = Session["DepotWiseLoadRequestDepotCode"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetDepotWiseLoadRequestSearch("MovementDate Desc", 10000000, 0, SearchString, SessionManager.UserCode, DepotCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("Date" + "\t" + "OrgCode" + "\t" + "WHCode" + "\t" + "WH Name"
                 + "\t" + "Item Cat Code" + "\t" + "ItemCode" + "\t" + "ItemName" + "\t" + "UOM" + "\t" + "Quantity" + "\t" + "Shipping UOM" + "\t" + "Quantity(in Shipping UOM)" + "\t" + "Load Delivery Date" + "\t" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.MovementDate.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(objOrderdetails.OrgCode + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.Description + "\t");
                    strFileContents.Append(objOrderdetails.CategoryCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.UOM + "\t");
                    strFileContents.Append(objOrderdetails.Quantity + "\t");
                    strFileContents.Append(objOrderdetails.S_UOM + "\t");
                    strFileContents.Append(objOrderdetails.QuantityLevel1 + "\t");
                    strFileContents.Append(objOrderdetails.OrderedDate.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void SFAJDELoadComparisonReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        decimal AllocatedQty = 0;
        try
        {
            string StartDate = Session["JDESFAStartDate"].ToString();
            string SearchString = Session["JDESFASearchString"].ToString();


            IList<PassCode> objOrdersReports = new PassCodeFacade().GetSFAJDELoadComparionSearch(SessionManager.UserCode, StartDate, SearchString);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("LoadDate" + "\t" + "WHCode" + "\t" + "ItemCode" + "\t" + "AllocatedUOM" + "\t" + "AllocatedQtyINUOM" + "\t");
                foreach (PassCode objRouteDetail in objOrdersReports)
                {
                    foreach (SFAJDEComparisonRoute objSFAJDEComparisonRoute in objRouteDetail.objSFAJDERouteList)
                    {
                        strFileContents.Append(objSFAJDEComparisonRoute.RouteCode + "\t");
                    }
                }
                strFileContents.Append("Total" + "\t" + "Variance between alocated and Transferred" + "\t");
                strFileContents.Append("\n");

                foreach (PassCode objOrderdetails in objOrdersReports)
                {

                    strFileContents.Append(objOrderdetails.LoadDate.ToString("MM-dd-yyyy") + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.AllocatedUOM + "\t");
                    strFileContents.Append(objOrderdetails.AllocatedQty + "\t");
                    foreach (SFAJDEComparison objSFAJDEComparisonRoute in objOrderdetails.objSFAJDEComnparisonList)
                    {
                        strFileContents.Append(objSFAJDEComparisonRoute.TotAlloc_QtyInLUOM + "\t");
                    }
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void SFAJDELoadComparisonReportExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string StartDate = Session["JDESFAStartDate"].ToString();
            string SearchString = Session["JDESFASearchString"].ToString();

            DataSet ds = new PassCodeFacade().GetSFAJDELoadComparionSearchExport(SessionManager.UserCode, StartDate, SearchString);
            int count = 0, ColumnCount = 0, ValueCount = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                PassCode obj = new PassCode();
                strFileContents = new StringBuilder();
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                //foreach (DataRow row in ds.Tables[0].Rows)
                //{
                foreach (DataColumn dc in ds.Tables[0].Columns)
                    //obj.RouteCode = Db.ToString(row["COLUMN_NAME"]);
                    //strFileContents.Append(Db.ToString(row["COLUMN_NAME"]) + "\t");
                    strFileContents.Append(Db.ToString(dc.ColumnName) + "\t");
                ColumnCount++;
                //}
                // }
                strFileContents.Append("\n");
                int i = ds.Tables[0].Columns.Count;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    //while (count < ColumnCount)
                    // {
                    //while (ValueCount < ColumnCount)
                    //{
                    // strFileContents.Append(ds.Tables[1].Columns[count] + "/t");
                    //strFileContents.Append(ds.Tables[1].Rows[count][ValueCount]);

                    foreach (DataRow Row in ds.Tables[0].Rows)
                    {
                        while (count < i)
                        {
                            string DataValue = Row[count].ToString();
                            strFileContents.Append(DataValue == "" ? "0" : DataValue);
                            strFileContents.Append("\t");
                            count++;
                        }
                        strFileContents.Append("\n");

                        count = 0;
                    }
                    strFileContents.Append("\n");
                    // ValueCount++;
                    //}
                    strFileContents.Append("/n");
                    // ValueCount = 0;
                    //  count++;
                    //}
                }

                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void LoadRequestComparisonReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["LoadRequestComparisonSearchString"].ToString();
            string StartDate = Session["LoadRequestComparisonStartDate"].ToString();
            string EndDate = Session["LoadRequestComparisonEndDate"].ToString();

            IList<PassCode> objOrdersReports = new PassCodeFacade().GetLoadRequestComparisonSearch("MovementDate Desc", 10000000, 0, SearchString, SessionManager.UserCode, StartDate, EndDate);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("MovementCode" + "\t" + "UserCode" + "\t" + "UserName" + "\t" + "RouteCode" + "\t" + "WHCode"
                    + "\t" + "Load Req Date" + "\t" + "Delivery Date" + "\t" + "Item Cat Code" + "\t" + "ItemCode" + "\t" + "ItemName" + "\t" + "Type" + "\t" + "UOM" + "\t" + "Req Qty" + "\t"
                    + "Sup App Qty" + "\t" + "Rec Qty" + "\t" + "Variance" + "\t" + "\n");
                foreach (PassCode objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.MovementCode + "\t");
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.MovementDate.ToString("dd/MM-yyyy") + "\t");
                    strFileContents.Append(objOrderdetails.DeliveredDate.ToString("dd/MM-yyyy") + "\t");
                    strFileContents.Append(objOrderdetails.CategoryCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.LoadType + "\t");
                    strFileContents.Append(objOrderdetails.SellingUOM + "\t");
                    strFileContents.Append(objOrderdetails.QuantityLevel1 + "\t");
                    strFileContents.Append(objOrderdetails.ApprovedQuantity + "\t");
                    strFileContents.Append(objOrderdetails.ShippedQuantity + "\t");
                    strFileContents.Append(CommonFunctions.getIntValue(objOrderdetails.ShippedQuantity) - CommonFunctions.getIntValue(objOrderdetails.ApprovedQuantity) + "\t");



                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void WareHouseItemStockExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {

            string SearchString = Session["WareHouseStockSearchString"].ToString();
            string WarehouseCode = Session["WareHouseStockWareHouse"].ToString();
            string SalesOrgCode = Session["WareHouseStockSalesOrg"].ToString();

            IList<WareHouseStock> objOrdersReports = new WarehouseStockFacade().GetWarehouseStockByWHCode_New("ItemCode ASC", 10000000, 0, SearchString, WarehouseCode, SalesOrgCode);
            if (objOrdersReports != null && objOrdersReports.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("ItemCode" + "\t" + "ItemName" + "\t" + "WHCode" + "\t" + "WH Name" + "\t" + "Quantity" + "\t" + "UOM" + "\t" + "\n");
                foreach (WareHouseStock objOrderdetails in objOrdersReports)
                {
                    strFileContents.Append(objOrderdetails.ItemCode + "\t");
                    strFileContents.Append(objOrderdetails.ItemName + "\t");
                    strFileContents.Append(objOrderdetails.WHCode + "\t");
                    strFileContents.Append(objOrderdetails.Warehouse + "\t");
                    strFileContents.Append(objOrderdetails.Quantity + "\t");
                    strFileContents.Append(objOrderdetails.UOM + "\t");
                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }

    private void Session_EndorsementExport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            DataSet ds = null;
            string result = "";
            DataSet dsresult = new DataSet();
            string Date = "";
            string Route = "";
            if (Session["Report_EndorseDate"] != null && Session["Report_EndorseDate"].ToString() != "")
            {
                Date = Session["Report_EndorseDate"].ToString();
            }
            if (Session["Route_EndorseRoute"] != null && Session["Route_EndorseRoute"].ToString() != "")
            {
                Route = Session["Route_EndorseRoute"].ToString();
            }

            DbParam[] param = new DbParam[2];
            param[0] = new DbParam("@RouteCode", Route, SqlDbType.VarChar);
            param[1] = new DbParam("@Date", Convert.ToDateTime(Date), SqlDbType.DateTime);

            ds = Db.GetDataSet("usp_Endorsement_SalesOverView_ByRouteday", param);

            if (ds.Tables.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("RouteCode:" + Route + "\t");
                strFileContents.Append("Date:" + Date + "\t");
                strFileContents.Append("User:" + (Session["EndorsementUser"] == null ? "" : Session["EndorsementUser"].ToString()) + "\t");
                strFileContents.Append("\n");
                DataTable dtCategories = new DataTable("dtCallsSalesOverView");
                DataTable dtCategory = new DataTable("dtCategory");
                dtCategory = ds.Tables[0];
                dtCategories.Columns.Add(new DataColumn("SalesOverView", typeof(string)));
                strFileContents.Append("SalesOverView" + "\t");
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string Entity = dr["CategoryDescription"].ToString();

                    strFileContents.Append(Entity + "\t");
                }
                strFileContents.Append("\n");
                float TotalSales = 0F;
                float TotalTgtDailySales = 0F;
                float TotalNetMtdSales = 0F;
                float TotalMtdtargetSales = 0F;
                float MaxDistributionForTheDay = 0F;
                float MaxMTDDistributionTillDate = 0F;
                float MaxTillDateCustomers = 0F;
                float MaxNoCustomersAsPerJCP = 0F;
                float MaxNoDistributions = 0F;
                foreach (DataRow drEntity in ds.Tables[1].Rows)
                {
                    DataRow dr = dtCategories.NewRow();
                    if (drEntity["EntityName"].ToString() == "Distribution For The Day")
                    {
                        strFileContents.Append("Distribution exception day" + "\t");
                    }
                    else if (drEntity["EntityName"].ToString() == "MTD Distribution Till Date")
                    {
                        strFileContents.Append("MTD Distribution exception" + "\t"); ;
                    }
                    else
                        strFileContents.Append(drEntity["EntityName"].ToString() + "\t");
                    foreach (DataRow drCategory in ds.Tables[0].Rows)
                    {
                        try
                        {

                            DataRow drvale = ds.Tables[2].Select("CategoryCode='" + drCategory["CategoryCode"].ToString() + "' and EntityName='" + drEntity["EntityName"].ToString() + "'").FirstOrDefault();

                            if (drEntity["EntityName"].ToString() == "Distribution For The Day" && drvale["CategoryCode"].ToString() != "Total")
                            {
                                if (MaxDistributionForTheDay <= CommonFunctions.getFloatValue(drvale["EntityValue"]))
                                {
                                    MaxDistributionForTheDay = 0;
                                    MaxDistributionForTheDay = CommonFunctions.getFloatValue(drvale["EntityValue"]);
                                }

                            }
                            if (drEntity["EntityName"].ToString() == "No Distribution" && drvale["CategoryCode"].ToString() != "Total")
                            {
                                if (MaxNoDistributions <= CommonFunctions.getFloatValue(drvale["EntityValue"]))
                                {
                                    MaxNoDistributions = 0;
                                    MaxNoDistributions = CommonFunctions.getFloatValue(drvale["EntityValue"]);
                                }

                            }
                            if (drEntity["EntityName"].ToString() == "MTD Distribution Till Date" && drvale["CategoryCode"].ToString() != "Total")
                            {
                                if (MaxMTDDistributionTillDate <= CommonFunctions.getFloatValue(drvale["EntityValue"]))
                                {
                                    MaxMTDDistributionTillDate = 0;
                                    MaxMTDDistributionTillDate = CommonFunctions.getFloatValue(drvale["EntityValue"]);
                                }
                            }
                            if (drEntity["EntityName"].ToString() == "Till Date Customers As Per JCP" && drvale["CategoryCode"].ToString() != "Total")
                            {
                                if (MaxTillDateCustomers <= CommonFunctions.getFloatValue(drvale["EntityValue"]))
                                {
                                    MaxTillDateCustomers = 0;
                                    MaxTillDateCustomers = CommonFunctions.getFloatValue(drvale["EntityValue"]);
                                }
                            }
                            if (drEntity["EntityName"].ToString() == "No. Customers As Per JCP" && drvale["CategoryCode"].ToString() != "Total")
                            {
                                if (MaxNoCustomersAsPerJCP <= CommonFunctions.getFloatValue(drvale["EntityValue"]))
                                {
                                    MaxNoCustomersAsPerJCP = 0;
                                    MaxNoCustomersAsPerJCP = CommonFunctions.getFloatValue(drvale["EntityValue"]);
                                }

                            }

                            if (drEntity["EntityName"].ToString() == "Net Sales SR")
                            {
                                TotalSales += CommonFunctions.getFloatValue(drvale["EntityValue"]);
                            }
                            if (drEntity["EntityName"].ToString() == "Tgt Daily Sales")
                            {
                                TotalTgtDailySales += CommonFunctions.getFloatValue(drvale["EntityValue"]);
                            }
                            if (drEntity["EntityName"].ToString() == "MTD Net Sales")
                            {
                                TotalNetMtdSales += CommonFunctions.getFloatValue(drvale["EntityValue"]);
                            }
                            if (drEntity["EntityName"].ToString() == "MTD Target Sales")
                            {
                                TotalMtdtargetSales += CommonFunctions.getFloatValue(drvale["EntityValue"]);
                            }

                            if (drvale != null)
                            {
                                if (drEntity["EntityName"].ToString() == "Achievement%" && drvale["CategoryCode"].ToString() == "Total")
                                {
                                    strFileContents.Append(Math.Round(CommonFunctions.getFloatValue(((TotalSales) * 1.0 / TotalTgtDailySales) * 100), 0) + "%\t"); ;
                                }
                                else if (drEntity["EntityName"].ToString() == "MTD Ach%" && drvale["CategoryCode"].ToString() == "Total")
                                {
                                    strFileContents.Append(Math.Round(CommonFunctions.getFloatValue(((TotalNetMtdSales) * 1.0 / TotalMtdtargetSales) * 100), 0) + "%\t"); ;
                                }
                                else if (drEntity["EntityName"].ToString() == "Distribution Achievement" && drvale["CategoryCode"].ToString() == "Total")
                                {
                                    strFileContents.Append(Math.Round(CommonFunctions.getFloatValue(((MaxDistributionForTheDay) * 1.0 / MaxNoCustomersAsPerJCP) * 100), 0) + "\t");
                                }
                                else if (drEntity["EntityName"].ToString() == "Distribution MTD Achievement" && drvale["CategoryCode"].ToString() == "Total")
                                {
                                    strFileContents.Append(Math.Round(CommonFunctions.getFloatValue(((MaxMTDDistributionTillDate) * 1.0 / MaxTillDateCustomers) * 100), 0) + "\t");
                                }
                                else if (drEntity["EntityName"].ToString() == "Distribution For The Day" && drvale["CategoryCode"].ToString() == "Total")
                                {
                                    strFileContents.Append(Math.Round(CommonFunctions.getFloatValue(MaxDistributionForTheDay)));
                                }
                                else if (drEntity["EntityName"].ToString() == "MTD Distribution Till Date" && drvale["CategoryCode"].ToString() == "Total")
                                {
                                    strFileContents.Append(Math.Round(CommonFunctions.getFloatValue(MaxMTDDistributionTillDate)));
                                }
                                else if (drEntity["EntityName"].ToString() == "Till Date Customers As Per JCP" && drvale["CategoryCode"].ToString() == "Total")
                                {
                                    strFileContents.Append(Math.Round(CommonFunctions.getFloatValue(MaxTillDateCustomers)));
                                }
                                else if (drEntity["EntityName"].ToString() == "No. Customers As Per JCP" && drvale["CategoryCode"].ToString() == "Total")
                                {
                                    strFileContents.Append(Math.Round(CommonFunctions.getFloatValue(MaxNoCustomersAsPerJCP)));
                                }
                                else
                                    strFileContents.Append(drvale["EntityValue"].ToString() + "\t");
                            }
                            else
                                strFileContents.Append("0" + "\t");

                        }
                        catch (Exception ee)
                        {
                            Db.LogError(ee, "SP_SalesOverVieweReport", "TrxHeaderDao");
                        }
                    }
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();

            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    private void ExportCollecionSettlement(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {
            string SalemanCodes = Session["SalesmanCodes"].ToString();
            string ReceiptDate = Session["ReceiptDate"].ToString();
            string SessionUserCode = SessionManager.UserCode;
            string SalesOrgCodes = Session["SalesOrgCodes"].ToString();
            string SettledStatus = Session["SettledStatus"].ToString();
            string RouteCode = Session["Route"].ToString();
            string DepotCode = Session["DepotCode"].ToString();
            string Supervisor = Session["Supervisor"].ToString();


            IList<Settlement> objOrdersReport = new SettlementFacade().GetSettlementsCollectionSearch("Usercode ASC", 500000, 0, SalemanCodes,
              ReceiptDate, SessionUserCode, SalesOrgCodes, SettledStatus, RouteCode, DepotCode, Supervisor);
            if (objOrdersReport != null && objOrdersReport.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesmanCode" + "\t" + "Salesman" + "\t" + "RouteCode" + "\t" + "Route" + "\t" + "ReceiptDate" + "\t" + "Cash Sales" + "\t" + "Cashier Received" + "\t" + "Shortage Amount" + "\t" + "Excess Amount" + "\n");
                foreach (var objOrderdetails in objOrdersReport)
                {
                    strFileContents.Append(objOrderdetails.UserCode + "\t");
                    strFileContents.Append(objOrderdetails.UserName + "\t");
                    strFileContents.Append(objOrderdetails.RouteCode + "\t");
                    strFileContents.Append(objOrderdetails.RouteName + "\t");
                    //strFileContents.Append("[ " + objOrderdetails.UserCode + "]" + objOrderdetails.UserName + "\t");
                    //strFileContents.Append("[ " + objOrderdetails.RouteCode + "]" + objOrderdetails.RouteName + "\t");
                    strFileContents.Append(objOrderdetails.ReceiptDate.ToString("yyyy-MM-dd") + "\t");
                    strFileContents.Append(objOrderdetails.Amount + "\t");
                    strFileContents.Append(objOrderdetails.TotalPayingAmount + "\t");
                    strFileContents.Append(objOrderdetails.TotalCashCollectedValue + "\t");
                    strFileContents.Append(objOrderdetails.EXCESSAmount + "\t");

                    strFileContents.Append("\n");

                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }


    }
    private void ExportFileItemwiseSalesAndWastageData(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {


            string ToDate = Session["ItemwiseSalesToDate"] == null ? "" : Convert.ToDateTime(Session["ItemwiseSalesToDate"]).ToString("yyyy-MM-dd");
            string fromDate = Session["ItemwiseSalesFromDate"] == null ? "" : Convert.ToDateTime(Session["ItemwiseSalesFromDate"]).ToString("yyyy-MM-dd");
            string SalesOrg = Session["ItemwiseSalesSalesOrg"] == null ? "" : Session["ItemwiseSalesSalesOrg"].ToString();
            string ScratchDepots = Session["ItemwiseSalesDepots"] == null ? "" : Session["ItemwiseSalesDepots"].ToString();
            string ScratchRoutess = Session["ItemwiseSalesRoutes"] == null ? "" : Session["ItemwiseSalesRoutes"].ToString();
            string Salesman = Session["ItemwiseSalesSalesman"] == null ? "" : Session["ItemwiseSalesSalesman"].ToString();
            string Supervisor = Session["ItemwiseSalesSupervisor"] == null ? "" : Session["ItemwiseSalesSupervisor"].ToString();




            IList<ItemwiseSalesAndWastageData> objlstItemwiseSalesAndWastageData = new ItemwiseSalesAndWastageDataFacade().ItemwiseSalesAndWastageDataSearch("TrxCode ASC", 500000, 0, ScratchRoutess, Salesman
                        , fromDate, ToDate, SalesOrg, Supervisor, SessionManager.UserCode.ToString());



            if (objlstItemwiseSalesAndWastageData != null && objlstItemwiseSalesAndWastageData.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("TrxDate " + "\t" + "RouteCode" + "\t" + "SupervisorCode" + "\t" + "SupervisorName" + "\t"
                    + "ItemCode" + "\t" + "ItemName" + "\t" + "SubCategoryCode" + "\t" + "SubCategoryName" + "\t" + "SalesQty" + "\t" + "UOM"
                    + "\t" + "NetSales" + "\t" + "GrossSales" + "\t" + "Wastage" + "\t" + "SalesTarget" + "\n");
                //strFileContents.Append("\n");
                foreach (ItemwiseSalesAndWastageData objScratchCard in objlstItemwiseSalesAndWastageData)
                {
                    strFileContents.Append(objScratchCard.TrxDate + "\t");
                    strFileContents.Append(objScratchCard.RouteCode.ToString() == "" ? "N/A" : objScratchCard.RouteCode.ToString() + "\t");
                    strFileContents.Append(objScratchCard.SupervisorCode + "\t");
                    strFileContents.Append(objScratchCard.SupervisorName.ToString() == "" ? "N/A" : objScratchCard.SupervisorName + "\t");
                    strFileContents.Append(objScratchCard.ItemCode.ToString() == "" ? "N/A" : objScratchCard.ItemCode + "\t");
                    strFileContents.Append(objScratchCard.ItemName.ToString() == "" ? "N/A" : objScratchCard.ItemName + "\t");
                    strFileContents.Append(objScratchCard.SubCategoryCode.ToString() == "" ? "N/A" : objScratchCard.SubCategoryCode + "\t");
                    strFileContents.Append(objScratchCard.SubCategoryName.ToString() == "" ? "N/A" : objScratchCard.SubCategoryName + "\t");
                    strFileContents.Append(objScratchCard.SalesQty.ToString() == "" ? "N/A" : objScratchCard.SalesQty + "\t");
                    strFileContents.Append(objScratchCard.UOM.ToString() == "" ? "N/A" : objScratchCard.UOM + "\t");
                    strFileContents.Append(objScratchCard.NetSales.ToString() == "" ? "N/A" : objScratchCard.NetSales + "\t");
                    strFileContents.Append(objScratchCard.GrossSales.ToString() == "" ? "N/A" : objScratchCard.GrossSales + "\t");
                    strFileContents.Append(objScratchCard.Wastage.ToString() == "" ? "N/A" : objScratchCard.Wastage + "\t");
                    strFileContents.Append(objScratchCard.SalesTarget.ToString() == "" ? "N/A" : objScratchCard.SalesTarget + "\t");


                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }

        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }


    }

    private void ExportHolidayRouteCustomerMapping(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;
        try
        {


            string searchString = Session["HRCM_SearchString"] == null ? "" : Session["HRCM_SearchString"].ToString();




            IList<Holiday> objHolidaylst = new HolidayFacade().GetHolidayRouteCustomer("SalesOrgCode ASC", 500000, 0, searchString, SessionManager.UserCode);



            if (objHolidaylst != null && objHolidaylst.Count > 0)
            {
                strFileContents = new StringBuilder();
                strFileContents.Append("SalesOrgCode " + "\t" + "Customer Code" + "\t" + "RouteCode" + "\t" + "Week Name" + "\t"
                    + "Visit Sequence" + "\n");
                foreach (Holiday objHoliday in objHolidaylst)
                {
                    strFileContents.Append(objHoliday.SalesOrgCode.ToString() == "" ? "N/A" : objHoliday.SalesOrgCode.ToString() + "\t");
                    strFileContents.Append(objHoliday.CustomerCode.ToString() == "" ? "N/A" : objHoliday.CustomerCode.ToString() + "\t");
                    strFileContents.Append(objHoliday.RouteCode.ToString() == "" ? "N/A" : objHoliday.RouteCode.ToString() + "\t");
                    strFileContents.Append(objHoliday.WeekName.ToString() == "" ? "N/A" : objHoliday.WeekName.ToString() + "\t");
                    strFileContents.Append(objHoliday.VisitSequence.ToString() == "" ? "N/A" : objHoliday.VisitSequence.ToString() + "\t");
                    strFileContents.Append("\n");
                }
                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }

        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }


    }
    public void ExportCurrentVanStockReport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        string SearchString = HttpContext.Current.Session["SessionCurrentVanStockReport"].ToString();
        IList<VanStock> objVanStockDetails = new VanStockFacade().GetVanStockDetailReport(SearchString, "UserName Desc", 99999999, 0);

        if ((objVanStockDetails != null && objVanStockDetails.Count > 0))
        {
            strFileContents = new StringBuilder();
            if (objVanStockDetails != null && objVanStockDetails.Count > 0)
            {
                //int Count =Convert.ToInt16(lstobj[0].Count);
                strFileContents.Append(" UserName\t" + "SalesOrgCode\t" + "VehicleCode\t" + "ItemCode\t" + "ItemName\t" +
                    "SellableQuantity\t" + "RouteCode\t" + "RouteName\t" + "\n");
                foreach (VanStock objVanStock in objVanStockDetails)
                {
                    strFileContents.Append(objVanStock.UserName + "\t");
                    strFileContents.Append(objVanStock.SalesOrgCode + "\t");
                    strFileContents.Append(objVanStock.VehicleCode + "\t");
                    strFileContents.Append(objVanStock.ItemCode + "\t");
                    strFileContents.Append(objVanStock.ItemName + "\t");
                    strFileContents.Append(objVanStock.SellableQuantity + "\t");
                    strFileContents.Append(objVanStock.RouteCode + "\t");
                    strFileContents.Append(objVanStock.RouteName + "\t");


                    strFileContents.Append("\n");
                }
                strFileContents.Append("\n");
                strFileContents.Append("\n\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }
    }
    private void ExportJourneyplanBulkImport(string strFileName)
    {
        System.IO.StreamWriter sw;
        StringBuilder strFileContents = null;

        int HeaderId = Convert.ToInt32(Session["JourneyPlanBulkImportHeaderId"].ToString());
        string SearchString = Session["JourneyPlanBulkImportSearchstring"] != null ? Session["JourneyPlanBulkImportSearchstring"].ToString() : "1=1";

        IList<CustomerMovementNew> lstCustomerMovementNew = GetJourneyPlanbulkImport_Export(HeaderId, SearchString);

        if (lstCustomerMovementNew != null && lstCustomerMovementNew.Count > 0)
        {
            strFileContents = new StringBuilder();
            strFileContents.Append("Customer Code" + "\t" + "Customer Name" + "\t" + "Classification" + "\t" + "Existing Route" + "\t" + "Delivery Type" + "\t" + "Existing Region" + "\t" + "New Route" + "\t Delivery Type" +
                "\t New Region" + "\t Visit Sequence" + "\t Week Day" + "\t Visit Frequency" + "\t Reason" + "\n");
            strFileContents.Append("\n");
            foreach (CustomerMovementNew obj in lstCustomerMovementNew)
            {
                strFileContents.Append(obj.CustomerCode != null ? (obj.CustomerCode != "" ? obj.CustomerCode : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.CustomerName != null ? (obj.CustomerName != "" ? obj.CustomerName : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.Classification != null ? (obj.Classification != "" ? obj.Classification : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.RouteCode != null ? (obj.RouteCode != "" ? obj.RouteCode : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.OldRouteDeliveryType != null ? (obj.OldRouteDeliveryType != "" ? obj.OldRouteDeliveryType : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.RegionCode != null ? (obj.RegionCode != "" ? obj.RegionCode : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.NewRoute != null ? (obj.NewRoute != "" ? obj.NewRoute : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.NewRouteDeliveryType != null ? (obj.NewRouteDeliveryType != "" ? obj.NewRouteDeliveryType : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.NewRegionCode != null ? (obj.NewRegionCode != "" ? obj.NewRegionCode : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.VisitSequence.ToString() != null ? (obj.VisitSequence.ToString() != "" ? obj.VisitSequence.ToString() : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.WeekDay != null ? (obj.WeekDay != "" ? obj.WeekDay : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.WeeklyFrequency != null ? (obj.WeeklyFrequency != "" ? obj.WeeklyFrequency : "N/A") + "\t" : "N/A" + "\t");
                strFileContents.Append(obj.Attribute2 != null ? (obj.Attribute2 != "" ? obj.Attribute2 : "N/A") + "\t" : "N/A" + "\t");

                strFileContents.Append("\n");
            }
            sw = System.IO.File.CreateText(strFileName);
            sw.Write(strFileContents.ToString());
            sw.Close();
        }


    }

    public IList<TrxHeader> GetCollectionSettlement_pendingforstampedinvoices_SearchAll(string SortExpression, int MaximumRows,
 int StartRowIndex, string SalemanCodes, string trxdate, string SessionUserCode, string SalesOrgCodes, string SettledStatus, string RouteCode, string DepotCode, string Supervisor, string StartDate, string EndDate)
    {
        IList<TrxHeader> objTrxHeaders = new List<TrxHeader>();
        TrxHeader objTrxHeader = null;

        DbParam[] param = new DbParam[13];
        DataTable dt;

        param[0] = new DbParam("@sortExpression", SortExpression, SqlDbType.VarChar);
        param[1] = new DbParam("@maximumRows", MaximumRows, SqlDbType.Int);
        param[2] = new DbParam("@startRowIndex", StartRowIndex, SqlDbType.Int);
        param[3] = new DbParam("@SalemanCodes", string.IsNullOrEmpty(SalemanCodes) ? "" : SalemanCodes, SqlDbType.VarChar);
        param[4] = new DbParam("@trxdate", trxdate, SqlDbType.VarChar);
        param[5] = new DbParam("@UserCode", SessionUserCode, SqlDbType.VarChar);
        param[6] = new DbParam("@SalesOrgCodes", string.IsNullOrEmpty(SalesOrgCodes) ? "" : SalesOrgCodes, SqlDbType.VarChar);
        param[7] = new DbParam("@SettledStatus", "1=1", SqlDbType.VarChar);
        param[8] = new DbParam("@RouteCode", RouteCode, SqlDbType.VarChar);
        param[9] = new DbParam("@DepotCode", DepotCode, SqlDbType.VarChar);
        param[10] = new DbParam("@Supervisor", Supervisor, SqlDbType.VarChar);
        param[11] = new DbParam("@StartDate", StartDate, SqlDbType.VarChar);
        param[12] = new DbParam("@EndDate", EndDate, SqlDbType.VarChar);

        dt = Db.GetDataTable("sp_tblTrxHeader_Pendingforstampedinvoices_SELALL_Search_V1", param);

        if (dt != null && dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                objTrxHeader = new TrxHeader();
                objTrxHeader.TrxCode = Db.ToString(row["TrxCode"]);
                objTrxHeader.ClientCode = Db.ToString(row["ClientCode"]);
                objTrxHeader.CustomerName = Db.ToString(row["CustomerName"]);
                objTrxHeader.UserCode = Db.ToString(row["UserCode"]);
                objTrxHeader.UserName = Db.ToString(row["UserName"]);
                objTrxHeader.TrxDate = Db.ToDateTime(row["TrxDate"]);
                objTrxHeader.OrgCode = Db.ToString(row["OrgCode"]);
                objTrxHeader.TotalAmount = Db.ToFloat(row["TotalAmount"]);
                objTrxHeader.DayCount = Db.ToInteger(row["DayCount"]);
                objTrxHeader.RouteCode = Db.ToString(row["RouteCode"]);
                objTrxHeader.SupervisorCode = Db.ToString(row["SupervisorCode"]);
                objTrxHeader.SupervisorName = Db.ToString(row["SupervisorName"]);
                objTrxHeader.ASMCode = Db.ToString(row["ASMCode"]);
                objTrxHeader.ASMName = Db.ToString(row["ASMName"]);
                if (row.Table.Columns.Contains("Sup_StampedDate"))
                {
                    objTrxHeader.Attribute1 = Db.ToString(row["Sup_StampedDate"]);
                }
                else
                {
                    objTrxHeader.Attribute1 = "N/A";
                }
                if (row.Table.Columns.Contains("Attribute2"))
                {
                    objTrxHeader.Attribute2 = Db.ToString(row["Attribute2"]);
                }
                else
                {
                    objTrxHeader.Attribute2 = "N/A";
                }
                objTrxHeaders.Add(objTrxHeader);

            }


        }
        return objTrxHeaders;
    }

    public IList<CustomerMovementNew> GetJourneyPlanbulkImport_Export(int HeaderId, string Searchstring)
    {
        IList<CustomerMovementNew> lstCustomerMovement = new List<CustomerMovementNew>();
        try
        {
            DbParam[] param = new DbParam[2];
            DataTable dt;

            param[0] = new DbParam("@HeaderId", HeaderId, SqlDbType.Int);
            param[1] = new DbParam("@Searchstring", Searchstring, SqlDbType.VarChar);

            dt = Db.GetDataTable("sp_tblCustomerJourneyPlanDetail_SELALL_Search", param);

            foreach (DataRow row in dt.Rows)
            {
                CustomerMovementNew objCustomerMovement = new CustomerMovementNew();
                if (row.Table.Columns.Contains("Id"))
                {
                    objCustomerMovement.Id = Db.ToInteger(row["Id"]);
                }
                if (row.Table.Columns.Contains("CustomerMovementHeaderId"))
                {
                    objCustomerMovement.CustomerMovementHeaderId = Db.ToInteger(row["CustomerMovementHeaderId"]);
                }
                if (row.Table.Columns.Contains("Attribute1"))
                {
                    objCustomerMovement.IsSameRegion = Db.ToInteger(row["Attribute1"]);
                }
                if (row.Table.Columns.Contains("Attribute2"))
                {
                    objCustomerMovement.Attribute2 = Db.ToString(row["Attribute2"]);
                }
                if (row.Table.Columns.Contains("RegionCode"))
                {
                    objCustomerMovement.RegionCode = Db.ToString(row["RegionCode"]);
                }
                if (row.Table.Columns.Contains("Classification"))
                {
                    objCustomerMovement.Classification = Db.ToString(row["Classification"]);
                }
                if (row.Table.Columns.Contains("OldRouteDeliveryType"))
                {
                    objCustomerMovement.OldRouteDeliveryType = Db.ToString(row["OldRouteDeliveryType"]);
                }
                if (row.Table.Columns.Contains("NewRouteDeliveryType"))
                {
                    objCustomerMovement.NewRouteDeliveryType = Db.ToString(row["NewRouteDeliveryType"]);
                }
                if (row.Table.Columns.Contains("NewRegionCode"))
                {
                    objCustomerMovement.NewRegionCode = Db.ToString(row["NewRegionCode"]);
                }
                if (row.Table.Columns.Contains("RegionName"))
                {
                    objCustomerMovement.RegionName = Db.ToString(row["RegionName"]);
                }
                if (row.Table.Columns.Contains("NewRegionName"))
                {
                    objCustomerMovement.NewRegionName = Db.ToString(row["NewRegionName"]);
                }
                if (row.Table.Columns.Contains("UserCode"))
                {
                    objCustomerMovement.UserCode = Db.ToString(row["UserCode"]);
                }
                if (row.Table.Columns.Contains("UserName"))
                {
                    objCustomerMovement.UserName = Db.ToString(row["UserName"]);
                }
                if (row.Table.Columns.Contains("SalesorgCode"))
                {
                    objCustomerMovement.SalesorgCode = Db.ToString(row["SalesorgCode"]);
                }
                if (row.Table.Columns.Contains("SalesorgName"))
                {
                    objCustomerMovement.SalesorgName = Db.ToString(row["SalesorgName"]);
                }
                if (row.Table.Columns.Contains("RouteCode"))
                {
                    objCustomerMovement.RouteCode = Db.ToString(row["RouteCode"]);
                }
                if (row.Table.Columns.Contains("RouteName"))
                {
                    objCustomerMovement.RouteName = Db.ToString(row["RouteName"]);
                }
                if (row.Table.Columns.Contains("CustomerCode"))
                {
                    objCustomerMovement.CustomerCode = Db.ToString(row["CustomerCode"]);
                }
                if (row.Table.Columns.Contains("CustomerName"))
                {
                    objCustomerMovement.CustomerName = Db.ToString(row["CustomerName"]);
                }
                if (row.Table.Columns.Contains("CustomerType"))
                {
                    objCustomerMovement.CustomerType = Db.ToString(row["CustomerType"]);
                }
                if (row.Table.Columns.Contains("Segment"))
                {
                    objCustomerMovement.CustomerSegment = Db.ToString(row["Segment"]);
                }
                if (row.Table.Columns.Contains("WeekDay"))
                {
                    objCustomerMovement.WeekDay = Db.ToString(row["WeekDay"]);
                }
                if (row.Table.Columns.Contains("Classification"))
                {
                    objCustomerMovement.Classification = Db.ToString(row["Classification"]);
                }
                if (row.Table.Columns.Contains("ImportedDate"))
                {
                    objCustomerMovement.ImportedDate = Db.ToDateTime(row["ImportedDate"]);
                }
                if (row.Table.Columns.Contains("CreatedOn"))
                {
                    objCustomerMovement.CreatedOn = Db.ToDateTime(row["CreatedOn"]);
                }
                if (row.Table.Columns.Contains("VisitFrequancy"))
                {
                    objCustomerMovement.WeeklyFrequency = Db.ToString(row["VisitFrequancy"]);
                }
                if (row.Table.Columns.Contains("VisitSequence"))
                {
                    objCustomerMovement.VisitSequence = Db.ToInteger(row["VisitSequence"]);
                }
                if (row.Table.Columns.Contains("NewRoute"))
                {
                    objCustomerMovement.NewRoute = Db.ToString(row["NewRoute"]);
                }
                if (row.Table.Columns.Contains("NewWeekDay1"))
                {
                    objCustomerMovement.NewWeekDay1 = Db.ToString(row["NewWeekDay1"]);
                }
                if (row.Table.Columns.Contains("NewWeekDay2"))
                {
                    objCustomerMovement.NewWeekDay2 = Db.ToString(row["NewWeekDay2"]);
                }
                lstCustomerMovement.Add(objCustomerMovement);
            }
        }
        catch (Exception ex)
        {
            //WINIT.ErrorLog.ErrorLogger.GetInstance().Log(ex, WINIT.ErrorLog.LogSeverity.Error);
        }
        return lstCustomerMovement;
    }

    public class CustomerMovementNew
    {
        public int Id { get; set; }
        public int CustomerMovementHeaderId { get; set; }
        public string UserCode { get; set; }
        public string UserName { get; set; }
        public string SalesorgCode { get; set; }
        public string SalesorgName { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string RouteCode { get; set; }
        public string RouteName { get; set; }
        public string CustomerType { get; set; }
        public string WeekDay { get; set; }
        public string CustomerSegment { get; set; }
        public string Classification { get; set; }
        public string WeeklyFrequency { get; set; }
        public int VisitSequence { get; set; }
        public int IsSameRegion { get; set; }

        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string NewRoute { get; set; }
        public string RegionCode { get; set; }
        public string RegionName { get; set; }
        public string NewRegionCode { get; set; }
        public string NewRegionName { get; set; }
        public string NewWeekDay1 { get; set; }
        public string NewWeekDay2 { get; set; }
        public string OldRouteDeliveryType { get; set; }
        public string NewRouteDeliveryType { get; set; }
        public string Attribute2 { get; set; }

        public string Attribute4 { get; set; }
        public string Attribute5 { get; set; }
        public string Attribute6 { get; set; }
        public string Attribute7 { get; set; }
        public string Attribute8 { get; set; }

        public DateTime ImportedDate { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime ModifiedOn { get; set; }

    }
    private void ExportJourneyPlanReportWeek(string strFileName)
    {
        System.IO.StreamWriter sw;
        try
        {
            StringBuilder strFileContents = new StringBuilder();
            string RouteCodes = CommonFunctions.getStringValue(Session["UCCommonFilter_Route"]);
            string SalesOrgCode = CommonFunctions.getStringValue(Session["UCCommonFilter_SalesOrganization"]);
            string RegionCodes = CommonFunctions.getStringValue(Session["UCCommonFilter_Region"]);
            string ASMCodes = CommonFunctions.getStringValue(Session["UCCommonFilter_ASM"]);
            string SupervisorCodes = CommonFunctions.getStringValue(Session["UCCommonFilter_Supervisor"]);
            string UserCode = SessionManager.UserCode;

            //DataSet ds = new JourneyPlanFacade().GetJourneyPlanReport(UserCode, RouteCode, 1);
            DataSet ds = null;
            if (RouteCodes != "" || SalesOrgCode != "" || ASMCodes != "" || RegionCodes != "" || SupervisorCodes != "")
            {
                ds = new JourneyPlanFacade().GetJourneyPlanReport(UserCode, RouteCodes, SalesOrgCode, ASMCodes, RegionCodes, SupervisorCodes, 1);
            }
            int count = 0, ColumnCount = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                strFileContents = new StringBuilder();

                foreach (DataColumn dc in ds.Tables[0].Columns)
                    strFileContents.Append(Db.ToString(dc.ColumnName) + "\t");
                ColumnCount++;
                strFileContents.Append("\n");
                int i = ds.Tables[0].Columns.Count;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow Row in ds.Tables[0].Rows)
                    {
                        while (count < i)
                        {
                            string DataValue = Row[count].ToString();
                            strFileContents.Append(DataValue == "" ? "" : DataValue);
                            strFileContents.Append("\t");
                            count++;
                        }
                        strFileContents.Append("\n");

                        count = 0;
                    }
                    strFileContents.Append("\n");
                    strFileContents.Append("/n");
                }

                sw = System.IO.File.CreateText(strFileName);
                sw.Write(strFileContents.ToString());
                sw.Close();
            }
        }
        catch (Exception ex)
        {
            CommonFunctions.LogError(ex, WINIT.ErrorLog.LogSeverity.Error);
        }

    }
    public class MTDSO_V1
    {
        public string JPDate { get; set; }
        public decimal NetSales { get; set; }
        public int InVoiceLessThan50 { get; set; }
        public int TotalNoofItem { get; set; }
        public string FirstInv { get; set; }
        public string LastInv { get; set; }
        public int ProductiveMin { get; set; }
        public decimal TargetValue { get; set; }
        public decimal ActualCall { get; set; }
        public decimal DailySalesVarPercent { get; set; }
        public decimal DailySalesVar { get; set; }
        public decimal Wastage { get; set; }
        public decimal MTDWastagePer { get; set; }
        public decimal MTDNetSales { get; set; }
        public decimal JourneyCount { get; set; }
        public string Category { get; set; }
        public string Type { get; set; }
        public string JP { get; set; }
        public string JPSeq { get; set; }
        public string Classification { get; set; }

        public int NoOfInvoices { get; set; }
        public decimal WastagePer { get; set; }
        public string Visit { get; set; }
        public string ValueSR { get; set; }
        public string VSO { get; set; }
        public string RedCall { get; set; }
        public string Time { get; set; }
        public string Overdue { get; set; }
        public string CollectedAMT { get; set; }
        public string Comments { get; set; }
        public string CheckInTime { get; set; }
        public string CheckOutTime { get; set; }
        public string RedColor { get; set; }
        public string TimeRedColor { get; set; }
    }

    public class SalesmansAcitvityReport
    {
        public int Precision { get; set; }
        public string ChannelCode { get; set; }
        public string ChannelName { get; set; }
        public string RegionCode { get; set; }
        public string RegionName { get; set; }
        public string RouteCode { get; set; }
        public string RouteName { get; set; }
        public string SalesOrgCode { get; set; }
        public string SalesOrgName { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string SalesmanCode { get; set; }
        public string SalesmanName { get; set; }
        public string AttendanceDate { get; set; }
        public string AttendanceDateNew { get; set; }
        public string EotDate { get; set; }
        public string EotStatus { get; set; }
        public string ImagePath { get; set; }
        public string CheckInTime { get; set; }
        public string CheckOutTime { get; set; }
        public string VisitDate { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }

        public string Duration { get; set; }
        public string Visited { get; set; }
        public string JourneyPlan { get; set; }
        public double OrderValue { get; set; }
        public double OrderVolume { get; set; }
        public double PerfectStore { get; set; }
        public double PerfectPoint { get; set; }
        public int MSLSold { get; set; }
        public int NPDSold { get; set; }

        public string Attribute1 { get; set; }
        public string Attribute2 { get; set; }
        public string Attribute3 { get; set; }
        public string Attribute4 { get; set; }
        public string Attribute5 { get; set; }
        public string Attribute6 { get; set; }
        public string Attribute7 { get; set; }
    }


}
namespace SFA.Export
{
    public class IntegrationFileGeneration
    {

        public string CheckingDate { get; set; }
        public string Depot { get; set; }
        public string RouteCode { get; set; }
        public string UserCode { get; set; }
        public string TripStartDate { get; set; }
        public string TripEndDate { get; set; }
        public string Supervisor { get; set; }
        public string LastEOTTime { get; set; }
        public string IVFile { get; set; }
        public string ARFile { get; set; }
        public string RSFile { get; set; }
        public string TripDateType { get; set; }
        public string PreviousEOT { get; set; }
        public string NextEOT { get; set; }
        public string Attribute4 { get; set; }
        public string Attribute5 { get; set; }
        public string RouteType { get; set; }

    }


   

}

